package com.desay.cd.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Configuration;

import de.codecentric.boot.admin.config.EnableAdminServer;

/**
 * 程序启动类
 * 
 * @author pengdengfu
 *
 */
@Configuration
@EnableAutoConfiguration
@EnableAdminServer
@EnableDiscoveryClient
public class PangooDataFactoryAdmin {

    public static void main(String[] args) {
        SpringApplication.run(PangooDataFactoryAdmin.class, args);
    }
}
