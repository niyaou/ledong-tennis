package com.desay.cd.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * 
 * @ClassName: PangooDataFactoryEurekaApplication
 * @author: pengdengfu
 * @date: 2019年2月28日 上午11:25:54
 */
@SpringBootApplication
@EnableEurekaServer
public class PangooDataFactoryEurekaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PangooDataFactoryEurekaApplication.class, args);
    }
}
