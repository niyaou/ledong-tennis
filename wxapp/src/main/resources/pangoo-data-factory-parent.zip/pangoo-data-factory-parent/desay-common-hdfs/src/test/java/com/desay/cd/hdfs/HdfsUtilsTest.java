package com.desay.cd.hdfs;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Test;

/**
 * 
 * @ClassName: HdfsUtilsTest
 * @author: pengdengfu
 * @date: 2019年3月7日 上午11:02:46
 */
public class HdfsUtilsTest {

    @Test
    public void mkdirTest() throws IOException {
        assertTrue(HdfsUtils.mkdir("/pangoo_data_fanctory/testFolder"));
        boolean existed = HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolder");
        assertTrue(existed);
        HdfsUtils.deleteFile("/pangoo_data_fanctory/testFolder", true);
        existed = HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolder");
        assertFalse(existed);
    }

    @Test
    public void uploadFileTest() throws Exception {
        InputStream inputStream = new FileInputStream(new File("D:\\hadoop-2.7.3.7z"));
        HdfsUtils.mkdir("/pangoo_data_fanctory/testFolder");
        HdfsUtils.uploadFileToHdfs(inputStream, "/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z");
        boolean existed = HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z");
        assertTrue(existed);
        HdfsUtils.deleteFile("/pangoo_data_fanctory", true);

    }

    @Test
    public void downloadFileTest() throws IOException {
        InputStream inputStream = new FileInputStream(new File("D:\\hadoop-2.7.3.7z"));
        HdfsUtils.mkdir("/pangoo_data_fanctory/testFolder");
        HdfsUtils.uploadFileToHdfs(inputStream, "/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z");

        InputStream downloadFileFromHdfs = HdfsUtils.downloadFileFromHdfs("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z");

        File localFile = new File("D:\\hadoop-2.7.3.7z.downloadTest");
        OutputStream outputStream = new FileOutputStream(new File("D:\\hadoop-2.7.3.7z.downloadTest"));
        IOUtils.copy(downloadFileFromHdfs, outputStream);
        HdfsUtils.deleteFile("/pangoo_data_fanctory", true);

        assertTrue(localFile.exists());

        localFile.deleteOnExit();
    }

    @Test
    public void copyFileTest() throws Exception {
        InputStream inputStream = new FileInputStream(new File("D:\\hadoop-2.7.3.7z"));
        HdfsUtils.mkdir("/pangoo_data_fanctory/testFolder");
        HdfsUtils.mkdir("/pangoo_data_fanctory/testFolderCopy");
        HdfsUtils.uploadFileToHdfs(inputStream, "/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z");

        HdfsUtils.copyHdfsFile("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z", "/pangoo_data_fanctory/testFolderCopy/hadoop-2.7.3.7z", false);
        assertTrue(HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z"));
        assertTrue(HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolderCopy/hadoop-2.7.3.7z"));

        HdfsUtils.copyHdfsFile("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z", "/pangoo_data_fanctory/testFolderCopy/hadoop-2.7.3.7z.2", true);
        assertFalse(HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z"));
        assertTrue(HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolderCopy/hadoop-2.7.3.7z.2"));

        HdfsUtils.moveFile("/pangoo_data_fanctory/testFolderCopy/hadoop-2.7.3.7z.2", "/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z");
        assertFalse(HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolderCopy/hadoop-2.7.3.7z.2"));
        assertTrue(HdfsUtils.checkFileExist("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z"));

        HdfsUtils.getHdfsFileLength("/pangoo_data_fanctory/testFolder/hadoop-2.7.3.7z");

        HdfsUtils.getALLFileStatus("/pangoo_data_fanctory");
        HdfsUtils.getALLFileStatus2("/pangoo_data_fanctory");

        HdfsUtils.deleteFile("/pangoo_data_fanctory", true);
    }

    @After
    public void destroy() {
        try {
            HdfsUtils.fsFileSystem.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
