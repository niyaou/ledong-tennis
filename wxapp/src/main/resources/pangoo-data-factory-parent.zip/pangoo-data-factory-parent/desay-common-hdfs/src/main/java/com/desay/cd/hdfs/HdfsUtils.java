package com.desay.cd.hdfs;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * HdfsUtils
 * 
 * @author pengdengfu
 *
 */
public class HdfsUtils {
    private static final Logger logger = LoggerFactory.getLogger(HdfsUtils.class);
    public static final Configuration CONFIG = new Configuration();
    public static FileSystem fsFileSystem;
    static {
        try {
            Properties properties = new Properties();
            properties.load(HdfsUtils.class.getClassLoader().getResourceAsStream("hdfs.propertites"));
            String nameservices = properties.getProperty("dfs.nameservices");
            String defaultFS = properties.getProperty("fs.defaultFS");
            String replication = properties.getProperty("dfs.replication", "3");

            CONFIG.set("fs.defaultFS", defaultFS);
            CONFIG.set("dfs.nameservices", nameservices);
            CONFIG.set("dfs.ha.namenodes." + nameservices, "nn1,nn2");
            CONFIG.set("dfs.namenode.rpc-address." + nameservices + ".nn1", properties.getProperty("dfs.namenode.rpc.address.ha.nn1"));
            CONFIG.set("dfs.namenode.rpc-address." + nameservices + ".nn2", properties.getProperty("dfs.namenode.rpc.address.ha.nn2"));
            CONFIG.set("dfs.client.failover.proxy.provider." + nameservices, "org.apache.hadoop.hdfs.server.namenode.ha.ConfiguredFailoverProxyProvider");

            CONFIG.set("dfs.replication", replication);
            CONFIG.setBoolean("dfs.support.append", true);
            CONFIG.set("dfs.client.block.write.replace-datanode-on-failure.policy", "NEVER");
            CONFIG.set("dfs.client.block.write.replace-datanode-on-failure.enable", "true");

            fsFileSystem = FileSystem.get(new URI(defaultFS), CONFIG, properties.getProperty("dfs.user"));
        } catch (IOException e) {
            if (logger.isErrorEnabled()) {
                logger.error("hdfs配置文件加载失败");
            }
            e.printStackTrace();
        } catch (Exception e) {
            if (logger.isErrorEnabled()) {
                logger.error("无法连接hdfs，请检查配置。");
            }
            e.printStackTrace();
        } finally {

        }
    }

    /**
     * 将本地文件上传到hdfs（覆盖已经存在的文件）
     * 
     * @param inputStream
     * @param hdfsFileName
     */
    public static boolean uploadFileToHdfs(InputStream inputStream, String hdfsFileName) {
        try {
            FSDataOutputStream outputStream = fsFileSystem.create(new Path(hdfsFileName), true);
            IOUtils.copyBytes(inputStream, outputStream, 4096, true);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeStream(inputStream);
        }
        return false;

    }

    /**
     * 创建文件输出流，用于写入数据
     * 
     * @param path
     * @return
     */
    public static OutputStream createFileStream(String path) {
        FSDataOutputStream outputStream = null;
        try {
            outputStream = fsFileSystem.create(new Path(path), true);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return outputStream;
    }

    /**
     * 从hdfs下载，返回文件流
     * 
     * @param hdfsFilename
     * @return
     */
    public static FSDataInputStream downloadFileFromHdfs(String hdfsFilename) {
        Path hdfsPath = new Path(hdfsFilename);
        FSDataInputStream fsDataInputStream = null;
        if (!directoryExist(hdfsFilename)) {
            return null;
        }
        try {
            fsDataInputStream = fsFileSystem.open(hdfsPath);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fsDataInputStream;
    }

    /**
     * 从hdfs下载，返回文件流
     * 
     * @param hdfsFilename
     * @param offset
     *            文件偏移的字节数
     * @return
     */
    public static FSDataInputStream downloadFileFromHdfs(String hdfsFilename, long offset) {
        Path hdfsPath = new Path(hdfsFilename);
        FSDataInputStream fsDataInputStream = null;
        try {
            fsDataInputStream = fsFileSystem.open(hdfsPath);
            fsDataInputStream.seek(offset);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fsDataInputStream;
    }

    /**
     * 在hdfs上创建目录。 会创建不存在的目录，相当于mkdir -p
     * 
     * @param path
     */
    public static boolean mkdir(String path) {

        URI i = fsFileSystem.getUri();
        Path p = new Path(i.toString() + path);
        try {
            logger.info("the path   " + i.toString() + path + " is exists or not :" + fsFileSystem.exists(p));
            if (fsFileSystem.exists(p)) {
                return true;
            }
            return fsFileSystem.mkdirs(new Path(i.toString() + path));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 在hdfs上查看指定目录是否存在。
     * 
     * @param path
     * @return
     */
    public static boolean directoryExist(String path) {
        Path p = new Path(path);
        try {
            return fsFileSystem.exists(p);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 移动文件或者文件夹
     * 
     * @param src
     *            初始路径
     * @param dst
     *            移动结束路径
     * @throws Exception
     */
    public static boolean moveFile(String src, String dst) {
        Path p1 = new Path(src);
        Path p2 = new Path(dst);
        try {
            return fsFileSystem.rename(p1, p2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 合并hdfs文件
     * 
     * @param folder
     * @param file
     */
    public static String mergeFile(String srcDir, String dstFile) {
        Path src = new Path(srcDir);
        Path dst = new Path(dstFile);
        String result = null;
        try {
            FileUtil.copyMerge(fsFileSystem, src, fsFileSystem, dst, true, CONFIG, null);
            logger.info("merge====done====");
            result = srcDir + dstFile;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;

    }

    /**
     * 合并文件
     * 
     * @param dirPath
     *            拆分文件所在目录名
     * @param partFileSuffix
     *            拆分文件后缀名
     * @param partFileSize
     *            拆分文件的字节数大小
     * @param mergeFileName
     *            合并后的文件名
     * @throws IOException
     */
    public static boolean mergePartFiles(String dirPath, String targetPath, String mergeFileName) throws IOException {
        Path src = new Path(dirPath);
        Path dst = new Path(targetPath + "/" + mergeFileName);
        return FileUtil.copyMerge(fsFileSystem, src, fsFileSystem, dst, true, CONFIG, null);
    }

    /**
     * 检查文件或者文件夹是否存在
     * 
     * @param filename
     * @return
     */
    public static boolean checkFileExist(String filename) {
        try {
            Path f = new Path(filename);
            return fsFileSystem.exists(f);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 复制hdfs文件到指定目录
     * 
     * @param srcfile
     *            复制的文件路径
     * @param desfile
     *            粘贴的路径
     * @param deleteSource
     *            是否删除原始文件
     * @return
     */
    public static boolean copyHdfsFile(String srcfile, String desfile, boolean deleteSource) {
        Path src = new Path(srcfile);
        Path dst = new Path(desfile);
        try {
            FileUtil.copy(fsFileSystem, src, fsFileSystem, dst, deleteSource, CONFIG);
        } catch (IOException e) {
            return false;
        }
        return true;
    }

    /**
     * 获取hdfs文件的文件大小
     * 
     * @param hdfsPath
     * @return
     */
    public static long getHdfsFileLength(String hdfsPath) {
        long fileLength = 0;
        try {
            FileStatus fileStatus = fsFileSystem.getFileStatus(new Path(hdfsPath));
            fileLength = fileStatus.getLen();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileLength;
    }

    /**
     * 删除hdfs 上已有的文件
     * 
     * @param fileName
     * @param recursive
     *            是否递归删除，如果针对目录有文件夹的情况，如果true，一起删除，否则抛出exception
     * @throws IOException
     */
    public static boolean deleteFile(String fileName, boolean recursive) throws IOException {
        Path path = new Path(fileName);
        try {
            if (!fsFileSystem.exists(path)) {
                logger.debug("给定路径：{}不存在", fileName);
                return false;
            } else {
                return fsFileSystem.delete(path, recursive);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /***
     * 查看hdfs某个文件的状态
     * 
     * @param fileName
     * @throws Exception
     */
    public static void getFileStatus(String fileName) throws Exception {
        Path path = new Path(fileName);
        fsFileSystem.listStatus(path);
    }

    /**
     * 给一个目录的路径，递归的列出该目录下面所有的文件的状态信息(不包括文件夹信息)方式1
     * 
     * @param fileName
     * @throws Exception
     */
    public static void getALLFileStatus(String fileName) throws Exception {
        Path path = new Path(fileName);
        FileStatus[] status = fsFileSystem.listStatus(path);
        for (FileStatus fileStatus : status) {
            if (fileStatus.isDirectory()) {
                getALLFileStatus(fileStatus.getPath().toString());
            } else {
            }
        }
    }

    /**
     * 给一个目录的路径，递归的列出该目录下面所有的文件的状态信息(不包括文件夹信息)方式2
     * 
     * @param fileName
     * @throws Exception
     */
    public static void getALLFileStatus2(String fileName) throws Exception {

        Path path = new Path(fileName);
        if (fsFileSystem.isDirectory(path)) {
            FileStatus[] status = fsFileSystem.listStatus(path);
            for (FileStatus fileStatus : status) {
                getALLFileStatus2(fileStatus.getPath().toString());
            }
        } else {
            fsFileSystem.getFileLinkStatus(path);
        }
    }

    /**
     * 获取指定目录下特定文件后缀名的文件列表(不包括子文件夹)
     * 
     * @param dirPath
     *            目录路径
     * @param suffix
     *            文件后缀
     * @return
     */
    public static ArrayList<File> getDirFiles(String dirPath, final String suffix) {
        File path = new File(dirPath);
        File[] fileArr = path.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                String lowerName = name.toLowerCase();
                String lowerSuffix = suffix.toLowerCase();
                if (lowerName.endsWith(lowerSuffix)) {
                    return true;
                }
                return false;
            }

        });
        ArrayList<File> files = new ArrayList<File>();

        for (File f : fileArr) {
            if (f.isFile()) {
                files.add(f);
            }
        }
        return files;
    }

    /**
     * 根据文件名，比较文件
     * 
     * @author yjmyzz@126.com
     *
     */
    @SuppressWarnings("unused")
    private static class FileComparator implements Comparator<File> {
        public int compare(File o1, File o2) {
            String[] oo1 = o1.getName().split("\\.");
            String[] oo2 = o2.getName().split("\\.");
            return Integer.valueOf(oo1[oo1.length - 2]).compareTo(Integer.valueOf(oo2[oo2.length - 2]));
        }
    }

}
