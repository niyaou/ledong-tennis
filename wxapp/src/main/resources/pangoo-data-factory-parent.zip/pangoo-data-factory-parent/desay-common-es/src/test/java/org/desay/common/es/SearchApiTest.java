package org.desay.common.es;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;

import org.desay.common.es.search.SearchApi;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.search.sort.SortOrder;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.alibaba.fastjson.JSONObject;


/**
 * Unit test for simple App.
 * @author uidq1343
 */
public class SearchApiTest 
{

    @BeforeClass
    public static void prepared() {
            URL uri = SearchApiTest.class.getResource("/");
            File f = new File(uri.getPath()+"es.properties");
            FileOutputStream fos=null;
            try {
                if(!f.exists()){
                    f.createNewFile();
                }
                 fos=new FileOutputStream(f);
                String content="es.node=desay.brace1.com,desay.brace2.com,desay.brace3.com\r\n" + 
                        "es.port=9200\r\n" + 
                        "es.timeout=30";
                fos.write(content.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }finally{
                if(fos!=null){
                    try {
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
    }

    @Test
    public void insert() {
        JSONObject doc=new JSONObject();
        doc.put("city","test");
        doc.put("name","test");
        Result result=    SearchApi.insertDocument("pangoo_platform.test", SearchApi.TYPE, doc.toJSONString()).getResult();
        assertEquals(Result.CREATED.toString(),result.name());
        doc.put("name","test1");
        result = SearchApi.updateDocument("pangoo_platform.test", SearchApi.TYPE, doc.toJSONString(), "1").getResult();
        assertEquals(Result.UPDATED.toString(),result.name());
        result =SearchApi.deleteDocument("pangoo_platform.test", SearchApi.TYPE,  "1").getResult();
        assertEquals(Result.DELETED.toString(),result.name());
    }
    
    @AfterClass
    public static void stop() {
        URL uri = SearchApiTest.class.getResource("/");
        File f = new File(uri.getPath()+"es.properties");
        if(f.exists()) {
            f.delete();
        }
        EsClientFactory.getInstance().close();
    }
    
    @Test
    public void test1() {
        LinkedList<HashMap<String, Object>> result=    SearchApi.searchByFieldSorted("pangoo_das.file_information", "status", "1","createTime", SortOrder.DESC, 0, 100);
        assertNotNull(result);
    }
    
    @Test
    public void test2() {
//        SearchResponse result=    SearchApi.fileStatiscByParams("pangoo_das.file_information", null);
//
//      
//
//        ParsedSum b=result.getAggregations().get("query_fileSize");
//      JSONObject a= JSONObject.parseObject(JSON.toJSONString(result.getAggregations().getAsMap().get("query_fileSize")));
//      System.out.println(result.getAggregations().get("query_fileSize").getClass());
//      System.out.println(b.getValue());
//      System.out.println(b.getValueAsString());
//      System.out.println(result.getHits().totalHits);
//      System.out.println(a.get("value"));
//        System.out.println(JSON.toJSONString(result.getAggregations().getAsMap()));
//        assertNotNull(result);
        

    }
    
}
