package com.desay.cd.factory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Properties;

import org.desay.common.es.search.SearchApi;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.ElasticsearchStatusException;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.service.IFileIformationService;
import com.desay.cd.factory.service.IndexConstant;
import com.desay.cd.factory.service.impl.FileIformationServiceImpl;
import com.desay.cd.factory.utils.DateUtil;

/**
 * 标注信息测试类
 * 
 * @author uidq1343
 *
 */

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class FileInformationServiceTest {

    @SuppressWarnings("unused")
    private MockMvc mvc;
    private String id = "nxc_test";
    private String taskId = "nxc_test_task";
    private String taskName = "nxc_test_name";
    private String deviceId = "nxc_test_device";
    private String deviceName = "nxc_test_devicename";
    private int taskSeq = 1;
    private String groupId = "nxc_test_group";
    JSONObject doc = new JSONObject();

    @Autowired
    protected WebApplicationContext wac;

    @Autowired
    IFileIformationService fileService;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        Properties properties = new Properties();
        // // 获取配置信息
        try {
            properties.load(ClassLoader.getSystemResourceAsStream("application-dev.properties"));
            properties.put("pangoo-data-factory.intercepter", false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void queryByDeviceId() {
        clearDatabases();
        doc.put(IndexConstant.CREATETIME, "2019-10-10");
        doc.put(IndexConstant.DEVICEID, deviceId);
        SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                doc.toJSONString(), id);
        sleep(2100);
        Object a = fileService.queryFileInfoByDeviceId(deviceId, null, true, null, null);
        assertNotNull(a);
        Page<HashMap<String, Object>> result = (Page<HashMap<String, Object>>) a;
        assertEquals(result.getTotalElements(), 1);
        clearDatabases();
    }

    @Test
    public void updateTaskInformation() {
        clearDatabases();
        long version = 2;
        String message = null;

        try {
            fileService.updateTaskInformation(id, taskId, taskName, taskSeq, groupId, version);
        } catch (ElasticsearchException e) {
            message = e.getMessage();
        }
        assertEquals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage(), message);
        doc.put(FileIformationServiceImpl.CREATETIME, "2019-10-10");

        SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                doc.toJSONString(), id);
        sleep(1800);
        LinkedList<HashMap<String, Object>> v = SearchApi.searchByFieldAndType(IndexConstant.FILE_INFORMATION_INDEX,
                IndexConstant.PANGOO_DLS_TYPE, IndexConstant.ID, id, null, null);
        version = (long) v.get(0).get(IndexConstant.VERSION);

        try {
            fileService.updateTaskInformation(id, taskId, taskName, taskSeq, groupId, 1);
        } catch (ElasticsearchStatusException e) {
            message = ResultCodeEnum.OTHER_USER_UPDATED.getMessage();
        }
        assertEquals(ResultCodeEnum.OTHER_USER_UPDATED.getMessage(), message);

        message = ((Result) fileService.updateTaskInformation(id, taskId, taskName, taskSeq, groupId, version))
                .toString();
        assertEquals(Result.UPDATED.toString(), message);
        clearDatabases();
    }

    @Test
    public void updateAuditInformation() {
        clearDatabases();
        long version = 2;
        String message = null;
        try {
            fileService.updateAuditInformation(taskId, id, true, "", "", version);
        } catch (ElasticsearchException e) {
            message = e.getMessage();
        }
        assertEquals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage(), message);
        doc.put(FileIformationServiceImpl.CREATETIME, "2019-10-10");

        SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                doc.toJSONString(), id);
        sleep(1800);
        LinkedList<HashMap<String, Object>> v = SearchApi.searchByFieldAndType(IndexConstant.FILE_INFORMATION_INDEX,
                IndexConstant.PANGOO_DLS_TYPE, IndexConstant.ID, id, null, null);
        version = (long) v.get(0).get(IndexConstant.VERSION);

        try {
            fileService.updateAuditInformation(taskId, id, true, "", "", 1);
        } catch (ElasticsearchStatusException e) {
            message = ResultCodeEnum.OTHER_USER_UPDATED.getMessage();
        }
        assertEquals(ResultCodeEnum.OTHER_USER_UPDATED.getMessage(), message);

        message = ((Result) fileService.updateAuditInformation(taskId, id, true, "", "", version)).toString();
        assertEquals(Result.UPDATED.toString(), message);
        clearDatabases();
    }

    @Test
    public void updateLabelInformation() throws IOException {
        clearDatabases();
        long version = 2;
        String message = null;
        JSONObject info = new JSONObject();

        try {
            fileService.updateLabelInformation(taskId, id, info, info, info, "", version);
        } catch (ElasticsearchException e) {
            message = e.getMessage();
        }
        assertEquals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage(), message);
        doc.put(IndexConstant.CREATETIME, DateUtil.getCurrentDateTime());
        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);

        SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                doc.toJSONString(), id);
        sleep(1800);
        LinkedList<HashMap<String, Object>> v = SearchApi.searchByFieldAndType(IndexConstant.FILE_INFORMATION_INDEX,
                IndexConstant.PANGOO_DLS_TYPE, IndexConstant.ID, id, null, null);
        version = (long) v.get(0).get(IndexConstant.VERSION);

        try {
            fileService.updateLabelInformation(taskId, id, info, info, info, "", 1);
        } catch (ElasticsearchStatusException e) {
            message = ResultCodeEnum.OTHER_USER_UPDATED.getMessage();
        }
        assertEquals(ResultCodeEnum.OTHER_USER_UPDATED.getMessage(), message);

        message = ((Result) fileService.updateLabelInformation(taskId, id, info, info, info, id, version)).toString();
        assertEquals(Result.UPDATED.toString(), message);

        BulkByScrollResponse s = SearchApi.deleteDocumentBySearchField(IndexConstant.FILE_LABEL_LOG_INDEX,
                IndexConstant.TYPE, IndexConstant.LABELER, id);
        assertEquals(s.getBulkFailures().size(), 0);
        clearDatabases();
    }

    @Test
    public void labelingLog() throws IOException {
        SearchApi.deleteDocumentBySearchField(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE,
                IndexConstant.LABELER, id);
        sleep(1600);
        String logId = (String) fileService.labelingLog(taskId, "taskName", deviceId, deviceName, id, "0", doc, id, "");
        assertNotNull(logId);
        SearchApi.deleteDocument(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE, logId);
    }

    @Test
    public void getLabelInformation() {
        clearDatabases();
        String message = null;
        try {
            fileService.getLabelInformation(id);
        } catch (ElasticsearchException e) {
            message = e.getMessage();
        }
        assertEquals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage(), message);
        doc.put(IndexConstant.CREATETIME, "2019-10-10");

        SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                doc.toJSONString(), id);
        sleep(1800);
        assertNotNull(fileService.getLabelInformation(id));
        clearDatabases();
    }

    /**
     * 等待时间
     * 
     * @param timeout
     */
    private void sleep(int timeout) {
        try {
            Thread.sleep(timeout);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 清除测试数据
     */
    private void clearDatabases() {
        try {
            SearchApi.deleteDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE, id);
            sleep(1600);
        } catch (Exception e) {
        }
    }
}
