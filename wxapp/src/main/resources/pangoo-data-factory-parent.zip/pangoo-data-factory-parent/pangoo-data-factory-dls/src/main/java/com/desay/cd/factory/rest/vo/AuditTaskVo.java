package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: ClearAlgorithmVo
 * @author: nixuchun
 */
//@Data
public class AuditTaskVo implements Serializable {

    private static final long serialVersionUID = -820211110052857928L;

    @NotEmpty
    @ApiModelProperty(value = "审核人ID")
    private String userId;

    @NotNull
    @ApiModelProperty(value = "审核状态 true: 通过， false:未通过")
    private Boolean passed;

    @ApiModelProperty(value = "备注信息")
    private String message;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Boolean getPassed() {
        return passed;
    }

    public void setPassed(Boolean passed) {
        this.passed = passed;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
