package com.desay.cd.factory.utils;

/**
 * 常量
 * 
 * @author uidq1343
 *
 */
public class Constant {

    public final static String SPLITCOMMA = ",";
    public final static String SPLITPOINT = ".";
    public final static String SPLITSLASH = "/";
}
