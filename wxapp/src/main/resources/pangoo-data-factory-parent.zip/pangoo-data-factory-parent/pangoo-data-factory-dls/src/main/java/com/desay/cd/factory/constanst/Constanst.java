package com.desay.cd.factory.constanst;

/**
 * 常量类
 * 
 * @author pengdengfu
 *
 */
public interface Constanst {
    /** 删除子系统或者删除用户需要发送消息的topic */
    public static final String DELETE_SYS_USER_TOPIC = "deletedSubsystemUserTopic";
    public static final String DELETE_SYS_USER_LOCK = "deletedSubsystemUserLock";
    /** 删除用户需要发送消息的topic */
    public static final String DELETE_USER_TOPIC = "deletedUserTopic";
    public static final String DELETE_USER_LOCK = "deletedUserLock";
    /** DLS子系统ID */
    public static final String PANGOO_DLS_SUBSYS_ID = "8a5982646ad8a9f1016ad8fb81900010";
}
