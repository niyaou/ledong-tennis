package com.desay.cd.factory.service;

import java.util.ArrayList;

import org.elasticsearch.ElasticsearchException;

/**
 * 文件标注信息
 * 
 * @author uidq1343
 *
 */

public interface IFileIformationService extends IndexConstant {

    /**
     * * 根据设备id查找文件信息
     * 
     * @param deviceName
     * @param sortProperties
     * @param flag true:返回所有文档信息， false:返回未分配标注任务的文件信息
     * @param pageNo
     * @param size
     * @return
     */
    Object queryFileInfoByDeviceId(String deviceName, ArrayList<String> sortProperties, boolean flag, Integer pageNo,
            Integer size);

    /**
     * * 更新文件标注任务信息
     * 
     * @param fileId
     * @param taskId
     * @param taskName
     * @param taskSeq
     * @param groupId
     * @param version
     * @return
     * @throws ElasticsearchException
     */
    Object updateTaskInformation(String fileId, String taskId, String taskName, int taskSeq, String groupId,
            long version) throws ElasticsearchException;

    /**
     * * 审核单个标注文件
     * 
     * @param taskId
     * @param fileId
     * @param auditStatus
     * @param auditMessage
     * @param auditor
     * @param version
     * @return
     * @throws ElasticsearchException
     */
    Object updateAuditInformation(String taskId, String fileId, boolean auditStatus, String auditMessage,
            String auditor, long version) throws ElasticsearchException;

    /**
     * * 更新文件标注信息
     * 
     * @param taskId
     * @param fileId
     * @param infos
     * @param tags
     * @param labels
     * @param labeler
     * @param version
     * @return
     * @throws ElasticsearchException
     */
    Object updateLabelInformation(String taskId, String fileId, Object infos, Object tags, Object labels,
            String labeler, long version) throws ElasticsearchException;

    /**
     * 文件标注日志写入
     * 
     * @param taskId
     * @param taskName
     * @param deviceId
     * @param deviceName
     * @param imageId
     * @param taskSeq
     * @param labels
     * @param labeler
     * @param result
     * @return
     */
    Object labelingLog(String taskId, String taskName, String deviceId, String deviceName, String imageId,
            String taskSeq, Object labels, String labeler, String result);

    /**
     * * 获取文件的标注信息
     * 
     * @param fileId
     * @return
     * @throws ElasticsearchException
     */
    Object getLabelInformation(String fileId) throws ElasticsearchException;
}
