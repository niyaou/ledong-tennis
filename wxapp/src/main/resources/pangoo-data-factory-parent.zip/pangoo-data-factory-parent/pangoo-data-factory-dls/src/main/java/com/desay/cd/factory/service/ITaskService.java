package com.desay.cd.factory.service;

import java.util.List;

import org.elasticsearch.ElasticsearchException;

import com.alibaba.fastjson.JSONObject;

/**
 * 分配任务接口
 * 
 * @author uidq1343
 *
 */

public interface ITaskService extends IndexConstant {

    /**
     ** 创建分派任务接口
     * 
     * @param taskName
     * @param groupId
     * @param abilityId
     * @param abilityName
     * @param deviceId
     * @param deviceName
     * @param taskLoad
     * @return
     */
    String createTaskInformation(String taskName, String groupId, String abilityId, String abilityName, String deviceId,
            String deviceName, Integer taskLoad);

    /**
     * 任务分配日志记录接口
     * 
     * @param taskId
     * @param taskName
     * @param deviceId
     * @param deviceName
     * @param abilityName
     * @param taskLoad
     * @param assignedTime
     * @return
     */
    String assignTaskLog(String taskId, String taskName, String deviceId, String deviceName, String abilityName,
            Integer taskLoad, String assignedTime);

    /**
     * 分配标注任务
     * 
     * @param task
     * @param abilityName
     * @return
     */
    String assignTask(JSONObject task, String abilityName);

    /**
     * 标注任务领取 提交 审核日志创建
     * 
     * @param taskId
     * @param taskName
     * @param taskLoad
     * @param groupId
     * @param groupName
     * @param deviceId
     * @param deviceName
     * @param userId
     * @param abilityName
     * @param status
     * @return
     */
    String submitedTaskLog(String taskId, String taskName, Integer taskLoad, String groupId, String groupName,
            String deviceId, String deviceName, String userId, String abilityName, Integer status);

    /**
     ** 任务分派统计
     * 
     * @param deviceName
     * @param startTime
     * @param endTime
     * @param sortProperties
     * @param pageNo
     * @param size
     * @return
     */
    Object exploreAssignTaskByTimeRange(String startTime, String endTime, String deviceName, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer size);

    /**
     * * 提交标注任务状态信息
     * 
     * @param taskId
     * @param status 0:分配；1：领取；2：提交, 3：审核通过，4：审核未通过
     * @param userId * 操作人id
     * @param version
     * @param version
     * @return
     * @throws ElasticsearchException
     */
    Object updateTaskStatusInformation(String taskId, String userId, Integer status, String message)
            throws ElasticsearchException;

    /**
     * 向任务添加组信息
     * 
     * @param taskId
     * @param group
     * @return
     * @throws ElasticsearchException
     */
    Object updateTaskGroupInformation(String taskId, String... group) throws ElasticsearchException;

    /**
     * *根据清洗策略对每个任务分配标注能力
     * 
     * @return
     * @throws ElasticsearchException
     */
    Object updateTaskAbilityInformation() throws ElasticsearchException;

    /**
     * * 获取标注任务详细信息
     * 
     * @param taskId
     * @param sortProperties
     * @param pageNo
     * @param size
     * @return
     */
    Object exploreAssignTaskByTaskId(String taskId, List<String> sortProperties, Integer pageNo, Integer size);

    /**
     * * 标注/审核概览
     * 
     * @param startTime
     * @param endTime
     * @return
     */
    Object labelTaskStatistics(String startTime, String endTime);

    /**
     ** 每个人的标注任务统计
     * 
     * @param startTime
     * @param endTime
     * @param type 1：个人；2：组；3：标注能力
     * @return
     */
    Object personalLabelTaskStatistics(String startTime, String endTime, int type);

    /**
     ** 统计指定用户时间段范围内每一天的标注审核概览
     * 
     * @param user
     * @param startTime
     * @param endTime
     * @param sortProperties
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object personalDailyStatistics(String user, String startTime, String endTime, String sortProperties, Integer pageNo,
            Integer pageSize);

    /**
     * *查询指定用户时间段范围内标注的文件信息
     * 
     * @param labeler
     * @param startTime
     * @param endTime
     * @param isExact
     * @param sortProperties
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object exploreLabelLogs(String labeler, String startTime, String endTime, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer pageSize);

    /**
     * *查询指定用户时间段范围内审核的任务信息
     * 
     * @param startTime
     * @param endTime
     * @param auditor
     * @param status
     * @param status
     * @param sortProperties
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object exploreAuditlLogs(String startTime, String endTime, String auditor, Integer status, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer pageSize);

    /**
     * *查询用户名下的标注任务
     * 
     * @param taskName
     * @param groupId
     * @param userId
     * @param status
     * @param sortProperties
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object explorePersonalTask(String taskName, String groupId, String userId, Integer status,
            List<String> sortProperties, Integer pageNo, Integer pageSize);

    /**
     * *向任务池填充标注任务
     * 
     * @return
     */
    Object teemTaskPool();

    /**
     * 领取任务
     * 
     * @param userId
     * @return
     */
    Object acquiredTask(String userId);

    /**
     * 查询任务领取日志记录接口
     * 
     * @param labeler
     * @param startTime
     * @param endTime
     * @param isExact
     * @param sortProperties
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object exploreAcquiredTaskLog(String labeler, String startTime, String endTime, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer pageSize);

    /**
     * 撤回指定用户的所有未审核通过任务任务
     * 
     * @param userId
     * @return
     */
    Object retreatedTasks(String userId);

}
