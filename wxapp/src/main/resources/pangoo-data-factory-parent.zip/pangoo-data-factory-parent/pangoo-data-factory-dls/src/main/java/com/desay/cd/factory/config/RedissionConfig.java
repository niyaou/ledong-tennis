package com.desay.cd.factory.config;

import java.io.IOException;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author uidq1070
 *
 */
@Configuration
@ConfigurationProperties(prefix = "spring.redis.cluster")
public class RedissionConfig {
    private String[] nodes;

    public String[] getNodes() {
        return nodes;
    }

    public void setNodes(String[] nodes) {
        this.nodes = nodes;
    }

    @Bean(destroyMethod = "shutdown", name = "reddission")
    RedissonClient redisson() throws IOException {
        Config config = new Config();
        config.useClusterServers().addNodeAddress(nodes);
        // config.useSingleServer().setAddress("redis://127.0.0.1:6379");
        return Redisson.create(config);
    }
}