package com.desay.cd.factory.rest;

import org.elasticsearch.ElasticsearchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.service.ITaskService;
import com.desay.cd.factory.utils.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author uidq1343
 *
 */
@RestController
@Api(value = "系统概览", tags = "系统概览")
public class SystemExploreController {

    @Autowired
    private ITaskService taskService;

    @ApiOperation(value = "系统概览-标注审核概览 ", notes = "")
    @RequestMapping(value = "/label/statistics/overview", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = true, dataType = "string", paramType = "query") })
    public Object labelTaskStatiscs(@RequestParam(value = "startTime", required = true) String startTime,
            @RequestParam(value = "endTime", required = true) String endTime) {
        try {
            return new ResponseEntity<Object>(
                    CommonResponse.success(taskService.labelTaskStatistics(startTime, endTime)), HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getCode().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "系统概览-标注统计 ", notes = "")
    @RequestMapping(value = "/label/statistics/detail", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "type", value = "统计类型  1：个人；2：组；3：标注能力", required = true, dataType = "int", paramType = "query") })
    public Object personalLabelTaskStatiscs(@RequestParam(value = "startTime", required = true) String startTime,
            @RequestParam(value = "endTime", required = true) String endTime,
            @RequestParam(value = "type", required = true) int type) {
        try {
            return new ResponseEntity<Object>(
                    CommonResponse.success(taskService.personalLabelTaskStatistics(startTime, endTime, type)),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getCode().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "系统概览-个人明细,个人明细（每天的统计数据） ", notes = "")
    @RequestMapping(value = "/label/statistics/detail/{userId}", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "用户id", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sort", value = "时间排序,asc 升序  ，desc 降序，默认为升序", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页条数", required = false, dataType = "int", paramType = "query")

    })
    public Object personalDailyLabelTaskStatiscs(@PathVariable(value = "userId", required = true) String userId,
            @RequestParam(value = "startTime", required = true) String startTime,
            @RequestParam(value = "endTime", required = true) String endTime,
            @RequestParam(value = "sort", required = true) String sort,
            @RequestParam(value = "pageNo", required = false) Integer pageNo,
            @RequestParam(value = "pageSize", required = false) Integer pageSize) {
        try {
            return new ResponseEntity<Object>(CommonResponse.success(taskService.personalDailyStatistics(
                    StringUtil.escapeQueryChars(userId), startTime, endTime, sort, pageNo, pageSize)), HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getCode().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

}
