package com.desay.cd.factory.feign;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.Request;
import feign.Retryer;

/**
 * 
 * @author uidq1163
 *
 */
@Configuration
public class FeignConfiguration {
    /** 连接超时时间 */
    public static final int CONNECTTIMEOUTMILLIS = 12000;
    /** 数据读取超时时间 */
    public static final int READTIMEOUTMILLIS = 12000;

    @Bean
    public Request.Options options() {
        return new Request.Options(CONNECTTIMEOUTMILLIS, READTIMEOUTMILLIS);
    }

    @Bean
    public Retryer feignRetryer() {
        return new Retryer.Default(100, 1000, 4);
    }
}