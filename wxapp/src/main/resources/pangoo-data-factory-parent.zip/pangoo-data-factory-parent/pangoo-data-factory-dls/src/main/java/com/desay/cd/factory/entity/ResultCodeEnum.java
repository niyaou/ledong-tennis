package com.desay.cd.factory.entity;

/**
 * 响应码
 * 
 * @author pengdengfu
 *
 */
public enum ResultCodeEnum {

    /** 成功状态码 */
    SUCCESS(0, "成功"),

    /** 文件审核参数错误 */
    FILE_INFORMATION_NOT_FOUND(10001, "标注文件未找到 "),

    FILE_INFORMATION_UPDATE_FAILDED(10002, "标注文件更新失败 "), FILE_TASKINFO_UPDATE_LOCKED(10003, "标注文件正在更新，请重试 "),
    FILE_LABEL_INFORMATION_ERROR(10004, "标注信息格式错误 "),

    TASK_INFORMATION_NOT_FOUND(20001, "标注任务未找到 "), TASK_EMPTY(20003, "暂无标注任务领取 "),
    TASK_ACQUIRED_FAILED(20004, "标注任务领取失败 "),

    /** 文件审核参数错误 */
    AUDIT_STATUS_PARSE_ERROR(50034, "文件正在审核，请重试 "),

    /** 文件审核参数错误 */
    TASK_STATUS_PARSE_ERROR(50035, "文件正在审核，请重试 "),

    /** 数据更新错误：80001-89999 */
    /** 数据已经被其他用户更新,请刷新重试 */
    OTHER_USER_UPDATED(80001, "数据已经被其他用户更新,请刷新重试"),

    /** 未知错误 */
    UNKOWN_ERROR(90001, "未知错误");

    private Integer code;

    private String message;

    ResultCodeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }

    public static String getMessage(String name) {
        for (ResultCodeEnum item : ResultCodeEnum.values()) {
            if (item.name().equals(name)) {
                return item.message;
            }
        }
        return name;
    }

    public static Integer getCode(String name) {
        for (ResultCodeEnum item : ResultCodeEnum.values()) {
            if (item.name().equals(name)) {
                return item.code;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return this.name();
    }
}
