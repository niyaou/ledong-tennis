import os
import urllib3
import threading
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import random
import datetime
from prettyprinter import cpprint



def createName():
    return ''.join(random.sample(['z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h','g','f','e','d','c','b','a'], 8))

def createTime(date=datetime.datetime.now().strftime('%Y-%m-%d'),delta=0):
     time = datetime.datetime.strptime(date,'%Y-%m-%d')
     date=time+datetime.timedelta(days=delta)
     return date.strftime('%Y-%m-%d')
     
def timeFormat():
    assignedTime =  createTime(delta=1)
    acquiredTime = createTime(assignedTime,random.randint(0,2))
    submitTime = createTime(acquiredTime,random.randint(0,2)) 
    auditTime = createTime(submitTime,random.randint(0,2)) 
    cpprint("  assignedTime %s" %assignedTime)
    cpprint("  acquiredTime %s" %acquiredTime)
    cpprint("  submitTime %s" %submitTime)
    cpprint("  auditTime %s" %auditTime)




def createData(count=1):
    result=[]
    user = ['uidq1111','uidq2222','uidq3333','uidq4444','uidq5555','uidq6666','uidq7777','uidq8888','uidq9999']
    user=random.sample(user,2)
    random.seed()
    group=createName()
    ability=createName()
    label=user[0]
    auditor=user[1]
    for type in range(5):
       delta=random.randint(-4,4)
       assignedTime =  createTime(delta=delta)
       acquiredTime = createTime(assignedTime,random.randint(0,2)) if type>0  else None
       random.seed()
       submitTime = createTime(acquiredTime,random.randint(0,3)) if type>1  else None
       random.seed()
       auditTime = createTime(submitTime,random.randint(0,2)) if type>2  else None
       random.seed()
       for i in range(count):
           body={'_index':'pangoo_dls_task_information',
           '_type':'_doc',
           '_source': {
           "status": type,
           "groupName":group,
           "abilityName":ability,
           "labeler":label,
           "auditor":auditor,
           "assignedTime":assignedTime,
           "acquiredTime":  acquiredTime,
           "submitTime": submitTime,
           "auditTime":auditTime
                   }
            }
           result.append(body)
    return result 

es = Elasticsearch(  ['10.219.14.51'],  port=9200)

def createUser(times=1):
     for time in range(times):
         actions = createData(count=10)
         for ok,response in helpers.streaming_bulk(es,actions):
               if not ok:
                   cpprint(response)



createUser(10)
