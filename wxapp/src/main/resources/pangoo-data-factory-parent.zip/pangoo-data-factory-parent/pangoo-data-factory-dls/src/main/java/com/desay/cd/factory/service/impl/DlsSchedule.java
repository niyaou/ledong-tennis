package com.desay.cd.factory.service.impl;

import java.util.concurrent.TimeUnit;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.desay.cd.factory.service.ITaskService;

/**
 * 
 * @author uidq1343
 *
 */
@Component
@EnableAsync
public class DlsSchedule {

    @Autowired
    private RedissonClient redissonClient;

    @Autowired
    ITaskService taskService;

    @Scheduled(cron = "0 0/5 * * * ?")
    @Async
    public void assignTask() throws InterruptedException {
        RLock dataLock = redissonClient.getLock("dlc_assignTask");
        // 尝试加锁，最多等待1秒(说明已经有其他节点在运行)，上锁以后60秒自动解锁
        boolean res = false;
        try {
            res = dataLock.tryLock(0, -1, TimeUnit.SECONDS);
            if (res) {
                taskService.updateTaskAbilityInformation();
            }

        } finally {
            if (res) {
                dataLock.unlock();
            }

        }
    }

    @Scheduled(cron = "0 0/6 * * * ?")
    @Async
    public void teemTaskPool() throws InterruptedException {
        RLock dataLock = redissonClient.getLock("dlc_teemTaskPool");
        // 尝试加锁，最多等待1秒(说明已经有其他节点在运行)，上锁以后60秒自动解锁
        boolean res = false;
        try {
            res = dataLock.tryLock(0, -1, TimeUnit.SECONDS);
            if (res) {
                taskService.teemTaskPool();
            }

        } finally {
            if (res) {
                dataLock.unlock();
            }

        }
    }

}
