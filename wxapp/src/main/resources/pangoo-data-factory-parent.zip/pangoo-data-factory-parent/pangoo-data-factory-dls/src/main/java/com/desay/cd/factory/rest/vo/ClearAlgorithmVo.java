package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: ClearAlgorithmVo
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:37:13
 */
@Data
public class ClearAlgorithmVo implements Serializable {
    private static final long serialVersionUID = -842011210052857928L;

    @NotEmpty
    @ApiModelProperty(value = "算法名称")
    private String algName;

    @ApiModelProperty(value = "算法描述")
    private String algDesc;

    @NotEmpty
    @ApiModelProperty(value = "镜像名称")
    private String imageName;

    @NotEmpty
    @ApiModelProperty(value = "镜像版本")
    private String imageVer;

    @NotEmpty
    @ApiModelProperty(value = "镜像参数")
    private String imageParams;

    @NotEmpty
    @ApiModelProperty(value = "运行环境")
    private String imageEnv;
}
