package com.desay.cd.factory.feign;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 
 * 
 * 
 * @author uidq1343
 * @Modified By： [修改人] on [修改日期] for [修改说明]
 *
 */
@FeignClient(name = "PANGOO-DATA-FACTORY")
public interface StrategyRequest {

    @RequestMapping(value = "/management/taskAssignStrategy", method = RequestMethod.GET)
    ResponseEntity<Object> tokenSecret(@RequestParam(value = "pageSize") Integer pageSize);

    @RequestMapping(value = "/management/taskAssignStrategy", method = RequestMethod.GET)
    ResponseEntity<Object> exploreStrategyByAbility(@RequestParam(value = "pageSize") Integer pageSize,
            @RequestParam(value = "taskTypeName") String taskTypeName);

    @RequestMapping(value = "/management/dictionary?classId=2", method = RequestMethod.GET)
    ResponseEntity<Object> searchDictionary();

    @RequestMapping(value = "/management/groups", method = RequestMethod.GET)
    ResponseEntity<Object> getUserGroup(@RequestParam(value = "userId") String userId);

    @RequestMapping(value = "/management/groups", method = RequestMethod.GET)
    ResponseEntity<Object> getGroupAbility(@RequestParam(value = "groupId") String groupId);

}
