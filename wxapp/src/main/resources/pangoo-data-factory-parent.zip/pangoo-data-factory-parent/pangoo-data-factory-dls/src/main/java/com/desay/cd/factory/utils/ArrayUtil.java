package com.desay.cd.factory.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 数组操作工具类
 * 
 * @author uidq1343
 */
public final class ArrayUtil {

    private ArrayUtil() {
    }

    /**
     * 数组转换为集合,如果数组为null返回null
     * 
     * @param objects
     *            转换的数组
     * @return List 转换后的List集合
     */
    public static <T> List<T> convertList(T[] objects) {
        List<T> list = null;
        if (!isEmpty(objects)) {
            list = new ArrayList<T>();
            list.addAll(Arrays.asList(objects));
        }
        return list;
    }

    /**
     * long数组转换为包装类型数组
     * 
     * @param objs
     *            long数组
     * @return Long[] 包装类型Long数组
     */
    public static Long[] objectArray(long[] objs) {
        Long[] result = null;
        if (objs != null) {
            result = new Long[objs.length];
            for (int i = 0; i < objs.length; i++) {
                result[i] = objs[i];
            }
        }
        return result;
    }

    /**
     * int数组转换为包装类型数组
     * 
     * @param objs
     *            int数组
     * @return Integer[] 包装类型Integer数组
     */
    public static Integer[] objectArray(int[] objs) {
        Integer[] result = null;
        if (objs != null) {
            result = new Integer[objs.length];
            for (int i = 0; i < objs.length; i++) {
                result[i] = objs[i];
            }
        }
        return result;
    }

    /**
     * char类型数组转换为包装类型数组
     * 
     * @param objs
     *            char数组
     * @return Character[] 包装类型Character数组
     */
    public static Character[] objectArray(char[] objs) {
        Character[] result = null;
        if (objs != null) {
            result = new Character[objs.length];
            for (int i = 0; i < objs.length; i++) {
                result[i] = objs[i];
            }
        }
        return result;
    }

    /**
     * boolean类型数组转换为包装类型数组
     * 
     * @param objs
     * @return
     */
    public static Boolean[] objectArray(boolean[] objs) {
        Boolean[] result = null;
        if (objs != null) {
            result = new Boolean[objs.length];
            for (int i = 0; i < objs.length; i++) {
                result[i] = objs[i];
            }
        }
        return result;
    }

    /**
     * 连接数组，返回连接收的字符串
     * 
     * @param objs
     *            数组
     * @param joinChar
     *            分隔符号
     * @return 数组连连接后的字符串
     */
    public static String joinArray(Object[] objs, String joinChar) {
        if (isEmpty(objs)) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (Object o : objs) {
            builder.append(o == null ? "null" : o.toString()).append(joinChar);
        }
        builder.deleteCharAt(builder.length() - 1);
        return builder.toString();
    }

    /**
     * 连接int数组
     * 
     * @param objs
     *            int类型数组
     * @param joinChar
     *            分隔符
     * @return 连接后的字符串
     */
    public static String joinArray(int[] objs, String joinChar) {
        return joinArray(objectArray(objs), joinChar);
    }

    /**
     * 连接long数组
     * 
     * @param objs
     *            long类型数组
     * @param joinChar
     *            分隔符
     * @return 连接后的字符串
     */
    public static String joinArray(long[] objs, String joinChar) {
        return joinArray(objectArray(objs), joinChar);
    }

    /**
     * 连接char数组
     * 
     * @param objs
     *            char类型数组
     * @param joinChar
     *            分隔符号
     * @return 连接后的字符串
     */
    public static String joinArray(char[] objs, String joinChar) {
        return joinArray(objectArray(objs), joinChar);
    }

    /**
     * 判断object类型的数组是否为空
     * 
     * @param objs
     *            数组
     * @return true为空，false不为空
     */
    public static boolean isEmpty(Object[] objs) {
        return ck(objs);
    }

    /**
     * 判断object类型的数组是否不为空
     * 
     * @param objs
     * @return
     */
    public static boolean isNotEmpty(Object[] objs) {
        return !isEmpty(objs);
    }

    /**
     * @param objs
     * @return
     */
    private static boolean ck(Object[] objs) {
        if (objs != null && objs.length > 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * 判断int类型数组是否为空
     * 
     * @param objs
     *            int类型数组
     * @return true为空，false不为空
     */
    public static boolean isEmpty(int[] objs) {
        return ck(objectArray(objs));
    }

    /**
     * 判断byte类型数组是否为空
     * 
     * @param objs
     *            byte类型数组
     * @return true为空，false不为空
     */
    public static boolean isEmpty(byte[] objs) {
        boolean result = objs == null ? true : objs.length <= 0;
        return result;
    }

    /**
     * 判断long类型数组是否为空
     * 
     * @param objs
     *            long类型数组
     * @return true为空，false不为空
     */
    public static boolean isEmpty(long[] objs) {
        return ck(objectArray(objs));
    }

    /**
     * 判断char类型数组是否为空
     * 
     * @param objs
     *            char数组
     * @return true为空，false不为空
     */
    public static boolean isEmpty(char[] objs) {
        return ck(objectArray(objs));
    }

    public static boolean isEmpty(boolean[] objs) {
        return ck(objectArray(objs));
    }

    /**
     * Object数组转换为Integer数组
     * 
     * @param objs
     *            Object数组
     * @return Integer[] Integer类型数组
     */
    public static Integer[] arrayTypeConvert(Object[] objs) {
        if (objs != null && objs.length > 0) {
            Integer[] nums = new Integer[objs.length];
            int index = 0;
            for (Object o : objs) {
                if (o != null && !"".equals(o)) {
                    if (o instanceof Integer) {
                        nums[index] = Integer.valueOf(o.toString());
                    }
                }
                index++;
            }
            return nums;
        }
        return new Integer[] {};
    }

    public static List<Long> splitLongList(String attentionPersonId) {
        String[] idsStrings = attentionPersonId.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (int i = 0; i < idsStrings.length; i++) {
            idList.add(Long.valueOf(idsStrings[i]));

        }
        return idList;
    }

    /**
     * 判断id参数是不是多个值
     * 
     * @param idstr
     * @return
     */
    public static boolean isIdList(String idstr) {
        boolean isIdList = false;
        String[] ids = idstr.split("\\,");
        if (ids != null && ids.length > 1) {
            isIdList = true;
        } else if (ids != null && ids.length == 1) {
            isIdList = false;
        }
        return isIdList;
    }
}
