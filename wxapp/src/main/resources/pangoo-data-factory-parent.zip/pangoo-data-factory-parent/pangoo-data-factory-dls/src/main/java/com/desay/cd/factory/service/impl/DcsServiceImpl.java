package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.desay.common.es.search.SearchApi;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.service.IDcsService;
import com.desay.cd.factory.utils.StringUtil;

/**
 * 
 * @author uidq1343
 *
 */
@Service
public class DcsServiceImpl implements IDcsService {
    private static Logger log = Logger.getLogger(DcsServiceImpl.class);

    @Override
    public Object exploreDcsLogs(String deviceName, Boolean deviceNameLike, String startTime, String endTime,
            String fileId, Integer clearStatus, List<String> sortProperties, Integer pageNo, Integer pageSize) {
        ArrayList<QueryBuilder> params = createQueryBuilders(deviceName, startTime, endTime, deviceNameLike, fileId,
                clearStatus);
        if (params.size() == 0) {
            params.add(SearchApi.createSearchAll());
        }
        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        Map<String, SortOrder> sortPropertiesQueries = SearchApi.createSortProperties(sortProperties, ENDTIME);
        List<String> sortField = new ArrayList<String>(16);
        SortOrder order = null;

        if (sortPropertiesQueries != null) {
            for (Map.Entry<String, SortOrder> sortPropertie : sortPropertiesQueries.entrySet()) {
                sortField.add(sortPropertie.getKey());
                order = sortPropertie.getValue();
            }
        }

        SearchResponse searchResponse = SearchApi.searchByMultiQueries(PANGOO_DCS_CLEAN_TASK_LOG, sortField, order,
                pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            m.put(VERSION, hit.getVersion());
            m.put(LOGID, hit.getId());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);
        return page;
    }

    @Override
    public Object dcsLogsStatistics(String startTime, String endTime) {
        HashMap<String, Object> result = SearchApi.aggregationDcsTask(PANGOO_DCS_CLEAN_TASK_LOG, "clearStatus",
                startTime, endTime);
        if (result != null) {
            Long failure = 0L;

            for (String key : result.keySet()) {
                if (!key.equals("0")) {
                    failure += (Long) result.get(key);
                }
            }
            result.put("success", result.get("0"));
            result.put("failure", failure);
            result.remove("0");
            result.remove("1");
        }
        return result;
    }

    private ArrayList<QueryBuilder> createQueryBuilders(String deviceName, String startTime, String endTime,
            Boolean isExact, String fileId, Integer clearStatus) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        if (StringUtil.isNotEmpty(startTime)) {
            queryBuilder.must(SearchApi.createSearchByFieldRangeGteSource(STARTTIME, startTime));
        }

        if (StringUtil.isNotEmpty(endTime)) {
            queryBuilder.must(SearchApi.createSearchByFieldRangeLteSource(ENDTIME, endTime));
        }

        if (queryBuilder.must().size() != 0) {
            params.add(queryBuilder);
        }

        if (clearStatus != null) {
            params.add(SearchApi.createSearchByFieldSource(CLEARSTATUS, clearStatus));
        }

        if (!TextUtils.isEmpty(fileId)) {
            params.add(SearchApi.createSearchByFieldSource(FILEID, fileId));
        }

        if (StringUtil.isNotEmpty(deviceName)) {
            if (isExact) {
                params.add(SearchApi.createFussySearchSource(DEVICENAME, deviceName));
            } else {
                params.add(SearchApi.createWildCardSearchSource(DEVICENAME, deviceName));
            }
        }
        return params;
    }

    @Override
    public Object dcsFailedReasons(String logId) {
        LinkedList<HashMap<String, Object>> logs = SearchApi.searchById(PANGOO_DCS_CLEAN_TASK_LOG, TYPE, logId);
        HashMap<String, Object> log = new HashMap<String, Object>();
        if (logs == null) {
            return null;
        } else {
            log.put(FAILEDREASON, logs.get(0).get(FAILEDREASON));
            return log;
        }
    }

    @Override
    public Object dcsDetailStatiscs(String startTime, String endTime, List<String> sortProperties, Integer pageNo,
            Integer pageSize) {

        List<HashMap<String, Object>> aggs = SearchApi.aggregationDcsDailyAggs(PANGOO_DCS_CLEAN_TASK_LOG,
                "imgTotalFrame", "imgTotalLength", "imgLeftFrame", "imgLength", "vFileLength", startTime, endTime,
                null);
        return aggs;
    }

}
