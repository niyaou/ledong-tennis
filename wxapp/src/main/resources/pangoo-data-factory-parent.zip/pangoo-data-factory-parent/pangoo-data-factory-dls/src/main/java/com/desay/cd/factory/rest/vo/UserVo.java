package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: UserVo
 * @author: nixuchun
 */

//@Data
public class UserVo implements Serializable {

    private static final long serialVersionUID = -821153874152857928L;

    @NotEmpty
    @ApiModelProperty(value = "标注人ID")
    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
