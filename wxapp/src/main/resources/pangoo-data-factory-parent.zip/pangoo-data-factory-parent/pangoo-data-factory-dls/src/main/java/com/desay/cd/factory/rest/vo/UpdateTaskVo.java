package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.alibaba.fastjson.JSONObject;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: UserVo
 * @author: nixuchun
 */
//@Data
public class UpdateTaskVo implements Serializable {

    private static final long serialVersionUID = -821143874152857928L;

    @NotEmpty
    @ApiModelProperty(value = "标注人ID")
    private String labeler;

    @NotNull
    @ApiModelProperty(value = "任务文档版本号，请填入查询到的版本号，更改无效")
    private Long version;

    @ApiModelProperty(value = "文件信息")
    private JSONObject infos;

    @ApiModelProperty(value = "文件标签信息")
    private JSONObject tags;

    @ApiModelProperty(value = "文件标注信息")
    private JSONObject labels;

    public String getLabeler() {
        return labeler;
    }

    public void setLabeler(String labeler) {
        this.labeler = labeler;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public JSONObject getInfos() {
        return infos;
    }

    public void setInfos(JSONObject infos) {
        this.infos = infos;
    }

    public JSONObject getTags() {
        return tags;
    }

    public void setTags(JSONObject tags) {
        this.tags = tags;
    }

    public JSONObject getLabels() {
        return labels;
    }

    public void setLabels(JSONObject labels) {
        this.labels = labels;
    }

}
