package com.desay.cd.factory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Properties;

import org.desay.common.es.search.SearchApi;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.service.IDcsService;
import com.desay.cd.factory.service.IndexConstant;
import com.desay.cd.factory.service.impl.TaskServiceImpl;
import com.desay.cd.factory.utils.DateUtil;

/**
 * 标注信息测试类
 * 
 * @author uidq1343
 *
 */

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class DcsServiceTest {
    @SuppressWarnings("unused")
    private MockMvc mvc;
    private String id = "nxc_test";
    private String taskId = "nxc_test_task";
    private String deviceId = "nxc_test_device";
    private String deviceName = "deviceName";
    @SuppressWarnings("unused")
    private int taskSeq = 1;
    private int taskLoad = 1;
    private String taskName = "taskName";
    private String abilityId = "abilityId";
    private String abilityName = "abilityName";
    private String groupId = "nxc_test_group";
    private String groupName = "groupName";
    JSONObject doc = new JSONObject();

    @Autowired
    protected WebApplicationContext wac;

    @Autowired
    IDcsService dcsService;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        Properties properties = new Properties();
        // // 获取配置信息
        try {
            properties.load(ClassLoader.getSystemResourceAsStream("application-dev.properties"));
            properties.put("pangoo-data-factory.intercepter", false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void dcsLogsStatistics() throws ParseException {
        clearDataSets();
        String startTime = DateUtil.getDatePlusDays(DateUtil.getCurrentDate(), 10);
        createCleanSets(startTime, 0);

        HashMap<String, Object> id = (HashMap<String, Object>) dcsService.dcsLogsStatistics(startTime,
                DateUtil.getDatePlusDays(startTime, 1));

        assertNotNull(id);
        assertNotEquals(0L, id.get("success"));
        assertNotEquals(0L, id.get("failure"));
        assertEquals(5L, id.get("success"));
        assertEquals(4L, id.get("failure"));
        clearDataSets();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void exploreDcsLogs() throws ParseException {
        clearDataSets();
        String startTime = DateUtil.getDatePlusDays(DateUtil.getCurrentDate(), 10);
        createCleanSets(startTime, 0);
        Page<HashMap<String, Object>> r = (Page<HashMap<String, Object>>) dcsService.exploreDcsLogs(null, true,
                startTime, DateUtil.getDatePlusDays(startTime, 1), null, 1, null, null, null);
        assertNotNull(id);
        assertNotEquals(0, r.getTotalElements());
        assertEquals(9, r.getTotalElements());
        r = (Page<HashMap<String, Object>>) dcsService.exploreDcsLogs(null, true, startTime,
                DateUtil.getDatePlusDays(startTime, 1), null, 1, null, null, null);
        assertEquals(5, r.getTotalElements());
        clearDataSets();
    }

    @Test
    public void dcsDetailStatiscs() throws ParseException {
        Object a = dcsService.dcsDetailStatiscs("2019-12-04", "2019-12-21", null, null, null);
        System.out.println(a);
    }

    private void createCleanSets(String date, int def) throws ParseException {
        String startTime = DateUtil.getDatePlusDays(date, def);
        String endTime = DateUtil.getDatePlusDays(date, def + 1);
        doc.put(IndexConstant.STARTTIME, startTime);
        doc.put(IndexConstant.ENDTIME, endTime);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.CLEARSTATUS, 1);

        for (int times = 0; times < 5; times++) {
            SearchApi.insertDocument(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());
        }

        doc.put(TaskServiceImpl.CLEARSTATUS, 0);
        for (int times = 0; times < 4; times++) {
            SearchApi.insertDocument(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());
        }
        doc = new JSONObject();
        sleep(2000);
    }

    private void createDataSets(String date, int def) throws ParseException {
        String assignTime = DateUtil.getDatePlusDays(date, def);
        doc.put(IndexConstant.ACQUIREDTIME, assignTime);
        doc.put(IndexConstant.STATUS, 1);
        doc.put(IndexConstant.LABELER, id);
        for (int times = 0; times < 5; times++) {
            SearchApi.insertDocument(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());
        }
        doc.put(IndexConstant.STATUS, 2);
        doc.put(IndexConstant.SUBMITTIME, assignTime);
        SearchApi.insertDocument(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());

        doc.put(TaskServiceImpl.STATUS, 3);
        doc.put(TaskServiceImpl.AUDITTIME, assignTime);
        for (int times = 0; times < 2; times++) {
            SearchApi.insertDocument(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());
        }

        doc.put(TaskServiceImpl.STATUS, 4);
        for (int times = 0; times < 2; times++) {
            SearchApi.insertDocument(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());
        }
        doc = new JSONObject();
        sleep(1600);
        // doc.put(TaskServiceImpl.SUBMITTIME, assignTime);

    }

    private void clearDataSets() {
        BulkByScrollResponse s;
        try {
            s = SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE,
                    IndexConstant.DEVICEID, deviceId);
            assertEquals(s.getBulkFailures().size(), 0);
//            s = SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE,
//                    IndexConstant.AUDITOR, id);
//            assertEquals(s.getBulkFailures().size(), 0);
//            s = SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE,
//                    IndexConstant.LABELER, id);
//            s = SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DCS_CLEAN_TASK_LOG, IndexConstant.TYPE,
//                    IndexConstant.AUDITOR, id);
            sleep(1000);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     * 等待时间
     * 
     * @param timeout
     */
    private void sleep(int timeout) {
        try {
            Thread.sleep(timeout);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 清除测试数据
     */
    private void clearDatabases(String index, String id) {
        try {
            SearchApi.deleteDocument(index, IndexConstant.TYPE, id);
        } catch (Exception e) {
        }
    }

}
