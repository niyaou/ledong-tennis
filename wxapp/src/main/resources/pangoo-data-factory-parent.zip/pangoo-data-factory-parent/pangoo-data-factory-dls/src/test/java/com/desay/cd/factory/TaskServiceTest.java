package com.desay.cd.factory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Queue;
import java.util.Random;

import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.desay.common.es.search.SearchApi;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.redisson.RedissonQueue;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.feign.StrategyRequest;
import com.desay.cd.factory.service.IFileIformationService;
import com.desay.cd.factory.service.ITaskService;
import com.desay.cd.factory.service.IndexConstant;
import com.desay.cd.factory.service.impl.TaskServiceImpl;
import com.desay.cd.factory.utils.DateUtil;

/**
 * 标注信息测试类
 * 
 * @author uidq1343
 *
 */

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TaskServiceTest {
    private static Logger log = Logger.getLogger(TaskServiceTest.class);
    @SuppressWarnings("unused")
    private MockMvc mvc;
    private String id = "nxc_test";
    private String taskId = "nxc_test_task";
    private String deviceId = "nxc_test_device";
    private String deviceName = "deviceName";
    @SuppressWarnings("unused")
    private int taskSeq = 1;
    private int taskLoad = 1;
    private String taskName = "taskName";
    private String abilityId = "abilityId";
    private String abilityName = "abilityName";
    private String fileName = "fileName";
    private String groupId = "nxc_test_group";
    private String groupName = "groupName";
    private String productName = "productName";

    @Autowired
    private RedissonClient redissonClient;

    JSONObject doc = new JSONObject();
    List<String> tasks;

    @Autowired
    protected WebApplicationContext wac;

    @Autowired
    ITaskService taskService;

    @Autowired
    private IFileIformationService fileService;

    @Autowired
    private StrategyRequest strategyRequest;

//    @Autowired
//    private RedissonClient redissonClient;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        Properties properties = new Properties();
        // // 获取配置信息
        try {
            properties.load(ClassLoader.getSystemResourceAsStream("application-dev.properties"));
            properties.put("pangoo-data-factory.intercepter", false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void createTaskInformation() {
        String id = null;
        id = taskService.createTaskInformation(taskName, groupId, abilityId, abilityName, deviceId, deviceName, 1);
        assertNotNull(id);
        sleep(1600);
        clearDatabases(IndexConstant.TASK_INFORMATION_INDEX, id);
    }

    // @Test
    // public void assignTaskLog() {
    // String id = null;
    // id = taskService.assignTaskLog(taskId, taskName, taskLoad, groupId,
    // groupName, deviceId, deviceName);
    // assertNotNull(id);
    // sleep(1600);
    // clearDatabases(IndexConstant.ASSIGNED_LOG_INDEX, id);
    // }

    @SuppressWarnings("unchecked")
    @Test
    public void exploreAssignTaskByTimeRange() {
        String startTime = "2009-11-11";
        String endTime = "2009-11-12";
        doc.put(TaskServiceImpl.ASSIGNEDTIME, startTime);
        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), id);
        sleep(1600);
        Page<HashMap<String, Object>> page = (Page<HashMap<String, Object>>) taskService
                .exploreAssignTaskByTimeRange(startTime, endTime, null, true, null, null, null);
        assertEquals(1, page.getTotalElements());

        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, id);

    }

    @Test
    public void updateTaskAuditInformation() {
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);
        Integer status = 0;
        String message = null;
        String auditor = "test1";
        try {
            taskService.updateTaskStatusInformation(taskId, auditor, status, null);
        } catch (ElasticsearchException e) {
            message = e.getMessage();
        }
        assertEquals(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND.getMessage(), message);
        doc.put(TaskServiceImpl.ASSIGNEDTIME, "2019-10-10");

        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), taskId);
        sleep(1800);

        message = ((Result) taskService.updateTaskStatusInformation(taskId, auditor, status, null)).toString();
        assertEquals(Result.UPDATED.toString(), message);
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);
    }

    @SuppressWarnings("unused")
    @Test
    public void submitedTaskLog() {

        clearDatabases(IndexConstant.TASK_INFORMATION_INDEX, taskId);
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);
        Integer status = 0;
        String message = null;
        String auditor = "test1";
        try {
            taskService.updateTaskStatusInformation(taskId, auditor, status, null);
        } catch (ElasticsearchException e) {
            message = e.getMessage();
        }
        assertEquals(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND.getMessage(), message);
        doc.put(TaskServiceImpl.ASSIGNEDTIME, "2019-10-10");

        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), taskId);
        sleep(1800);
        LinkedList<HashMap<String, Object>> v = SearchApi.searchByFieldAndType(IndexConstant.TASK_INFORMATION_INDEX,
                IndexConstant.TYPE, IndexConstant.ID, taskId, null, null);

        message = ((Result) taskService.updateTaskStatusInformation(taskId, auditor, status, null)).toString();
        assertEquals(Result.UPDATED.toString(), message);
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void exploreAssignTaskByTaskId() {
        SearchApi.deleteDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE, id);
        doc.put(IndexConstant.CREATETIME, DateUtil.getCurrentDate());
        doc.put(IndexConstant.TASKID, taskId);
        SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                doc.toJSONString(), id);
        sleep(2000);
        Page<HashMap<String, Object>> page = (Page<HashMap<String, Object>>) taskService
                .exploreAssignTaskByTaskId(taskId, null, null, null);
        assertEquals(1, page.getTotalElements());
        SearchApi.deleteDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE, id);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void exploreLabelLogs() throws ParseException {
        clearDataSets();
        String date = DateUtil.getCurrentDate();
        doc.put(IndexConstant.LABELEDTIME, date);
        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);
        doc.put(IndexConstant.FILEID, id);
        doc.put(IndexConstant.LABELER, id);
        doc.put(IndexConstant.LABELS, doc);
        SearchApi.insertDocument(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE, doc.toJSONString());
        doc.put(IndexConstant.LABELEDTIME, DateUtil.getDatePlusDays(date, 1));
        SearchApi.insertDocument(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE, doc.toJSONString());
        List<String> list = new ArrayList<String>();
        list.add("-" + IndexConstant.LABELEDTIME);
        Page<HashMap<String, Object>> r = (Page<HashMap<String, Object>>) taskService.exploreLabelLogs(id, null,
                DateUtil.getDatePlusDays(date, 1), false, list, null, null);
        assertNotNull(r);
        clearDataSets();

    }

    @Test
    public void exploreLabelLogsData() throws ParseException {
        String[] users = new String[] { "uidp5340", "uidp5344", "uidp5367", "uidp5368", "uidq0812", "uida3681" };

        for (String id : users) {
            String date = DateUtil.getCurrentDate();
            int def = -10;
            Random random = new Random();
            random.setSeed(System.currentTimeMillis());
            def += random.nextInt(20);
            for (int i = 0; i < 10; i++) {
                date = DateUtil.getDatePlusDays(date, def);
                doc.put(IndexConstant.LABELEDTIME, date);
                doc.put(IndexConstant.TASKID, taskId);
                doc.put(IndexConstant.DEVICEID, deviceId);
                doc.put(IndexConstant.DEVICENAME, deviceName);
                doc.put(IndexConstant.FILEID, id);
                doc.put(IndexConstant.LABELER, id);
                doc.put(IndexConstant.LABELS, doc);
                SearchApi.insertDocument(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE, doc.toJSONString());
                doc.put(IndexConstant.LABELEDTIME, DateUtil.getDatePlusDays(date, 1));
                SearchApi.insertDocument(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE, doc.toJSONString());
            }

        }

    }

    @SuppressWarnings("unchecked")
    @Test
    public void exploreAuditlLogs() throws ParseException {

        clearDataSets();
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);
        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.TASKNAME, taskName);
        doc.put(IndexConstant.TASKLOAD, taskLoad);
        doc.put(IndexConstant.GROUPID, groupId);
        doc.put(IndexConstant.GROUPNAME, groupName);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);
        doc.put(IndexConstant.LABELER, id);
        doc.put(IndexConstant.ABILITYNAME, abilityName);
        doc.put(IndexConstant.ASSIGNEDTIME, DateUtil.getCurrentDateTime());
        doc.put(IndexConstant.ACQUIREDTIME, DateUtil.getCurrentDateTime());
        doc.put(IndexConstant.SUBMITTIME, DateUtil.getCurrentDateTime());

        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), taskId);
        sleep(2000);
        String message = ((Result) taskService.updateTaskStatusInformation(taskId, id, 3, null)).toString();
        assertEquals(Result.UPDATED.toString(), message);

        String date = DateUtil.getCurrentDate();

        List<String> list = new ArrayList<String>();
        list.add("-" + IndexConstant.LABELEDTIME);
        Page<HashMap<String, Object>> r = (Page<HashMap<String, Object>>) taskService.exploreAuditlLogs(null,
                DateUtil.getDatePlusDays(date, 1), id, 3, true, list, null, null);
        assertNotEquals(0, r.getTotalElements());
        clearDataSets();
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void exploreAuditlLogsData() throws ParseException {
        String[] users = new String[] { "uidp5340", "uidp5344", "uidp5367", "uidp5368", "uidq0812", "uida3681" };

        for (String id : users) {
            String date = DateUtil.getCurrentDate();
            int def = -10;
            Random random = new Random();
            random.setSeed(System.currentTimeMillis());
            def += random.nextInt(20);
            for (int i = 0; i < 10; i++) {

                doc.put(IndexConstant.TASKID, taskId);
                doc.put(IndexConstant.TASKNAME, taskName);
                doc.put(IndexConstant.TASKLOAD, taskLoad);
                doc.put(IndexConstant.GROUPID, groupId);
                doc.put(IndexConstant.GROUPNAME, groupName);
                doc.put(IndexConstant.DEVICEID, deviceId);
                doc.put(IndexConstant.DEVICENAME, deviceName);
                doc.put(IndexConstant.AUDITOR, id);
                doc.put(IndexConstant.ABILITYNAME, abilityName);
                date = DateUtil.getDatePlusDays(date, def);
                doc.put(IndexConstant.ASSIGNEDTIME, date);
                doc.put(IndexConstant.ACQUIREDTIME, date);
                doc.put(IndexConstant.SUBMITTIME, date);
                doc.put(IndexConstant.AUDITTIME, date);
                doc.put(IndexConstant.STATUS, random.nextInt(20) % 2 == 0 ? 3 : 4);
                SearchApi.insertDocument(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());

            }
        }

    }

    @SuppressWarnings("unchecked")
    @Test
    public void explorePersonalTask() throws ParseException {
        clearDataSets();
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);
        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.TASKNAME, taskName);
        doc.put(IndexConstant.TASKLOAD, taskLoad);
        doc.put(IndexConstant.GROUPID, groupId);
        doc.put(IndexConstant.GROUPNAME, groupName);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);
        doc.put(IndexConstant.LABELER, id);
        doc.put(IndexConstant.STATUS, 0);
        doc.put(IndexConstant.ABILITYNAME, abilityName);
        doc.put(IndexConstant.ASSIGNEDTIME, DateUtil.getCurrentDateTime());
        doc.put(IndexConstant.ACQUIREDTIME, DateUtil.getCurrentDateTime());
        doc.put(IndexConstant.SUBMITTIME, DateUtil.getCurrentDateTime());

        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), taskId);
        sleep(2000);

        List<String> list = new ArrayList<String>();
        list.add("-" + IndexConstant.ASSIGNEDTIME);
        Page<HashMap<String, Object>> r = (Page<HashMap<String, Object>>) taskService.explorePersonalTask(taskName,
                groupId, id, 0, list, null, null);
        assertNotEquals(0, r.getTotalElements());
        r = (Page<HashMap<String, Object>>) taskService.explorePersonalTask(null, null, null, 0, list, null, null);
        assertNotEquals(0, r.getTotalElements());
        clearDataSets();
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void labelTaskStatistics() throws ParseException, IOException {
        clearDataSets();
        String date = DateUtil.getCurrentDateTime();
        int def = 30;
        createDataSets(date, def);

        HashMap<String, Object> result = (HashMap<String, Object>) taskService
                .labelTaskStatistics(DateUtil.getDatePlusDays(date, 30), DateUtil.getDatePlusDays(date, 31));
        System.out.print(result.toString());
        assertNotNull(result);
        assertNotEquals(result.size(), 0);
        assertEquals(((HashMap<String, Object>) result.get("labelEff")).get("unsubmited"), 5L);
        assertEquals(((HashMap<String, Object>) result.get("auditEff")).get("audited"), 4L);
        assertEquals(((HashMap<String, Object>) result.get("labelQa")).get("passed"), 2L);
        clearDataSets();
    }

    @Test
    public void labelTaskStatisticsData() throws ParseException, IOException {
        String date = DateUtil.getCurrentDateTime();
        int def = -10;
        String[] users = new String[] { "uidp5340", "uidp5344", "uidp5367", "uidp5368", "uidq0812", "uida3681" };
        for (String id : users) {
            createDataSetsId(date, def, id);
        }

    }

    @SuppressWarnings("unchecked")
    @Test
    public void personalLabelTaskStatistics() throws ParseException {
        clearDataSets();
        String date = DateUtil.getCurrentDateTime();
        int def = 30;
        createDataSets(date, def);
        List<HashMap<String, Object>> result = (List<HashMap<String, Object>>) taskService
                .personalLabelTaskStatistics(DateUtil.getDatePlusDays(date, 30), DateUtil.getDatePlusDays(date, 31), 1);
        System.out.print(result.toString());
        assertNotNull(result);
        assertNotEquals(result.size(), 0);
        assertEquals(Integer.parseInt((String) result.get(0).get("labelEff")), 50);
        clearDataSets();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void personalDailyStatistics() throws ParseException {

        clearDataSets();
        String date = DateUtil.getCurrentDateTime();
        int def = 30;

        createAuditSets(date, def);
        createDataSets(date, def);

        createAuditSets(date, def + 1);
        createDataSets(date, def + 1);

        Page<HashMap<String, Object>> result = (Page<HashMap<String, Object>>) taskService.personalDailyStatistics(id,
                DateUtil.getDatePlusDays(date, def + 1), DateUtil.getDatePlusDays(date, def + 1), "asc", null, null);
        System.out.print(result.getContent().toString());
        assertEquals(((HashMap<String, Object>) result.getContent().get(0).get("audit")).get("audited"), 4L);
        assertEquals(((HashMap<String, Object>) result.getContent().get(0).get("label")).get("labelEff"),
                String.valueOf(50));
        clearDataSets();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateTaskAbilityInformation() throws ParseException {
        clearDataSets();
        // 第一步获取全部策略
        ResponseEntity<?> response = strategyRequest.tokenSecret(Integer.MAX_VALUE);
        JSONObject page = (JSONObject) JSONObject.toJSON(response.getBody());
        JSONArray strategies = (JSONArray) ((JSONObject) page.get("data")).get("content");
        String ability = null;
        String deviceId = null;
        int taskLoad = 0;
        for (int i = 0; i < strategies.size(); i++) {
            JSONObject strategy = strategies.getJSONObject(i);
            deviceId = strategy.getJSONObject("sysDevice").getString("deviceId");
            ability = strategy.getJSONObject("taskType").getString("name");
            ability = strategy.getJSONObject("taskType").getString("name");
            taskLoad = strategy.getIntValue("taskLoad");
            if (TextUtils.isEmpty(ability)) {
                continue;
            }
        }

        doc.put(IndexConstant.CREATETIME, DateUtil.getCurrentDate());
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.PRODUCTNAME, fileName);
        for (int i = 0; i < taskLoad; i++) {
            SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                    doc.toJSONString());
        }

        sleep(2000);
        tasks = (List<String>) taskService.updateTaskAbilityInformation();
        assertNotNull(tasks);
        assertNotEquals(0, tasks.size());
        sleep(2000);
        LinkedList<HashMap<String, Object>> a = SearchApi.searchByFieldAndType(IndexConstant.FILE_INFORMATION_INDEX,
                IndexConstant.PANGOO_DLS_TYPE, IndexConstant.PRODUCTNAME, fileName, 0, taskLoad);
        System.out.println("ability : " + ability);
        System.out.println("deviceId : " + deviceId);
        System.out.println("file info : " + a);
        System.out.println("tasks : " + tasks.toString());
        clearTaskLoad();
        clearDataSets();
        assertNotNull(a);

    }

    @Test
    public void updateTaskAbilityInformationDATA() throws ParseException {
//        clearDataSets();
        // 第一步获取全部策略
        ResponseEntity<?> response = strategyRequest.tokenSecret(Integer.MAX_VALUE);
        JSONObject page = (JSONObject) JSONObject.toJSON(response.getBody());
        JSONArray strategies = (JSONArray) ((JSONObject) page.get("data")).get("content");
        String ability = null;
        String deviceId = null;
        String deviceName = null;
        int taskLoad = 0;
        for (int i = 0; i < strategies.size(); i++) {
            JSONObject strategy = strategies.getJSONObject(i);
            if (strategy.getJSONObject("sysDevice") == null) {
                continue;
            }
            deviceId = strategy.getJSONObject("sysDevice").getString("deviceId");
            deviceName = strategy.getJSONObject("sysDevice").getString("deviceName");
            if (strategy.getJSONObject("taskType") == null) {
                continue;
            }
            ability = strategy.getJSONObject("taskType").getString("name");
            ability = strategy.getJSONObject("taskType").getString("name");
            if (strategy.getInteger("taskLoad") == null) {
                continue;
            }
            taskLoad = strategy.getIntValue("taskLoad");
            if (TextUtils.isEmpty(ability)) {
                continue;
            }
            doc.put(IndexConstant.CREATETIME, DateUtil.getCurrentTimeStamp());
            doc.put(IndexConstant.DEVICEID, deviceId);
            doc.put(IndexConstant.DEVICENAME, deviceName);
            doc.put(IndexConstant.PRODUCTNAME, fileName);
            doc.put(IndexConstant.FOLDERNMAE, "/pangoo_dls/qlVoDW8BCYsNJuM1bRAJ");
            doc.put(IndexConstant.IMAGENAME, "ITTI_Behavior_Detection_253_11220.jpg");
            for (int J = 0; J < taskLoad * 2; J++) {
                SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                        doc.toJSONString());
            }

//            sleep(2000);
//            tasks = (List<String>) taskService.updateTaskAbilityInformation();
        }

    }

//    @Test
//    public void increate() {
//        RAtomicLong entityIdCounter = redissonClient.getAtomicLong("taskTest");
//
//        Long increment = entityIdCounter.getAndIncrement();
//
//        for (int i = 0; i < 10000; i++) {
//            System.out.println(increment);
//            increment = entityIdCounter.getAndIncrement();
//        }
//
//    }

    @Test
    public void assignTaskLog() throws IOException {

        SearchApi.deleteDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, taskId);
        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKLOAD, String.valueOf(taskLoad));
        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.TASKNAME, taskName);
        doc.put(IndexConstant.PRODUCTNAME, fileName);
        doc.put(IndexConstant.TASKLOAD, taskLoad);
        doc.put(IndexConstant.GROUPID, groupId);
        doc.put(IndexConstant.GROUPNAME, groupName);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);
        doc.put(IndexConstant.LABELER, id);

        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), taskId);
        sleep(2000);
        String date = DateUtil.getCurrentDateTime();
        taskService.assignTask(doc, abilityName);
        sleep(2000);
        LinkedList<HashMap<String, Object>> list = SearchApi.searchByTimeGte(IndexConstant.TASK_INFORMATION_INDEX,
                IndexConstant.TYPE, IndexConstant.ASSIGNEDTIME, date, null, null);
        assertNotEquals(0, list.size());
        assertNotNull(list.get(0).get(IndexConstant.STATUS));
        assertNotEquals(1, list.get(0).get(IndexConstant.STATUS));
        assertEquals(0, list.get(0).get(IndexConstant.STATUS));
        doc = new JSONObject();

        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKLOAD, String.valueOf(taskLoad));
        SearchApi.deleteDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, taskId);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void exploreAcquiredTaskLog() throws IOException, ParseException {

        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKID, taskId);

        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.TASKNAME, taskName);
        doc.put(IndexConstant.TASKLOAD, taskLoad);
        doc.put(IndexConstant.GROUPID, groupId);
        doc.put(IndexConstant.GROUPNAME, groupName);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);
        doc.put(IndexConstant.LABELER, id);
        doc.put(IndexConstant.ABILITYNAME, abilityName);
        String date = DateUtil.getCurrentDateTime();

        doc.put(IndexConstant.ASSIGNEDTIME, date);
        doc.put(IndexConstant.ACQUIREDTIME, date);
        doc.put(IndexConstant.STATUS, 1);
        SearchApi.insertDocument(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE, doc.toJSONString());

        sleep(2000);

        Page<HashMap<String, Object>> r = (Page<HashMap<String, Object>>) taskService.exploreAcquiredTaskLog(id,
                DateUtil.getDatePlusDays(date, -1), DateUtil.getDatePlusDays(date, 1), false, null, null, null);
        assertNotEquals(0, r.getTotalElements());
        clearDataSets();
        clearDatabases(TaskServiceImpl.TASK_INFORMATION_INDEX, taskId);

        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKLOAD, String.valueOf(taskLoad));
        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKID, taskId);
        SearchApi.deleteDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, taskId);

    }

    @Test
    public void assignTaskData() {
        taskService.teemTaskPool();
    }

    @Test
    public void assignTask() throws IOException {
        SearchApi.deleteDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, taskId);

        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.TASKNAME, taskName);
        doc.put(IndexConstant.PRODUCTNAME, fileName);
        doc.put(IndexConstant.TASKLOAD, taskLoad);
        doc.put(IndexConstant.GROUPID, groupId);
        doc.put(IndexConstant.GROUPNAME, groupName);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);
        doc.put(IndexConstant.LABELER, id);

        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), taskId);
        sleep(2000);
        taskService.assignTask(doc, abilityName);
        sleep(2000);
        LinkedList<HashMap<String, Object>> list = SearchApi.searchById(IndexConstant.TASK_INFORMATION_INDEX,
                IndexConstant.TYPE, taskId);
        assertNotNull(list);
        assertNotEquals(0, list.size());
        assertNotNull(list.get(0).get(IndexConstant.STATUS));
        assertNotEquals(1, list.get(0).get(IndexConstant.STATUS));
        assertEquals(0, list.get(0).get(IndexConstant.STATUS));
        doc = new JSONObject();
        SearchApi.deleteDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, taskId);
        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKLOAD, String.valueOf(taskLoad));
    }

    @SuppressWarnings("unused")
    @Test
    public void teemTaskPool() throws ParseException, IOException {

        clearDataSets();
        clearTaskLoad();

        // 获取一个能力（字典检索）
        ResponseEntity<?> response = strategyRequest.searchDictionary();
        JSONObject content = (JSONObject) JSONObject.toJSON(response.getBody());
        JSONArray Abilities = content.getJSONArray("data");

        JSONObject mAbility = Abilities.getJSONObject(0);
        String abilityName = mAbility.getString("name");
        // 第二步 搜索能力对应的策略,每个策略对应一个设备
        while (TextUtils.isEmpty(abilityName)) {
            mAbility = Abilities.getJSONObject(0);
            abilityName = mAbility.getString("name");
        }
        // 第二步 搜索能力对应的策略,每个策略对应一个设备
        ResponseEntity<?> resp = strategyRequest.exploreStrategyByAbility(Integer.MAX_VALUE, abilityName);
        JSONObject page = (JSONObject) JSONObject.toJSON(resp.getBody());
        JSONArray strategies = (JSONArray) ((JSONObject) page.get("data")).get("content");
        List<String> tasks = new ArrayList<>(10);
        RedissonQueue<Object> queue = null;
        for (int j = 0; j < strategies.size(); j++) {
            JSONObject strategy = strategies.getJSONObject(j);
            String deviceId = strategy.getJSONObject("sysDevice").getString("deviceId");
            String deviceName = strategy.getJSONObject("sysDevice").getString("deviceName");
            Integer taskLoad = strategy.getInteger("taskLoad");

            // 查看该能力的任务池
            queue = (RedissonQueue<Object>) redissonClient.getQueue(abilityName);

            // 清空该能力池
            while (queue.size() > 0) {
                queue.remove();
            }
            // 创建任务满足能力要求
            doc.put(IndexConstant.TASKID, taskId);
            doc.put(IndexConstant.TASKNAME, taskName);
            doc.put(IndexConstant.PRODUCTNAME, fileName);
            doc.put(IndexConstant.TASKLOAD, taskLoad);
            doc.put(IndexConstant.GROUPID, groupId);
            doc.put(IndexConstant.GROUPNAME, groupName);
            doc.put(IndexConstant.DEVICEID, deviceId);
            doc.put(IndexConstant.DEVICENAME, deviceName);
            doc.put(IndexConstant.STATUS, 0);
            doc.put(IndexConstant.ABILITYNAME, abilityName);

            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(),
                    taskId);
            doc = new JSONObject();
            sleep(2000);
            break;
            // 第三步 搜索策略对应的任务,按照优先级排序,按照优先级加入到任务池

        }

        // 调用方法
        taskService.teemTaskPool();
        // 查看能力池数量
        assertNotEquals(0, queue.size());
        queue.clear();

        // 删除

        clearDataSets();
        clearTaskLoad();

        SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.TASKID, taskId);

    }

    @Test
    public void acquiredTaskData() throws IOException {
        String userId = "uidp5340";
        int task1 = (int) taskService.acquiredTask(userId);
        assertNotEquals(0, task1);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void acquiredTask() throws IOException {
        String userId = "uidp5340";
//        String userId = "uidq0985";

        // 清理测试数据
        BulkByScrollResponse s = SearchApi.deleteDocumentBySearchField(IndexConstant.TASK_INFORMATION_INDEX,
                IndexConstant.TYPE, IndexConstant.LABELER, userId);
        clearDataSets();
        clearTaskLoad();
        // end

        // 查询用户组
        ResponseEntity<?> response = strategyRequest.getUserGroup(userId);
        JSONObject content = (JSONObject) JSONObject.toJSON(response.getBody());
        JSONArray groups = content.getJSONObject("data").getJSONArray("content");

        if (groups == null || groups.size() == 0) {
        }

        List<Integer> list = new LinkedList<Integer>();
        for (int i = 0; i < groups.size(); i++) {
            list.add(i);
        }
        Collections.shuffle(list);
        assertNotEquals(0, list.size());
        JSONObject group = groups.getJSONObject(list.get(0));

        // 获取该组的一个能力
        ResponseEntity<?> respAbility = strategyRequest.getGroupAbility(group.getString(IndexConstant.GROUPID));
        JSONObject contentAbility = (JSONObject) JSONObject.toJSON(respAbility.getBody());
        JSONArray Abilities = contentAbility.getJSONObject("data").getJSONArray("content").getJSONObject(0)
                .getJSONArray("abilities");

        Random random = new Random();
        random.setSeed(System.currentTimeMillis());

        Queue<JSONObject> groupQ = new LinkedList<JSONObject>();
        while (groupQ.size() < Abilities.size()) {
            groupQ.add(Abilities.getJSONObject(random.nextInt(Abilities.size())));
        }

        System.out.println(groupQ.toString());
        System.out.println(groupQ);

        group = groupQ.remove();

        // 获取该能力任务池下的任务
        RedissonQueue<Object> queue = (RedissonQueue<Object>) redissonClient.getQueue(group.getString("dataId"));
        while (queue.size() > 0) {
            queue.remove();
        }
        System.out.println(group.getString("dataId"));

        assertEquals(0, queue.size());

        // 查询能力下的策略，任意一个策略就满足
        ResponseEntity<?> resp = strategyRequest.exploreStrategyByAbility(Integer.MAX_VALUE, group.getString("name"));
        JSONObject page = (JSONObject) JSONObject.toJSON(resp.getBody());
        JSONArray strategies = (JSONArray) ((JSONObject) page.get("data")).get("content");
        List<String> tasks = new ArrayList<>(10);
        while (strategies.size() == 0 && groupQ.size() > 0) {
            group = groupQ.remove();
            resp = strategyRequest.exploreStrategyByAbility(Integer.MAX_VALUE, group.getString("name"));
            page = (JSONObject) JSONObject.toJSON(resp.getBody());
            strategies = (JSONArray) ((JSONObject) page.get("data")).get("content");
        }

        // 根据策略获取设备
        JSONObject strategy = strategies.getJSONObject(0);
        String deviceId = strategy.getJSONObject("sysDevice").getString("deviceId");
        String deviceName = strategy.getJSONObject("sysDevice").getString("deviceName");
        Integer priority = Integer.valueOf(strategy.getJSONObject("priority").getString("value"));
        Integer taskLoad = strategy.getInteger("taskLoad");
        System.out.println(strategy.toJSONString());
        System.out.println(deviceId);

        System.out.println(deviceName);
        System.out.println(priority);

        // 构造设备名关联的图片信息

        doc.put(IndexConstant.CREATETIME, DateUtil.getCurrentDate());
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.PRODUCTNAME, fileName);
        for (int i = 0; i < taskLoad; i++) {
            SearchApi.insertDocument(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.PANGOO_DLS_TYPE,
                    doc.toJSONString());
        }

        sleep(2000);

        tasks = (List<String>) taskService.updateTaskAbilityInformation();
        assertNotEquals(0, tasks.size());
        sleep(2000);
        int task1 = (int) taskService.acquiredTask(userId);
        assertNotEquals(0, task1);
        sleep(2000);
        s = SearchApi.deleteDocumentBySearchField(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE,
                IndexConstant.LABELER, userId);
        s = SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.LABELER, userId);
        clearDataSets();
        clearTaskLoad();

    }

    @SuppressWarnings("unchecked")
    @Test
    public void retreatedTasks() throws IOException {

        // 清理测试数据
        BulkByScrollResponse s = SearchApi.deleteDocumentBySearchField(IndexConstant.TASK_INFORMATION_INDEX,
                IndexConstant.TYPE, IndexConstant.LABELER, id);
        clearDataSets();
        clearTaskLoad();

        sleep(1500);

        String assignTime = DateUtil.getCurrentDateTime();
        doc.put(IndexConstant.TASKID, taskId);
        doc.put(IndexConstant.TASKNAME, taskName);
        doc.put(IndexConstant.PRODUCTNAME, fileName);
        doc.put(IndexConstant.TASKLOAD, taskLoad);
        doc.put(IndexConstant.GROUPID, groupId);
        doc.put(IndexConstant.GROUPNAME, groupName);
        doc.put(IndexConstant.DEVICEID, deviceId);
        doc.put(IndexConstant.DEVICENAME, deviceName);
        doc.put(IndexConstant.ABILITYNAME, abilityName);
        doc.put(IndexConstant.ASSIGNEDTIME, assignTime);
        doc.put(IndexConstant.ACQUIREDTIME, assignTime);
        doc.put(IndexConstant.SUBMITTIME, assignTime);
        doc.put(IndexConstant.AUDITTIME, assignTime);
        doc.put(IndexConstant.LABELER, id);
        doc.put(IndexConstant.STATUS, 2);
        doc.put(IndexConstant.AUDITOR, id);
        doc.put(IndexConstant.GROUPID, groupName);
        doc.put(IndexConstant.GROUPNAME, groupName);

        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString(), taskId);
        doc = new JSONObject();
        sleep(3000);

        Page<HashMap<String, Object>> r = (Page<HashMap<String, Object>>) taskService.explorePersonalTask(null, null,
                id, null, null, null, null);
        assertNotEquals(0, r.getTotalElements());
        assertNotEquals(null, r.getContent().get(0).get(IndexConstant.LABELER));
        assertNotEquals(null, r.getContent().get(0).get(IndexConstant.ASSIGNEDTIME));
        assertNotEquals(null, r.getContent().get(0).get(IndexConstant.ACQUIREDTIME));
        assertNotEquals(null, r.getContent().get(0).get(IndexConstant.SUBMITTIME));
        assertNotEquals(null, r.getContent().get(0).get(IndexConstant.AUDITTIME));
        assertNotEquals(null, r.getContent().get(0).get(IndexConstant.SUBMITTIME));

        taskService.retreatedTasks(id);

        sleep(3000);
//        assertTrue(false);
        r = (Page<HashMap<String, Object>>) taskService.explorePersonalTask(taskName, null, null, null, null, null,
                null);
        assertNotEquals(0, r.getTotalElements());
        assertEquals(null, r.getContent().get(0).get(IndexConstant.LABELER));
        assertEquals(null, r.getContent().get(0).get(IndexConstant.ASSIGNEDTIME));
        assertEquals(null, r.getContent().get(0).get(IndexConstant.ACQUIREDTIME));
        assertEquals(null, r.getContent().get(0).get(IndexConstant.SUBMITTIME));
        assertEquals(null, r.getContent().get(0).get(IndexConstant.AUDITTIME));
        assertEquals(null, r.getContent().get(0).get(IndexConstant.SUBMITTIME));

        s = SearchApi.deleteDocumentBySearchField(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE,
                IndexConstant.LABELER, id);
        s = SearchApi.deleteDocumentBySearchField(IndexConstant.PANGOO_DLS_TASK_LOG, IndexConstant.TYPE,
                IndexConstant.LABELER, id);
        clearDataSets();
        clearTaskLoad();

    }

    private void createAuditSets(String date, int def) throws ParseException {
        String assignTime = DateUtil.getDatePlusDays(date, def);
        doc.put(IndexConstant.ACQUIREDTIME, assignTime);
        doc.put(IndexConstant.STATUS, 1);

        doc.put(IndexConstant.STATUS, 2);
        doc.put(IndexConstant.SUBMITTIME, assignTime);

        doc.put(IndexConstant.STATUS, 3);
        doc.put(IndexConstant.AUDITTIME, assignTime);
        doc.put(IndexConstant.AUDITOR, id);
        for (int times = 0; times < 2; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }

        doc.put(TaskServiceImpl.STATUS, 4);
        for (int times = 0; times < 2; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }
        doc = new JSONObject();
    }

    private void createDataSets(String date, int def) throws ParseException {
        String assignTime = DateUtil.getDatePlusDays(date, def);
        doc.put(IndexConstant.ACQUIREDTIME, assignTime);
        doc.put(IndexConstant.STATUS, 1);
        doc.put(IndexConstant.LABELER, id);
        for (int times = 0; times < 5; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }
        doc.put(IndexConstant.STATUS, 2);
        doc.put(IndexConstant.SUBMITTIME, assignTime);
        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());

        doc.put(TaskServiceImpl.STATUS, 3);
        doc.put(TaskServiceImpl.AUDITTIME, assignTime);
        for (int times = 0; times < 2; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }

        doc.put(TaskServiceImpl.STATUS, 4);
        for (int times = 0; times < 2; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }
        doc = new JSONObject();
        sleep(1600);
        // doc.put(TaskServiceImpl.SUBMITTIME, assignTime);

    }

    private void createDataSetsId(String date, int def, String userId) throws ParseException {
        Random random = new Random();
        random.setSeed(System.currentTimeMillis());
        def += random.nextInt(20);
        String assignTime = DateUtil.getDatePlusDays(date, def);
        doc.put(IndexConstant.ACQUIREDTIME, assignTime);
        doc.put(IndexConstant.STATUS, 1);
        doc.put(IndexConstant.LABELER, userId);
        for (int times = 0; times < 10; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }
        doc.put(IndexConstant.STATUS, 2);
        doc.put(IndexConstant.SUBMITTIME, assignTime);
        SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());

        doc.put(TaskServiceImpl.STATUS, 3);
        doc.put(TaskServiceImpl.AUDITTIME, assignTime);
        for (int times = 0; times < 6; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }

        doc.put(TaskServiceImpl.STATUS, 4);
        for (int times = 0; times < 5; times++) {
            SearchApi.insertDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, doc.toJSONString());
        }
        doc = new JSONObject();
    }

    private void clearDataSets() {
        BulkByScrollResponse s;
        try {
            s = SearchApi.deleteDocumentBySearchField(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE,
                    IndexConstant.LABELER, id);
            assertEquals(s.getBulkFailures().size(), 0);
            s = SearchApi.deleteDocumentBySearchField(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE,
                    IndexConstant.AUDITOR, id);
            assertEquals(s.getBulkFailures().size(), 0);
            s = SearchApi.deleteDocumentBySearchField(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE,
                    IndexConstant.LABELER, id);
            s = SearchApi.deleteDocumentBySearchField(IndexConstant.FILE_LABEL_LOG_INDEX, IndexConstant.TYPE,
                    IndexConstant.AUDITOR, id);
            s = SearchApi.deleteDocumentBySearchField(IndexConstant.FILE_INFORMATION_INDEX, IndexConstant.FILETYPE,
                    IndexConstant.PRODUCTNAME, fileName);
            s = SearchApi.deleteDocumentBySearchField(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE,
                    IndexConstant.TASKID, taskId);
            sleep(1000);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception h) {
            log.error(h.getMessage());
        }

    }

    private void clearTaskLoad() {
        if (tasks != null) {
            for (String string : tasks) {
                System.out.println(string);
                SearchApi.deleteDocument(IndexConstant.TASK_INFORMATION_INDEX, IndexConstant.TYPE, string);
            }
            tasks.clear();
        }
    }

    /**
     * 等待时间
     * 
     * @param timeout
     */
    private void sleep(int timeout) {
        try {
            Thread.sleep(timeout);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 清除测试数据
     */
    private void clearDatabases(String index, String id) {
        try {
            SearchApi.deleteDocument(index, IndexConstant.TYPE, id);
        } catch (Exception e) {
        }
    }

}
