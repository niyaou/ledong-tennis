package com.desay.cd.factory.service.impl;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;

import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.desay.common.es.search.SearchApi;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.sort.SortOrder;
import org.redisson.RedissonQueue;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.feign.StrategyRequest;
import com.desay.cd.factory.service.IFileIformationService;
import com.desay.cd.factory.service.ITaskService;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;

/**
 * 
 * @author uidq1343
 *
 */
@Service
public class TaskServiceImpl implements ITaskService {
    private static Logger log = Logger.getLogger(TaskServiceImpl.class);

    @Autowired
    private StrategyRequest strategyRequest;

    @Autowired
    private IFileIformationService fileService;

    @Autowired
    private RedissonClient redissonClient;

    @Override
    public String createTaskInformation(String taskName, String groupId, String abilityId, String abilityName,
            String deviceId, String deviceName, Integer taskLoad) {

        JSONObject doc = new JSONObject();
        if (!TextUtils.isEmpty(taskName)) {
            doc.put(TASKNAME, taskName);
        }
        if (!TextUtils.isEmpty(groupId)) {
            doc.put(GROUPID, groupId);
        }
        if (!TextUtils.isEmpty(abilityId)) {
            doc.put(ABILITYID, abilityId);
        }
        if (!TextUtils.isEmpty(abilityName)) {
            doc.put(ABILITYNAME, abilityName);
        }
        if (!TextUtils.isEmpty(deviceId)) {
            doc.put(DEVICEID, deviceId);
        }
        if (!TextUtils.isEmpty(deviceName)) {
            doc.put(DEVICENAME, deviceName);
        }

        doc.put(TASKLOAD, taskLoad);
        doc.put(CREATETIME, DateUtil.getCurrentTimeStamp());

        DocWriteResponse result = SearchApi.insertDocument(TASK_INFORMATION_INDEX, TYPE, doc.toJSONString());
        return result.getResult().equals(Result.CREATED) ? result.getId() : null;
    }

    @Override
    public String assignTaskLog(String taskId, String taskName, String deviceId, String deviceName, String abilityName,
            Integer taskLoad, String assignedTime) {
        JSONObject doc = new JSONObject();
        if (!TextUtils.isEmpty(taskId)) {
            doc.put(TASKID, taskId);
        }
        if (!TextUtils.isEmpty(taskName)) {
            doc.put(TASKNAME, taskName);
        }

        if (!TextUtils.isEmpty(deviceId)) {
            doc.put(DEVICEID, deviceId);
        }
        if (!TextUtils.isEmpty(deviceName)) {
            doc.put(DEVICENAME, deviceName);
        }

        if (!TextUtils.isEmpty(abilityName)) {
            doc.put(ABILITYNAME, abilityName);
        }

        doc.put(TASKLOAD, taskLoad);
        doc.put(ASSIGNEDTIME, assignedTime);

        DocWriteResponse result = SearchApi.insertDocument(PANGOO_DLS_TASK_LOG, TYPE, doc.toJSONString());
        return result.getResult().equals(Result.CREATED) ? result.getId() : null;

    }

    @Override
    public String assignTask(JSONObject doc, String abilityName) {
        String assignedTime = DateUtil.getCurrentTimeStamp();
        doc.put(ASSIGNEDTIME, assignedTime);
        doc.put(STATUS, 0);
        DocWriteResponse result = SearchApi.updateDocument(TASK_INFORMATION_INDEX, TYPE, doc.toJSONString(),
                doc.getString(TASKID));
        if (result.getResult().equals(Result.UPDATED)) {
            assignTaskLog(doc.getString(TASKID), doc.getString(TASKNAME), doc.getString(DEVICEID),
                    doc.getString(DEVICENAME), abilityName, doc.getInteger(TASKLOAD), assignedTime);
        }
        return result.getResult().equals(Result.UPDATED) ? result.getId() : null;
    }

    @Override
    public Object exploreAssignTaskByTimeRange(String startTime, String endTime, String deviceName, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer pageSize) {
        ArrayList<QueryBuilder> params = createQueryBuilders(deviceName, startTime, endTime, isExact);
        if (params.size() == 0) {
            return null;
        }
        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        SearchResponse searchResponse = SearchApi.searchByMultiQueries(TASK_INFORMATION_INDEX, null, null, pageNo,
                pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            m.put(TASKID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);
        return page;
    }

    @Override
    public Object updateTaskGroupInformation(String taskId, String... group) throws ElasticsearchException {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByFieldAndType(TASK_INFORMATION_INDEX, TYPE, ID,
                taskId, null, null);
        if (dic == null || dic.size() == 0) {
            throw new ElasticsearchException(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND.getMessage());
        }
        HashMap<String, Object> doc = dic.get(0);
        doc.put(GROUPID, group);
        doc.put(STATUS, 1);
        DocWriteResponse result = SearchApi.updateDocument(TASK_INFORMATION_INDEX, TYPE, JSON.toJSONString(doc),
                taskId);
        return result.getResult().equals(Result.UPDATED) ? result.getId() : null;
    }

    @Override
    public Object updateTaskStatusInformation(String taskId, String userId, Integer status, String message)
            throws ElasticsearchException {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByFieldAndType(TASK_INFORMATION_INDEX, TYPE, ID,
                taskId, null, null);
        if (dic == null || dic.size() == 0) {
            throw new ElasticsearchException(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND.getMessage());
        }
        HashMap<String, Object> doc = dic.get(0);
        doc.put(STATUS, status);
        doc.put(AUDITMESSAGE, message);
        switch (status) {
        case 0:
            doc.put(ASSIGNEDTIME, DateUtil.getCurrentTimeStamp());
            break;
        case 1:
            doc.put(ACQUIREDTIME, DateUtil.getCurrentTimeStamp());
            doc.put(LABELER, userId);
            break;
        case 2:
            doc.put(SUBMITTIME, DateUtil.getCurrentTimeStamp());
            doc.put(LABELER, userId);
            break;
        case 3:
        case 4:
            doc.put(AUDITTIME, DateUtil.getCurrentTimeStamp());
            doc.put(AUDITOR, userId);
            break;
        default:
            break;
        }

        DocWriteResponse result = SearchApi.updateDocument(TASK_INFORMATION_INDEX, TYPE, JSON.toJSONString(doc),
                taskId);

        submitedTaskLog(taskId, String.valueOf(doc.get("taskName")), ((Integer) doc.get("taskLoad")),
                String.valueOf(doc.get("groupId")), String.valueOf(doc.get("groupName")),
                String.valueOf(doc.get("deviceId")), String.valueOf(doc.get("deviceName")), userId,
                String.valueOf(doc.get("abilityName")), status);

        // createTaskDealingLog( );
        return result.getResult().equals(Result.UPDATED) ? result.getId() : null;

    }

    @Override
    public Object exploreAssignTaskByTaskId(String taskId, List<String> sortProperties, Integer pageNo, Integer size) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();

        if (StringUtil.isNotEmpty(taskId)) {
            params.add(SearchApi.createSearchByFieldSource(TASKID, taskId));
        }

        if (params.size() == 0) {
            return null;
        }

        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        Map<String, SortOrder> sortPropertiesQueries = SearchApi.createSortProperties(sortProperties, CREATETIME);

        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders(FILE_INFORMATION_INDEX, FILETYPE,
                sortPropertiesQueries, pageNo, size, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            m.put(TASKID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, size, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);
        return page;
    }

    /**
     * * 标注质量 labelQa 为 当日提交任务数、当日通过任务数 、 当日未通过任务数 的统计结果 * 标注效率 labelEff 为 *
     * 当日领取任务数、当日提交任务数、当日未提交任务数 的统计结果 * 审核效率 auditEff 为 当日提交任务数、当日已经审批的任务数、当日未审批任务数
     * * 的统计结果
     */
    @SuppressWarnings("unchecked")
    @Override
    public Object labelTaskStatistics(String startTime, String endTime) {
        try {
            endTime = DateUtil.getDatePlusDays(endTime, 1);
        } catch (ParseException e) {
            log.error(e.getMessage());
        }
        HashMap<String, Object> aggr = SearchApi.aggregationTimeSubAgg(TASK_INFORMATION_INDEX, startTime, endTime,
                "submitTime", "acquiredTime");
        if (aggr == null) {
            return null;
        }

        HashMap<String, Object> mQa = (HashMap<String, Object>) aggr.get("labelQa");
        HashMap<String, Object> mEff = (HashMap<String, Object>) aggr.get("labelEff");
        HashMap<String, Object> picQa = ((HashMap<String, Object>) mQa.get("taskLoad"));
        HashMap<String, Object> picEff = ((HashMap<String, Object>) mEff.get("taskLoad"));
        HashMap<String, Object> labelQa = new HashMap<String, Object>(16);
        labelQa.put("submited", mQa.get("total"));
        labelQa.put("submitedPic", picQa.get("total") == null ? 0.0 : picQa.get("total"));
        labelQa.put("passed", mQa.get(String.valueOf(3)) == null ? 0 : mQa.get(String.valueOf(3)));
        labelQa.put("passedPic", picQa.get(String.valueOf(3)) == null ? 0 : picQa.get(String.valueOf(3)));
        labelQa.put("unpassed", mQa.get(String.valueOf(4)) == null ? 0 : mQa.get(String.valueOf(4)));
        labelQa.put("unpassedPic", picQa.get(String.valueOf(4)) == null ? 0 : picQa.get(String.valueOf(4)));

        HashMap<String, Object> labelEff = new HashMap<String, Object>(16);
        labelEff.put("received", mEff.get("total"));
        labelEff.put("receivedPic", picEff.get("total") == null ? 0.0 : picEff.get("total"));
        long unSubmited = mEff.get(String.valueOf(1)) == null ? 0L : (long) mEff.get(String.valueOf(1));
        labelEff.put("submited", (long) mEff.get("total") - unSubmited);
        labelEff.put("submitedPic", picEff.get("total") == null ? 0.0
                : ((double) picEff.get("total"))
                        - (picEff.get(String.valueOf(1)) == null ? 0.0 : (double) picEff.get(String.valueOf(1))));
        labelEff.put("unsubmited", unSubmited);
        labelEff.put("unsubmitedPic",
                picEff.get(String.valueOf(1)) == null ? 0.0 : (double) picEff.get(String.valueOf(1)));

        HashMap<String, Object> auditEff = new HashMap<String, Object>(16);
        auditEff.put("submited", mQa.get("total"));
        auditEff.put("submitedPic", picQa.get("total") == null ? 0.0 : picQa.get("total"));
        long audited = (mQa.get(String.valueOf(3)) == null ? 0L : (long) mQa.get(String.valueOf(3)))
                + (mQa.get(String.valueOf(4)) == null ? 0L : (long) mQa.get(String.valueOf(4)));
        double auditedPic = (picQa.get(String.valueOf(3)) == null ? 0L : (double) picQa.get(String.valueOf(3)))
                + (picQa.get(String.valueOf(4)) == null ? 0L : (double) picQa.get(String.valueOf(4)));
        auditEff.put("audited", audited);
        auditEff.put("auditedPic", auditedPic);
        long unaudited = (mQa.get(String.valueOf(2)) == null ? 0L : (long) mQa.get(String.valueOf(2)));
        double unauditedPic = (picQa.get(String.valueOf(2)) == null ? 0L : (double) picQa.get(String.valueOf(2)));
        auditEff.put("unaudited", unaudited);
        auditEff.put("unauditedPic", unauditedPic);

        HashMap<String, Object> result = new HashMap<String, Object>(16);
        result.put("auditEff", auditEff);
        result.put("labelQa", labelQa);
        result.put("labelEff", labelEff);
        return result;
    }

    @Override
    public Object personalLabelTaskStatistics(String startTime, String endTime, int type) {

        String field = null;
        switch (type) {
        case 1:
            field = "labeler";
            break;
        case 2:
            field = "groupName";
            break;
        case 3:
            field = "abilityName";
            break;
        default:
            field = "labeler";
        }
        Object aggr = SearchApi.aggregationPersonalAggs(TASK_INFORMATION_INDEX, startTime, endTime, ACQUIREDTIME, field,
                "status");
        if (aggr == null) {
            return null;
        }
        return aggr;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object personalDailyStatistics(String userId, String startTime, String endTime, String sortProperties,
            Integer pageNo, Integer pageSize) {

        HashMap<String, Object> aggs = SearchApi.aggregationPersonalDailyAggs(TASK_INFORMATION_INDEX, userId,
                ACQUIREDTIME, AUDITTIME, LABELER, AUDITOR, userId, startTime, endTime, "asc".equals(sortProperties));

        List<HashMap<String, Object>> result = new ArrayList<HashMap<String, Object>>();

        List<HashMap<String, Object>> labeler = (List<HashMap<String, Object>>) aggs.get("label");
        List<HashMap<String, Object>> auditor = (List<HashMap<String, Object>>) aggs.get("audit");

        for (HashMap<String, Object> daily : labeler) {
            HashMap<String, Object> sum = new HashMap<String, Object>(16);
            sum.put("sumDate", daily.get("aggsTime"));
            HashMap<String, Object> label = new HashMap<String, Object>(16);

            Long received = (Long) daily.get("aggsTotal");
            Double receivedPic = 0.0;
            Long submited = 0L;
            Double submitedPic = 0.0;
            for (Map.Entry<String, Object> status : ((HashMap<String, Object>) daily.get("data")).entrySet()) {
                Long key = Long.parseLong(status.getKey());
                HashMap<String, Object> parseObj = (HashMap<String, Object>) status.getValue();
                Long value = (Long) parseObj.get("status");
                Double load = (Double) parseObj.get("taskLoad");
                receivedPic += load;
                if (key != 1) {
                    submited += value;
                    submitedPic += load;
                }
            }
            NumberFormat numberFormat = NumberFormat.getInstance();
            numberFormat.setMaximumFractionDigits(2);
            label.put("received", received);
            label.put("receivedPic", receivedPic);
            label.put("submited", submited);
            label.put("submitedPic", submitedPic);
            label.put("labelEff", submited == 0 ? 0 : numberFormat.format((float) submited / (float) received * 100));
            sum.put("label", label);
            HashMap<String, Object> audit = new HashMap<String, Object>(16);
            Double auditPic = 0.0;
            for (HashMap<String, Object> dailyAudit : auditor) {
                if (dailyAudit.get("aggsTime").equals(daily.get("aggsTime"))) {
                    Long total = (Long) dailyAudit.get("aggsTotal");
                    HashMap<String, Object> auditObj = (HashMap<String, Object>) dailyAudit.get("data");
                    audit.put("audited", total);
                    for (Map.Entry<String, Object> auditStatus : auditObj.entrySet()) {

                        Double pic = (Double) ((HashMap<String, Object>) auditStatus.getValue()).get("taskLoad");
                        auditPic += pic;
                    }
                    audit.put("auditedPic", auditPic);
                }
            }
            sum.put("audit", audit);
            result.add(sum);
        }
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, result.size());
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(result, page1, result.size());
        return page;
    }

    @Override
    public Object exploreLabelLogs(String labeler, String startTime, String endTime, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer pageSize) {

        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
        if (!TextUtils.isEmpty(labeler)) {
            if (isExact) {
                params.add(SearchApi.createSearchByFieldSource(LABELER, labeler));
            } else {
                params.add(SearchApi.createWildCardSearchSource(LABELER, labeler));
            }
        }

        params.add(SearchApi.createSearchByFieldRangeSource(LABELEDTIME, startTime, endTime));
        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        Map<String, SortOrder> sortPropertiesQueries = SearchApi.createSortProperties(sortProperties, LABELEDTIME);

        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders(FILE_LABEL_LOG_INDEX, TYPE,
                sortPropertiesQueries, pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
//            m.put(FILEID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);

        return page;

    }

    @Override
    public Object exploreAuditlLogs(String startTime, String endTime, String auditor, Integer status, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer pageSize) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();

        if (!TextUtils.isEmpty(auditor)) {
            if (isExact) {
                params.add(SearchApi.createSearchByFieldSource(AUDITOR, auditor));
            } else {
                params.add(SearchApi.createWildCardSearchSource(AUDITOR, auditor));
            }
        }

        params.add(SearchApi.createSearchByFieldRangeSource(AUDITTIME, startTime, endTime));
        if (status != null) {
            params.add(SearchApi.createSearchByFieldSource(STATUS, status));
        }

        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        Map<String, SortOrder> sortPropertiesQueries = SearchApi.createSortProperties(sortProperties, AUDITTIME);

        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders(PANGOO_DLS_TASK_LOG, TYPE,
                sortPropertiesQueries, pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
//            m.put(TASKID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);

        return page;
    }

    @Override
    public String submitedTaskLog(String taskId, String taskName, Integer taskLoad, String groupId, String groupName,
            String deviceId, String deviceName, String userId, String abilityName, Integer status) {
        JSONObject doc = new JSONObject();
        if (!TextUtils.isEmpty(taskId)) {
            doc.put(TASKID, taskId);
        }
        if (!TextUtils.isEmpty(taskName)) {
            doc.put(TASKNAME, taskName);
        }
        if (taskLoad != null) {
            doc.put(TASKLOAD, taskLoad);
        }
        if (!TextUtils.isEmpty(groupId)) {
            doc.put(GROUPID, groupId);
        }
        if (!TextUtils.isEmpty(groupName)) {
            doc.put(GROUPNAME, groupName);
        }
        if (!TextUtils.isEmpty(deviceId)) {
            doc.put(DEVICEID, deviceId);
        }
        if (!TextUtils.isEmpty(deviceName)) {
            doc.put(DEVICENAME, deviceName);
        }
        if (!TextUtils.isEmpty(userId)) {
            String userType = status > 2 ? AUDITOR : LABELER;
            doc.put(userType, userId);
        }
        if (!TextUtils.isEmpty(abilityName)) {
            doc.put(ABILITYNAME, abilityName);
        }
        switch (status) {
        case 0:
            doc.put(ASSIGNEDTIME, DateUtil.getCurrentTimeStamp());
            break;
        case 1:
            doc.put(ACQUIREDTIME, DateUtil.getCurrentTimeStamp());
            break;
        case 2:
            doc.put(SUBMITTIME, DateUtil.getCurrentTimeStamp());
            break;
        case 3:
        case 4:
            doc.put(AUDITTIME, DateUtil.getCurrentTimeStamp());
            break;
        default:
            break;
        }
        doc.put(STATUS, status);
        DocWriteResponse result = SearchApi.insertDocument(PANGOO_DLS_TASK_LOG, TYPE, doc.toJSONString());
        return result.getResult().equals(Result.CREATED) ? result.getId() : null;
    }

    /**
     * 
     * @param productName
     * @param deviceName
     * @param startTime
     * @param endTime
     * @return
     */
    private ArrayList<QueryBuilder> createQueryBuilders(String deviceName, String startTime, String endTime,
            boolean isExact) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
        if (StringUtil.isNotEmpty(startTime) && StringUtil.isNotEmpty(endTime)) {
            params.add(SearchApi.createSearchByFieldRangeSource(ASSIGNEDTIME, startTime, endTime));
        }
        if (StringUtil.isNotEmpty(deviceName)) {
            if (isExact) {
                params.add(SearchApi.createFussySearchSource(DEVICENAME, deviceName));
            } else {
                params.add(SearchApi.createWildCardSearchSource(DEVICENAME, deviceName));
            }

        }
        return params;
    }

    /**
     * 根据条件构建精确查询
     * 
     * @param field
     * @param value
     * @param isExact
     * @return
     */
    private QueryBuilder createExactQueryByType(String field, String value, boolean isExact) {
        if (StringUtil.isNotEmpty(field) && StringUtil.isNotEmpty(value)) {
            if (isExact) {
                return SearchApi.createFussySearchSource(field, value);
            } else {
                return SearchApi.createWildCardSearchSource(field, value);
            }
        }
        return null;
    }

    @Override
    public Object explorePersonalTask(String taskName, String groupId, String userId, Integer status,
            List<String> sortProperties, Integer pageSize, Integer pageNo) {

        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();

        if (StringUtil.isNotEmpty(taskName)) {
            params.add(SearchApi.createWildCardSearchSource(TASKNAME, taskName));
        }

        if (StringUtil.isNotEmpty(groupId)) {
            params.add(SearchApi.createSearchByFieldSource(GROUPID, groupId));
        }
        if (StringUtil.isNotEmpty(userId)) {
            params.add(SearchApi.createSearchByFieldSource(LABELER, userId));
        }
        if (status != null) {
            params.add(SearchApi.createSearchByFieldSource(STATUS, status));
        }

        if (params.size() == 0) {
            params.add(SearchApi.createSearchAll());
        }

        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        Map<String, SortOrder> sortPropertiesQueries = SearchApi.createSortProperties(sortProperties, CREATETIME);

        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders(TASK_INFORMATION_INDEX, TYPE,
                sortPropertiesQueries, pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }

        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            m.put(TASKID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);
        return page;

    }

    @Override
    public Object updateTaskAbilityInformation() throws ElasticsearchException {
        // 第一步获取全部策略
        ResponseEntity<?> response = strategyRequest.tokenSecret(Integer.MAX_VALUE);
        JSONObject page = (JSONObject) JSONObject.toJSON(response.getBody());
        JSONArray strategies = (JSONArray) ((JSONObject) page.get("data")).get("content");
        List<String> tasks = new ArrayList<>(10);
        for (int i = 0; i < strategies.size(); i++) {
            JSONObject strategy = strategies.getJSONObject(i);
            if (strategy.getJSONObject("sysDevice") == null) {
                continue;
            }
            String deviceId = strategy.getJSONObject("sysDevice").getString("deviceId");
            String deviceName = strategy.getJSONObject("sysDevice").getString("deviceName");
            if (strategy.getJSONObject("taskType") == null) {
                continue;
            }
            String ability = strategy.getJSONObject("taskType").getString("name");
            String abilityiD = strategy.getJSONObject("taskType").getString("dataId");
            if (TextUtils.isEmpty(ability)) {
                continue;
            }

            Integer taskLoad = strategy.getInteger("taskLoad");
            if (taskLoad == null) {
                continue;
            }
            // 第二步 根据策略名下设备ID搜索没有分配任务的图片
            ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();

            params.add(SearchApi.createSearchByFieldSource(DEVICEID, deviceId));
            params.add(SearchApi.createEmptyOrNotExistedSource(TASKID));

            QueryBuilder[] values = new QueryBuilder[2];
            LinkedList<HashMap<String, Object>> result = SearchApi.searchByMultiQueriesWithType(FILE_INFORMATION_INDEX,
                    FILETYPE, null, null, 0, taskLoad, null, params.toArray(values));

            if (result == null) {
                // 没有对应的标注文件，不做操作
                continue;
            }

            boolean active = strategy.getInteger("isActive") == 1;
            if (result.size() < taskLoad && active) {
                continue;
            }
            Long taskSeq = incr(abilityiD + "atom");
            String taskName = ability + "task" + String.valueOf(taskSeq);
            log.info(result.toString());
            // 第三步 创建具有标注能力和设备ID的标注任务
            String taskId = createTaskInformation(taskName, null, null, ability, deviceId, deviceName, taskLoad);
            log.info(" create task  name: " + taskName);
            tasks.add(taskId);
            int seq = 1;
            for (HashMap<String, Object> hashMap : result) {
                // 第四步 将每一个策略id写入到对应的图片上
                fileService.updateTaskInformation((String) hashMap.get("fileId"), taskId, taskName, seq++, null,
                        (long) hashMap.get("version"));
            }
        }
        return tasks;
    }

    @Override
    public Object teemTaskPool() {
        // 第一步 搜索全部能力（字典检索）

        ResponseEntity<?> response = strategyRequest.searchDictionary();
        JSONObject content = (JSONObject) JSONObject.toJSON(response.getBody());
        JSONArray Abilities = content.getJSONArray("data");
        Integer newAssignedTask = -1;
        for (int i = 0; i < Abilities.size(); i++) {
            JSONObject mAbility = Abilities.getJSONObject(i);
            String abilityName = mAbility.getString("name");
            String abilityiD = mAbility.getString("dataId");
            // 第二步 搜索能力对应的策略,每个策略对应一个设备
            if (TextUtils.isEmpty(abilityName)) {
                continue;
            }
            // 第二步 搜索能力对应的策略,每个策略对应一个设备
            ResponseEntity<?> resp = strategyRequest.exploreStrategyByAbility(Integer.MAX_VALUE, abilityName);
            JSONObject page = (JSONObject) JSONObject.toJSON(resp.getBody());
            JSONArray strategies = (JSONArray) ((JSONObject) page.get("data")).get("content");
            for (int j = 0; j < strategies.size(); j++) {
                JSONObject strategy = strategies.getJSONObject(j);
                if (strategy.getJSONObject("sysDevice") == null) {
                    continue;
                }
                String deviceId = strategy.getJSONObject("sysDevice").getString("deviceId");
                String deviceName = strategy.getJSONObject("sysDevice").getString("deviceName");
                if (strategy.getJSONObject("priority") == null) {
                    continue;
                }
                Integer priority = Integer.valueOf(strategy.getJSONObject("priority").getString("value"));

                // 第三步 搜索策略对应的任务,按照优先级排序,按照优先级加入到任务池
                RedissonQueue<Object> queue = (RedissonQueue<Object>) redissonClient.getQueue(abilityiD);
                if (queue.size() >= 100) {
                    continue;
                }

                ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
                params.add(SearchApi.createSearchByFieldSource(DEVICEID, deviceId));
                params.add(SearchApi.createNotExistedSource(ASSIGNEDTIME));

                QueryBuilder[] values = new QueryBuilder[2];
                LinkedList<HashMap<String, Object>> result = SearchApi.searchByMultiQueriesWithType(
                        TASK_INFORMATION_INDEX, TYPE, null, null, 0, priority, TASKID, params.toArray(values));

                if (result == null) {
                    continue;
                }

                for (HashMap<String, Object> hashMap : result) {
                    String taskId = (String) hashMap.get("taskId");
                    String taskName = (String) hashMap.get("taskName");
                    hashMap.put(ABILITYNAME, abilityName);
                    hashMap.put(DEVICEID, deviceId);
                    hashMap.put(DEVICENAME, deviceName);
                    hashMap.put(TASKNAME, taskName);
                    if (queue.size() >= 100) {
                        continue;
                    }

                    String id = assignTask((JSONObject) JSONObject.toJSON(hashMap), abilityName);
                    newAssignedTask += TextUtils.isEmpty(id) ? 0 : 1;
                    queue.add(taskId);
                }
            }

        }

        // 第三步 搜索策略对应的任务,按照优先级排序,按照优先级加入到任务池
        return newAssignedTask;
    }

    @Override
    public Object acquiredTask(String userId) {
        int tasks = -1;
        // 第一步查询用户所在group
        ResponseEntity<?> response = strategyRequest.getUserGroup(userId);
        JSONObject content = (JSONObject) JSONObject.toJSON(response.getBody());
        JSONArray groups = content.getJSONObject("data").getJSONArray("content");

        if (groups == null || groups.size() == 0) {
            return -2;
        }

        List<Integer> list = new LinkedList<Integer>();
        for (int i = 0; i < groups.size(); i++) {
            list.add(i);
        }
        Collections.shuffle(list);

        ArrayList<String> groupArrs = new ArrayList<String>();
        for (int i = 0; i < groups.size(); i++) {
            boolean isMaster = false;
            JSONObject group = groups.getJSONObject(list.get(i));
            JSONArray master = group.getJSONArray("masters");
            if (master.size() != 0) {
                for (int j = 0; j < master.size(); j++) {
                    isMaster = false;
                    if (master.getJSONObject(j).getString("userId").equals(userId)) {
                        isMaster = true;
                        continue;
                    }
                }
            }
            if (!isMaster) {
                groupArrs.add(group.getString(GROUPID));
            }
        }

        for (String groupId : groupArrs) {

            // 第二步查询组所具有的能力
            ResponseEntity<?> respAbility = strategyRequest.getGroupAbility(groupId);
            JSONObject contentAbility = (JSONObject) JSONObject.toJSON(respAbility.getBody());
            JSONArray Abilities = contentAbility.getJSONObject("data").getJSONArray("content").getJSONObject(0)
                    .getJSONArray("abilities");
            Random random = new Random();
            random.setSeed(System.currentTimeMillis());

            Queue<JSONObject> groupQ = new LinkedList<JSONObject>();
            while (groupQ.size() < Abilities.size()) {
                groupQ.add(Abilities.getJSONObject(groupQ.size()));
            }

            while (groupQ.size() > 0) {
                String abilityiD = groupQ.remove().getString("dataId");
                // 第三步查询该能力对应的任务池
                RedissonQueue<Object> queue = (RedissonQueue<Object>) redissonClient.getQueue(abilityiD);
                String taskId = null;
                try {
                    taskId = (String) queue.remove();
                    // 第四步改变任务状态
                    // 第四步领取一个任务
                    Object result = updateTaskStatusInformation(taskId, userId, 1, null);
                    tasks = result == null ? 0 : 1;
                    if (tasks > 0) {
                        String[] groupIds = new String[groupArrs.size()];
                        updateTaskGroupInformation(taskId, groupArrs.toArray(groupIds));
                        return tasks;
                    }
                } catch (Exception e) {
                    continue;
                }
            }

        }
        return tasks;
    }

    @Override
    public Object exploreAcquiredTaskLog(String labeler, String startTime, String endTime, boolean isExact,
            List<String> sortProperties, Integer pageNo, Integer pageSize) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();

        if (!TextUtils.isEmpty(labeler)) {
            params.add(createExactQueryByType(LABELER, labeler, isExact));

        }

        params.add(SearchApi.createSearchByFieldRangeSource(ACQUIREDTIME, startTime, endTime));

        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        Map<String, SortOrder> sortPropertiesQueries = SearchApi.createSortProperties(sortProperties, ACQUIREDTIME);

        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders(PANGOO_DLS_TASK_LOG, TYPE,
                sortPropertiesQueries, pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);

        return page;
    }

    @Override
    public Object retreatedTasks(String userId) {
        // 1.查询所有审核未通过任务
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();

        if (!TextUtils.isEmpty(userId)) {
            params.add(createExactQueryByType(LABELER, userId, true));
        }
        params.add(SearchApi.createNotSearchSource(STATUS, String.valueOf(3)));

        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<Boolean> dic = new LinkedList<Boolean>();

        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders(TASK_INFORMATION_INDEX, TYPE, null, 0,
                50000, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();

        for (SearchHit hit : searchHits) {
            HashMap<String, Object> doc = (HashMap<String, Object>) hit.getSourceAsMap();
            doc.put(STATUS, 0);
            // 2.抹去分配时间、领取时间、提交时间、审核时间、领取人、审核人
            doc.remove(ASSIGNEDTIME);
            doc.remove(ACQUIREDTIME);
            doc.remove(SUBMITTIME);
            doc.remove(AUDITTIME);
            doc.remove(LABELER);
            doc.remove(AUDITOR);
            doc.remove(GROUPID);
            doc.remove(GROUPNAME);

            DocWriteResponse result = SearchApi.removeDocumentSource(TASK_INFORMATION_INDEX, TYPE,
                    JSON.toJSONString(doc), hit.getId(), new String[] { ASSIGNEDTIME, ACQUIREDTIME, SUBMITTIME,
                            AUDITTIME, LABELER, STATUS, AUDITOR, GROUPID, GROUPNAME });
            dic.push(result.getResult().toString().equals(Result.UPDATED.toString()));
        }
        return dic;
    }

    /**
     *
     * @param key
     * @param liveTime
     * @return
     */
    private Long incr(String key) {
        RAtomicLong entityIdCounter = redissonClient.getAtomicLong(key);

        Long increment = entityIdCounter.getAndIncrement();

        return increment;
    }

}
