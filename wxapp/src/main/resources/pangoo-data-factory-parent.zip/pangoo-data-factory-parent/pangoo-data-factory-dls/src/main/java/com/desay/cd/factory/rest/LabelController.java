package com.desay.cd.factory.rest;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.util.TextUtils;
import org.elasticsearch.ElasticsearchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.rest.vo.AuditTaskVo;
import com.desay.cd.factory.rest.vo.FileAuditVo;
import com.desay.cd.factory.rest.vo.UpdateTaskVo;
import com.desay.cd.factory.rest.vo.UserVo;
import com.desay.cd.factory.service.IFileIformationService;
import com.desay.cd.factory.service.ITaskService;
import com.desay.cd.factory.utils.Constant;
import com.desay.cd.factory.utils.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 
 * @author uidq1343
 *
 */
@RestController
@Api(value = "数据标注", tags = "数据标注")
public class LabelController {

    @Autowired
    private ITaskService taskService;

    @Autowired
    private IFileIformationService fileService;

    @ApiOperation(value = "数据标注-提交标注任务信息 ", notes = "")
    @RequestMapping(value = "/label/tasks/{taskId}", method = RequestMethod.PUT)
    @ApiImplicitParam(name = "taskId", value = "任务ID", required = true, dataType = "string", paramType = "path")
    public Object submitTask(@PathVariable(value = "taskId", required = true) String taskId,
            @Validated @RequestBody UserVo userId) {
        try {
            int status = 2;
            return new ResponseEntity<Object>(
                    CommonResponse
                            .success(taskService.updateTaskStatusInformation(taskId, userId.getUserId(), status, null)),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse.failure(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND),
                    HttpStatus.OK);
        }
    }

    @ApiIgnore
    @RequestMapping(value = "/label/tasks/teemTask", method = RequestMethod.GET)
    public Object teemTask() {
        try {
            return new ResponseEntity<Object>(CommonResponse.success(taskService.teemTaskPool()), HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse.failure(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND),
                    HttpStatus.OK);
        }
    }

    @ApiIgnore
    @RequestMapping(value = "/label/tasks/assigntask", method = RequestMethod.GET)
    public Object updateTaskAbilityInformation() {
        try {
            return new ResponseEntity<Object>(CommonResponse.success(taskService.updateTaskAbilityInformation()),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse.failure(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据标注-审核标注任务信息 ", notes = "")
    @RequestMapping(value = "/label/tasks/audit/{taskId}", method = RequestMethod.PUT)
    @ApiImplicitParam(name = "taskId", value = "任务ID", required = true, dataType = "string", paramType = "path")
    public Object auditTask(@PathVariable(value = "taskId", required = true) String taskId,
            @Validated @RequestBody AuditTaskVo vo) {
        try {
            int status = vo.getPassed() ? 3 : 4;
            return new ResponseEntity<Object>(
                    CommonResponse.success(
                            taskService.updateTaskStatusInformation(taskId, vo.getUserId(), status, vo.getMessage())),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse.failure(ResultCodeEnum.TASK_INFORMATION_NOT_FOUND),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据标注-获取标注任务下的图片信息 ", notes = "")
    @RequestMapping(value = "/label/tasks/{taskId}", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "taskId", value = "标注任务ID", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "sortProperties", value = "排序依据，排序字段数组   +前缀代表升序，-前缀代表降序,格式为字符串数组   \"+sort,-sort\"   ", required = false, dataType = "array", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query") })
    public Object getLabelInformationByTaskId(@PathVariable(value = "taskId", required = true) String taskId,
            @RequestParam(value = "sortProperties", required = false) String sortProperties,
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "pageNo", required = false) Integer pageNo) {
        try {
            List<String> list = new ArrayList<String>();
            if (!TextUtils.isEmpty(sortProperties)) {
                for (String s : sortProperties.split(Constant.SPLITCOMMA)) {
                    list.add(s);
                }
            } else {
                list.add("+taskSeq");
            }
            return new ResponseEntity<Object>(
                    CommonResponse.success(taskService.exploreAssignTaskByTaskId(taskId, list, pageNo, pageSize)),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据标注-更新文档的标注信息 ", notes = "")
    @RequestMapping(value = "/label/tasks/{taskId}/{_id}", method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "taskId", value = "任务ID", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "_id", value = "文件ID", required = true, dataType = "string", paramType = "path") })
    public Object updateLabelInformationById(@PathVariable(value = "taskId", required = true) String taskId,
            @PathVariable(value = "_id", required = true) String fileId, @Validated @RequestBody UpdateTaskVo vo) {
        try {
            JSONObject labelObj = null;
            JSONObject tagsObj = null;
            JSONObject infosObj = null;
            if (vo.getTags() != null) {
                tagsObj = vo.getTags();
            }
            if (vo.getInfos() != null) {
                infosObj = vo.getInfos();
            }
            if (vo.getLabels() != null) {
                labelObj = vo.getLabels();
            }

            return new ResponseEntity<Object>(CommonResponse.success(fileService.updateLabelInformation(taskId, fileId,
                    infosObj, tagsObj, labelObj, vo.getLabeler(), vo.getVersion())), HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        } catch (JSONException j) {
            return new ResponseEntity<Object>(
                    CommonResponse.failure(ResultCodeEnum.FILE_LABEL_INFORMATION_ERROR, j.getMessage()), HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据标注-更新文档的审核信息 ", notes = "")
    @RequestMapping(value = "/label/tasks/{taskId}/{_id}", method = RequestMethod.PUT)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "taskId", value = "任务ID", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "_id", value = "文件ID", required = true, dataType = "string", paramType = "path") })
    public Object updateAuditInformationById(@PathVariable(value = "taskId", required = true) String taskId,
            @PathVariable(value = "_id", required = true) String fileId, @Validated @RequestBody FileAuditVo vo) {
        try {
            return new ResponseEntity<Object>(CommonResponse.success(fileService.updateAuditInformation(taskId, fileId,
                    vo.getAuditStatus(), vo.getAuditMessage(), vo.getAuditor(), vo.getVersion())), HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据标注-获取图片的标注信息 ", notes = "")
    @RequestMapping(value = "/label/tasks/{taskId}/{_id}", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "taskId", value = "任务ID", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "_id", value = "文件ID", required = true, dataType = "string", paramType = "path") })
    public Object getLabelInformationById(@PathVariable(value = "taskId", required = true) String taskId,
            @PathVariable(value = "_id", required = true) String fileId) {
        try {
            return new ResponseEntity<Object>(CommonResponse.success(fileService.getLabelInformation(fileId)),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据标注-获取 标注任务列表 ", notes = "")
    @RequestMapping(value = "/label/tasks", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "status", value = "状态0：待领取；1：已领取；2：已提交；3：已通过；4：未通过", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "taskName", value = "任务名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupId", value = "任务组", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "任务领取人ID", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序依据，排序字段数组   +前缀代表升序，-前缀代表降序,格式为字符串数组   \"+sort,-sort\"   ", required = false, dataType = "array", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query") })
    public Object getPersonalTask(@RequestParam(value = "status", required = false) Integer status,
            @RequestParam(value = "taskName", required = false) String taskName,
            @RequestParam(value = "groupId", required = false) String groupId,
            @RequestParam(value = "userId", required = false) String userId,
            @RequestParam(value = "sortProperties", required = false) String sortProperties,
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "pageNo", required = false) Integer pageNo) {
        try {
            List<String> list = new ArrayList<String>();
            if (!TextUtils.isEmpty(sortProperties)) {
                for (String s : sortProperties.split(Constant.SPLITCOMMA)) {
                    list.add(s);
                }
            }
            return new ResponseEntity<Object>(
                    CommonResponse.success(taskService.explorePersonalTask(StringUtil.escapeQueryChars(taskName),
                            groupId, StringUtil.escapeQueryChars(userId), status, list, pageSize, pageNo)),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据标注-领取标注任务", notes = "")
    @RequestMapping(value = "/label/tasks/acquire", method = RequestMethod.PATCH)
    public Object acquireTask(@RequestBody @Validated UserVo userId) {
        int result = (Integer) taskService.acquiredTask(userId.getUserId());
        if (result > 0) {
            return new ResponseEntity<Object>(CommonResponse.success(result), HttpStatus.OK);
        } else if (result == -1) {
            return new ResponseEntity<Object>(CommonResponse.failure(ResultCodeEnum.TASK_EMPTY), HttpStatus.OK);
        } else {
            return new ResponseEntity<Object>(CommonResponse.failure(ResultCodeEnum.TASK_ACQUIRED_FAILED),
                    HttpStatus.OK);
        }

    }
}
