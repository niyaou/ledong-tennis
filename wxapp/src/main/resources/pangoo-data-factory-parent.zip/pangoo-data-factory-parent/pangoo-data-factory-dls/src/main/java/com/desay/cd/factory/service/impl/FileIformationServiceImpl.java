package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import org.apache.http.util.TextUtils;
import org.desay.common.es.search.SearchApi;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.service.IFileIformationService;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;

/**
 * 
 * @author uidq1343
 *
 */
@Service
public class FileIformationServiceImpl implements IFileIformationService {

    @Override
    public Object queryFileInfoByDeviceId(String deviceId, ArrayList<String> sortProperties, boolean flag,
            Integer pageNo, Integer pageSize) {

        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();

        if (StringUtil.isNotEmpty(deviceId)) {
            params.add(SearchApi.createWildCardSearchSource(DEVICEID, deviceId));
        }

        if (params.size() == 0) {
            return null;
        }

        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        Map<String, SortOrder> sortPropertiesQueries = new HashMap<String, SortOrder>(16);
        if (sortProperties == null || sortProperties.size() == 0) {
            sortProperties = new ArrayList<String>();
            sortProperties.add("-" + CREATETIME);
        }
        for (String sortPropertie : sortProperties) {
            if (sortPropertie.startsWith("+")) {
                sortPropertiesQueries.put(sortPropertie.substring(1, sortPropertie.length()), SortOrder.ASC);
            } else if (sortPropertie.startsWith("-")) {
                sortPropertiesQueries.put(sortPropertie.substring(1, sortPropertie.length()), SortOrder.DESC);
            }

        }

        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE,
                sortPropertiesQueries, pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            if (!flag && m.get(ASSIGNEDFLAG) != null && (boolean) m.get(ASSIGNEDFLAG)) {
                continue;
            }
            m.put(IMAGEID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);
        return page;
    }

    @Override
    public Object updateTaskInformation(String fileId, String taskId, String taskName, int taskSeq, String groupId,
            long version) throws ElasticsearchException {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchById(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE, fileId,
                IMAGEID);

        if (dic == null || dic.size() == 0) {
            throw new ElasticsearchException(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage());
        }
        HashMap<String, Object> doc = dic.get(0);
        doc.put(TASKID, taskId);
        doc.put(TASKNAME, taskName);
        doc.put(TASKSEQ, taskSeq);
        doc.put(GROUPID, groupId);
        doc.put(ASSIGNEDTIME, DateUtil.getCurrentTimeStamp());
        doc.put(ASSIGNEDFLAG, true);
        DocWriteResponse result = SearchApi.updateDocumentByLock(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE,
                JSON.toJSONString(doc), fileId, version);
        return result.getResult().equals(Result.UPDATED) ? Result.UPDATED : null;
    }

    @Override
    public Object updateAuditInformation(String taskId, String fileId, boolean auditStatus, String auditMessage,
            String auditor, long version) throws ElasticsearchException {

        LinkedList<HashMap<String, Object>> dic = SearchApi.searchById(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE, fileId,
                IMAGEID);
        if (dic == null || dic.size() == 0) {
            throw new ElasticsearchException(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage());
        }
        HashMap<String, Object> doc = dic.get(0);
        doc.put(ASSIGNEDTIME, DateUtil.getCurrentTimeStamp());
        doc.put(ASSIGNEDFLAG, true);
        doc.put(AUDITSTATUS, auditStatus);
        doc.put(AUDITOR, auditor);
        doc.put(AUDITMESSAGE, auditMessage);
        DocWriteResponse result = SearchApi.updateDocumentByLock(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE,
                JSON.toJSONString(doc), fileId, version);
        return result.getResult().equals(Result.UPDATED) ? Result.UPDATED : null;
    }

    @Override
    public Object updateLabelInformation(String taskId, String fileId, Object infos, Object tags, Object labels,
            String labeler, long version) throws ElasticsearchException {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchById(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE, fileId,
                IMAGEID);
        if (dic == null || dic.size() == 0) {
            throw new ElasticsearchException(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage());
        }
        HashMap<String, Object> doc = dic.get(0);
        doc.put(LABELEDTIME, DateUtil.getCurrentTimeStamp());
        if (tags != null) {
            doc.put(MANUAL_TAGS, tags);
        }
        if (infos != null) {
            doc.put(MANUAL_INFOS, infos);
        }
        doc.put(MANUAL_LABELS, labels);
        doc.put(LABELER, labeler);
        DocWriteResponse result = SearchApi.updateDocumentByLock(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE,
                JSON.toJSONString(doc), fileId, version);
        String deviceName = doc.get(DEVICENAME) == null ? "" : doc.get(DEVICENAME).toString();
        labelingLog(doc.get(TASKID).toString(), doc.get(TASKNAME).toString(), doc.get(DEVICEID).toString(), deviceName,
                fileId, String.valueOf(doc.get(TASKSEQ)), labels, labeler, result.getResult().toString());
        return result.getResult().equals(Result.UPDATED) ? Result.UPDATED : null;
    }

    @Override
    public Object getLabelInformation(String fileId) throws ElasticsearchException {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchById(FILE_INFORMATION_INDEX, PANGOO_DLS_TYPE, fileId,
                IMAGEID);
        if (dic == null || dic.size() == 0) {
            throw new ElasticsearchException(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getMessage());
        }
        HashMap<String, Object> doc = dic.get(0);
        return doc;
    }

    @Override
    public Object labelingLog(String taskId, String taskName, String deviceId, String deviceName, String fileId,
            String taskSeq, Object labels, String labeler, String result) {

        JSONObject doc = new JSONObject();
        if (!TextUtils.isEmpty(taskId)) {
            doc.put(TASKID, taskId);
        }
        if (!TextUtils.isEmpty(taskName)) {
            doc.put(TASKNAME, taskName);
        }
        if (!TextUtils.isEmpty(deviceId)) {
            doc.put(DEVICEID, deviceId);
        }
        if (!TextUtils.isEmpty(deviceName)) {
            doc.put(DEVICENAME, deviceName);
        }
        if (!TextUtils.isEmpty(fileId)) {
            doc.put(FILEID, fileId);
        }
        if (!TextUtils.isEmpty(taskSeq)) {
            doc.put(TASKSEQ, taskSeq);
        }
        if (!TextUtils.isEmpty(labeler)) {
            doc.put(LABELER, labeler);
        }
        if (labels != null) {
            doc.put(LABELS, labels);
        }
        doc.put(LABELEDTIME, DateUtil.getCurrentTimeStamp());
        DocWriteResponse response = SearchApi.insertDocument(FILE_LABEL_LOG_INDEX, TYPE, doc.toJSONString());
        return response.getResult().equals(Result.CREATED) ? response.getId() : null;

    }

}
