/**
 * @author: create by pengdengfu
 * @version: v1.0
 * @description: com.desay.cd.factory.config
 * @date:2020年3月9日
 */
package com.desay.cd.factory.config;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.redisson.api.RLock;
import org.redisson.api.RTopic;
import org.redisson.api.RedissonClient;
import org.redisson.api.listener.MessageListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.desay.cd.factory.constanst.Constanst;
import com.desay.cd.factory.service.ITaskService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author uidq1070
 *
 */
@Component
@Slf4j
public class DeleteUserMessageSubcriber {

    @Autowired
    private RedissonClient redissonClient;
    @Autowired
    private ITaskService taskService;

    @PostConstruct
    public void subscribeDeleteUser() {
        RTopic<String> topic = redissonClient.getTopic(Constanst.DELETE_USER_TOPIC);
        topic.addListener(new MessageListener<String>() {
            @Override
            public void onMessage(String channel, String message) {
                // 多节点环境下，只需要一个节点处理
                RLock dataLock = redissonClient.getLock(Constanst.DELETE_USER_LOCK);
                boolean res = false;
                try {
                    res = dataLock.tryLock(0, -1, TimeUnit.SECONDS);
                    if (res) {
                        log.info("DLS recive message:deleted user :{}", message);
                        // 检查dls中是否有该用户的任务，如果有，进行任务释放
                        try {
                            checkUserDlsTask(message);
                        } catch (Exception e) {
                            log.error("exception happened in checkUserDlsTask.");
                        }
                    }

                } catch (InterruptedException e) {
                    log.error("subscribeDeleteSubsysUser InterruptedException");
                    Thread.currentThread().interrupt();
                } finally {
                    if (res) {
                        dataLock.unlock();
                    }

                }

            }
        });
    }

    @PostConstruct
    public void subscribeDeleteSubsysUser() {
        RTopic<Map<String, String>> topic = redissonClient.getTopic(Constanst.DELETE_SYS_USER_TOPIC);
        topic.addListener(new MessageListener<Map<String, String>>() {
            @Override
            public void onMessage(String channel, Map<String, String> message) {
                RLock dataLock = redissonClient.getLock(Constanst.DELETE_SYS_USER_LOCK);
                boolean res = false;
                try {
                    res = dataLock.tryLock(0, -1, TimeUnit.SECONDS);
                    if (res) {
                        // 获取
                        String userId = message.get(Constanst.PANGOO_DLS_SUBSYS_ID);
                        if (StringUtils.isNotEmpty(userId)) {
                            log.info("DLS recive message:deleted subsystem user :{}", message);
                            try {
                                checkUserDlsTask(userId);
                            } catch (Exception e) {
                                log.error("exception happened in checkUserDlsTask.");
                            }
                        }
                    }
                } catch (InterruptedException e) {
                    log.error("subscribeDeleteSubsysUser InterruptedException");
                    Thread.currentThread().interrupt();
                } finally {
                    if (res) {
                        dataLock.unlock();
                    }

                }

            }
        });
    }

    /**
     * 重试3次，第一次5s后，第二次10s后，第三次20s后
     * 
     * @param userId
     * @throws Exception
     */
    @Retryable(value = { Exception.class }, maxAttempts = 3, backoff = @Backoff(delay = 5000L, multiplier = 1))
    public void checkUserDlsTask(String userId) throws Exception {
        taskService.retreatedTasks(userId);
    }

}
