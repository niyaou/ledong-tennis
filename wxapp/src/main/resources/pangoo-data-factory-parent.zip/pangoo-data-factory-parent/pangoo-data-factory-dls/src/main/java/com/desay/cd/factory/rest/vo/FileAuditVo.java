package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: UserVo
 * @author: nixuchun
 */
//@Data
public class FileAuditVo implements Serializable {

    private static final long serialVersionUID = -820253811352857928L;

    @NotEmpty
    @ApiModelProperty(value = "审核人ID")
    private String auditor;

    @NotNull
    @ApiModelProperty(value = "任务文档版本号，请填入查询到的版本号，更改无效")
    private Long version;

    @ApiModelProperty(value = "文件审核信息")
    private String auditMessage;

    @NotNull
    @ApiModelProperty(value = "审核状态  ---通过:true， 不通过:false")
    private Boolean auditStatus;

    public String getAuditor() {
        return auditor;
    }

    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getAuditMessage() {
        return auditMessage;
    }

    public void setAuditMessage(String auditMessage) {
        this.auditMessage = auditMessage;
    }

    public Boolean getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Boolean auditStatus) {
        this.auditStatus = auditStatus;
    }

}
