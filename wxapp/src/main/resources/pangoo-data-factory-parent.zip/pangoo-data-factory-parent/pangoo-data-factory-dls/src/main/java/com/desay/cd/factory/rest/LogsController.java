package com.desay.cd.factory.rest;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.service.ITaskService;
import com.desay.cd.factory.utils.Constant;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author uidq1343
 *
 */
@RestController
@Api(value = "日志管理", tags = "日志管理")
public class LogsController {
    @Autowired
    private ITaskService taskService;

    @ApiOperation(value = "日志管理-任务标注日志 查看某个标注员一段时间内的标注记录 ", notes = "")
    @RequestMapping(value = "/task/label/logs", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "labeler", value = "标注员", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "isExact", value = "模糊搜索", required = false, dataType = "boolean", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序依据，排序字段数组   +前缀代表升序，-前缀代表降序,格式为字符串数组   \"+sort,-sort\"   ", required = false, dataType = "array", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页条数", required = false, dataType = "int", paramType = "query") })
    public Object exploreLabelLogs(@RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime,
            @RequestParam(value = "labeler", required = false) String labeler,
            @RequestParam(value = "isExact", required = false) Boolean isExact,
            @RequestParam(value = "sortProperties", required = false) String sortProperties,
            @RequestParam(value = "pageNo", required = false) Integer pageNo,
            @RequestParam(value = "pageSize", required = false) Integer pageSize) {
        if (TextUtils.isEmpty(startTime)) {
            startTime = DateUtil.getCurrentDate();
        }
        if (TextUtils.isEmpty(endTime)) {
            endTime = DateUtil.getCurrentDate();
        }
        if (isExact == null) {
            isExact = false;
        }
        List<String> list = new ArrayList<String>();
        if (!TextUtils.isEmpty(sortProperties)) {
            for (String s : sortProperties.split(Constant.SPLITCOMMA)) {
                list.add(s);
            }
        }
        return new ResponseEntity<Object>(
                CommonResponse.success(taskService.exploreLabelLogs(StringUtil.escapeQueryChars(labeler), startTime,
                        endTime, isExact, list, pageNo, pageSize)),
                HttpStatus.OK);
    }

    @ApiOperation(value = "日志管理-任务标注日志 查看某个审核员一段时间内的审核记录 ", notes = "")
    @RequestMapping(value = "/task/audit/logs", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "auditor", value = "审核员", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "isExact", value = "模糊搜索", required = false, dataType = "boolean", paramType = "query"),
            @ApiImplicitParam(name = "auditStatus", value = "审核结果", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序依据，排序字段数组   +前缀代表升序，-前缀代表降序,格式为字符串数组   \"+sort,-sort\"   ", required = false, dataType = "array", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页条数", required = false, dataType = "int", paramType = "query") })
    public Object exploreAuditLogs(@RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime,
            @RequestParam(value = "auditor", required = false) String auditor,
            @RequestParam(value = "isExact", required = false) Boolean isExact,
            @RequestParam(value = "auditStatus", required = false) Integer auditStatus,
            @RequestParam(value = "sortProperties", required = false) String sortProperties,
            @RequestParam(value = "pageNo", required = false) Integer pageNo,
            @RequestParam(value = "pageSize", required = false) Integer pageSize) {
        if (TextUtils.isEmpty(startTime)) {
            startTime = DateUtil.getCurrentDate();
        }
        if (TextUtils.isEmpty(endTime)) {
            endTime = DateUtil.getCurrentDate();
        }
        List<String> list = new ArrayList<String>();
        if (!TextUtils.isEmpty(sortProperties)) {
            for (String s : sortProperties.split(Constant.SPLITCOMMA)) {
                list.add(s);
            }
        }
        if (isExact == null) {
            isExact = false;
        }
        return new ResponseEntity<Object>(
                CommonResponse.success(taskService.exploreAuditlLogs(startTime, endTime,
                        StringUtil.escapeQueryChars(auditor), auditStatus, isExact, list, pageNo, pageSize)),
                HttpStatus.OK);
    }

    @ApiOperation(value = "日志管理-任务领取日志 查看某个标注员一段时间内的领取记录 ", notes = "")
    @RequestMapping(value = "/task/acquired/logs", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "labeler", value = "标注员", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "isExact", value = "模糊搜索", required = false, dataType = "boolean", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序依据，排序字段数组   +前缀代表升序，-前缀代表降序,格式为字符串数组   \"+sort,-sort\"   ", required = false, dataType = "array", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页条数", required = false, dataType = "int", paramType = "query") })
    public Object exploreAcquiredLogs(@RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime,
            @RequestParam(value = "labeler", required = false) String labeler,
            @RequestParam(value = "isExact", required = false) Boolean isExact,
            @RequestParam(value = "sortProperties", required = false) String sortProperties,
            @RequestParam(value = "pageNo", required = false) Integer pageNo,
            @RequestParam(value = "pageSize", required = false) Integer pageSize) {
        if (TextUtils.isEmpty(startTime)) {
            startTime = DateUtil.getCurrentDate();
        }
        if (TextUtils.isEmpty(endTime)) {
            endTime = DateUtil.getCurrentDate();
        }
        if (isExact == null) {
            isExact = false;
        }
        List<String> list = new ArrayList<String>();
        if (!TextUtils.isEmpty(sortProperties)) {
            for (String s : sortProperties.split(Constant.SPLITCOMMA)) {
                list.add(s);
            }
        }
        return new ResponseEntity<Object>(
                CommonResponse.success(taskService.exploreAcquiredTaskLog(StringUtil.escapeQueryChars(labeler),
                        startTime, endTime, isExact, list, pageNo, pageSize)),
                HttpStatus.OK);
    }

}
