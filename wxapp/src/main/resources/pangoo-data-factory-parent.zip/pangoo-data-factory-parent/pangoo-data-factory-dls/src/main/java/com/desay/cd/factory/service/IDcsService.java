package com.desay.cd.factory.service;

import java.util.List;

/**
 * 清洗任务
 * 
 * @author uidq1343
 *
 */

public interface IDcsService extends IndexConstant {

    /**
     * 清洗日志查询接口
     * 
     * @param deviceName
     * @param deviceNameLike
     * @param startTime
     * @param endTime
     * @param fileId
     * @param clearStatus
     * @param sortProperties
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object exploreDcsLogs(String deviceName, Boolean deviceNameLike, String startTime, String endTime, String fileId,
            Integer clearStatus, List<String> sortProperties, Integer pageNo, Integer pageSize);

    /**
     * 清洗日志统计接口
     * 
     * @param startTime
     * @param endTime
     * @return
     */
    Object dcsLogsStatistics(String startTime, String endTime);

    /**
     * 查看清洗失败原因
     * 
     * @param logId
     * @return
     */
    Object dcsFailedReasons(String logId);

    /**
     * 清洗明细统计
     * 
     * @param startTime
     * @param endTime
     * @param sortProperties
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object dcsDetailStatiscs(String startTime, String endTime, List<String> sortProperties, Integer pageNo,
            Integer pageSize);

}
