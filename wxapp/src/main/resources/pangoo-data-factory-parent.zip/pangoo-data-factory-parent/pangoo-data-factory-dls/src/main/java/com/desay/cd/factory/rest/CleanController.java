package com.desay.cd.factory.rest;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.util.TextUtils;
import org.elasticsearch.ElasticsearchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.service.IDcsService;
import com.desay.cd.factory.utils.Constant;
import com.desay.cd.factory.utils.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author uidq1343
 *
 */
@RestController
@Api(value = "数据清洗", tags = "数据清洗")
public class CleanController {

    @Autowired
    private IDcsService dcsService;

    @ApiOperation(value = "数据清洗-清洗日志查询", notes = "")
    @RequestMapping(value = "/clean/log", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "deviceName", value = "设备名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceNameLike", value = "为true时，模糊匹配，其他为精确查询", required = false, dataType = "boolean", paramType = "query"),
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "fileId", value = "文件id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "clearStatus", value = "清洗状态(0：成功，1：失败)", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序依据，排序字段数组   +前缀代表升序，-前缀代表降序,格式为字符串数组   \"+sort,-sort\"   ", required = false, dataType = "array", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "每页条数", required = false, dataType = "int", paramType = "query") })
    public Object exploreDcsLogs(@RequestParam(value = "deviceName", required = false) String deviceName,
            @RequestParam(value = "deviceNameLike", required = false) Boolean deviceNameLike,
            @RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime,
            @RequestParam(value = "fileId", required = false) String fileId,
            @RequestParam(value = "clearStatus", required = false) Integer clearStatus,
            @RequestParam(value = "sortProperties", required = false) String sortProperties,
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "pageNo", required = false) Integer pageNo) {
        try {
            if (deviceNameLike == null) {
                deviceNameLike = true;
            }
            List<String> list = new ArrayList<String>();
            if (!TextUtils.isEmpty(sortProperties)) {
                for (String s : sortProperties.split(Constant.SPLITCOMMA)) {
                    list.add(s);
                }
            }
            return new ResponseEntity<Object>(
                    CommonResponse.success(dcsService.exploreDcsLogs(StringUtil.escapeQueryChars(deviceName),
                            deviceNameLike, startTime, endTime, fileId, clearStatus, list, pageNo, pageSize)),
                    HttpStatus.OK);
        } catch (ElasticsearchException e) {
            return new ResponseEntity<Object>(CommonResponse
                    .failure(e.getMessage().equals(ResultCodeEnum.FILE_INFORMATION_NOT_FOUND.getCode().toString())
                            ? ResultCodeEnum.FILE_INFORMATION_NOT_FOUND
                            : ResultCodeEnum.FILE_TASKINFO_UPDATE_LOCKED),
                    HttpStatus.OK);
        }
    }

    @ApiOperation(value = "数据清洗-清洗结果统计", notes = "")
    @RequestMapping(value = "/clean/statistics/odds", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = false, dataType = "string", paramType = "query") })
    public Object dcsLogsStatistics(@RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime) {
        return new ResponseEntity<Object>(CommonResponse.success(dcsService.dcsLogsStatistics(startTime, endTime)),
                HttpStatus.OK);

    }

    @ApiOperation(value = "数据清洗-清洗失败原因", notes = "")
    @RequestMapping(value = "/clean/log/failedReason", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "logId", value = "日志ID", required = false, dataType = "string", paramType = "query") })
    public Object dcsFailedReasons(@RequestParam(value = "logId", required = false) String logId) {
        return new ResponseEntity<Object>(CommonResponse.success(dcsService.dcsFailedReasons(logId)), HttpStatus.OK);

    }

    @ApiOperation(value = "数据清洗-清洗明细统计", notes = "")
    @RequestMapping(value = "/clean/statistics/details", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startTime", value = "开始时间", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序依据，排序字段数组   +前缀代表升序，-前缀代表降序,格式为字符串数组   \"+sort,-sort\"   ", required = false, dataType = "array", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "每页条数", required = false, dataType = "int", paramType = "query") })
    public Object dcsLogsStatisticsDetail(@RequestParam(value = "startTime", required = true) String startTime,
            @RequestParam(value = "endTime", required = true) String endTime,
            @RequestParam(value = "sortProperties", required = false) String sortProperties,
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "pageNo", required = false) Integer pageNo) {
        List<String> list = new ArrayList<String>();
        if (!TextUtils.isEmpty(sortProperties)) {
            for (String s : sortProperties.split(Constant.SPLITCOMMA)) {
                list.add(s);
            }
        }
        return new ResponseEntity<Object>(
                CommonResponse.success(dcsService.dcsDetailStatiscs(startTime, endTime, list, pageSize, pageNo)),
                HttpStatus.OK);

    }

}
