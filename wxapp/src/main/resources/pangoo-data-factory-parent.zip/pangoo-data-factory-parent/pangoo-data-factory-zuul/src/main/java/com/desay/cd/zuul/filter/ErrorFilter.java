package com.desay.cd.zuul.filter;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

/**
 * 
 * @Description： 异常过滤器
 * @author Shouyi.Huang@desay-svautomotive.com on [2019年11月22日上午8:38:33]
 * @Modified By： [修改人] on [修改日期] for [修改说明]
 *
 */
@Component
public class ErrorFilter extends ZuulFilter {

    /**
     * pre：可以在请求被路由之前调用 routing：在路由请求时候被调用 post：在routing和error过滤器之后被调用
     * error：处理请求时发生错误时被调用
     *
     * @return
     */
    @Override
    public String filterType() {
        return "error";
    }

    /**
     * 过滤器执行顺序
     */
    @Override
    public int filterOrder() {
        return 10;
    }

    /**
     * 过滤器开关
     */
    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() {
        RequestContext ctx = RequestContext.getCurrentContext();
        Throwable throwable = ctx.getThrowable();
        ctx.set("error.status_code", HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        ctx.set("error.exception", throwable.getCause());
        return null;
    }

}
