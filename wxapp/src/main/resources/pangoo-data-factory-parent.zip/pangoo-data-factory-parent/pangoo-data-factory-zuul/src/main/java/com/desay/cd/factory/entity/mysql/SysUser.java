package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;

/**
 * 系统用户
 * 
 * @author pengdengfu
 *
 */
public class SysUser implements Serializable {

    private static final long serialVersionUID = 5154767751636642095L;

    private String userId;
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysUser other = (SysUser) obj;
        if (userId == null) {
            if (other.userId != null) {
                return false;
            }
        } else if (!userId.equals(other.userId)) {
            return false;
        }
        return true;
    }

}
