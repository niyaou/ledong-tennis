package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;

/**
 * 系统权限
 * 
 * @author pengdengfu
 *
 */
public class SysPermission implements Serializable {

    private static final long serialVersionUID = -462282051234984338L;

    private String permissionId;

    /** 权限名称 */
    private String permissionName;

    /** url的方法 */
    private String method;

    /** 权限对应的url */
    private String url;

    /** 权限描述 */
    private String permissionDesc;


    /** 是否可用，0，不可用，1，可用 */
    private String isActive = "1";

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPermissionDesc() {
        return permissionDesc;
    }

    public void setPermissionDesc(String permissionDesc) {
        this.permissionDesc = permissionDesc;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((permissionId == null) ? 0 : permissionId.hashCode());
        result = prime * result + ((permissionName == null) ? 0 : permissionName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysPermission other = (SysPermission) obj;
        if (permissionId == null) {
            if (other.permissionId != null) {
                return false;
            }
        } else if (!permissionId.equals(other.permissionId)) {
            return false;
        }
        if (permissionName == null) {
            if (other.permissionName != null) {
                return false;
            }
        } else if (!permissionName.equals(other.permissionName)) {
            return false;
        }
        return true;
    }

   
}
