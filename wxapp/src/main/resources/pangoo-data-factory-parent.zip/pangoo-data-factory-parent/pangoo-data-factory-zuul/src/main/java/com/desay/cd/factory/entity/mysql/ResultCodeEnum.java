package com.desay.cd.factory.entity.mysql;


/**
 * 响应码
 * 
 * @author pengdengfu
 *
 */
public enum ResultCodeEnum {

    /** 成功状态码 */
    SUCCESS(0, "成功"),
    TOKEN_PERMSSION_ERROR(10005, "token认证失败"),
    /** 权限错误：70001-79999 */
    PERMISSION_NO_ACCESS(70001, "无访问权限"),
    /** 未知错误 */
    UNKOWN_ERROR(90001, "未知错误");

    private Integer code;

    private String message;

    public Integer getCode() {
        return code;
    }
    public String getMessage() {
        return message;
    }

    ResultCodeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }


    public static String getMessage(String name) {
        for (ResultCodeEnum item : ResultCodeEnum.values()) {
            if (item.name().equals(name)) {
                return item.message;
            }
        }
        return name;
    }

    public static Integer getCode(String name) {
        for (ResultCodeEnum item : ResultCodeEnum.values()) {
            if (item.name().equals(name)) {
                return item.code;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return this.name();
    }
}
