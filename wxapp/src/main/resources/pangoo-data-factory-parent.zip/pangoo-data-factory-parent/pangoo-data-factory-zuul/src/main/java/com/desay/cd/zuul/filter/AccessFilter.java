package com.desay.cd.zuul.filter;

import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.session.ExpiringSession;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.StringUtils;

import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.auth.uitls.ConstantUtils;
import com.desay.cd.factory.entity.mysql.CommonResponse;
import com.desay.cd.factory.entity.mysql.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.google.gson.Gson;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

/**
 * 请求过滤
 * 
 * @author uidq1163
 *
 */
@Component
@SuppressWarnings("rawtypes")
public class AccessFilter extends ZuulFilter {
    @Autowired
    private FindByIndexNameSessionRepository findByIndexNameSessionRepository;

    private static final String POST_METHOD="POST";
    private static final String FILESYSTEM="/fileSystem/files";
    /**
     * pre：可以在请求被路由之前调用 routing：在路由请求时候被调用 post：在routing和error过滤器之后被调用
     * error：处理请求时发生错误时被调用
     *
     * @return
     */
    @Override
    public String filterType() {
        return "pre";
    }

    /**
     * 过滤器执行顺序
     */
    @Override
    public int filterOrder() {
        return 0;
    }

    /**
     * 是否执行该过滤器。
     *
     * true：说明需要过滤；
     *
     * false：说明不要过滤；
     *
     * @return
     */
    @Override
    public boolean shouldFilter() {
        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();
        String uri = request.getRequestURI();
        String method = request.getMethod();
        // 不需要过滤的url
        String rex = "(getPassWordRSA)|(auth)|(\\.html)|(\\.css)|(\\.js)|(\\.woff)|(v2/api-docs)|(swagger-resources)";
        Pattern sinaPatten = Pattern.compile(rex, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
        // 获取此请求的地址
        Matcher matcher = sinaPatten.matcher(uri);
        //根据条件去判断是否需要路由，是否需要执行该过滤器
        if (matcher.find()) {
            return false;
        }
        if ((uri.endsWith(FILESYSTEM) && POST_METHOD.equals(method.toUpperCase()))) {
            return false;
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object run() {
        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();
        // 获取此请求的地址
        // 非法路径处理
        String uri = request.getRequestURI();
        // 请求的方法
        String method = request.getMethod();
        Object token = request.getHeader("access_token");
        Boolean tokenFlg = Boolean.FALSE;
        Boolean urlFlg = Boolean.FALSE;
        if (null != token) {
            ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token.toString());
            TokenDto tokenDto = null;
            if (session != null) {
                tokenDto = session.getAttribute(ConstantUtils.SESSION_TOKEN);
                session.setLastAccessedTime(System.currentTimeMillis());
                findByIndexNameSessionRepository.save(session);
            }
            if (null != tokenDto) {
                tokenFlg = Boolean.TRUE;
                Map<String, Object> sysUser = (Map<String, Object>) tokenDto.getUserInfo();
                Set<SysPermission> sysPermissions = (Set<SysPermission>) sysUser.get("permissions");
                for (SysPermission sysPermission : sysPermissions) {
                    if (!StringUtils.isEmpty(sysPermission.getUrl())) {
                        AntPathMatcher methodmatcher = new AntPathMatcher();
                        String methodpattern = sysPermission.getUrl();
                        if (methodmatcher.match(methodpattern, uri)
                                && sysPermission.getMethod().toUpperCase().equals(method)) {
                            urlFlg = true;
                            break;
                        }
                    }
                }
            }
        }
        if (tokenFlg && urlFlg) {
            return true;
        } else {
            if (!tokenFlg) {
                // 认证失败
                ctx.setSendZuulResponse(false);
                ctx.setResponseStatusCode(401);
                ctx.getResponse().setContentType("text/html;charset=UTF-8");
                ctx.setResponseBody(new Gson().toJson(CommonResponse.failure(ResultCodeEnum.TOKEN_PERMSSION_ERROR)));
                return null;
            }
            if (!urlFlg) {
                // 该接口没有访问权限
                ctx.setSendZuulResponse(false);
                ctx.setResponseStatusCode(401);
                ctx.getResponse().setContentType("text/html;charset=UTF-8");
                ctx.setResponseBody(new Gson().toJson(CommonResponse.failure(ResultCodeEnum.PERMISSION_NO_ACCESS)));
                return null;
            }
        }
        return null;
    }
}
