package com.desay.cd.factory.rest.vo;

import java.util.Map;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddDeviceVo
 * @author: pengdengfu
 * @date: 2019年4月8日 下午4:07:17
 */
public class AddDeviceVo {
    @ApiModelProperty(value = "设备名称(0<size<=30)", required = true)
    private String deviceName;
    @ApiModelProperty(value = "设备属性名称key-value(0<size<=30),忽略长度超多30的", required = false)
    private Map<String, String> deviceAttributeNames;
    @ApiModelProperty(value = "设备类型Id", required = false)
    private String deviceTypeId;
    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", example = "1", required = false)
    private String status;

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Map<String, String> getDeviceAttributeNames() {
        return deviceAttributeNames;
    }

    public void setDeviceAttributeNames(Map<String, String> deviceAttributeNames) {
        this.deviceAttributeNames = deviceAttributeNames;
    }

    public String getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(String deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return " [deviceName=" + deviceName + ", deviceAttributeNames=" + deviceAttributeNames + ", deviceTypeId=" + deviceTypeId + ", status=" + status + "]";
    }

}
