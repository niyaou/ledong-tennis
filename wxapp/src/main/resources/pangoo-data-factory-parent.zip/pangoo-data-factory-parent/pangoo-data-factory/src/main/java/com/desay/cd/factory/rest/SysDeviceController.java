package com.desay.cd.factory.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysDevice;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddDeviceVo;
import com.desay.cd.factory.rest.vo.UpdateDeviceVo;
import com.desay.cd.factory.service.ISysDeviceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 产品和设备管理
 * 
 * @ClassName: SysDeviceController
 * @author: pengdengfu
 * @date: 2019年4月8日 上午11:28:00
 */
@RestController
@Api(value = "产品管理-设备管理", tags = "SysDeviceController")
public class SysDeviceController {
    @Autowired
    ISysDeviceService deviceService;

    /**
     * 添加设备
     * 
     * @param addDeviceVo
     * @return
     */
    @RequestMapping(value = "/management/devices", method = RequestMethod.POST)
    @ApiOperation(value = "设备管理-添加设备", notes = "{<br>" + "  \"deviceAttributeNames\": {},//设备属性列表，<b>可选</b><br>" + "  \"deviceName\": \"string\",//设备名称，<b>必选</b><br>"
            + "  \"deviceTypeId\": \"string\"//设备类型Id,<b>可选</b><br>" + "}")
    @LogAnnotation(action = LogActionEnum.DEVICE, message = "设备管理-添加设备")
    public ResponseEntity<?> addDevice(@RequestBody AddDeviceVo addDeviceVo) {
        SysDevice sysDevice = deviceService.addDevice(addDeviceVo.getDeviceName(), addDeviceVo.getDeviceAttributeNames(), addDeviceVo.getDeviceTypeId(), addDeviceVo.getStatus());
        return new ResponseEntity<Object>(CommonResponse.success(sysDevice.getDeviceId()), HttpStatus.OK);
    }

    /**
     * 设备管理-删除设备
     * 
     * @param deviceId
     * @return
     */
    @RequestMapping(value = "/management/devices/{deviceId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "设备管理-删除设备", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceId", value = "设备Id", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.DEVICE, message = "设备管理-删除设备")
    public ResponseEntity<?> deleteDevice(@PathVariable(value = "deviceId", required = true) String deviceId) {
        deviceService.deleteDevice(deviceId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 设备管理-更新设备
     * 
     * @param deviceId
     * @param deviceName
     * @return
     */
    @RequestMapping(value = "/management/devices/{deviceId}", method = RequestMethod.PUT)
    @ApiOperation(value = "设备管理-更新设备", notes = "\"deviceAttributeNames\": [<br>" + "  {<br>" + "    \"attributeId\": \"8a5982646b002505016b015837c6000a\",<br>"
            + "    \"attributeName\": \"8\",<br>" + "    \"attributeValue\": \"888\"<br>" + "  },<br>" + "  {<br>"
            + "    \"attributeId\": \"8a5982646b002505016b015837b20009\",<br>" + "    \"attributeName\": \"7\",<br>" + "    \"attributeValue\": \"777\"<br>" + "  },<br>"
            + "  {<br>" + "    \"attributeName\": \"9\",<br>" + "    \"attributeValue\": \"999\"<br>" + "  }<br>" + "]")
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceId", value = "设备Id", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.DEVICE, message = "设备管理-更新设备")
    public ResponseEntity<?> updateDevice(@PathVariable(value = "deviceId", required = true) String deviceId, @RequestBody UpdateDeviceVo updateDeviceVo) {
        deviceService.updateDevice(deviceId, updateDeviceVo.getDeviceName(), updateDeviceVo.getDeviceAttributeNames(), updateDeviceVo.getDeviceTypeId(),
                updateDeviceVo.getStatus());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /***
     * 设备管理-更新设备-删除设备属性
     * 
     * @param deviceId
     * @param deleteDeviceAttrinuteIds
     * @return
     */
    @RequestMapping(value = "/management/devices/{deviceId}/attributes/{attributeId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "设备管理-更新设备-删除设备属性", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceId", value = "设备Id", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "attributeId", value = "设备属性Id", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.DEVICE, message = "设备管理-更新设备-删除设备属性")
    public ResponseEntity<?> updateDeviceDeleteAttribute(@PathVariable(value = "deviceId", required = true) String deviceId,
            @PathVariable(value = "attributeId", required = false) String attributeId) {
        deviceService.updateDeviceDeleteAttribute(deviceId, attributeId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /***
     * 设备管理-更新设备-删除设备类型
     * 
     * @param deviceId
     * @param deleteDeviceAttrinuteIds
     * @return
     */
    @RequestMapping(value = "/management/devices/{deviceId}/deviceType/{deviceTypeId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "设备管理-更新设备-删除设备类型", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceId", value = "设备Id", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "deviceTypeId", value = "设备类型Id", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.DEVICE, message = "设备管理-更新设备-删除设备类型")
    public ResponseEntity<?> updateDeviceDeleteDeviceType(@PathVariable(value = "deviceId", required = true) String deviceId,
            @PathVariable(value = "deviceTypeId", required = false) String deviceTypeId) {
        deviceService.updateDeviceDeleteDeviceType(deviceId, deviceTypeId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取设备
     * 
     * @param pageNo
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/management/devices", method = RequestMethod.GET)
    @ApiOperation(value = "设备管理-获取设备列表", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceId", value = "设备ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceName", value = "设备名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "deviceTypeId", value = "设备类型Id（返回该设备类型的所有设备）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "hasCleanStrategy", value = "是否已分配清洗策略，0，无；1，有", required = false, dataType = "string", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "hasTaskStrategy", value = "是否已分配任务分配策略，0，无；1，有", required = false, dataType = "string", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.DEVICE, message = "设备管理-获取设备列表")
    public ResponseEntity<?> getDevices(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "deviceId", required = false) String deviceId, @RequestParam(value = "deviceName", required = false) String deviceName,
            @RequestParam(value = "status", required = false) String status, @RequestParam(value = "deviceTypeId", required = false) String deviceTypeId,
            @RequestParam(value = "hasCleanStrategy", required = false) String hasCleanStrategy, @RequestParam(value = "hasTaskStrategy", required = false) String hasTaskStrategy,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection) {
        Page<SysDevice> devices = deviceService.listDevice(pageNo, pageSize, deviceId, deviceName, status, deviceTypeId, hasCleanStrategy, hasTaskStrategy, sortProperties,
                sortDirection);
        return new ResponseEntity<Object>(CommonResponse.success(devices), HttpStatus.OK);
    }
}
