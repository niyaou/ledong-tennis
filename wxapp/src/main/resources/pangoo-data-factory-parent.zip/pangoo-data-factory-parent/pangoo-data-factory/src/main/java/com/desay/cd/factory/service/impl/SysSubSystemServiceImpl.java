package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.redisson.api.RTopic;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.auth.LdapAuthorize;
import com.desay.cd.auth.dto.PersonDto;
import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysGroupDao;
import com.desay.cd.factory.dao.ISysSubSystemDao;
import com.desay.cd.factory.dao.ISysUserDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysGroup;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.rest.vo.GroupVO;
import com.desay.cd.factory.rest.vo.SysGroupVo;
import com.desay.cd.factory.service.ISysGroupService;
import com.desay.cd.factory.service.ISysRoleService;
import com.desay.cd.factory.service.ISysSubSystemService;
import com.desay.cd.factory.service.ISysUserService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @ClassName: DeviceServiceImpl
 * @author: pengdengfu
 * @date: 2019年4月8日 上午10:56:27
 */
@Service
@Transactional(rollbackOn = Exception.class)
@Slf4j
public class SysSubSystemServiceImpl implements ISysSubSystemService {
    @Autowired
    private ISysSubSystemDao sysSubSystemDao;
    @Autowired
    private ISysUserDao sysUserDao;
    @Autowired
    LdapAuthorize ldapAuthorize;
    @Autowired
    ISysRoleService sysRoleService;
    @Autowired
    ISysGroupService sysGroupService;
    @Autowired
    private ISysGroupDao sysGroupDao;

    @Autowired
    private ISysUserService userService;
    @Autowired
    private RedissonClient redissonClient;

    @Override
    public SysSubSystem addSubSystem(String subSystemName, String subSystemDesc, Set<String> userIds, String status) {
        checkSubSystemName(subSystemName, true, null);
        SysSubSystem sysSubSystem = new SysSubSystem();
        if (StringUtils.isNotEmpty(subSystemName)) {
            SysSubSystem sysSubSystemCheck = sysSubSystemDao.findBySubsystemName(subSystemName);
            if (sysSubSystemCheck != null && Constanst.ACTIVE_STATUS_0.equals(sysSubSystemCheck.getIsActive())) {
                throw new CustumException(ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getCode(), ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getMessage(), sysSubSystemCheck);
            }
            sysSubSystem.setSubsystemName(subSystemName);
        }
        if (StringUtils.isNotEmpty(subSystemDesc)) {
            sysSubSystem.setSubsystemDesc(subSystemDesc);
        }
        if (StringUtils.isNotEmpty(status)) {
            ControllerCommonUtils.checkStatus(status);
            sysSubSystem.setIsActive(status);
        }

        // 检查Userids，并且添加关联关系
        checkUserIds(userIds, sysSubSystem);
        SysSubSystem subSystem = null;
        try {
            subSystem = sysSubSystemDao.saveAndFlush(sysSubSystem);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.SUB_SYSTEM_NAME_EXISTED.getCode(), ResultCodeEnum.SUB_SYSTEM_NAME_EXISTED.getMessage());
        }
        return subSystem;
    }

    @Override
    public void deleteSubSystem(String subSystemId) {
        SysSubSystem sysSubSystem = checkSubSystemId(subSystemId);
        sysSubSystem.setIsActive(Constanst.ACTIVE_STATUS_0);

        try {
            sysSubSystemDao.saveAndFlush(sysSubSystem);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public void deleteSubSystemUsers(String subSystemId, Set<String> userIds, String loginUserId) {
        // 检查subSystemId
        SysSubSystem subSystem = checkSubSystemId(subSystemId);
        if (userIds != null && userIds.size() > 0) {
            Set<SysUser> sysUsers = subSystem.getSysUsers();
            if (sysUsers == null) {
                sysUsers = new HashSet<>(userIds.size());
            }
            Page<SysRole> sysRoles = sysRoleService.getSysRoles(Integer.toString(Constanst.FIRST_PAGE_NO), Integer.toString(Integer.MAX_VALUE), null, null, subSystemId, null, null,
                    null, null);
            for (String userId : userIds) {
                if (StringUtils.isEmpty(loginUserId)) {
                    throw new CustumException(ResultCodeEnum.USER_NOT_LOGGED_IN.getCode(), ResultCodeEnum.USER_NOT_LOGGED_IN.getMessage());
                }
                if (loginUserId.equals(userId)) {
                    throw new CustumException(ResultCodeEnum.USER_CANNOT_DELETE_SELF.getCode(), ResultCodeEnum.USER_CANNOT_DELETE_SELF.getMessage());
                }
                SysUser sysUser = sysUserDao.findOne(userId);
                if (sysUser != null) {
                    if (sysUsers.contains(sysUser)) {
                        // boolean checkTask = ControllerCommonUtils.checkTask(null, userId);
                        // if (!checkTask) {
                        // throw new BusinessException(ResultCodeEnum.TASK_NOT_FINISHED, null,
                        // ResultCodeEnum.TASK_NOT_FINISHED.getMessage());
                        // }
                        sysUser.getSysRoles().removeAll(sysRoles.getContent());
                        sysUsers.remove(sysUser);

                        // 删除组关系
                        Page<SysGroup> search = sysGroupService.search(userId, null, null, null, null, null, null, null, null, null, null, Integer.MAX_VALUE, null);
                        sysUser.getMasterGroups().removeAll(search.getContent());
                        sysUser.getMemberGroups().removeAll(search.getContent());

                    } else {
                        throw new CustumException(ResultCodeEnum.SUB_SYSTEM_HAVING_NOT_USER.getCode(), ResultCodeEnum.SUB_SYSTEM_HAVING_NOT_USER.getMessage());
                    }

                } else {
                    throw new CustumException(ResultCodeEnum.USER_NOT_EXIST.getCode(), ResultCodeEnum.USER_NOT_EXIST.getMessage());
                }
            }
            sysUserDao.save(sysUsers);
            subSystem.setSysUsers(sysUsers);
        }

        try {
            sysSubSystemDao.saveAndFlush(subSystem);
            log.info("delete user : {} in subsystem {}", userIds, subSystemId);
            if (userIds != null && userIds.size() > 0) {
                // 发送删除用户的消息
                RTopic<Map<String, String>> topic = redissonClient.getTopic(Constanst.DELETE_SYS_USER_TOPIC);

                userIds.forEach(userId -> {
                    Map<String, String> map = new HashMap<>(1);
                    map.put(subSystemId, userId);
                    topic.publish(map);
                });
            }

        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.SUB_SYSTEM_NAME_EXISTED.getCode(), ResultCodeEnum.SUB_SYSTEM_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public void updateSubSystem(String subSystemId, String subSystemName, String subSystemDesc, Set<String> userIds, String status) {
        // 检查subSystemId
        SysSubSystem subSystem = checkSubSystemId(subSystemId);
        // 检查subSystemName
        checkSubSystemName(subSystemName, false, subSystemId);
        if (StringUtils.isNotEmpty(subSystemName)) {
            subSystem.setSubsystemName(subSystemName);
        }
        if (StringUtils.isNotEmpty(subSystemDesc)) {
            subSystem.setSubsystemDesc(subSystemDesc);
        }
        // 检查Userids，并且添加关联关系
        checkUserIds(userIds, subSystem);
        if (StringUtils.isNotEmpty(status)) {
            ControllerCommonUtils.checkStatus(status);
            subSystem.setIsActive(status);
            Set<SysRole> sysRoles = subSystem.getSysRoles();
            Set<SysPermission> sysPermissions = subSystem.getSysPermissions();
            for (SysRole sysRole : sysRoles) {
                sysRole.setIsActive(status);
            }
            for (SysPermission sysPermission : sysPermissions) {
                sysPermission.setIsActive(status);
            }
        }

        try {
            sysSubSystemDao.saveAndFlush(subSystem);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.SUB_SYSTEM_NAME_EXISTED.getCode(), ResultCodeEnum.SUB_SYSTEM_NAME_EXISTED.getMessage());
        }
    }

    @Override
    public Page<SysSubSystem> getSubSystems(String pageNo, String pageSize, String subSystemName, String subSystemId, String status, List<String> properties,
            String sortDirection) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, properties, sortDirection, "subsystemName");
        if (StringUtils.isNotEmpty(subSystemName)) {
            subSystemName = subSystemName.replaceAll("%", "\\\\%");
            subSystemName = subSystemName.replaceAll("_", "\\\\_");
        }
        final String subSystemNameTmp = subSystemName;
        Specification<SysSubSystem> specification = new Specification<SysSubSystem>() {
            @Override
            public Predicate toPredicate(Root<SysSubSystem> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                // 特殊字符转义
                if (StringUtils.isNotEmpty(subSystemNameTmp)) {
                    predicates.add(cb.like(root.get("subsystemName"), "%" + subSystemNameTmp + "%"));
                }
                if (StringUtils.isNotEmpty(subSystemId)) {
                    predicates.add(cb.equal(root.get("subsystemId"), subSystemId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        return sysSubSystemDao.findAll(specification, pageable);
    }

    /**
     * 检查subSystemId
     * 
     * @param subSystemId
     * @return
     */
    private SysSubSystem checkSubSystemId(String subSystemId) {
        if (StringUtils.isEmpty(subSystemId)) {
            throw new CustumException(ResultCodeEnum.SUB_SYSTEM_ID_CANNOT_NULL.getCode(), ResultCodeEnum.SUB_SYSTEM_ID_CANNOT_NULL.getMessage());
        }
        SysSubSystem findOne = sysSubSystemDao.findOne(subSystemId);
        if (findOne == null) {
            throw new CustumException(ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED.getCode(), ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED.getMessage());
        }

        return findOne;
    }

    /**
     * 检查userIds
     * 
     * @param userIds
     * @param subSystem
     */
    private void checkUserIds(Set<String> userIds, SysSubSystem subSystem) {
        if (userIds != null) {
            Set<SysUser> sysUsers = subSystem.getSysUsers();
            if (sysUsers == null) {
                sysUsers = new HashSet<>(userIds.size());
            }
            for (String userId : userIds) {
                SysUser sysUser = sysUserDao.findOne(userId);
                if (sysUser != null) {
                    if (!sysUsers.contains(sysUser)) {
                        sysUsers.add(sysUser);
                    } else {
                        throw new CustumException(ResultCodeEnum.USER_HAS_EXISTED.getCode(), ResultCodeEnum.USER_HAS_EXISTED.getMessage());
                    }
                } else {
                    // 判断UID账户系统是否存在该用户
                    Map<String, ArrayList<String>> searchUserById = null;
                    try {
                        searchUserById = ldapAuthorize.searchUserById(userId);
                    } catch (Exception e) {
                        throw new CustumException(ResultCodeEnum.LDAP_CONNECT_FAILED.getCode(), ResultCodeEnum.LDAP_CONNECT_FAILED.getMessage());
                    }
                    if (searchUserById == null) {
                        throw new CustumException(ResultCodeEnum.UID_USER_NOT_EXIST.getCode(), ResultCodeEnum.UID_USER_NOT_EXIST.getMessage());
                    }
                    sysUser = new SysUser();
                    sysUser.setUserId(userId);
                    // 从缓存中取用户信息
                    getInfoFromCache(sysUser);
                    sysUsers.add(sysUser);
                }
            }
            sysUserDao.save(sysUsers);
            subSystem.setSysUsers(sysUsers);
        }
    }

    /**
     * 从缓存中取用户信息
     * 
     * @param sysUser
     */
    public void getInfoFromCache(SysUser sysUser) {
        PersonDto person = (PersonDto) ldapAuthorize.get(sysUser.getUserId());
        if (person != null) {
            ArrayList<String> mail = person.getMail();
            if (mail != null && mail.size() > 0) {
                sysUser.setEmail(mail.get(0));
            }
            ArrayList<String> mailnickname = person.getName();
            if (mailnickname != null && mailnickname.size() > 0) {
                sysUser.setUserName(mailnickname.get(0));
            }
            ArrayList<String> thumbnailPhoto = person.getThumbnailPhoto();
            if (thumbnailPhoto != null && thumbnailPhoto.size() > 0) {
                sysUser.setAvatar(thumbnailPhoto.get(0));
            }
        }
    }

    /**
     * 检查subSystemName
     * 
     * @param subSystemName
     * @param checkEmpty
     * @param subSystemId
     * @return
     */
    private void checkSubSystemName(String subSystemName, boolean checkEmpty, String subSystemId) {
        // 如果设备名称为空
        if (checkEmpty) {
            if (StringUtils.isEmpty(subSystemName)) {
                throw new CustumException(ResultCodeEnum.SUB_SYSTEM_NAME_CONNOT_NULL.getCode(), ResultCodeEnum.SUB_SYSTEM_NAME_CONNOT_NULL.getMessage());
            }
            if (subSystemName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.SUB_SYSTEM_NAME_TOO_LONG.getCode(), ResultCodeEnum.SUB_SYSTEM_NAME_TOO_LONG.getMessage());
            }
        } else {
            if (StringUtils.isNotEmpty(subSystemName) && subSystemName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.SUB_SYSTEM_NAME_TOO_LONG.getCode(), ResultCodeEnum.SUB_SYSTEM_NAME_TOO_LONG.getMessage());
            }
        }
        if (StringUtils.isEmpty(subSystemName)) {
            return;
        }

    }

    @Override
    public void deleteSubsystemGroup(String subSystemId, String groupId) {
        checkSubSystemId(subSystemId);
        SysGroup findOne = sysGroupDao.findOne(groupId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        Page<SysGroup> searchGroup = sysGroupService.search(null, groupId, subSystemId, null, null, null, null, null, null, null, null, Integer.MAX_VALUE, null);

        if (searchGroup != null && searchGroup.getContent() != null && searchGroup.getContent().size() > 0) {
            // boolean checkTask = ControllerCommonUtils.checkTask(groupId, null);
            // if (!checkTask) {
            // throw new BusinessException(ResultCodeEnum.TASK_NOT_FINISHED, null,
            // ResultCodeEnum.TASK_NOT_FINISHED.getMessage());
            // }
            sysGroupService.delete(groupId);
        } else {
            throw new BusinessException(ResultCodeEnum.SUB_SYSTEM_NOT_MATCH_GROUP, null, ResultCodeEnum.SUB_SYSTEM_NOT_MATCH_GROUP.getMessage());
        }
    }

    @Override
    public void updateSubsystemGroup(String subSystemId, String groupId, SysGroupVo sysGroupVo, boolean isOverall) {
        checkSubSystemId(subSystemId);
        SysGroup findOne = sysGroupDao.findOne(groupId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        Page<SysGroup> searchGroup = sysGroupService.search(null, groupId, subSystemId, null, null, null, null, null, null, null, null, Integer.MAX_VALUE, null);
        if (searchGroup != null && searchGroup.getContent() != null && searchGroup.getContent().size() > 0) {
            sysGroupService.update(groupId, sysGroupVo, isOverall);
        } else {
            throw new BusinessException(ResultCodeEnum.SUB_SYSTEM_NOT_MATCH_GROUP, null, ResultCodeEnum.SUB_SYSTEM_NOT_MATCH_GROUP.getMessage());
        }
    }

    @Override
    public SysUser addSubSystemUsers(String subSystemId, String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups) {
        checkSubSystemId(subSystemId);
        if (subSystemIds == null) {
            subSystemIds = new HashSet<>(1);
        }
        subSystemIds.add(subSystemId);
        Page<SysUser> sysUsers = userService.getSysUsers(null, Integer.toString(Integer.MAX_VALUE), userId, null, null, subSystemId, null, null, null, null, null, null, null,
                null);
        if (sysUsers != null && sysUsers.getContent() != null && !sysUsers.getContent().isEmpty()) {
            throw new BusinessException(ResultCodeEnum.SUB_SYSTEM_HAVING_EXISTED_USER, null, ResultCodeEnum.SUB_SYSTEM_HAVING_EXISTED_USER.getMessage());
        } else {
            SysUser user = new SysUser();
            Page<SysUser> sysUser = userService.getSysUsers(null, Integer.toString(Integer.MAX_VALUE), userId, null, null, null, null, null, null, null, null, null, null, null);
            if (sysUser != null && sysUser.getContent() != null && !sysUser.getContent().isEmpty()) {
                user = userService.updateUser(userId, status, roleIds, subSystemIds, abilityIds, groups);
            } else {
                user = userService.addUser(userId, status, roleIds, subSystemIds, abilityIds, groups);
            }
            return user;
        }
    }

    @Override
    public void updateUser(String subSystemId, String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups) {
        checkSubSystemId(subSystemId);
        if (subSystemIds == null) {
            subSystemIds = new HashSet<>(1);
        }
        subSystemIds.add(subSystemId);

        Page<SysUser> sysUsers = userService.getSysUsers(null, Integer.toString(Integer.MAX_VALUE), userId, null, null, subSystemId, null, null, null, null, null, null, null,
                null);
        if (sysUsers != null && sysUsers.getContent() != null && sysUsers.getContent().size() > 0) {
            userService.updateUser(userId, status, roleIds, subSystemId, abilityIds, groups);
        } else {
            throw new BusinessException(ResultCodeEnum.SUB_SYSTEM_HAVING_NOT_USER, null, ResultCodeEnum.SUB_SYSTEM_HAVING_NOT_USER.getMessage());
        }

    }

}
