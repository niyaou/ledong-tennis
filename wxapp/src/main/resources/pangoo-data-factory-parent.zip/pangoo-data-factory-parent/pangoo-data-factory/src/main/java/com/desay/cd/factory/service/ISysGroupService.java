package com.desay.cd.factory.service;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysGroup;
import com.desay.cd.factory.rest.vo.SysGroupVo;

/**
 * 
 * @ClassName: ICleanStrategyService
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:22:23
 */
public interface ISysGroupService {
    /**
     * 添加
     * 
     * @param sysGroupVo
     * @return
     */
    String add(SysGroupVo sysGroupVo);

    /**
     * 删除
     * 
     * @param groupId
     */
    void delete(String groupId);

    /**
     * 更新
     * 
     * @param groupId
     * @param sysGroupVo
     * @param isOverall
     */
    void update(String groupId, SysGroupVo sysGroupVo, boolean isOverall);

    /**
     * 查询
     * 
     * @param userId
     * @param groupId
     * @param subsystemId
     * @param groupName
     * @param groupNameLike
     * @param abilityIds
     * @param abilityIdsCondition
     * @param abilityName
     * @param abilityNameLike
     * @param status
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @return
     */
    Page<SysGroup> search(String userId, String groupId, String subsystemId, String groupName, String groupNameLike, Set<String> abilityIds, String abilityIdsCondition,
            String abilityName, String abilityNameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties);
}
