package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysPermission;

/**
 * 权限服务
 * 
 * @author pengdengfu
 *
 */
public interface ISysPermissionService {
    /**
     * 添加权限
     * 
     * @param permissionName
     * @param methord
     * @param url
     * @param permissionDesc
     * @param subSystemId
     * @return
     */
    SysPermission addPermission(String permissionName, String methord, String url, String permissionDesc, String subSystemId);

    /**
     * 删除权限
     * 
     * @param permissionId
     */
    void deletePermission(String permissionId);

    /**
     * 更新权限
     * 
     * @param permissionId
     * @param permissionName
     * @param methord
     * @param url
     * @param permissionDesc
     * @param subSystemId
     */
    void updatePermission(String permissionId, String permissionName, String methord, String url, String permissionDesc, String subSystemId);

    /**
     * 获取系统权限
     * 
     * @param pageNo
     * @param pageSize
     * @param permissionId
     * @param permissionName
     * @param subSystemId
     * @param roleId
     * @param properties
     * @param sortDirection
     * @param status
     * @return
     */
    Page<SysPermission> getSyspermissions(String pageNo, String pageSize, String permissionId, String permissionName, String subSystemId, String roleId, List<String> properties, String sortDirection,
            String status);

}
