package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * 系统用户
 * 
 * @author pengdengfu
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_user")
@Getter
@Setter
public class SysUser implements Serializable {

    private static final long serialVersionUID = 5154767751636642095L;

    /** 用户ID */
    @Id
    @Column(name = "user_id", nullable = false, length = 20, columnDefinition = "varchar(20) COMMENT 'userID'")
    private String userId;

    /** 用户状态，1：启用，0：不启用,3:删除 */
    @Column(name = "status", columnDefinition = "char(1) default '1' COMMENT '用户状态，1：启用，0：不启用'")
    private String status = "1";

    /** 用户所属子系统 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_user_sub_system", joinColumns = { @JoinColumn(name = "user_id") }, inverseJoinColumns = { @JoinColumn(name = "sub_system_id") })
    @JsonIgnore
    private Set<SysSubSystem> sysSubSystems;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_user_role", joinColumns = { @JoinColumn(name = "user_id") }, inverseJoinColumns = { @JoinColumn(name = "role_id") })
    private Set<SysRole> sysRoles;

    /** 个人能力 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_user_abilities", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "data_id"))
    @OrderBy("name DESC")
    private Set<DataDictionary> abilities;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    @JsonIgnore
    private SysNoticeRules sysNoticeRules;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_group_members", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "group_id"))
    @OrderBy("group_name DESC")
    @JsonIgnoreProperties({ "masters", "members", "abilities", "sysSubsystem" })
    private Set<SysGroup> memberGroups;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_group_masters", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "group_id"))
    @OrderBy("group_name DESC")
    @JsonIgnoreProperties({ "masters", "members", "abilities", "sysSubsystem" })
    private Set<SysGroup> masterGroups;

    @Column(name = "user_name", columnDefinition = "text COMMENT '用户名'")
    private String userName;
    @Column(name = "email", columnDefinition = "varchar(100) COMMENT '电子邮件'")
    private String email;
    @Column(name = "icon_image", columnDefinition = "text COMMENT '头像的base64编码'")
    private String avatar;

    @Version
    @JsonIgnore
    private Long version;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysUser other = (SysUser) obj;
        if (userId == null) {
            if (other.userId != null) {
                return false;
            }
        } else if (!userId.equals(other.userId)) {
            return false;
        }
        return true;
    }

}
