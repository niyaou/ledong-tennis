package com.desay.cd.factory.utils;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.UUIDGenerator;

/**
 * 
 * @author uidq1070
 *
 */
public class CustomUUIDGenerator extends UUIDGenerator {
    @Override
    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
        String id = UuidHexGenerator.generate();
        if (id != null) {
            return (Serializable) id;
        }
        return super.generate(session, object);
    }
}