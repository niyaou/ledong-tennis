package com.desay.cd.factory.service;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.rest.vo.GroupVO;

/**
 * 用户服务
 * 
 * @author pengdengfu
 *
 */
public interface ISysUserService {
    /**
     * 从服务器获取公钥
     * 
     * @return
     */
    public Object getPublicKey();

    /**
     * 用户登录
     * 
     * @param userId
     * @param password
     * @param request
     * @return
     */
    public Object login(String userId, String password, HttpServletRequest request);

    /**
     * 用户登出
     * 
     * @param token
     * @return
     */
    public boolean logout(String token);

    /**
     * 获取系统用户
     * 
     * @param pageNo
     * @param pageSize
     * @param userId
     * @param userName
     * @param roleId
     * @param subsystemId
     * @param status
     * @param roleName
     * @param properties
     * @param sortDirection
     * @param abilityIds
     * @param abilityIdsCondition
     * @param abilityName
     * @param abilityNameLike
     * @return
     */
    public Page<SysUser> getSysUsers(String pageNo, String pageSize, String userId, String userName, String roleId, String subsystemId, String status, String roleName,
            List<String> properties, String sortDirection, Set<String> abilityIds, String abilityIdsCondition, String abilityName, String abilityNameLike);

    /**
     * 添加用户
     * 
     * @param userId
     * @param status
     * @param roleIds
     * @param subSystemIds
     * @param abilityIds
     * @param groups
     * @return
     */
    public SysUser addUser(String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups);

    /**
     * 删除用户
     * 
     * @param userId
     * @param loginUserId
     */
    public void deleteUser(String userId, String loginUserId);

    /**
     * 更新用户
     * 
     * @param userId
     * @param status
     * @param roleIds
     * @param subSystemIds
     * @param abilityIds
     * @param groups
     * @return
     */
    SysUser updateUser(String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups);

    /**
     * 更新用户
     * 
     * @param userId
     * @param status
     * @param roleIds
     * @param subSystemId
     * @param abilityIds
     * @param groups
     * @return
     */
    SysUser updateUser(String userId, String status, Set<String> roleIds, String subSystemId, Set<String> abilityIds, Set<GroupVO> groups);

    /**
     * 更新用户-删除用户角色
     * 
     * @param userId
     * @param roleId
     */
    public void updateUserDeleteRole(String userId, String roleId);

    /**
     * 更新用户-删除用户所属子系统
     * 
     * @param userId
     * @param subSystemId
     */
    public void updateUserDeleteSubSystem(String userId, String subSystemId);

    /**
     * token合法认证
     * 
     * @param token
     * @return
     */
    public Object tokenAuthorize(String token);

    /**
     * 获取部门及其成员信息
     * 
     * @return
     */
    public Object getDepart();

    /**
     * 模糊搜索用户信息
     * 
     * @param id
     * @param pageNo
     * @param pageSize
     * @return
     */
    public Object searchUserInfo(String id, String pageNo, String pageSize);
}
