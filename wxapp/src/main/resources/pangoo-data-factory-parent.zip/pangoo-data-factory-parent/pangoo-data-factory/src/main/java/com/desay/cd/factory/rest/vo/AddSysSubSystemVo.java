package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddSysSubSystemVo
 * @author: pengdengfu
 * @date: 2019年4月17日 下午3:44:50
 */
public class AddSysSubSystemVo {
    @ApiModelProperty(value = "系统名称(0<size<=30)", required = true)
    private String subsystemName;
    @ApiModelProperty(value = "系统描述", required = false)
    private String subsystemDesc;
    @ApiModelProperty(value = "用户Id列表,忽略不存在的Id", required = false)
    private Set<String> userIds;
    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", example = "1", required = false)
    private String status;

    public String getSubsystemName() {
        return subsystemName;
    }

    public void setSubsystemName(String subsystemName) {
        this.subsystemName = subsystemName;
    }

    public String getSubsystemDesc() {
        return subsystemDesc;
    }

    public void setSubsystemDesc(String subsystemDesc) {
        this.subsystemDesc = subsystemDesc;
    }

    public Set<String> getUserIds() {
        return userIds;
    }

    public void setUserIds(Set<String> userIds) {
        this.userIds = userIds;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return " [subsystemName=" + subsystemName + ", subsystemDesc=" + subsystemDesc + ", userIds=" + userIds + ", status=" + status + "]";
    }

}
