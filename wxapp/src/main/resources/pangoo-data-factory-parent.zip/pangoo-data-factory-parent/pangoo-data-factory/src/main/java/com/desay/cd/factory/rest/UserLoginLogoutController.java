package com.desay.cd.factory.rest;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddUserVo;
import com.desay.cd.factory.rest.vo.UpdateUserVo;
import com.desay.cd.factory.service.ISysUserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/***
 * 用户登录管理
 * 
 * @author pengdengfu
 *
 */
@RestController
@Api(value = "用户管理-用户管理", tags = "UserLoginLogoutController")
public class UserLoginLogoutController {
    @Autowired
    private ISysUserService userService;

    /**
     * 添加用户
     * 
     * @param userId
     * @return
     */
    @RequestMapping(value = "/management/users", method = RequestMethod.POST)
    @ApiOperation(value = "用户管理-添加用户", notes = "")
    @LogAnnotation(action = LogActionEnum.USER, message = "添加用户")
    public ResponseEntity<?> addUser(@RequestBody AddUserVo addUser) {
        SysUser sysUser = userService.addUser(addUser.getUserId(), addUser.getStatus(), addUser.getRoleIds(), addUser.getSubsystemId(), addUser.getAbilityIds(),
                addUser.getGroups());
        return new ResponseEntity<Object>(CommonResponse.success(sysUser.getUserId()), HttpStatus.OK);
    }

    /**
     * 删除用户
     * 
     * @param userId
     * @return
     */
    @RequestMapping(value = "/management/users/{userId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "用户管理-删除用户", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.USER, message = "删除用户")
    public ResponseEntity<?> deleteUser(@PathVariable(value = "userId", required = true) String userId, HttpServletRequest request) {
        String loginUserId = getUserId(request);
        userService.deleteUser(userId, loginUserId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 用户管理-更新用户
     * 
     * @param userId
     * @param status
     * @return
     */
    @RequestMapping(value = "/management/users/{userId}", method = RequestMethod.PUT)
    @ApiOperation(value = "用户管理-更新用户", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.USER, message = "用户管理-更新用户)")
    public ResponseEntity<?> updateUser(@PathVariable String userId, @RequestBody UpdateUserVo updateUserVo) {
        userService.updateUser(userId, updateUserVo.getStatus(), updateUserVo.getRoleIds(), updateUserVo.getSubsystemId(), updateUserVo.getAbilityIds(), updateUserVo.getGroups());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 用户管理-更新用户角色-删除角色
     * 
     * @param userId
     * @param roleId
     * @return
     */
    @RequestMapping(value = "/management/users/{userId}/roles/{roleId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "用户管理-更新用户角色-删除角色", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "roleId", value = "roleId", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.USER, message = "用户管理-更新用户角色-删除角色")
    public ResponseEntity<?> updateUserDeleteRoles(@PathVariable String userId, @PathVariable(value = "roleId", required = true) String roleId) {
        userService.updateUserDeleteRole(userId, roleId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 用户管理-更新用户角色-删除所属子系统
     * 
     * @param userId
     * @param subSystemId
     * @return
     */
    @RequestMapping(value = "/management/users/{userId}/subsystems/{subsystemId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "用户管理-更新用户角色-删除所属子系统", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "subsystemId", value = "subsystemId", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.USER, message = "用户管理-更新用户角色-删除所属子系统")
    public ResponseEntity<?> updateUserDeleteSys(@PathVariable String userId, @PathVariable(value = "subsystemId", required = true) String subsystemId) {
        userService.updateUserDeleteSubSystem(userId, subsystemId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取所有用户
     * 
     * @param pageNo
     * @param pageSize
     * 
     * @return
     */
    @RequestMapping(value = "/management/users", method = RequestMethod.GET)
    @ApiOperation(value = "用户管理-获取所有用户", notes = "1、当pageNo，pageSize为空时，默认返回第一页10条数据.<br>")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userName", value = "用户名（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "角色Id（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleName", value = "角色名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "子系统Id（精确查询）.通过关键词“global”查询全局用户", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query"),
            @ApiImplicitParam(name = "abilityIds", value = "能力Id列表", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "abilityIdsCondition", value = "能力Id的关系", required = false, dataType = "string", allowableValues = "and,or", paramType = "query"),
            @ApiImplicitParam(name = "abilityName", value = "能力名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "abilityNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.USER, message = "获取所有用户")
    public ResponseEntity<?> getUsers(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "userId", required = false) String userId, @RequestParam(value = "userName", required = false) String userName,
            @RequestParam(value = "roleId", required = false) String roleId, @RequestParam(value = "roleName", required = false) String roleName,
            @RequestParam(value = "subsystemId", required = false) String subsystemId, @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection,
            @RequestParam(value = "abilityIds", required = false) Set<String> abilityIds, @RequestParam(value = "abilityIdsCondition", required = false) String abilityIdsCondition,
            @RequestParam(value = "abilityName", required = false) String abilityName, @RequestParam(value = "abilityNameLike", required = false) String abilityNameLike) {
        Page<SysUser> sysUsers = userService.getSysUsers(pageNo, pageSize, userId, userName, roleId, subsystemId, status, roleName, sortProperties, sortDirection, abilityIds,
                abilityIdsCondition, abilityName, abilityNameLike);
        return new ResponseEntity<Object>(CommonResponse.success(sysUsers), HttpStatus.OK);
    }

    /**
     * 获取部门及其成员信息
     * 
     * @return
     */
    @RequestMapping(value = "/management/department", method = RequestMethod.GET)
    @ApiOperation(value = "用户管理-获取部门及其成员信息", notes = "")
    @LogAnnotation(action = LogActionEnum.USER, message = "用户管理-获取部门及其成员信息")
    public ResponseEntity<?> getDepartment() {
        return new ResponseEntity<Object>(CommonResponse.success(userService.getDepart()), HttpStatus.OK);
    }

    /**
     * 用户管理-模糊搜索用户信息
     * 
     * @return
     */
    @RequestMapping(value = "/management/users/search", method = RequestMethod.GET)
    @ApiOperation(value = "用户管理-模糊搜索用户信息", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户ID（模糊查询）", required = true, dataType = "string", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.USER, message = "用户管理-模糊搜索用户信息")
    public ResponseEntity<?> getuserInfo(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "userId", required = true) String userId) {
        return new ResponseEntity<Object>(CommonResponse.success(userService.searchUserInfo(userId, pageNo, pageSize)), HttpStatus.OK);
    }

    /**
     * 获取userId
     * 
     * @param request
     * @return
     */
    private String getUserId(HttpServletRequest request) {
        Object token = request.getHeader("access_token");
        TokenDto tokenDto = null;
        if (null != token) {
            tokenDto = (TokenDto) userService.tokenAuthorize((String) token);
            if (null != tokenDto) {
                return tokenDto.cid;
            }
        }
        return null;
    }
}
