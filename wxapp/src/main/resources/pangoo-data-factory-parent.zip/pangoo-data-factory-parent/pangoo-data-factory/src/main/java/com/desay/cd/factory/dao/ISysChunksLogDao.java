package com.desay.cd.factory.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.desay.cd.factory.entity.mysql.SysChunksLog;

/**
 * ISysUploadLogDao
 * 
 * @author nixuchun
 *
 */
public interface ISysChunksLogDao extends JpaRepository<SysChunksLog, Serializable> {
    
    
    /**
     * findByFileId
     * @param fileId
     * @return
     */
    List<SysChunksLog>  findByFileId(String fileId);
    
    /**
     * findByUserId
     * @param userId
     * @return
     */
    List<SysChunksLog>  findByUserId(String userId);
}
