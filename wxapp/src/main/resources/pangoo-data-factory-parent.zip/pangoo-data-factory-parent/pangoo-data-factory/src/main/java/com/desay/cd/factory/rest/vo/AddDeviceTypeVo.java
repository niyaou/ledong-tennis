package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddDeviceTypeVo
 * @author: pengdengfu
 * @date: 2019年4月17日 上午11:44:02
 */
public class AddDeviceTypeVo {
    @ApiModelProperty(value = "设备类型名称(0<size<=30)", required = true)
    private String deviceTypeName;
    @ApiModelProperty(value = "父级Id", required = false)
    private String parentDeviceTypeId;

    @ApiModelProperty(value = "添加的子节点名称列表", required = false)
    private Set<String> childrenNames;

    public String getDeviceTypeName() {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    public String getParentDeviceTypeId() {
        return parentDeviceTypeId;
    }

    public void setParentDeviceTypeId(String parentDeviceTypeId) {
        this.parentDeviceTypeId = parentDeviceTypeId;
    }

    public Set<String> getChildrenNames() {
        return childrenNames;
    }

    public void setChildrenNames(Set<String> childrenNames) {
        this.childrenNames = childrenNames;
    }

    @Override
    public String toString() {
        return " [deviceTypeName=" + deviceTypeName + ", parentDeviceTypeId=" + parentDeviceTypeId + ", childrenNames=" + childrenNames + "]";
    }

}
