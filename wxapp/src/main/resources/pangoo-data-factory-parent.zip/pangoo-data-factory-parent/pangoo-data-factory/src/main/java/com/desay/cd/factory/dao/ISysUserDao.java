package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.cd.factory.entity.mysql.SysUser;

/**
 * ISysUserDao
 * 
 * @author pengdengfu
 *
 */
public interface ISysUserDao extends JpaRepository<SysUser, Serializable>, JpaSpecificationExecutor<SysUser> {
    /**
     * 通过角色查询用户
     * 
     * @param roleId
     * @param pageable
     * @return
     */
    @Query("select user from SysUser user inner join user.sysRoles role where role.roleId = :roleId")
    public Page<SysUser> getSysUsersByRoleId(@Param(value = "roleId") String roleId, Pageable pageable);

    /**
     * 根据子系统查询用户
     * 
     * @param subSystemId
     * @param pageable
     * @return
     */
    @Query("select user from SysUser user inner join user.sysSubSystems system where system.subsystemId = :subSystemId ")
    public Page<SysUser> getUserBySystem(@Param(value = "subSystemId") String subSystemId, Pageable pageable);

}
