package com.desay.cd.factory.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.cd.factory.entity.mysql.SysDeviceType;

/**
 * ISysTagDao
 * 
 * @author pengdengfu
 *
 */
public interface ISysDeviceTypeDao extends JpaRepository<SysDeviceType, Serializable>, JpaSpecificationExecutor<SysDeviceType> {

    /**
     * 查看是否存在一当前项目下子节点有效的数据
     * 
     * @param parent
     * @param isActive
     * @return
     */
    List<SysDeviceType> findByParentAndIsActive(SysDeviceType parent, String isActive);

    /**
     * 根据名称查询
     * 
     * @param deviceTypeName
     * @return
     */
    SysDeviceType findByDeviceTypeName(String deviceTypeName);
}
