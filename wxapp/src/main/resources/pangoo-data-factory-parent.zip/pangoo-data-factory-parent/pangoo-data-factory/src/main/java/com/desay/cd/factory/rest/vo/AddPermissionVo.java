package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddRoleVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午4:11:27
 */
@ApiModel(value = "权限")
public class AddPermissionVo {
    @ApiModelProperty(value = "权限名称(0<size<=30)", required = true, example = "权限名称(0<size<=30),必选")
    private String permissionName;
    @ApiModelProperty(value = "权限对应的url", required = true, example = "权限对应的url,必选")
    private String url;
    @ApiModelProperty(value = "权限对应的methord:post,get,put,delete", required = true, allowableValues = "post,get,put,delete", example = "权限对应的methord:post,get,put,delete，必选")
    private String method;
    @ApiModelProperty(value = "权限描述", required = false, example = "权限描述")
    private String permissionDesc;

    @ApiModelProperty(value = "该权限所属的子系统Id", required = false, example = "该权限所属的子系统Id")
    private String subsystemId;

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getPermissionDesc() {
        return permissionDesc;
    }

    public void setPermissionDesc(String permissionDesc) {
        this.permissionDesc = permissionDesc;
    }

    public String getSubsystemId() {
        return subsystemId;
    }

    public void setSubsystemId(String subsystemId) {
        this.subsystemId = subsystemId;
    }

    @Override
    public String toString() {
        return " [permissionName=" + permissionName + ", url=" + url + ", method=" + method + ", permissionDesc=" + permissionDesc + ", subsystemId=" + subsystemId + "]";
    }

}
