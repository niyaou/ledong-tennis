package com.desay.cd.factory.transaction.base;

import com.desay.cd.factory.exception.CustumException;

/**
 * 文件事务处理的抽象类
 * 
 * @author uidq1343
 *
 */
public abstract class AbstractFileHandler {

    /** 上一个处理器 */
    private AbstractFileHandler preHandler;

    /** 下一个处理器 */
    private AbstractFileHandler nextHandler;

    /**
     * 业务执行
     * 
     * 
     * @param element
     */

    public FileElement doHandle(FileElement element) {
        try {
            doHandleReal(element);
        } catch (CustumException e) {
            // 业务代码执行失败主动回滚
            element.setError(e);
            return rollBack(element);
        }

        // 业务代码执行成功主动调用下一个处理器处理
        if (null != nextHandler) {
            return nextHandler.doHandle(element);
        }
        clean();
        return element;
    }

    /**
     * 事务回滚
     * 
     * 
     * @param element
     */
    public FileElement rollBack(FileElement element) {
        rollBackReal(element);
        clean();
        // 本处理器业务回滚完成，主动调用前一个处理器业务回滚
        if (null != preHandler) {
            return preHandler.rollBack(element);
        }
        return element;
    }

    /**
     * 每个处理器特有的业务处理方法
     * 
     * @param element
     * @throws CustumException
     */
    public abstract void doHandleReal(FileElement element) throws CustumException;

    /**
     * 每个处理器特有的业务回滚方法
     * 
     * @param element
     */
    public abstract void rollBackReal(FileElement element);

    /**
     * 清理执行需要的资源
     */
    protected abstract void clean();

    /**
     * 配置执行需要的资源
     * 
     * @param resouce
     */
    public abstract <T> void setResource(T resouce);

    private AbstractFileHandler setPreHandler(AbstractFileHandler preHandler) {
        this.preHandler = preHandler;
        return preHandler;
    }

    public AbstractFileHandler setNextHandler(AbstractFileHandler nextHandler) {
        this.nextHandler = nextHandler;
        nextHandler.setPreHandler(this);
        return nextHandler;
    }

}