package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * 
 * @ClassName: ClearAlgorithm
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:18:19
 */
@Data
@Entity
@Table(name = "clean_algorithm", uniqueConstraints = { @UniqueConstraint(columnNames = { "alg_name" }) })
@EntityListeners(AuditingEntityListener.class)
public class CleanAlgorithm implements Serializable {

    private static final long serialVersionUID = 7358292361758218721L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "alg_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String algId;

    @Column(name = "alg_name", unique = true, nullable = false, columnDefinition = "varchar(50) COMMENT '算法名称'")
    private String algName;
    @Column(name = "alg_desc", columnDefinition = "text COMMENT '算法描述'")
    private String algDesc;
    @Column(name = "image_name", columnDefinition = "varchar(50) COMMENT '镜像名称'")
    private String imageName;
    @Column(name = "image_ver", columnDefinition = "varchar(50) COMMENT '镜像版本（标签）'")
    private String imageVer;
    @Column(name = "image_params", columnDefinition = "text COMMENT '运行参数'")
    private String imageParams;
    @Column(name = "image_env", columnDefinition = "text COMMENT '运行环境'")
    private String imageEnv;

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private Integer isActive = 0;
    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

}
