package com.desay.cd.factory.transaction.impl;

import java.util.HashMap;

import org.apache.http.util.TextUtils;
import org.elasticsearch.action.DocWriteResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.FileIndex;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.enums.LogFileOptEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.impl.FileServiceImpl;
import com.desay.cd.factory.service.impl.IndexServiceImpl;
import com.desay.cd.factory.transaction.base.BaseIndexServiceHandler;
import com.desay.cd.factory.transaction.base.FileElement;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;



/**
 * 创建es文档事务处理实现类
 * @author uidq1343
 *
 */
public class IndexCreateHandler extends  BaseIndexServiceHandler {

    
    
    /**
     * 将文档信息插入es
     * 目前。若ES存在同名文档，则删除该文档，再创建新文档，此处业务需要讨论，根据需求决定是否修改
     */
    @Override
    public void doHandleReal(FileElement element) throws CustumException {
        DocWriteResponse result=null;
        String fileId=null;
        if(element.getChunk()!=null) {
           fileId=element.getChunk().getFileId();
        }
        HashMap<String, Object> dic=null;
        if(StringUtil.isNotEmpty(fileId) ) {
            dic= indexService.queryFileInfomation(fileId);
            element.setDoc(new JSONObject(dic));
        }

        String name=null;
        String type=null;
        FileIndex doc=null;
        if(dic!=null) {
            /**  已存在文件id，则进行文档编辑*/
             name=element.getFileName();
             type=(String) dic.get(IndexServiceImpl.FILETYPE);
             doc=new FileIndex(name,type,element.getFilePath(),element.getUserId()
                    ,DateUtil.getTimeStamp( element.getOperationTime()),element.getFileSize(),element.getVo().getProductId(),
                    element.getVo().getProductName(), element.getVo().getDeviceId(), element.getVo().getDeviceName());
            if(element.getChunk().getChunks().intValue()==element.getChunk().getCurrent().intValue()  ) {
                doc.setStatus(FileStatusEnum.PENDING_TO_AUDITED.getCode());
                element.setFileIndex(doc);
            }
            result=indexService.updateFileInfomation(JSON.toJSONString(doc), fileId);
        }else {
            /** 文件不存在，建立文档*/
             name=StringUtil.getFileNameWithoutPrefix(element.getVo().getFileName());
             type=StringUtil.getPrefixFileName(element.getVo().getFileName());
             doc=new FileIndex(name,type,element.getFilePath(),element.getUserId()
                    ,DateUtil.getTimeStamp( element.getOperationTime()),element.getFileSize(),element.getVo().getProductId(),
                    element.getVo().getProductName(), element.getVo().getDeviceId(), element.getVo().getDeviceName());
             try {
                result=  indexService.createFileInfomation(JSON.toJSONString(doc));
             }catch(Exception e) {
                 e.printStackTrace();
                 throw new CustumException(ResultCodeEnum.ES_TIMEOUT.getCode(), ResultCodeEnum.ES_TIMEOUT.getMessage());
             }
            //TO DO TIMEOUT
        }
          
        if(result==null) {
            throw new CustumException(ResultCodeEnum.INSERT_DATA_FAILD.getCode(), ResultCodeEnum.INSERT_DATA_FAILD.getMessage());
        }
        element.setFileName(name);
        element.setFileId(result.getId());
        
        /**  写入操作日志*/
        if(dic==null) {
            FileServiceImpl.createOperationLog(element,LogFileOptEnum.CREATED); 
        }
        if(FileStatusEnum.PENDING_TO_AUDITED.getCode()==doc.getStatus()) {
            FileServiceImpl.createOperationLog(element,LogFileOptEnum.UPLOADED);
        }
    }

    
    /**
     * 回滚操作
     * 删除已插入的es文档
     */
    @Override
    public void rollBackReal(FileElement element) {
        String fileId=element.getFileId();
        if(!TextUtils.isEmpty(fileId)) {
            indexService.updateFileInfomation(element.getDoc().toJSONString(), fileId);
        }
    }
   

}
