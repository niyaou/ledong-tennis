package com.desay.cd.factory.transaction.impl;

import java.util.HashMap;

import org.apache.http.util.TextUtils;
import org.elasticsearch.action.DocWriteResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.enums.LogFileOptEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.impl.FileServiceImpl;
import com.desay.cd.factory.service.impl.IndexServiceImpl;
import com.desay.cd.factory.transaction.base.BaseIndexServiceHandler;
import com.desay.cd.factory.transaction.base.FileElement;
import com.desay.cd.factory.utils.DateUtil;



/**
 * 取消文件上传任务es文档事务处理基类
 * @author uidq1343
 *
 */
public class IndexCancelHandler extends  BaseIndexServiceHandler {



    @Override
    public void doHandleReal(FileElement element) throws CustumException {
        
        HashMap<String, Object> doc = indexService.queryFileInfomation(element.getChunk().getFileId());
        if (doc == null) {
            throw new CustumException(ResultCodeEnum.FILE_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_NOT_EXISTED.getMessage());
        }
        element.setDoc(new JSONObject(doc));
        doc.put(IndexServiceImpl.STATUS, FileStatusEnum.CANCELED.getCode());
        doc.put(IndexServiceImpl.CANCELTIME, DateUtil.getTimeStamp(element.getOperationTime()));
        element.setFilePath((String) doc.get(IndexServiceImpl.FILEPATH));
        DocWriteResponse result=null;
        result=  indexService.updateFileInfomation(JSON.toJSONString(doc), element.getChunk().getFileId());
        if(result==null) {
            throw new CustumException(ResultCodeEnum.CANCELD_FILE_FAILD.getCode(), ResultCodeEnum.CANCELD_FILE_FAILD.getMessage());
        }
        /**  写入操作日志*/
        FileServiceImpl.createOperationLog(element,LogFileOptEnum.CANCELED);
    }

    @Override
    public void rollBackReal(FileElement element) {
        String fileId=element.getChunk().getFileId();
        if(!TextUtils.isEmpty(fileId)) {
            indexService.updateFileInfomation(element.getDoc().toJSONString(), fileId);
        }
    }


}
