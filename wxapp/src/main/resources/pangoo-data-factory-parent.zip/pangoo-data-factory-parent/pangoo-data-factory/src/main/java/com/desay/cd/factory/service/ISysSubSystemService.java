package com.desay.cd.factory.service;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.rest.vo.GroupVO;
import com.desay.cd.factory.rest.vo.SysGroupVo;

/**
 * 
 * @ClassName: ISysSubSystemService
 * @author: pengdengfu
 * @date: 2019年4月17日 下午2:42:02
 */
public interface ISysSubSystemService {

    /**
     * 添加子系统
     * 
     * @param subSystemName
     * @param subSystemDesc
     * @param userIds
     * @param status
     * @return
     */
    SysSubSystem addSubSystem(String subSystemName, String subSystemDesc, Set<String> userIds, String status);

    /**
     * 删除子系统
     * 
     * @param subSystemId
     */
    void deleteSubSystem(String subSystemId);

    /**
     * 删除系统所属用户
     * 
     * @param subSystemId
     * @param userIds
     * @param loginUserId
     */
    void deleteSubSystemUsers(String subSystemId, Set<String> userIds, String loginUserId);

    /**
     * 添加子系统用户
     * 
     * @param subSystemId
     * @param userId
     * @param status
     * @param roleIds
     * @param subSystemIds
     * @param abilityIds
     * @param groups
     * @return
     */
    SysUser addSubSystemUsers(String subSystemId, String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups);

    /**
     * 更新子系统用户
     * 
     * @param subSystemId
     * @param userId
     * @param status
     * @param roleIds
     * @param subSystemIds
     * @param abilityIds
     * @param groups
     */
    void updateUser(String subSystemId, String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups);

    /**
     * 更新子系统
     * 
     * @param subSystemId
     * @param subSystemName
     * @param subSystemDesc
     * @param userIds
     * @param status
     */
    void updateSubSystem(String subSystemId, String subSystemName, String subSystemDesc, Set<String> userIds, String status);

    /**
     * 查询子系统
     * 
     * @param pageNo
     * @param pageSize
     * @param subSystemName
     * @param subSystemId
     * @param status
     * @param properties
     * @param sortDirection
     * @return
     */
    Page<SysSubSystem> getSubSystems(String pageNo, String pageSize, String subSystemName, String subSystemId, String status, List<String> properties, String sortDirection);

    /**
     * 删除子系统的组
     * 
     * @param subSystemId
     * @param groupId
     */
    void deleteSubsystemGroup(String subSystemId, String groupId);

    /**
     * 更新子系统的组
     * 
     * @param subSystemId
     * @param groupId
     * @param sysGroupVo
     * @param isOverall
     */
    void updateSubsystemGroup(String subSystemId, String groupId, SysGroupVo sysGroupVo, boolean isOverall);

}
