package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.rest.vo.UploadChunkVo;
import com.desay.cd.factory.rest.vo.UploadFileVo;

/**
 * 处理文件相关的复杂业务
 * 
 * @author uidq1343
 *
 */
public interface IFileService {

    /**
     * 断点续传文件
     * 
     * @param userId
     * @param ip
     * @param chunks
     * @param file
     * @return
     */
    Object saveChunksFile(String userId, String ip, UploadChunkVo chunks, MultipartFile file);

    /**
     * 创建文件文档
     * 
     * @param userId
     * @param ip
     * @param vo
     * @return
     */
    Object createFileDocument(String userId, String ip, UploadFileVo vo);

    /**
     * 更新文件文档信息
     * 
     * @param userId
     * @param ip
     * @param fielId
     * @param vo
     * @param version
     * @return
     */
    Object updateFileDocument(String userId, String ip, String fielId, UploadFileVo vo, long version);

    /**
     * 查看未完成的断点续传任务
     * 
     * @param userId
     * @param pageNo
     * @param pageSize
     * @return
     */
    Object exploreChunksLog(String userId, String pageNo, String pageSize);

    /**
     * 根据参数查询文档
     * 
     * @param fileId
     * @param status
     * @param userId
     * @param startTime
     * @param endTime
     * @param productId
     * @param productName
     * @param deviceId
     * @param deviceName
     * @param fileType
     * @param minSize
     * @param maxSize
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @param sortDirection
     * @return
     */
    Object exploreFilesByParams(String fileId, String status, String userId, String startTime, String endTime, String productId, String productName, String deviceId, String deviceName,
            String fileType, String minSize, String maxSize, String pageNo, String pageSize, List<String> sortProperties, String sortDirection);

    /**
     * 查询非此状态的文件信息
     * 
     * @param status
     * @param productId
     * @param deviceId
     * @return
     */
    Object exploreFilesByStatusNotMatch(String status, String productId, String deviceId);

    /**
     * 根据查询条件获取文档总数
     * 
     * @param fileId
     * @param status
     * @param userId
     * @param startTime
     * @param endTime
     * @param productId
     * @param productName
     * @param deviceId
     * @param deviceName
     * @param fileType
     * @param minSize
     * @param maxSize
     * @return
     */
    Object getFilesTotalCountByParams(String fileId, String status, String userId, String startTime, String endTime, String productId, String productName, String deviceId, String deviceName,
            String fileType, String minSize, String maxSize);
    // Object getFilesTotalCountByTimeRange(String startTime, String endTime);
    // Object getFilesTotalCountByUser(String userId);
    // Object getFilesTotalCountByVehicleType(String vehicleType);
    // Object getFilesTotalCountByVehicleType(String vehicleType);

    /**
     * 根据时间范围查询文件
     * 
     * @param startTime
     * @param endTime
     * @param pageNo
     * @param size
     * @return
     */
    Object queryFileInfoByTimeRange(String startTime, String endTime, String pageNo, String size);

    /**
     * 根据文件状态浏览文件
     * 
     * @param status
     * @param pageNo
     * @param size
     * @return
     */
    Object exploreFilesByStatus(int status, String pageNo, String size);

    /**
     * 根据用户名查询文档
     * 
     * @param userId
     * @param pageNo
     * @param size
     * @return
     */
    Object exploreFilesByUserId(String userId, String pageNo, String size);

    /**
     * 根据产品名查询文档
     * 
     * @param productName
     * @param pageNo
     * @param size
     * @return
     */
    Object exploreFilesByProductName(String productName, String pageNo, String size);

    /**
     * 根据设备名查询文档
     * 
     * @param deviceName
     * @param pageNo
     * @param size
     * @return
     */
    Object exploreFilesByDeviceName(String deviceName, String pageNo, String size);

    /**
     * 根据指定条件统计文件信息
     * 
     * @param autoType
     * @param deviceId
     * @param productId
     * @param status
     * @param fileType
     * @param userId
     * @param startTime
     * @param endTime
     * @return
     */
    Object fileStatisticsByParams(String autoType, String deviceId, String productId, Integer status, String fileType, String userId, String startTime, String endTime);

    /**
     * 根据指定条件统计文件信息,根据状态分类
     * 
     * @param autoType
     * @param deviceId
     * @param productId
     * @param fileType
     * @param userId
     * @param startTime
     * @param endTime
     * @return
     */
    Object fileStatisticsByParamsMultiTypes(String autoType, String deviceId, String productId, String fileType, String userId, String startTime, String endTime);

    /**
     * 根据指定条件统计每日文件信息
     * 
     * @param autoType
     * @param deviceId
     * @param productId
     * @param status
     * @param fileType
     * @param userId
     * @param startTime
     * @param endTime
     * @return
     */
    Object fileStatisticsByParamsDetails(String autoType, String deviceId, String productId, Integer status, String fileType, String userId, String startTime, String endTime);

    /**
     * 根据指定条件统计每日文件信息,根据状态分类
     * 
     * @param autoType
     * @param deviceId
     * @param productId
     * @param fileType
     * @param userId
     * @param startTime
     * @param endTime
     * @return
     */
    Object fileStatisticsByParamsMultiTypiesDetails(String autoType, String deviceId, String productId, String fileType, String userId, String startTime, String endTime);

    /**
     * 审核文件
     * 
     * @param userId
     * @param ip
     * @param fileId
     * @param status
     * @param version
     * @param message
     * @return
     */
    Object verifiedFiles(String userId, String ip, String fileId, FileStatusEnum status, long version, String message);

    // Object triggeredAuditMessage();

    /**
     * 根据文件类型查询文档
     * 
     * @param type
     * @param pageNo
     * @param size
     * @return
     */
    Object exploreFilesByFileType(int type, String pageNo, String size);

    /**
     * 根据大小范围查询文件
     * 
     * @param minSize
     * @param maxSize
     * @param pageNo
     * @param size
     * @return
     */
    Object queryFileInfomationBySize(String minSize, String maxSize, String pageNo, String size);

    /**
     * 永久删除指定id的文件
     * 
     * @param userId
     * @param ip
     * @param fileId
     * @return
     */
    boolean deleteFiles(String userId, String ip, String fileId);

    /**
     * 取消未完成的上传任务
     * 
     * @param userId
     * @param ip
     * @param fileId
     * @return
     */
    boolean cancelUploadTask(String userId, String ip, String fileId);

    /**
     * 制作媒体文件的概览图
     * 
     * @return
     */
    boolean createMediaThumbNail();

    /**
     * 根据ID获取文件缩略图路径
     * 
     * @param id
     * @return
     */
    String getThumbNailPath(String id);

    /**
     * 根据id获取文件路径
     * 
     * @param id
     * @return
     */
    String getRealPath(String id);

}
