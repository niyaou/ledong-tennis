package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * 通知规则触发事件
 * 
 * @author pengdengfu
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_trigger_event", uniqueConstraints = { @UniqueConstraint(columnNames = { "event_name" }) })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "eventId")
public class SysTriggerEvent implements Serializable {

    private static final long serialVersionUID = 63877862119215138L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "event_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String eventId;

    /** 事件名称 */
    @Column(name = "event_name", unique = true, nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '权限名称'")
    private String eventName;

    /** 权限角色关系 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_notice_rule_event", joinColumns = { @JoinColumn(name = "event_id") }, inverseJoinColumns = { @JoinColumn(name = "notice_id") })
    @JsonIgnore
    private Set<SysNoticeRules> sysNoticeRules;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    @JsonIgnore
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((eventId == null) ? 0 : eventId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysTriggerEvent other = (SysTriggerEvent) obj;
        if (eventId == null) {
            if (other.eventId != null) {
                return false;
            }
        } else if (!eventId.equals(other.eventId)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "SysTriggerEvent [eventId=" + eventId + ", eventName=" + eventName + "]";
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public Set<SysNoticeRules> getSysNoticeRules() {
        return sysNoticeRules;
    }

    public void setSysNoticeRules(Set<SysNoticeRules> sysNoticeRules) {
        this.sysNoticeRules = sysNoticeRules;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

}
