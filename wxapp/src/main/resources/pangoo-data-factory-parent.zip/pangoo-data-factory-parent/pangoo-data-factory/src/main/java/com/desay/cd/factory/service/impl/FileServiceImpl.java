package com.desay.cd.factory.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.http.util.TextUtils;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.desay.cd.auth.LdapAuthorize;
import com.desay.cd.auth.dto.PersonDto;
import com.desay.cd.factory.config.LogFile;
import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.entity.Log;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysChunksLog;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.enums.FileTypeEnum;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.enums.LogFileOptEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.rest.vo.UploadChunkVo;
import com.desay.cd.factory.rest.vo.UploadFileVo;
import com.desay.cd.factory.service.IFileService;
import com.desay.cd.factory.transaction.base.AbstractFileHandler;
import com.desay.cd.factory.transaction.base.BaseHdfsServiceHandler;
import com.desay.cd.factory.transaction.base.BaseIndexServiceHandler;
import com.desay.cd.factory.transaction.base.FileElement;
import com.desay.cd.factory.transaction.impl.ChunksProcessHandler;
import com.desay.cd.factory.transaction.impl.HdfsCancelFileHandler;
import com.desay.cd.factory.transaction.impl.HdfsCreateFileHandler;
import com.desay.cd.factory.transaction.impl.HdfsDeleteFileHandler;
import com.desay.cd.factory.transaction.impl.IndexCancelHandler;
import com.desay.cd.factory.transaction.impl.IndexCreateHandler;
import com.desay.cd.factory.transaction.impl.IndexDeleteHandler;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;
import com.desay.cd.factory.utils.ThumbNailUtil;
import com.desay.cd.hdfs.HdfsUtils;

/**
 * 文件管理服务实现类
 * 
 * @author uidq1343
 *
 */
@Service
public class FileServiceImpl implements IFileService {
    @Autowired
    private HdfsFileServiceImpl hdfsService;

    @Autowired
    private IndexServiceImpl indexService;

    @Autowired
    private LdapAuthorize ldapService;

    @Autowired
    private SysChunksLogServiceImpl chunksLogService;

    @Resource(name = "defaultThreadPool")
    private ThreadPoolTaskExecutor executor;

    @Autowired
    private MailSenderServiceImpl mailService;

    @Autowired
    private ApplicationContext applicationContext;

    private final static String AUDITMAILTITLE = "pangoo_das_factory files audit result ";

    /**
     * 1.建立临时文件夹 2.保存文件快 3.合并文件块，删除临时文件夹 4.调用保存文件事务
     */
    @Override
    public Object saveChunksFile(String userId, String ip, UploadChunkVo chunks, MultipartFile file) {
        String path = null;
        String fileName = null;
        HashMap<String, Object> dic = null;
        if (StringUtil.isEmpty(chunks.getFileId())) {
            throw new CustumException(ResultCodeEnum.FILEID_NOT_EMPTY.getCode(), ResultCodeEnum.FILEID_NOT_EMPTY.getMessage());
        } else {
            dic = indexService.queryFileInfomation(chunks.getFileId());
            if (dic == null) {
                throw new CustumException(ResultCodeEnum.DATA_NOT_FOUND.getCode(), ResultCodeEnum.DATA_NOT_FOUND.getMessage());
            }
            fileName = (String) dic.get(IndexServiceImpl.FILENAME) + Constanst.POINT + dic.get(IndexServiceImpl.FILETYPE);
            path = (String) dic.get(IndexServiceImpl.FILEPATH);
        }

        UploadFileVo vo = new UploadFileVo();
        vo.setDeviceId((String) dic.get(IndexServiceImpl.DEVICEID));
        vo.setDeviceName((String) dic.get(IndexServiceImpl.DEVICENAME));
        vo.setProductId((String) dic.get(IndexServiceImpl.PRODUCTID));
        vo.setProductName((String) dic.get(IndexServiceImpl.PRODUCTNAME));
        vo.setFileName(fileName);

        /** 文件合并之前检查是否存在，若存在，则重命名 */
        String mergePath = new StringBuffer(path).append(fileName).toString();

        if (HdfsUtils.directoryExist(mergePath)) {
            fileName = hdfsService.createFileName(new StringBuffer(path).append(vo.getFileName()).toString());
        }
        ;

        vo.setFileName(fileName);
        FileElement element = initFileElement(StringUtil.getFileNameWithoutPrefix(fileName), userId, ip, chunks.getSize(), vo, chunks);
        element.setFilePath(path);
        element.setVo(vo);
        try {
            element.setIns(file.getInputStream());
            element = initTransaction(new IndexCreateHandler(), new HdfsCreateFileHandler(), new ChunksProcessHandler(), element);
            if (chunks.getChunks().intValue() == chunks.getCurrent().intValue()) {
                applicationContext.publishEvent(element);
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw new CustumException(ResultCodeEnum.FILE_INPUTSTREAM_ERROR.getCode(), ResultCodeEnum.FILE_INPUTSTREAM_ERROR.getMessage());
        }
        return element.getFileId();
    }

    @Override
    public Object createFileDocument(String userId, String ip, UploadFileVo vo) {
        /** 包含最后的路径标识符 / */
        String path = hdfsService.getCurrentFolderPath(HdfsFileServiceImpl.DATA);
        String fileName = null;
        /** 文件名.后缀名 */
        fileName = hdfsService.createFileName(new StringBuffer(path).append(vo.getFileName()).toString());

        FileElement element = initFileElement(StringUtil.getFileNameWithoutPrefix(fileName), userId, ip, 0, vo, null);
        vo.setFileName(fileName);
        element.setFilePath(new StringBuffer(path).toString());
        element.setVo(vo);
        element = initTransaction(new IndexCreateHandler(), null, null, element);
        return element.getFileId();
    }

    @Override
    public Object updateFileDocument(String userId, String ip, String fileId, UploadFileVo vo, long version) {
        HashMap<String, Object> doc = indexService.queryFileInfomation(fileId);
        if (doc == null) {
            throw new CustumException(ResultCodeEnum.FILE_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_NOT_EXISTED.getMessage());
        }
        doc.put(IndexServiceImpl.DEVICEID, vo.getDeviceId());
        doc.put(IndexServiceImpl.DEVICENAME, vo.getDeviceName());
        doc.put(IndexServiceImpl.PRODUCTID, vo.getProductId());
        doc.put(IndexServiceImpl.PRODUCTNAME, vo.getProductName());
        doc.put(IndexServiceImpl.STATUS, FileStatusEnum.PENDING_TO_AUDITED.getCode());
        try {
            doc.put(IndexServiceImpl.UPDATETIME, DateUtil.getTimeStamp(DateUtil.getDateTime(new Date(System.currentTimeMillis()))));
        } catch (ParseException e1) {
            e1.printStackTrace();
        }

        try {
            DocWriteResponse result = indexService.updateFileInfomationWithVersion(JSON.toJSONString(doc), fileId, version);
            return result.getResult();
        } catch (ElasticsearchException e) {
            e.printStackTrace();
            throw new CustumException(ResultCodeEnum.FILE_ALREADY_EDITED.getCode(), ResultCodeEnum.FILE_ALREADY_EDITED.getMessage());
        }
    }

    @Override
    public Object exploreChunksLog(String userId, String pageNo, String pageSize) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = StringUtil.isNotEmpty(pageNo) ? Integer.parseInt(pageNo) : null;
            pageSizeInt = StringUtil.isNotEmpty(pageSize) ? Integer.parseInt(pageSize) : null;
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        Page<SysChunksLog> list = chunksLogService.queryLogByUserId(userId, pageNoInt, pageSizeInt);
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(IndexServiceImpl.TOTAL, list.getTotalElements());
        map.put(IndexServiceImpl.CONTENT, list.getContent());
        return map;
    }

    @Override
    public Object exploreFilesByParams(String fileId, String status, String userId, String startTime, String endTime, String productId, String productName, String deviceId,
            String deviceName, String fileType, String minSize, String maxSize, String pageNo, String pageSize, List<String> sortProperties, String sortDirection) {
        startTime = StringUtil.isNotEmpty(startTime) ? DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) : null;
        endTime = StringUtil.isNotEmpty(endTime) ? DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) : null;
        Integer minSizeInt = null;
        Integer maxSizeInt = null;
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = StringUtil.isNotEmpty(pageNo) ? Integer.parseInt(pageNo) : null;
            pageSizeInt = StringUtil.isNotEmpty(pageSize) ? Integer.parseInt(pageSize) : null;
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        try {
            minSizeInt = StringUtil.isNotEmpty(minSize) ? Integer.parseInt(minSize) : null;
            maxSizeInt = StringUtil.isNotEmpty(maxSize) ? Integer.parseInt(maxSize) : null;
            if (minSizeInt != null && maxSizeInt != null && maxSizeInt < minSizeInt) {
                throw new CustumException(ResultCodeEnum.MAXSIZE_MUST_ABOVE_MINSIZE.getCode(), ResultCodeEnum.MAXSIZE_MUST_ABOVE_MINSIZE.getMessage());
            }
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.FILE_SIZE_PARSE_ERROR.getCode(), ResultCodeEnum.FILE_SIZE_PARSE_ERROR.getMessage());
        }
        if (StringUtil.isNotEmpty(startTime) && StringUtil.isNotEmpty(endTime) && startTime.compareToIgnoreCase(endTime) > 0) {
            throw new CustumException(ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getCode(), ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getMessage());
        } else {
            boolean checkTime = (StringUtil.isNotEmpty(startTime) || StringUtil.isNotEmpty(endTime)) && (StringUtil.isEmpty(startTime) || StringUtil.isEmpty(endTime));
            if (checkTime) {
                throw new CustumException(ResultCodeEnum.TIMERANGE_MUST_EXISTED.getCode(), ResultCodeEnum.TIMERANGE_MUST_EXISTED.getMessage());
            }
        }
        boolean checkSize = (minSizeInt != null || maxSizeInt != null) && (minSizeInt == null || maxSizeInt == null);
        if (checkSize) {
            throw new CustumException(ResultCodeEnum.SIZERANGE_MUST_EXISTED.getCode(), ResultCodeEnum.SIZERANGE_MUST_EXISTED.getMessage());
        }
        if (sortProperties == null || sortProperties.size() <= 0) {
            sortProperties = new ArrayList<>(1);
            sortProperties.add("createTime");
        }
        if (StringUtils.isEmpty(sortDirection)) {
            sortDirection = Constanst.SORT_DIRECTION_DESC;
        }
        SortOrder sortOrder = null;
        if (Constanst.SORT_DIRECTION_ASC.equalsIgnoreCase(sortDirection)) {
            sortOrder = SortOrder.ASC;
        } else {
            sortOrder = SortOrder.DESC;
        }
        return indexService.exploreFilesByParams(fileId, status, userId, startTime, endTime, productId, productName, deviceId, deviceName, fileType, minSizeInt, maxSizeInt,
                pageNoInt, pageSizeInt, sortProperties, sortOrder);
    }

    @Override
    public Object exploreFilesByStatusNotMatch(String status, String productId, String deviceId) {

        return indexService.exploreFilesByStatusNotMatch(status, productId, deviceId);
    }

    @Override
    public Object getFilesTotalCountByParams(String fileId, String status, String userId, String startTime, String endTime, String productId, String productName, String deviceId,
            String deviceName, String fileType, String minSize, String maxSize) {
        startTime = StringUtil.isNotEmpty(startTime) ? DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) : null;
        endTime = StringUtil.isNotEmpty(endTime) ? DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) : null;
        Integer minSizeInt = StringUtil.isNotEmpty(minSize) ? Integer.parseInt(minSize) : null;
        Integer maxSizeInt = StringUtil.isNotEmpty(maxSize) ? Integer.parseInt(maxSize) : null;
        return indexService.exploreFilesByParamsWithoutSize(fileId, status, userId, startTime, endTime, productId, productName, deviceId, deviceName, fileType, minSizeInt,
                maxSizeInt);
    }

    @Override
    public Object queryFileInfoByTimeRange(String startTime, String endTime, String pageNo, String size) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = StringUtil.isNotEmpty(pageNo) ? Integer.parseInt(pageNo) : null;
            pageSizeInt = StringUtil.isNotEmpty(size) ? Integer.parseInt(size) : null;
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getCode(), ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getMessage());
        }
        return indexService.queryFileInfoByTimeRange(startTime, endTime, pageNoInt, pageSizeInt);
    }

    @Override
    public Object exploreFilesByStatus(int status, String pageNo, String size) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = StringUtil.isNotEmpty(pageNo) ? Integer.parseInt(pageNo) : null;
            pageSizeInt = StringUtil.isNotEmpty(size) ? Integer.parseInt(size) : null;
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getCode(), ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getMessage());
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        LinkedList<HashMap<String, Object>> result = indexService.queryFileInfomationByStatus(status, pageNoInt, pageSizeInt);
        if (result == null) {
            return null;
        }
        map.put(IndexServiceImpl.TOTAL, result.size());
        map.put(IndexServiceImpl.RESULT, result);
        return map;
    }

    @Override
    public Object exploreFilesByUserId(String userId, String pageNo, String size) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = Integer.parseInt(pageNo);
            pageSizeInt = Integer.parseInt(size);
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getCode(), ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getMessage());

        }
        return indexService.queryFileInfomationByUserId(userId, pageNoInt, pageSizeInt);
    }

    @Override
    public Object exploreFilesByProductName(String productName, String pageNo, String size) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = Integer.parseInt(pageNo);
            pageSizeInt = Integer.parseInt(size);
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getCode(), ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getMessage());

        }
        return indexService.queryFileInfomationByProductName(productName, pageNoInt, pageSizeInt);
    }

    @Override
    public Object exploreFilesByDeviceName(String deviceName, String pageNo, String size) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = Integer.parseInt(pageNo);
            pageSizeInt = Integer.parseInt(size);
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getCode(), ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getMessage());

        }
        return indexService.queryFileInfomationByDeviceName(deviceName, pageNoInt, pageSizeInt);
    }

    @Override
    public Object exploreFilesByFileType(int type, String pageNo, String size) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = Integer.parseInt(pageNo);
            pageSizeInt = Integer.parseInt(size);
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getCode(), ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getMessage());
        }
        return indexService.queryFileInfomationByFileType(pageNoInt, pageSizeInt, FileTypeEnum.getMIMEType(type).getPrefix());
    }

    @Override
    public String getThumbNailPath(String id) {
        HashMap<String, Object> dic = indexService.queryFileInfomation(id);
        return dic != null ? ((String) dic.get(IndexServiceImpl.THUMBPATH)) : null;
    }

    @Override
    public Object queryFileInfomationBySize(String minSize, String maxSize, String pageNo, String size) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        try {
            pageNoInt = Integer.parseInt(pageNo);
            pageSizeInt = Integer.parseInt(size);
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getCode(), ResultCodeEnum.PAGEABLE_PARMAS_PARSE_ERROR.getMessage());
        }
        Integer minSizeInt = null;
        Integer maxSizeInt = null;
        try {
            minSizeInt = Integer.parseInt(minSize);
            maxSizeInt = Integer.parseInt(maxSize);
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.FILE_SIZE_PARSE_ERROR.getCode(), ResultCodeEnum.FILE_SIZE_PARSE_ERROR.getMessage());
        }
        return indexService.queryFileInfomationBySize(minSizeInt, maxSizeInt, pageNoInt, pageSizeInt);
    }

    @Override
    public boolean createMediaThumbNail() {
        String timeStamp = DateUtil.getCurrentTimeStamp();
        LinkedList<HashMap<String, Object>> list = indexService.queryFileInfoByTerm(timeStamp, 0, null, null);
        if (list != null) {
            for (HashMap<String, Object> hashMap : list) {
                String id = (String) hashMap.get(IndexServiceImpl.FILEID);
                String type = (String) hashMap.get(IndexServiceImpl.FILETYPE);
                if (StringUtil.containsContent(type, "mp4") || StringUtil.containsContent(type, "avi")) {
                    String path = (String) hashMap.get(IndexServiceImpl.FILEPATH);
                    String name = (String) hashMap.get(IndexServiceImpl.FILENAME);
                    InputStream ins = HdfsUtils.downloadFileFromHdfs(new StringBuffer(path).append(name).append(".").append(type).toString());
                    try {
                        String target = ThumbNailUtil.createGif(name, hdfsService.getCurrentFolderPath(HdfsFileServiceImpl.THUMBNAIL), ins);
                        if (!TextUtils.isEmpty(target)) {
                            hashMap.put(IndexServiceImpl.THUMBPATH, target);
                            indexService.updateFileInfomation(JSON.toJSONString(hashMap), id);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return false;
    }

    @Override
    public String getRealPath(String id) {
        return indexService.getIntegratedPath(id);
        // HashMap<String, Object> doc = indexService.queryFileInfomation(id);
        // if(doc!=null) {
        // return indexService.getIntegratedPath(id);
        //// return (String) doc.get(IndexServiceImpl.FILEPATH);
        // }
        // return null;
    }

    @Override
    public boolean deleteFiles(String userId, String ip, String fileId) {

        HashMap<String, Object> doc = indexService.queryFileInfomation(fileId);
        if (doc == null) {
            throw new CustumException(ResultCodeEnum.FILE_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_NOT_EXISTED.getMessage());
        } else {
            if (FileStatusEnum.DELETED.getCode() == doc.get(IndexServiceImpl.STATUS)) {
                throw new CustumException(ResultCodeEnum.FILE_ALREADY_DELETED.getCode(), ResultCodeEnum.FILE_ALREADY_DELETED.getMessage());
            }
        }
        UploadFileVo vo = new UploadFileVo(((String) doc.get(IndexServiceImpl.FILENAME) + Constanst.POINT + ((String) doc.get(IndexServiceImpl.FILETYPE))),
                (String) doc.get(IndexServiceImpl.DEVICEID), (String) doc.get(IndexServiceImpl.DEVICENAME));
        UploadChunkVo chunks = new UploadChunkVo(fileId);
        chunks.setChunks(0);
        chunks.setCurrent(0);
        FileElement element = initFileElement((String) doc.get(IndexServiceImpl.FILENAME), userId, ip, 0, vo, chunks);
        initTransaction(new IndexDeleteHandler(), new ChunksProcessHandler(), new HdfsDeleteFileHandler(), element);
        return true;
    }

    @Override
    public boolean cancelUploadTask(String userId, String ip, String fileId) {
        HashMap<String, Object> doc = indexService.queryFileInfomation(fileId);
        if (doc == null) {
            throw new CustumException(ResultCodeEnum.FILE_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_NOT_EXISTED.getMessage());
        } else {
            if (FileStatusEnum.DELETED.getCode() == doc.get(IndexServiceImpl.STATUS)) {
                throw new CustumException(ResultCodeEnum.FILE_ALREADY_DELETED.getCode(), ResultCodeEnum.FILE_ALREADY_DELETED.getMessage());
            } else if (FileStatusEnum.CANCELED.getCode() == doc.get(IndexServiceImpl.STATUS)) {
                throw new CustumException(ResultCodeEnum.FILE_ALREADY_CANCELED.getCode(), ResultCodeEnum.FILE_ALREADY_CANCELED.getMessage());
            }
        }
        UploadFileVo vo = new UploadFileVo(((String) doc.get(IndexServiceImpl.FILENAME) + Constanst.POINT + ((String) doc.get(IndexServiceImpl.FILETYPE))),
                (String) doc.get(IndexServiceImpl.DEVICEID), (String) doc.get(IndexServiceImpl.DEVICENAME));
        UploadChunkVo chunks = new UploadChunkVo(fileId);
        chunks.setChunks(0);
        chunks.setCurrent(0);
        FileElement element = initFileElement((String) doc.get(IndexServiceImpl.FILENAME), userId, ip, 0, vo, chunks);
        initTransaction(new IndexCancelHandler(), new HdfsCancelFileHandler(), new ChunksProcessHandler(), element);
        return true;
    }

    @Override
    public Object verifiedFiles(String userId, String ip, String fileId, FileStatusEnum status, long version, String message) {
        HashMap<String, Object> doc = indexService.queryFileInfomation(fileId);
        if (doc == null) {
            throw new CustumException(ResultCodeEnum.FILE_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_NOT_EXISTED.getMessage());
        } else {
            if (FileStatusEnum.PENDING_TO_AUDITED.getCode() == doc.get(IndexServiceImpl.STATUS) || FileStatusEnum.DENIED.getCode() == doc.get(IndexServiceImpl.STATUS)) {
                doc.put(IndexServiceImpl.STATUS, status.getCode());
                doc.put(IndexServiceImpl.AUDITMESSAGE, message);
                try {
                    doc.put(IndexServiceImpl.AUDITTIME, DateUtil.getTimeStamp(DateUtil.getDateTime(new Date(System.currentTimeMillis()))));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                doc.put(IndexServiceImpl.AUDIT, userId);
                try {
                    DocWriteResponse result = indexService.updateFileInfomationWithVersion(JSON.toJSONString(doc), fileId, version);
                    FileElement element = new FileElement();
                    element.setIp(ip);
                    element.setUserId((String) doc.get(IndexServiceImpl.CREATOR));
                    element.setFileName((String) doc.get(IndexServiceImpl.FILENAME) + "." + doc.get(IndexServiceImpl.FILETYPE));
                    element.setAuditMessage(message);
                    element.setFileId(fileId);
                    element.setAuditor(userId);
                    Log log = createOperationLog(element, FileStatusEnum.PENDING_TO_CLEANED.getCode().equals(status.getCode()) ? LogFileOptEnum.AUDITED : LogFileOptEnum.DENIED);
                    if (FileStatusEnum.DENIED.equals(status)) {
                        sendAuditMail(log);
                    }
                    return result.getResult();
                } catch (ElasticsearchException e) {
                    e.printStackTrace();
                    throw new CustumException(ResultCodeEnum.FILE_ALREADY_VERIFIED.getCode(), ResultCodeEnum.FILE_ALREADY_VERIFIED.getMessage());
                }
            } else {
                throw new CustumException(ResultCodeEnum.FILE_ALREADY_VERIFIED.getCode(), ResultCodeEnum.FILE_ALREADY_VERIFIED.getMessage());
            }
        }
    }

    private FileElement initFileElement(String fileName, String userId, String ip, double size, UploadFileVo vo, UploadChunkVo chunks) {
        FileElement element = new FileElement();
        element.setFileName(fileName);
        element.setUserId(userId);
        element.setIp(ip);
        element.setFileSize(size);
        element.setChunk(chunks);
        element.setVo(vo);
        return element;
    }

    /**
     * 初始化事务
     * 
     * @param firstHandler
     * @param nextHandler
     * @param lastHandler
     * @param element
     * @return
     */
    private FileElement initTransaction(AbstractFileHandler firstHandler, AbstractFileHandler nextHandler, AbstractFileHandler lastHandler, FileElement element)
            throws CustumException {
        setHandlerResource(firstHandler);
        if (nextHandler != null) {
            setHandlerResource(nextHandler);
            nextHandler = firstHandler.setNextHandler(nextHandler);
        }

        if (nextHandler != null && lastHandler != null) {
            setHandlerResource(lastHandler);
            nextHandler.setNextHandler(lastHandler);
        }

        element = firstHandler.doHandle(element);
        if (element.getError() != null) {
            throw element.getError();
        }
        return element;
    }

    /**
     * 初始化handler
     * 
     * @param handler
     */
    private void setHandlerResource(AbstractFileHandler handler) {
        if (handler instanceof BaseIndexServiceHandler) {
            handler.setResource(indexService);
        } else if (handler instanceof BaseHdfsServiceHandler) {
            handler.setResource(hdfsService);
        } else {
            handler.setResource(chunksLogService);
        }
    }

    /**
     * 写入操作日志
     * 
     * @param element
     */
    public static Log createOperationLog(FileElement element, LogFileOptEnum type) {
        Log log = new Log();
        log.setAction(LogActionEnum.FILE);
        log.setOptType(type);
        log.setIp(element.getIp());
        log.setUser(element.getUserId());
        if (element.getVo() != null) {
            log.setFileName(element.getVo().getFileName());
        } else {
            log.setFileName(element.getFileName());
        }
        try {
            log.setCreateTime(DateUtil.getDateTime(element.getOperationTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        log.setFileId(element.getFileId());
        if (StringUtil.isNotEmpty(element.getAuditor())) {
            log.setAuditor(element.getAuditor());
        }
        if (StringUtil.isNotEmpty(element.getAuditMessage())) {
            log.setAuditMessage(element.getAuditMessage());
        }
        LogFile.writeLogger(log);
        return log;
    }

    public void sendAuditMail(Log log) {
        String message = " your file %s has been denied with the comment :%s ";
        Object c = ldapService.get(log.getUser());
        if (c == null) {
            return;
        }
        PersonDto p = (PersonDto) c;
        message = String.format(message, log.getFileName(), log.getAuditMessage());
        try {
            mailService.sendMail(AUDITMAILTITLE, message, p.getMail().get(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Object fileStatisticsByParams(String autoType, String deviceId, String productId, Integer status, String fileType, String userId, String startTime, String endTime) {
        startTime = StringUtil.isNotEmpty(startTime) ? DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) : null;
        endTime = StringUtil.isNotEmpty(endTime) ? DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) : null;
        if (StringUtil.isNotEmpty(startTime) && StringUtil.isNotEmpty(endTime)) {

            if (startTime != null && endTime != null && startTime.compareTo(endTime) > 0) {
                throw new CustumException(ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getCode(), ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getMessage());
            }
        } else if (StringUtil.isEmpty(startTime) || StringUtil.isEmpty(endTime)) {
            if (StringUtil.isNotEmpty(endTime) || StringUtil.isNotEmpty(startTime)) {
                throw new CustumException(ResultCodeEnum.TIMERANGE_MUST_EXISTED.getCode(), ResultCodeEnum.TIMERANGE_MUST_EXISTED.getMessage());
            }
        }
        return indexService.fileStatisticsByParams(autoType, deviceId, productId, status, fileType, userId, startTime, endTime);

    }

    @Override
    public Object fileStatisticsByParamsDetails(String autoType, String deviceId, String productId, Integer status, String fileType, String userId, String startTime,
            String endTime) {

        String startTimeParse = StringUtil.isNotEmpty(startTime) ? DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) : null;
        String endTimeParse = StringUtil.isNotEmpty(endTime) ? DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) : null;
        if (StringUtil.isEmpty(startTimeParse) || StringUtil.isEmpty(endTimeParse)) {
            throw new CustumException(ResultCodeEnum.TIMERANGE_MUST_EXISTED.getCode(), ResultCodeEnum.TIMERANGE_MUST_EXISTED.getMessage());
        } else if (startTimeParse != null && endTimeParse != null && startTimeParse.compareTo(endTimeParse) > 0) {
            throw new CustumException(ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getCode(), ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getMessage());

        } else {
            return indexService.fileStatisticsByParamsDetails(autoType, deviceId, productId, fileType, userId, startTime, endTime);
        }
    }

    @Override
    public Object fileStatisticsByParamsMultiTypiesDetails(String autoType, String deviceId, String productId, String fileType, String userId, String startTime, String endTime) {
        String startTimeParse = StringUtil.isNotEmpty(startTime) ? DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) : null;
        String endTimeParse = StringUtil.isNotEmpty(endTime) ? DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) : null;
        if (StringUtil.isEmpty(startTimeParse) || StringUtil.isEmpty(endTimeParse)) {
            throw new CustumException(ResultCodeEnum.TIMERANGE_MUST_EXISTED.getCode(), ResultCodeEnum.TIMERANGE_MUST_EXISTED.getMessage());
        } else if (startTimeParse != null && endTimeParse != null && startTimeParse.compareTo(endTimeParse) > 0) {
            throw new CustumException(ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getCode(), ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getMessage());

        } else {
            return indexService.fileStatisticsByParamsDetails(autoType, deviceId, productId, fileType, userId, startTime, endTime);
        }
    }

    @Override
    public Object fileStatisticsByParamsMultiTypes(String autoType, String deviceId, String productId, String fileType, String userId, String startTime, String endTime) {

        startTime = StringUtil.isNotEmpty(startTime) ? DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) : null;
        endTime = StringUtil.isNotEmpty(endTime) ? DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) : null;
        if (StringUtil.isNotEmpty(startTime) && StringUtil.isNotEmpty(endTime)) {

            if (startTime != null && endTime != null && startTime.compareTo(endTime) > 0) {
                throw new CustumException(ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getCode(), ResultCodeEnum.STARTTIME_MUST_BEFORE_ENDTIME.getMessage());
            }
        } else if (StringUtil.isEmpty(startTime) || StringUtil.isEmpty(endTime)) {
            if (StringUtil.isNotEmpty(endTime) || StringUtil.isNotEmpty(startTime)) {
                throw new CustumException(ResultCodeEnum.TIMERANGE_MUST_EXISTED.getCode(), ResultCodeEnum.TIMERANGE_MUST_EXISTED.getMessage());
            }
        }
        LinkedList<HashMap<String, Object>> multiTypes = new LinkedList<HashMap<String, Object>>();

        for (FileStatusEnum status : FileStatusEnum.values()) {
            HashMap<String, Object> result = new HashMap<String, Object>(16);
            result.put(IndexServiceImpl.STATUS, status.getCode());
            result.put(IndexServiceImpl.RESULT, indexService.fileStatisticsByParams(autoType, deviceId, productId, status.getCode(), fileType, userId, startTime, endTime));
            multiTypes.add(result);
        }

        return multiTypes;

    }

}
