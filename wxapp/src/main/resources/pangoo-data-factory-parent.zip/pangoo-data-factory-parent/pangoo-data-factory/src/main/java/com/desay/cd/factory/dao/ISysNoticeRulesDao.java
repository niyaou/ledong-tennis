package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.desay.cd.factory.entity.mysql.SysNoticeRules;

/**
 * ISysNoticeRulesDao
 * 
 * @author pengdengfu
 *
 */
public interface ISysNoticeRulesDao extends JpaRepository<SysNoticeRules, Serializable> {

}
