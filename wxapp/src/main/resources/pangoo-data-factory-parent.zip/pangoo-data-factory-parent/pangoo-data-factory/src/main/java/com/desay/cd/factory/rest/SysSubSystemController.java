package com.desay.cd.factory.rest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysGroup;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddSysSubSystemVo;
import com.desay.cd.factory.rest.vo.AddUserVo;
import com.desay.cd.factory.rest.vo.SysGroupVo;
import com.desay.cd.factory.rest.vo.UpdateUserVo;
import com.desay.cd.factory.service.ISysGroupService;
import com.desay.cd.factory.service.ISysPermissionService;
import com.desay.cd.factory.service.ISysRoleService;
import com.desay.cd.factory.service.ISysSubSystemService;
import com.desay.cd.factory.service.ISysUserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 子系统管理
 * 
 * @ClassName: SysSubSystemController
 * @author: pengdengfu
 * @date: 2019年4月17日 下午2:40:33
 */
@RestController
@Api(value = "子系统管理", tags = "SysSubSystemController")
public class SysSubSystemController {
    @Autowired
    ISysSubSystemService sysSubSystemService;
    @Autowired
    ISysPermissionService sysPermissionService;
    @Autowired
    ISysRoleService sysRoleService;
    @Autowired
    ISysUserService sysUserService;

    @Autowired
    private ISysGroupService sysGroupService;

    /**
     * 子系统管理-添加子系统
     * 
     * @param addSysSubSystemVo
     * @return
     */
    @RequestMapping(value = "/management/subsystems", method = RequestMethod.POST)
    @ApiOperation(value = "子系统管理-添加子系统", notes = "")
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-添加子系统")
    public ResponseEntity<?> addSystem(@RequestBody AddSysSubSystemVo addSysSubSystemVo) {
        SysSubSystem addSubSystem = sysSubSystemService.addSubSystem(addSysSubSystemVo.getSubsystemName(), addSysSubSystemVo.getSubsystemDesc(), addSysSubSystemVo.getUserIds(),
                addSysSubSystemVo.getStatus());
        return new ResponseEntity<Object>(CommonResponse.success(addSubSystem.getSubsystemId()), HttpStatus.OK);
    }

    /**
     * 子系统管理-删除子系统
     * 
     * @param subsystemId
     * @return
     */
    @RequestMapping(value = "/management/subsystems/{subsystemId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "子系统管理-删除子系统", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-删除子系统")
    public ResponseEntity<?> deleteSystem(@PathVariable(value = "subsystemId", required = true) String subsystemId) {
        sysSubSystemService.deleteSubSystem(subsystemId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 子系统管理-更新子系统
     * 
     * @param subsystemId
     * @param updateSysSubSystemVo
     * @return
     */
    @RequestMapping(value = "/management/subsystems/{subsystemId}", method = RequestMethod.PUT)
    @ApiOperation(value = "子系统管理-更新子系统", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-更新子系统")
    public ResponseEntity<?> updateSystem(@PathVariable(value = "subsystemId", required = true) String subsystemId, @RequestBody AddSysSubSystemVo updateSysSubSystemVo) {
        sysSubSystemService.updateSubSystem(subsystemId, updateSysSubSystemVo.getSubsystemName(), updateSysSubSystemVo.getSubsystemDesc(), updateSysSubSystemVo.getUserIds(),
                updateSysSubSystemVo.getStatus());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 子系统管理-更新子系统-删除用户
     * 
     * @param subsystemId
     * @return
     */
    @RequestMapping(value = "/management/subsystems/{subsystemId}/users/{userId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "子系统管理-更新子系统-删除用户", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "userId", value = "用户ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-更新子系统-删除用户")
    public ResponseEntity<?> deleteSystemUser(@PathVariable(value = "subsystemId", required = true) String subsystemId,
            @PathVariable(value = "userId", required = true) String userId, HttpServletRequest request) {
        Set<String> ids = new HashSet<>(1);
        ids.add(userId);
        String loginUserId = getUserId(request);
        sysSubSystemService.deleteSubSystemUsers(subsystemId, ids, loginUserId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 子系统管理-查询子系统权限
     * 
     * @param subsystemId
     * @return
     */
    @RequestMapping(value = "/management/subsystems/{subsystemId}/permissions", method = RequestMethod.GET)
    @ApiOperation(value = "子系统管理-查询子系统权限", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "permissionId", value = "权限ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "permissionName", value = "权限名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "属于该子系统的权限,通过关键词“global”查询全局权限", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "roleId", value = "属于角色的权限", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-查询子系统权限")
    public ResponseEntity<?> getSubsystemPermissions(@RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize, @RequestParam(value = "permissionId", required = false) String permissionId,
            @RequestParam(value = "permissionName", required = false) String permissionName, @PathVariable(value = "subsystemId", required = true) String subsystemId,
            @RequestParam(value = "roleId", required = false) String roleId, @RequestParam(value = "sortProperties", required = false) List<String> sortProperties,
            @RequestParam(value = "sortDirection", required = false) String sortDirection, @RequestParam(value = "status", required = false) String status) {
        Page<SysPermission> syspermissions = sysPermissionService.getSyspermissions(pageNo, pageSize, permissionId, permissionName, subsystemId, roleId, sortProperties,
                sortDirection, status);
        return new ResponseEntity<Object>(CommonResponse.success(syspermissions), HttpStatus.OK);
    }

    /**
     * 子系统管理-查询子系统角色
     * 
     * @param subsystemId
     * @return
     */
    @RequestMapping(value = "/management/subsystems/{subsystemId}/roles", method = RequestMethod.GET)
    @ApiOperation(value = "子系统管理-查询子系统角色", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户Id，查询该用户拥有的角色", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "角色ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleName", value = "角色名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "属于该子系统的角色,通过关键词“global”查询全局角色", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-查询子系统角色")
    public ResponseEntity<?> getSubsystemRoles(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "userId", required = false) String userId, @RequestParam(value = "roleId", required = false) String roleId,
            @RequestParam(value = "roleName", required = false) String roleName, @PathVariable(value = "subsystemId", required = true) String subsystemId,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection,
            @RequestParam(value = "status", required = false) String status) {
        Page<SysRole> sysRoles = sysRoleService.getSysRoles(pageNo, pageSize, roleId, roleName, subsystemId, userId, sortProperties, sortDirection, status);
        return new ResponseEntity<Object>(CommonResponse.success(sysRoles), HttpStatus.OK);
    }

    /**
     * 子系统管理-查询子系统用户
     * 
     * @param subsystemId
     * @return
     */
    @RequestMapping(value = "/management/subsystems/{subsystemId}/users", method = RequestMethod.GET)
    @ApiOperation(value = "子系统管理-查询子系统用户", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userName", value = "角色名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "角色Id（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleName", value = "角色名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "属于该子系统的用户,通过关键词“global”查询全局用户", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query"),
            @ApiImplicitParam(name = "abilityIds", value = "能力Id列表", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "abilityIdsCondition", value = "能力Id的关系", required = false, dataType = "string", allowableValues = "and,or", paramType = "query"),
            @ApiImplicitParam(name = "abilityName", value = "能力名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "abilityNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-查询子系统用户")
    public ResponseEntity<?> getSubsystemUsers(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "userId", required = false) String userId, @RequestParam(value = "userName", required = false) String userName,
            @RequestParam(value = "roleId", required = false) String roleId, @RequestParam(value = "roleName", required = false) String roleName,
            @PathVariable(value = "subsystemId", required = true) String subsystemId, @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection,
            @RequestParam(value = "abilityIds", required = false) Set<String> abilityIds, @RequestParam(value = "abilityIdsCondition", required = false) String abilityIdsCondition,
            @RequestParam(value = "abilityName", required = false) String abilityName, @RequestParam(value = "abilityNameLike", required = false) String abilityNameLike) {
        Page<SysUser> sysUsers = sysUserService.getSysUsers(pageNo, pageSize, userId, userName, roleId, subsystemId, status, roleName, sortProperties, sortDirection, abilityIds,
                abilityIdsCondition, abilityName, abilityNameLike);
        return new ResponseEntity<Object>(CommonResponse.success(sysUsers), HttpStatus.OK);
    }

    /**
     * 添加用户
     * 
     * @param userId
     * @return
     */
    @RequestMapping(value = "/management/subsystems/{subsystemId}/users", method = RequestMethod.POST)
    @ApiOperation(value = "子系统管理-用户管理-添加用户", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.USER, message = "添加用户")
    public ResponseEntity<?> addUser(@PathVariable(value = "subsystemId", required = true) String subsystemId, @Validated @RequestBody AddUserVo addUser) {
        SysUser sysUser = sysSubSystemService.addSubSystemUsers(subsystemId, addUser.getUserId(), addUser.getStatus(), addUser.getRoleIds(), addUser.getSubsystemId(),
                addUser.getAbilityIds(), addUser.getGroups());
        return new ResponseEntity<Object>(CommonResponse.success(sysUser.getUserId()), HttpStatus.OK);
    }

    @RequestMapping(value = "/management/subsystems/{subsystemId}/users/{userId}", method = RequestMethod.PUT)
    @ApiOperation(value = "子系统管理-用户管理-更新用户", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.USER, message = "用户管理-更新用户)")
    public ResponseEntity<?> updateUser(@PathVariable(value = "subsystemId", required = true) String subsystemId, @PathVariable String userId,
            @RequestBody UpdateUserVo updateUserVo) {
        sysSubSystemService.updateUser(subsystemId, userId, updateUserVo.getStatus(), updateUserVo.getRoleIds(), updateUserVo.getSubsystemId(), updateUserVo.getAbilityIds(),
                updateUserVo.getGroups());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 子系统管理-查询子系统
     * 
     * @param deviceTypeId
     * @return
     */
    @RequestMapping(value = "/management/subsystems", method = RequestMethod.GET)
    @ApiOperation(value = "子系统管理-查询子系统", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "需要查询的设备类型Id（精确查询）", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "subsystemName", value = "需要查询的子系统名称（模糊查询）", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.SUB_SYSTEM, message = "子系统管理-查询子系统")
    public ResponseEntity<?> getSystems(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "subsystemId", required = false) String subsystemId, @RequestParam(value = "subsystemName", required = false) String subsystemName,
            @RequestParam(value = "status", required = false) String status, @RequestParam(value = "sortProperties", required = false) List<String> sortProperties,
            @RequestParam(value = "sortDirection", required = false) String sortDirection) {
        return new ResponseEntity<Object>(
                CommonResponse.success(sysSubSystemService.getSubSystems(pageNo, pageSize, subsystemName, subsystemId, status, sortProperties, sortDirection)), HttpStatus.OK);
    }

    @RequestMapping(value = "/management/subsystems/{subsystemId}/groups", method = RequestMethod.POST)
    @ApiOperation(value = "子系统管理-增加组", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path") })
    public ResponseEntity<?> addGroup(@PathVariable(value = "subsystemId", required = true) String subsystemId, @RequestBody @Validated SysGroupVo sysGroupVo) {
        sysGroupVo.setSubsystemId(subsystemId);
        String groupId = sysGroupService.add(sysGroupVo);
        return new ResponseEntity<Object>(CommonResponse.success(groupId), HttpStatus.OK);
    }

    @RequestMapping(value = "/management/subsystems/{subsystemId}/groups", method = RequestMethod.GET)
    @ApiOperation(value = "子系统管理-查询组", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "groupId", value = "策略Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupName", value = "策略名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "abilityIds", value = "能力Id列表", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "abilityIdsCondition", value = "能力Id的关系", required = false, dataType = "string", allowableValues = "and,or", paramType = "query"),
            @ApiImplicitParam(name = "abilityName", value = "设备名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "abilityNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    public ResponseEntity<?> getGroup(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @PathVariable(value = "userId", required = false) String userId, @PathVariable(value = "subsystemId", required = true) String subsystemId,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "groupId", required = false) String groupId,
            @RequestParam(value = "groupName", required = false) String groupName, @RequestParam(value = "groupNameLike", required = false) String groupNameLike,
            @RequestParam(value = "abilityIds", required = false) Set<String> abilityIds, @RequestParam(value = "abilityIdsCondition", required = false) String abilityIdsCondition,
            @RequestParam(value = "abilityName", required = false) String abilityName, @RequestParam(value = "abilityNameLike", required = false) String abilityNameLike,
            @RequestParam(value = "status", required = false) String status) {
        Page<SysGroup> sysGroups = sysGroupService.search(userId, groupId, subsystemId, groupName, groupNameLike, abilityIds, abilityIdsCondition, abilityName, abilityNameLike,
                status, pageNo, pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(sysGroups), HttpStatus.OK);
    }

    @RequestMapping(value = "/management/subsystems/{subsystemId}/groups/{groupId}", method = RequestMethod.DELETE)
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "groupId", value = "组ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "子系统管理-组别管理-删除", notes = "")
    public ResponseEntity<?> add(@PathVariable(value = "subsystemId", required = true) String subsystemId, @PathVariable(value = "groupId", required = true) String groupId) {
        sysSubSystemService.deleteSubsystemGroup(subsystemId, groupId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    @RequestMapping(value = "/management/subsystems/{subsystemId}/groups/{groupId}", method = RequestMethod.PUT)
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "groupId", value = "组ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "子系统管理-组别管理-更新-整体更新", notes = "用提供的对象数据，替换原始数据")
    public ResponseEntity<?> put(@PathVariable(value = "subsystemId", required = true) String subsystemId, @PathVariable(value = "groupId", required = true) String groupId,
            @Validated @RequestBody SysGroupVo sysGroupVo) {
        sysSubSystemService.updateSubsystemGroup(subsystemId, groupId, sysGroupVo, true);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    @RequestMapping(value = "/management/subsystems/{subsystemId}/groups/{groupId}", method = RequestMethod.PATCH)
    @ApiImplicitParams({ @ApiImplicitParam(name = "subsystemId", value = "子系统ID", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "groupId", value = "组ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "子系统管理-组别管理-局部更新", notes = "用提供对象的指定字段，替换原始对象的指定指定")
    public ResponseEntity<?> update(@PathVariable(value = "subsystemId", required = true) String subsystemId, @PathVariable(value = "groupId", required = true) String groupId,
            @RequestBody SysGroupVo sysGroupVo) {
        sysSubSystemService.updateSubsystemGroup(subsystemId, groupId, sysGroupVo, false);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取userId
     * 
     * @param request
     * @return
     */
    private String getUserId(HttpServletRequest request) {
        Object token = request.getHeader("access_token");
        TokenDto tokenDto = null;
        if (null != token) {
            tokenDto = (TokenDto) sysUserService.tokenAuthorize((String) token);
            if (null != tokenDto) {
                return tokenDto.cid;
            }
        }
        return null;
    }

}
