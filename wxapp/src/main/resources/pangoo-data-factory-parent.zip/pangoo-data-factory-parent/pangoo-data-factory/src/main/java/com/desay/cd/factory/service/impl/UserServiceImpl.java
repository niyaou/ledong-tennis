package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.redisson.api.RTopic;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.auth.LdapAuthorize;
import com.desay.cd.auth.dto.PersonDto;
import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.auth.service.LdapAuthorizeService;
import com.desay.cd.auth.uitls.ConstantUtils;
import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.IDataDictionaryDao;
import com.desay.cd.factory.dao.ISysGroupDao;
import com.desay.cd.factory.dao.ISysRoleDao;
import com.desay.cd.factory.dao.ISysSubSystemDao;
import com.desay.cd.factory.dao.ISysUserDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.entity.mysql.SysGroup;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.rest.vo.GroupVO;
import com.desay.cd.factory.service.ISysGroupService;
import com.desay.cd.factory.service.ISysRoleService;
import com.desay.cd.factory.service.ISysUserService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * UserServiceImpl
 * 
 * @author pengdengfu
 *
 */
@Service
@Transactional(rollbackOn = Exception.class)
@Slf4j
public class UserServiceImpl implements ISysUserService {
    @Autowired
    private ISysUserDao sysUserDao;
    @Autowired
    private ISysRoleDao sysRoleDao;
    @Autowired
    private ISysSubSystemDao sysSubSystemDao;
    @Autowired
    private LdapAuthorizeService ldapAuthorizeService;
    @Autowired
    LdapAuthorize ldapAuthorize;
    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    ISysGroupDao sysGroupDao;
    @Autowired
    private ISysGroupService sysGroupService;

    @Autowired
    private IDataDictionaryDao dataDictionaryDao;
    @Autowired
    ISysRoleService sysRoleService;

    @Autowired
    private RedissonClient redissonClient;

    @Override
    public Object getPublicKey() {
        Object publicKey = ldapAuthorizeService.getPublicKey();
        return publicKey;
    }

    @Override
    public Object login(String userId, String password, HttpServletRequest request) {
        SysUser userInfo = sysUserDao.findOne(userId);
        if (null == userInfo) {
            return null;
        }
        TokenDto tokenDto = (TokenDto) ldapAuthorizeService.pwdAuthorizeldap(userId, password, "pangoo-data-factory", request);
        if (null == tokenDto) {
            return null;
        }
        Map<String, Object> roleMap = new HashMap<>(1);

        Set<SysPermission> sysPermissions = new HashSet<>(16);
        // 只返回active=1的权限
        for (SysRole sysRole : userInfo.getSysRoles()) {
            if (Constanst.ACTIVE_STATUS_1.equals(sysRole.getIsActive())) {
                for (SysPermission sysPermission : sysRole.getPermissions()) {
                    if (Constanst.ACTIVE_STATUS_1.equals(sysPermission.getIsActive())) {
                        sysPermissions.add(sysPermission);
                    }
                }
            }
        }
        roleMap.put("userId", userInfo.getUserId());
        roleMap.put("status", userInfo.getStatus());
        roleMap.put("userName", userInfo.getUserName());
        roleMap.put("email", userInfo.getEmail());
        roleMap.put("avatar", userInfo.getAvatar());
        roleMap.put("permissions", sysPermissions);
        roleMap.put("sysRole", userInfo.getSysRoles());

        tokenDto.setUserInfo(roleMap);
        tokenDto.setSysUserInfo(userInfo);
        request.getSession().setAttribute(ConstantUtils.SESSION_TOKEN, tokenDto);
        return tokenDto;
    }

    @Override
    public boolean logout(String token) {
        return (boolean) ldapAuthorizeService.logOutBytoken(token);
    }

    @Override
    public Object getDepart() {
        return ldapAuthorizeService.getDepartmentInfo();
    }

    /**
     * token 合法认证
     * 
     * @param token
     * @return
     */
    @Override
    public Object tokenAuthorize(String token) {
        return ldapAuthorizeService.tokenAuthorize(token);
    }

    @Override
    public SysUser addUser(String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups) {
        SysUser sysUser = new SysUser();
        sysUser.setUserId(userId);

        // 检查userId
        checkUserId(userId, true, false);
        // 修正状态
        addUserStatus(status, sysUser);
        // 判断UID账户系统是否存在该用户
        Map<String, ArrayList<String>> searchUserById = null;

        try {
            searchUserById = ldapAuthorize.searchUserById(userId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustumException(ResultCodeEnum.LDAP_CONNECT_FAILED.getCode(), ResultCodeEnum.LDAP_CONNECT_FAILED.getMessage());
        }
        if (searchUserById == null) {
            throw new CustumException(ResultCodeEnum.UID_USER_NOT_EXIST.getCode(), ResultCodeEnum.UID_USER_NOT_EXIST.getMessage());
        }
        // }
        // 缓存信息
        getInfoFromCache(sysUser);
        // 添加角色
        addUserRoles(roleIds, sysUser);
        // 添加所属子系统
        addUserSubSys(subSystemIds, sysUser, true);

        // 添加能力
        addUserAbilities(abilityIds, sysUser);
        // 添加用户组
        addGroups(groups, sysUser);

        SysUser addUser = sysUserDao.saveAndFlush(sysUser);
        return addUser;
    }

    /**
     * 添加用户组
     * 
     * @param groups
     * @param sysUser
     */
    private void addGroups(Set<GroupVO> groups, SysUser sysUser) {
        if (groups != null && groups.size() > 0) {
            for (GroupVO group : groups) {
                String groupId = group.getGroupId();
                if (groupId != null) {
                    SysGroup findOne = sysGroupDao.findOne(groupId);
                    if (findOne == null) {
                        throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
                    }
                    Set<SysGroup> masterGroups = sysUser.getMasterGroups();
                    Set<SysGroup> memberGroups = sysUser.getMemberGroups();
                    if (masterGroups == null) {
                        masterGroups = new HashSet<>(1);
                    }
                    if (memberGroups == null) {
                        memberGroups = new HashSet<>(1);
                    }
                    Boolean isMaster = group.getIsMaster();
                    if (isMaster) {
                        masterGroups.add(findOne);
                    } else {
                        memberGroups.add(findOne);
                    }

                    sysUser.setMasterGroups(masterGroups);
                    sysUser.setMemberGroups(memberGroups);
                }
            }
        } else if (groups != null && groups.size() == 0) {
            sysUser.setMasterGroups(null);
            sysUser.setMemberGroups(null);
        }
    }

    @Override
    public void deleteUser(String userId, String loginUserId) {
        if (StringUtils.isEmpty(loginUserId)) {
            throw new CustumException(ResultCodeEnum.USER_NOT_LOGGED_IN.getCode(), ResultCodeEnum.USER_NOT_LOGGED_IN.getMessage());
        }
        if (loginUserId.equals(userId)) {
            throw new CustumException(ResultCodeEnum.USER_CANNOT_DELETE_SELF.getCode(), ResultCodeEnum.USER_CANNOT_DELETE_SELF.getMessage());
        }
        // 检查userId
        SysUser user = checkUserId(userId, false, true);
        // 判断组是否有任务
        // boolean checkTask = ControllerCommonUtils.checkTask(null, userId);
        // if (!checkTask) {
        // throw new BusinessException(ResultCodeEnum.TASK_NOT_FINISHED, null,
        // ResultCodeEnum.TASK_NOT_FINISHED.getMessage());
        // }
        try {
            // 删除组关系
            Page<SysGroup> search = sysGroupService.search(userId, null, null, null, null, null, null, null, null, null, null, Integer.MAX_VALUE, null);
            for (SysGroup sysGroup : search.getContent()) {
                Set<SysUser> masters = sysGroup.getMasters();
                Set<SysUser> members = sysGroup.getMembers();
                if (masters.contains(user)) {
                    masters.remove(user);
                }
                if (members.contains(user)) {
                    members.remove(user);
                }
                sysGroupDao.saveAndFlush(sysGroup);
            }

            // 清楚该用户缓存
            ldapAuthorize.delete(userId);
            sysUserDao.delete(userId);
            log.info("delete user : {} fully", userId);
            // 发送删除用户的消息
            RTopic<String> topic = redissonClient.getTopic(Constanst.DELETE_USER_TOPIC);
            topic.publish(userId);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public SysUser updateUser(String userId, String status, Set<String> roleIds, Set<String> subSystemIds, Set<String> abilityIds, Set<GroupVO> groups) {
        // 检查userId
        SysUser sysUser = checkUserId(userId, false, true);
        // 修正状态
        addUserStatus(status, sysUser);
        // 添加角色
        addUserRoles(roleIds, sysUser);
        // 添加所属子系统
        addUserSubSys(subSystemIds, sysUser, false);
        // 添加能力
        addUserAbilities(abilityIds, sysUser);
        // 添加用户组
        addGroups(groups, sysUser);
        try {
            return sysUserDao.saveAndFlush(sysUser);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public SysUser updateUser(String userId, String status, Set<String> roleIds, String subSystemId, Set<String> abilityIds, Set<GroupVO> groups) {
        // 检查userId
        SysUser sysUser = checkUserId(userId, false, true);
        // 修正状态
        addUserStatus(status, sysUser);
        // 添加角色
        addUserRoles(roleIds, sysUser, subSystemId);
        // 添加所属子系统
        Set<String> subSystemIds = new HashSet<>(1);
        subSystemIds.add(subSystemId);
        addUserSubSys(subSystemIds, sysUser, false);
        // 添加能力
        addUserAbilities(abilityIds, sysUser);
        // 添加用户组
        addGroups(groups, sysUser);
        try {
            return sysUserDao.saveAndFlush(sysUser);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public void updateUserDeleteRole(String userId, String roleId) {
        // 检查userId
        SysUser sysUser = checkUserId(userId, false, true);

        if (StringUtils.isEmpty(roleId)) {
            throw new CustumException(ResultCodeEnum.ROLE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.ROLE_ID_CANNOT_NULL.getMessage());
        }
        SysRole sysRole = sysRoleDao.findOne(roleId);
        if (sysRole == null) {
            throw new CustumException(ResultCodeEnum.ROLE_NOT_EXISTED.getCode(), ResultCodeEnum.ROLE_NOT_EXISTED.getMessage());
        }
        if (!sysUser.getSysRoles().contains(sysRole)) {
            throw new CustumException(ResultCodeEnum.USER_HAVING_NOT_ROLE.getCode(), ResultCodeEnum.USER_HAVING_NOT_ROLE.getMessage());
        }
        Set<SysRole> sysRoles = sysUser.getSysRoles();
        if (sysRoles.contains(sysRole)) {
            sysRoles.remove(sysRole);
        }
        try {
            sysUserDao.saveAndFlush(sysUser);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }
    }

    @Override
    public void updateUserDeleteSubSystem(String userId, String subSystemId) {
        // 检查userId
        SysUser sysUser = checkUserId(userId, false, true);
        if (StringUtils.isEmpty(subSystemId)) {
            throw new CustumException(ResultCodeEnum.SUB_SYSTEM_ID_CANNOT_NULL.getCode(), ResultCodeEnum.SUB_SYSTEM_ID_CANNOT_NULL.getMessage());
        }
        SysSubSystem sysSubSystem = sysSubSystemDao.findOne(subSystemId);
        if (sysSubSystem == null) {
            throw new CustumException(ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED.getCode(), ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED.getMessage());
        }
        Set<SysSubSystem> userOwmSys = sysUser.getSysSubSystems();
        if (userOwmSys.contains(sysSubSystem)) {
            userOwmSys.remove(sysSubSystem);
        }
        try {
            sysUserDao.saveAndFlush(sysUser);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public Page<SysUser> getSysUsers(String pageNo, String pageSize, String userId, String userName, String roleId, String subsystemId, String status, String roleName,
            List<String> properties, String sortDirection, Set<String> abilityIds, String abilityIdsCondition, String abilityName, String abilityNameLike) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, properties, sortDirection, "userName");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(userId)) {
            userId = userId.replaceAll("%", "\\\\%");
            userId = userId.replaceAll("_", "\\\\_");
        }
        final String userIdTmp = userId;
        if (StringUtils.isNotEmpty(userName)) {
            userName = userName.replaceAll("%", "\\\\%");
            userName = userName.replaceAll("_", "\\\\_");
        }
        final String userNameTmp = userName;
        // 特殊字符转义
        if (StringUtils.isNotEmpty(roleName)) {
            roleName = roleName.replaceAll("%", "\\\\%");
            roleName = roleName.replaceAll("_", "\\\\_");
        }

        final String abilityNameTmp = abilityName;

        final String roleNameTmp = roleName;
        Specification<SysUser> specification = new Specification<SysUser>() {
            @Override
            public Predicate toPredicate(Root<SysUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(userIdTmp)) {
                    predicates.add(cb.equal(root.get("userId"), userIdTmp));
                }
                if (StringUtils.isNotEmpty(userNameTmp)) {
                    predicates.add(cb.like(root.get("userName"), "%" + userNameTmp + "%"));
                }

                if (StringUtils.isNotEmpty(roleId)) {
                    Join<SysUser, SysRole> join = root.join("sysRoles", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("roleId"), roleId));
                }
                if (StringUtils.isNotEmpty(subsystemId)) {
                    if (Constanst.GLOABLE_FLG.equalsIgnoreCase(subsystemId)) {
                        predicates.add(cb.isEmpty(root.get("sysSubSystems")));
                    } else {
                        Join<SysUser, SysSubSystem> join = root.join("sysSubSystems", JoinType.LEFT);
                        predicates.add(cb.equal(join.get("subsystemId"), subsystemId));
                    }
                }
                if (StringUtils.isNotEmpty(status)) {
                    ControllerCommonUtils.checkStatus(status);
                    predicates.add(cb.equal(root.get("status"), status));
                }
                if (StringUtils.isNotEmpty(roleNameTmp)) {
                    Join<SysUser, SysRole> join = root.join("sysRoles", JoinType.LEFT);
                    predicates.add(cb.or(cb.like(join.get("roleName"), "%" + roleNameTmp + "%"), cb.like(join.get("roleDesc"), "%" + roleNameTmp + "%")));
                }
                if (abilityIds != null && abilityIds.size() > 0) {
                    Join<SysUser, DataDictionary> join = root.join("abilities", JoinType.LEFT);
                    List<Predicate> restrictions = new ArrayList<>(16);

                    for (String abilityId : abilityIds) {
                        restrictions.add(cb.equal(join.get("dataId"), abilityId));
                    }
                    String and = "and";
                    if (StringUtils.equalsIgnoreCase(and, abilityIdsCondition)) {
                        predicates.add(cb.and(restrictions.toArray(new Predicate[] {})));
                    } else {
                        predicates.add(cb.or(restrictions.toArray(new Predicate[] {})));
                    }

                }

                if (StringUtils.isNotEmpty(abilityNameTmp)) {
                    Join<SysUser, DataDictionary> join = root.join("abilities", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(abilityNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(join.get("name"), "%" + abilityNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(join.get("name"), abilityNameTmp));
                    }
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        Page<SysUser> pageSysUsers = sysUserDao.findAll(specification, pageable);
        pageSysUsers = filterRoles(pageSysUsers, subsystemId);
        return getUserInfo(pageSysUsers);
    }

    /**
     * 过滤角色
     * 
     * @param sysUsers
     * @param subsystemId
     */
    private Page<SysUser> filterRoles(Page<SysUser> sysUsers, String subsystemId) {
        if (StringUtils.isEmpty(subsystemId)) {
            return sysUsers;
        }
        Iterator<SysUser> iteratorUser = sysUsers.getContent().iterator();
        while (iteratorUser.hasNext()) {
            SysUser sysUser = iteratorUser.next();
            entityManager.detach(sysUser);
            Iterator<SysRole> iteratorRole = sysUser.getSysRoles().iterator();
            while (iteratorRole.hasNext()) {
                SysRole sysRole = iteratorRole.next();
                if (sysRole != null) {
                    if (sysRole.getSysSubsystem() != null) {
                        if (!sysRole.getSysSubsystem().getSubsystemId().equals(subsystemId)) {
                            iteratorRole.remove();
                        }
                    } else {
                        iteratorRole.remove();
                    }
                }
            }
        }
        return sysUsers;
    }

    /**
     * 从缓存取信息填充用户信息
     * 
     * @param usersPage
     * @return
     */
    private Page<SysUser> getUserInfo(Page<SysUser> usersPage) {
        if (usersPage != null && usersPage.getContent() != null) {
            for (SysUser sysUser : usersPage.getContent()) {
                getInfoFromCache(sysUser);
            }
        }
        return usersPage;
    }

    /**
     * 从缓存中取用户信息
     * 
     * @param sysUser
     */
    private void getInfoFromCache(SysUser sysUser) {
        PersonDto person = (PersonDto) ldapAuthorize.get(sysUser.getUserId());
        if (person != null) {
            ArrayList<String> mail = person.getMail();
            if (mail != null && mail.size() > 0) {
                sysUser.setEmail(mail.get(0));
            }
            ArrayList<String> mailnickname = person.getName();
            if (mailnickname != null && mailnickname.size() > 0) {
                sysUser.setUserName(mailnickname.get(0));
            }
            ArrayList<String> thumbnailPhoto = person.getThumbnailPhoto();
            if (thumbnailPhoto != null && thumbnailPhoto.size() > 0) {
                sysUser.setAvatar(thumbnailPhoto.get(0));
            }
        }
    }

    /**
     * 检查userId
     * 
     * @param userId
     * @param checkLength
     * @param checkNull
     * @return
     */
    private SysUser checkUserId(String userId, boolean checkLength, boolean checkNull) {
        if (checkLength && StringUtils.isEmpty(userId)) {
            throw new CustumException(ResultCodeEnum.USER_ID_CANNOT_NULL.getCode(), ResultCodeEnum.USER_ID_CANNOT_NULL.getMessage());
        }
        if (checkLength && userId.length() > Constanst.USER_ID_LENGTH) {
            throw new CustumException(ResultCodeEnum.USER_ID_TOO_LONG.getCode(), ResultCodeEnum.USER_ID_TOO_LONG.getMessage());
        }
        SysUser sysUser = sysUserDao.findOne(userId);
        if (checkNull) {
            if (sysUser == null) {
                throw new CustumException(ResultCodeEnum.USER_NOT_EXIST.getCode(), ResultCodeEnum.USER_NOT_EXIST.getMessage());
            }
        } else {
            if (sysUser != null) {
                throw new CustumException(ResultCodeEnum.USER_HAS_EXISTED.getCode(), ResultCodeEnum.USER_HAS_EXISTED.getMessage());
            }
        }

        return sysUser;
    }

    /**
     * 修正状态
     * 
     * @param status
     * @param sysUser
     */
    private void addUserStatus(String status, SysUser sysUser) {
        if (status != null) {
            Set<String> statusSet = new HashSet<>();
            statusSet.add(Constanst.ACTIVE_STATUS_0);
            statusSet.add(Constanst.ACTIVE_STATUS_1);
            if (!statusSet.contains(status)) {
                throw new CustumException(ResultCodeEnum.STATUS_JUST_ONLY_ONE_TWO.getCode(), ResultCodeEnum.STATUS_JUST_ONLY_ONE_TWO.getMessage());
            }
            sysUser.setStatus(status);
        }
    }

    /**
     * 添加所属子系统
     * 
     * @param subSystemIds
     * @param sysUser
     */
    private void addUserSubSys(Set<String> subSystemIds, SysUser sysUser, boolean isAdd) {
        if (subSystemIds != null && subSystemIds.size() > 0) {
            Set<SysSubSystem> userOwnSys = sysUser.getSysSubSystems();
            if (userOwnSys == null) {
                userOwnSys = new HashSet<>(subSystemIds.size());
            }
            for (String subSystemId : subSystemIds) {
                SysSubSystem sysSubSystem = sysSubSystemDao.findOne(subSystemId);
                if (sysSubSystem != null) {
                    if (!userOwnSys.contains(sysSubSystem)) {
                        userOwnSys.add(sysSubSystem);
                    } else {
                        if (isAdd) {
                            throw new CustumException(ResultCodeEnum.USER_HAS_EXISTED.getCode(), ResultCodeEnum.USER_HAS_EXISTED.getMessage());
                        }
                    }
                }
            }
            sysUser.setSysSubSystems(userOwnSys);
        }
    }

    /**
     * 更新用户能力
     * 
     * @param abilityIds
     * @param sysUser
     */
    private void addUserAbilities(Set<String> abilityIds, SysUser sysUser) {
        if (abilityIds != null && abilityIds.size() > 0) {
            Set<DataDictionary> abilities = new HashSet<>(abilityIds.size());
            for (String abilityId : abilityIds) {
                DataDictionary findOne = dataDictionaryDao.findOne(abilityId);
                if (findOne != null) {
                    abilities.add(findOne);
                }
            }
            sysUser.setAbilities(abilities);
        } else if (abilityIds != null && abilityIds.size() <= 0) {
            sysUser.setAbilities(null);
        }
    }

    /**
     * 添加角色
     * 
     * @param roleIds
     * @param sysUser
     */
    private void addUserRoles(Set<String> roleIds, SysUser sysUser) {
        if (roleIds != null && roleIds.size() > 0) {
            Set<SysRole> userOwnRoles = sysUser.getSysRoles();
            if (userOwnRoles == null) {
                userOwnRoles = new HashSet<>(roleIds.size());
            }
            for (String roleId : roleIds) {
                SysRole sysRole = sysRoleDao.findOne(roleId);
                if (sysRole != null) {
                    userOwnRoles.add(sysRoleDao.findOne(roleId));
                }
            }
            sysUser.setSysRoles(userOwnRoles);
        }
    }

    private void addUserRoles(Set<String> roleIds, SysUser sysUser, String subSystemId) {
        Page<SysRole> userSysRoles = sysRoleService.getSysRoles("0", Integer.toString(Integer.MAX_VALUE), null, null, subSystemId, sysUser.getUserId(), null, null, null);
        Set<SysRole> userOwnRoles = sysUser.getSysRoles();
        if (roleIds != null && roleIds.size() > 0) {
            if (userOwnRoles == null) {
                userOwnRoles = new HashSet<>(roleIds.size());
            }
            if (userSysRoles != null && userSysRoles.getTotalElements() > 0) {
                userOwnRoles.removeAll(userSysRoles.getContent());
            }
            for (String roleId : roleIds) {
                SysRole sysRole = sysRoleDao.findOne(roleId);
                if (sysRole != null) {
                    userOwnRoles.add(sysRoleDao.findOne(roleId));
                }
            }
        } else {
            userOwnRoles.removeAll(userSysRoles.getContent());
        }

        sysUser.setSysRoles(userOwnRoles);
    }

    @Override
    public Page<Object> searchUserInfo(String userId, String pageNo, String pageSize) {
        if (StringUtils.isEmpty(userId)) {
            throw new CustumException(ResultCodeEnum.USER_ID_CANNOT_NULL.getCode(), ResultCodeEnum.USER_ID_CANNOT_NULL.getMessage());
        }
        Integer pageNo2 = 0;
        Integer pageSize2 = 0;
        try {
            pageNo2 = Integer.parseInt(pageNo);
        } catch (NumberFormatException e) {
            pageNo2 = Constanst.FIRST_PAGE_NO;
        }
        try {
            pageSize2 = Integer.parseInt(pageSize);
        } catch (NumberFormatException e) {
            pageSize2 = Constanst.PAGE_SIZE;
        }
        if (pageNo2 <= 0) {
            pageNo2 = Constanst.FIRST_PAGE_NO;
        }
        if (pageSize2 <= 0) {
            pageSize2 = Constanst.PAGE_SIZE;
        }
        // JPA的page参数从0开始
        pageNo2--;
        PageImpl<Object> pager = new PageImpl<Object>(ldapAuthorize.autoCompletedSearch(userId, pageNo2.toString(), pageSize2.toString()),
                new PageRequest(pageNo2, pageSize2, null),
                ldapAuthorize.autoCompletedSearch(userId, Constanst.FIRST_PAGE_NO.toString(), Integer.toString(Integer.MAX_VALUE)).size());
        return pager;
    }
}
