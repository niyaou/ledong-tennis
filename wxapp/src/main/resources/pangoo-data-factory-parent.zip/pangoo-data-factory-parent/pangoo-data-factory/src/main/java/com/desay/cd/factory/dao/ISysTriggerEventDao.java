package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.desay.cd.factory.entity.mysql.SysTriggerEvent;

/**
 * /** ISysTriggerEventDao
 * 
 * @author pengdengfu
 *
 */

public interface ISysTriggerEventDao extends JpaRepository<SysTriggerEvent, Serializable> {

}
