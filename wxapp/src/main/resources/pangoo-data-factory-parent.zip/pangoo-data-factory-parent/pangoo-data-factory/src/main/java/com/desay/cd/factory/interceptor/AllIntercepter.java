package com.desay.cd.factory.interceptor;

import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.service.ISysUserService;
import com.desay.cd.factory.utils.RespUtil;
import com.desay.cd.factory.utils.StringUtil;
import com.google.gson.Gson;

/**
 * 请求拦截器
 * 
 * @author uidq1163
 *
 */
public class AllIntercepter extends HandlerInterceptorAdapter {

    @Autowired
    private ISysUserService userService;

    @Value("${pangoo-data-factory.intercepter}")
    Boolean intercepter;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (intercepter) {
            return allowVisit(request, response);
        } else {
        }
        return true;
    }

    /**
     * 是否允许访问
     * 
     * @param request
     * @param response
     * @return
     */
    private boolean allowVisit(HttpServletRequest request, HttpServletResponse response) {
        // 拦截未登录的url
        String rex = "(\\.html)|(\\.css)|(\\.js)|(\\.woff)|(v2/api-docs)|(swagger-resources)";
        Pattern sinaPatten = Pattern.compile(rex, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
        // 获取此请求的地址
        // 非法路径处理
        String uri = request.getRequestURI();
        // 请求的方法
        String method = request.getMethod();
        Matcher matcher = sinaPatten.matcher(uri);
        if (matcher.find()) {

        } else {
            Object token = request.getHeader("access_token");
            Boolean tokenFlg = Boolean.FALSE;
            Boolean urlFlg = Boolean.FALSE;
            if (null != token) {
                TokenDto tokenDto = (TokenDto) userService.tokenAuthorize((String) token);
                if (null != tokenDto) {
                    tokenFlg = Boolean.TRUE;
                    Map<String, Object> sysUser = (Map<String, Object>) tokenDto.getUserInfo();
                    Set<SysPermission> sysPermissions = (Set<SysPermission>) sysUser.get("permissions");
                    // for (SysRole sysRole : sysRoles) {
                    // Set<SysPermission> sysPermissions = sysRole.getPermissions();
                    for (SysPermission sysPermission : sysPermissions) {
                        if (StringUtil.isNotEmpty(sysPermission.getUrl())) {
                            AntPathMatcher methodmatcher = new AntPathMatcher();
                            String methodpattern = sysPermission.getUrl();
                            if (methodmatcher.match(methodpattern, uri) && sysPermission.getMethod().toUpperCase().equals(method)) {
                                urlFlg = true;
                                break;
                            }
                        }
                    }
                    // if (urlFlg) {
                    // break;
                    // }
                    // }
                }
            }
            if (tokenFlg && urlFlg) {
                return true;
            } else {
                if (!tokenFlg) {
                    // 认证失败
                    RespUtil.returnResult(request, response, new Gson().toJson(CommonResponse.failure(ResultCodeEnum.TOKEN_PERMSSION_ERROR)));
                    return false;
                }
                if (!urlFlg) {
                    // 该接口没有访问权限
                    RespUtil.returnResult(request, response, new Gson().toJson(CommonResponse.failure(ResultCodeEnum.PERMISSION_NO_ACCESS)));
                    return false;
                }
            }
        }
        return true;
    }

}
