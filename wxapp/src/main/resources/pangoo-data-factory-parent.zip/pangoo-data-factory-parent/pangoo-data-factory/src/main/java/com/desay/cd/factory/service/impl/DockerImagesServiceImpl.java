package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.storage.engine.common.rest.RestClient;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONPath;
import com.desay.cd.factory.entity.mysql.SysEnvConfig;
import com.desay.cd.factory.service.IDockerImagesService;
import com.desay.cd.factory.service.ISysEnvConfigService;

/**
 * 
 * @ClassName: DockerImagesServiceImpl
 * @author: pengdengfu
 * @date: 2019年11月1日 下午12:01:07
 */
@Service
public class DockerImagesServiceImpl implements IDockerImagesService {
    @Autowired
    private ISysEnvConfigService sysEnvConfigService;

    @Override
    public Object getImagesInfo(String type, String imageName) {
        Page<SysEnvConfig> imageServerConfig = sysEnvConfigService.search(null, "2", null, null, null, null, Integer.MAX_VALUE, null);
        if (imageServerConfig == null || imageServerConfig.getTotalElements() <= 0) {
            return null;
        }
        SysEnvConfig sysEnvConfig = imageServerConfig.getContent().get(0);
        String ip = sysEnvConfig.getIp();
        Integer sshPort = sysEnvConfig.getSshPort();
        String userName = sysEnvConfig.getUserName();
        String password = sysEnvConfig.getPassword();
        String requestUrl = "";
        String restResponse = "";
        String type1 = "1";
        if (StringUtils.equals(type, type1)) {
            requestUrl = "http://" + ip + ":" + sshPort + "/api/projects?name=dcs";
            restResponse = RestClient.getRestResponse(requestUrl, userName, password);
            Object projectId = JSONPath.read(restResponse, "$[0].project_id");
            if (projectId == null || StringUtils.isEmpty(projectId + "")) {
                return null;
            }
            // http://10.219.6.29:8000/api/repositories?project_id=3
            requestUrl = "http://" + ip + ":" + sshPort + "/api/repositories?project_id=" + projectId;
            restResponse = RestClient.getRestResponse(requestUrl, userName, password);
        } else {
            // http://10.219.6.29:8000/api/repositories/dcs%2Fdcs_yolov3/tags
            requestUrl = "http://" + ip + ":" + sshPort + "/api/repositories/" + imageName + "/tags";
            restResponse = RestClient.getRestResponse(requestUrl, userName, password);
        }
        JSONArray jsonArr = JSONArray.parseArray(restResponse);
        JSONArray sortedJsonArray = new JSONArray();
        List<JSONObject> jsonValues = new ArrayList<JSONObject>();
        for (int i = 0; i < jsonArr.size(); i++) {
            jsonValues.add(jsonArr.getJSONObject(i));
        }
        Collections.sort(jsonValues, new Comparator<JSONObject>() {

            @Override
            public int compare(JSONObject a, JSONObject b) {
                String nameA = a.getString("name");
                String nameB = b.getString("name");
                return nameB.compareTo(nameA);
            }
        });
        for (int i = 0; i < jsonArr.size(); i++) {
            sortedJsonArray.add(jsonValues.get(i));
        }
        return sortedJsonArray;
    }

}
