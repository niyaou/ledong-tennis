package com.desay.cd.factory.rest;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysNoticeRules;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddNoticeRulesVo;
import com.desay.cd.factory.service.ISysNoticeRulesService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/***
 * 通知规则管理
 * 
 * @author pengdengfu
 *
 */
@RestController
@Api(value = "通知规则管理", tags = "SysNoticeRulesController")
@ApiIgnore
public class SysNoticeRulesController {
    @Autowired
    private ISysNoticeRulesService sysNoticeRulesService;

    /**
     * 添加通知规则
     * 
     * @param userId
     * @param triggerEventIds
     * @param noticeFreqId
     * @return
     */
    @RequestMapping(value = "/management/noticeRules/backup", method = RequestMethod.POST)
    @ApiIgnore
    @ApiOperation(value = "添加通知规则(包括更新功能)", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId(当userId=all时，代表所有用户的通用设置)", required = true, dataType = "string", paramType = "form"),
            @ApiImplicitParam(name = "triggerEventIds", value = "触发事件Id，忽略不存储在的权限ID(不传该参数哦，则不更新；传递空数组，则是清空触发事件)", required = false, allowMultiple = true, dataType = "string", paramType = "form"),
            @ApiImplicitParam(name = "noticeFrequencyId", value = "通知频率ID", required = false, dataType = "string", paramType = "form") })
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "添加通知规则(包括更新功能)")
    public ResponseEntity<?> addNoticeRule(@RequestParam(value = "userId", required = true) String userId, @RequestParam(value = "triggerEventIds", required = false) Set<String> triggerEventIds,
            @RequestParam(value = "noticeFrequencyId", required = false) String noticeFrequencyId) {
        SysNoticeRules sysNoticeRules = sysNoticeRulesService.addNoticeRule(userId, triggerEventIds, noticeFrequencyId);
        return new ResponseEntity<Object>(CommonResponse.success(sysNoticeRules.getUserId()), HttpStatus.OK);
    }

    /**
     * 添加通知规则
     * 
     * @param userId
     * @param triggerEventIds
     * @param noticeFreqId
     * @return
     */
    @RequestMapping(value = "/management/noticeRules", method = RequestMethod.POST)
    @ApiOperation(value = "添加通知规则(包括更新功能)", notes = "")
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "添加通知规则(包括更新功能)(json请求)")
    public ResponseEntity<?> addNoticeRule(@RequestBody AddNoticeRulesVo addNoticeRules) {
        SysNoticeRules sysNoticeRules = sysNoticeRulesService.addNoticeRule(addNoticeRules.getUserId(), addNoticeRules.getTriggerEventIds(), addNoticeRules.getNoticeFreqId());
        return new ResponseEntity<Object>(CommonResponse.success(sysNoticeRules.getUserId()), HttpStatus.OK);
    }

    /**
     * 删除通知规则
     * 
     * @param userId
     * @return
     */
    @RequestMapping(value = "/management/noticeRules/{userId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除通知规则", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "删除通知规则")
    public ResponseEntity<?> deleteNoticeRule(@PathVariable(value = "userId", required = true) String userId) {
        sysNoticeRulesService.deleteNoticeRule(userId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取指定用户的通知规则
     * 
     * @param userId
     * @return
     */
    @RequestMapping(value = "/management/noticeRules/{userId}", method = RequestMethod.GET)
    @ApiOperation(value = "获取通知规则", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "userId", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "获取通知规则")
    public ResponseEntity<?> getNoticeRules(@PathVariable(value = "userId", required = true) String userId) {
        List<SysNoticeRules> noticeRules = sysNoticeRulesService.getNoticeRules(userId);
        return new ResponseEntity<Object>(CommonResponse.success(noticeRules), HttpStatus.OK);
    }

}
