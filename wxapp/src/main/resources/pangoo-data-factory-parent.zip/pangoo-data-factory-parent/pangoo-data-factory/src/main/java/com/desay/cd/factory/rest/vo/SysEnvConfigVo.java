package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: CleanStrategyVo
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:37:13
 */
@Data
public class SysEnvConfigVo implements Serializable {
    private static final long serialVersionUID = 8597533682669337821L;
    @ApiModelProperty(value = "数据类型：1，算法机器；2：镜像仓库；3：hdfs client")
    @NotEmpty
    private String type;

    @ApiModelProperty(value = "IP地址")
    @NotEmpty
    private String ip;

    @ApiModelProperty(value = "主机名称")
    private String hostName;

    @ApiModelProperty(value = "ssh连接端口")
    private Integer sshPort;

    @ApiModelProperty(value = "用户名")
    private String userName;

    @ApiModelProperty(value = "密码")
    private String password;

}
