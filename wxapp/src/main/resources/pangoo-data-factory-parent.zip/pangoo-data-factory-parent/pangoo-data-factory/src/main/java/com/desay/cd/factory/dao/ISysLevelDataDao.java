package com.desay.cd.factory.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.cd.factory.entity.mysql.SysLevelData;

/**
 * ISysTagDao
 * 
 * @author pengdengfu
 *
 */
public interface ISysLevelDataDao extends JpaRepository<SysLevelData, Serializable>, JpaSpecificationExecutor<SysLevelData> {
    /**
     * 查询顶级标签
     * 
     * @return
     */
    List<SysLevelData> findByParentIsNull();
}
