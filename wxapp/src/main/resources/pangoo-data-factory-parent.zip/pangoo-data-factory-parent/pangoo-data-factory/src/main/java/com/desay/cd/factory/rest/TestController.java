package com.desay.cd.factory.rest;

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.BeanFactoryUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.desay.cd.auth.uitls.RsaUtils;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ThumbNail;
import com.desay.cd.factory.service.IFileService;
import com.desay.cd.factory.service.ISysUserService;
import com.desay.cd.factory.service.MailSenderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 测试
 * 
 * @author uidq1163
 *
 */
@RestController
@Api(value = "内部测试专用")
public class TestController {
    @Autowired
    private ISysUserService userService;
    @Autowired
    private MailSenderService mailSenderService;
    @Autowired
    private IFileService fileService;

    /**
     * 获取服务器公钥
     * 
     * @return
     */
    @RequestMapping(value = "/getPassWordRSA", method = RequestMethod.POST)
    @ApiImplicitParams({ @ApiImplicitParam(name = "password", value = "用户密码", required = true, dataType = "string", paramType = "form") })
    @ApiOperation(value = "密码进行RSA加密", notes = "")
    public ResponseEntity<?> getServerPublicKey(@RequestParam(value = "password", required = true) String password) {
        String publicKey = (String) userService.getPublicKey();
        Object encodepwd = null;
        try {
            encodepwd = RsaUtils.rsaEncode(string2PublicKey(publicKey), password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<Object>(CommonResponse.success(encodepwd), HttpStatus.OK);
    }

    /**
     * 获取服务器公钥
     * 
     * @return
     */
    @RequestMapping(value = "/mailSender", method = RequestMethod.POST)
    @ApiImplicitParams({ @ApiImplicitParam(name = "title", value = "邮件主题", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "message", value = "邮件信息", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "mail", value = "邮件地址", required = true, dataType = "string", paramType = "query") })
    @ApiOperation(value = "发送邮件", notes = "")
    public ResponseEntity<?> mailSender(@ApiIgnore HttpServletRequest request, @RequestParam(value = "title", required = true) String title,
            @RequestParam(value = "message", required = true) String message, @RequestParam(value = "mail", required = true) String mail) {
        String errorMsg = null;
        HttpStatus httpStatus = null;
        try {
            mailSenderService.sendMail(title, message, mail);
            httpStatus = HttpStatus.OK;
        } catch (Exception e) {
            errorMsg = e.getMessage();
            httpStatus = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(CommonResponse.success(errorMsg), httpStatus);
    }

    @Autowired
    private ApplicationContext applicationContext;

    @ApiOperation(value = "文件管理-开始制作视频文件缩略图", notes = "")
    @RequestMapping(value = "/fileSystem/files/thumbnail", method = RequestMethod.GET)
    public Object createThumbNail() {
        applicationContext.publishEvent(new ThumbNail(this));
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-根据ID获取文件缩略图路径 ", notes = "")
    @RequestMapping(value = "/fileSystem/thumbNailPath/{id}", method = RequestMethod.GET)
    @ApiImplicitParam(name = "id", value = "文件ID", required = true, dataType = "string", paramType = "path")
    public Object getFileThumbNailPath(HttpServletRequest request, @PathVariable(value = "id", required = true) String id) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.getThumbNailPath(id)), HttpStatus.OK);
    }

    /**
     * 将Base64编码后的公钥转换成PublicKey对象
     * 
     * @param pubStr
     * @return
     * @throws Exception
     */
    public PublicKey string2PublicKey(String pubStr) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(pubStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    private Object test(HttpServletRequest request) {

        javax.servlet.ServletContext servletContext = request.getSession().getServletContext();
        if (servletContext == null) {
            return null;
        }
        WebApplicationContext appContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);

        // 请求url和处理方法的映射
        List<RequestToMethodItem> requestToMethodItemList = new ArrayList<RequestToMethodItem>();
        // 获取所有的RequestMapping
        Map<String, HandlerMapping> allRequestMappings = BeanFactoryUtils.beansOfTypeIncludingAncestors(appContext, HandlerMapping.class, true, false);

        for (HandlerMapping handlerMapping : allRequestMappings.values()) {
            // 本项目只需要RequestMappingHandlerMapping中的URL映射
            if (handlerMapping instanceof RequestMappingHandlerMapping) {
                RequestMappingHandlerMapping requestMappingHandlerMapping = (RequestMappingHandlerMapping) handlerMapping;
                Map<RequestMappingInfo, HandlerMethod> handlerMethods = requestMappingHandlerMapping.getHandlerMethods();
                for (Map.Entry<RequestMappingInfo, HandlerMethod> requestMappingInfoHandlerMethodEntry : handlerMethods.entrySet()) {
                    RequestMappingInfo requestMappingInfo = requestMappingInfoHandlerMethodEntry.getKey();
                    HandlerMethod mappingInfoValue = requestMappingInfoHandlerMethodEntry.getValue();

                    RequestMethodsRequestCondition methodCondition = requestMappingInfo.getMethodsCondition();

                    String requestType = methodCondition.getMethods() != null && methodCondition.getMethods().size() > 0
                            ? methodCondition.getMethods().stream().collect(Collectors.toList()).get(0).toString()
                            : null;

                    PatternsRequestCondition patternsCondition = requestMappingInfo.getPatternsCondition();

                    String requestUrl = patternsCondition.getPatterns() != null && patternsCondition.getPatterns().size() > 0
                            ? patternsCondition.getPatterns().stream().collect(Collectors.toList()).get(0).toString()
                            : null;

                    String controllerName = mappingInfoValue.getBeanType().toString();
                    String requestMethodName = mappingInfoValue.getMethod().getName();
                    Class<?>[] methodParamTypes = mappingInfoValue.getMethod().getParameterTypes();
                    RequestToMethodItem item = new RequestToMethodItem(requestUrl, requestType, controllerName, requestMethodName, methodParamTypes);

                    requestToMethodItemList.add(item);
                }
                break;
            }
        }
        return requestToMethodItemList;
    }

    private class RequestToMethodItem {
        public String controllerName;
        public String methodName;
        public String requestType;
        public String requestUrl;
        public Class<?>[] methodParmaTypes;

        public RequestToMethodItem(String requestUrl, String requestType, String controllerName, String requestMethodName, Class<?>[] methodParmaTypes) {
            this.requestUrl = requestUrl;
            this.requestType = requestType;
            this.controllerName = controllerName;
            this.methodName = requestMethodName;
            this.methodParmaTypes = methodParmaTypes;

        }
    }

}
