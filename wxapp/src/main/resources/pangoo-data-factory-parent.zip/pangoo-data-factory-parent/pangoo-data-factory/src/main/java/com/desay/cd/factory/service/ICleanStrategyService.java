package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.CleanStrategy;

/**
 * 
 * @ClassName: ICleanStrategyService
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:22:23
 */
public interface ICleanStrategyService {
    /**
     * 添加
     * 
     * @param cleanStrategy
     * @return
     */
    String add(CleanStrategy cleanStrategy);

    /**
     * 删除
     * 
     * @param strgyId
     */
    void delete(String strgyId);

    /**
     * 更新
     * 
     * @param cleanStrategy
     * @param isOverall
     */
    void update(CleanStrategy cleanStrategy, boolean isOverall);

    /**
     * 查询
     * 
     * @param strgyId
     * @param strygName
     * @param strygNameLike
     * @param deviceId
     * @param deviceName
     * @param deviceNameLike
     * @param algId
     * @param algName
     * @param algNameLike
     * @param status
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @return
     */
    Page<CleanStrategy> search(String strgyId, String strygName, String strygNameLike, String deviceId, String deviceName, String deviceNameLike, String algId, String algName, String algNameLike,
            String status, Integer pageNo, Integer pageSize, List<String> sortProperties);
}
