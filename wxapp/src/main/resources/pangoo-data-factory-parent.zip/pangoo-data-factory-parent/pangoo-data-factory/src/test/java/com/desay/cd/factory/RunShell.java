package com.desay.cd.factory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author uidq1070
 *
 */
public class RunShell {

    public static void writeToHdfs(OutputStream out) {
        File f = new File("D:\\temp\\dahai.mp4");
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(f);

            byte bytes[] = new byte[1024];
            int temp = 0;
            while ((temp = fileInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, temp);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fileInputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String downloadFile(String displayName, String storedPath, InputStream is) {
        File f = new File("D:\\temp\\" + displayName);
        FileOutputStream outputStream = null;

        try {
            System.out.println(is.available());
            outputStream = new FileOutputStream(f);
            byte bytes[] = new byte[1024];
            int temp = 0;
            while ((temp = is.read(bytes)) != -1) {
                outputStream.write(bytes, 0, temp);
            }
            return "temp/" + displayName;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;

    }

    public static String runShell(String[] cmds) {
        String result = "";
        Process process = null;
        List<String> processList = new ArrayList<String>();
        try {
            process = Runtime.getRuntime().exec(cmds);
            int exitValue = process.waitFor();
            System.out.println("runtime result :" + exitValue);
            if (0 != exitValue) {
                System.out.println("call shell failed. error code is :" + exitValue);
            }
            BufferedReader input = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = "";
            while ((line = input.readLine()) != null) {
                processList.add(line);
            }
            input.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (Exception f) {
            return null;
        }

        for (String line : processList) {
            result = line;
        }
        return result;
    }

    public static String[] createFrameTimes(String time) {
        String[] arrs = new String[25];
        String[] defaultArr = new String[] { "00:00:02", "00:00:04", "00:00:06", "00:00:08", "00:00:10", "00:00:12", "00:00:14", "00:00:16", "00:00:18", "00:00:20", "00:00:22",
                "00:00:24", "00:00:26", "00:00:28", "00:00:30", "00:00:32", "00:00:34", "00:00:36", "00:00:38", "00:00:40", "00:00:42", "00:00:44", "00:00:46", "00:00:48",
                "00:00:50", };
        String[] times = time.split(":");
        if (times.length > 1) {
            if (Integer.valueOf(times[1]) > 1 || Integer.valueOf(times[1]) > 0) {
                return defaultArr;
            } else {
                arrs = createSeries(times);
            }
            ;

        } else {
            return defaultArr;
        }

        return arrs;

    }

    public static String[] createSeries(String[] times) {
        float seconds = Float.parseFloat(times[2]);
        int minutes = Integer.parseInt(times[1]);
        float total = (minutes * 60 + seconds);
        float interval = total / 25;
        String[] arrs = new String[25];
        float current = 0;
        int int25 = 25;
        for (int i = 0; i < int25; i++) {
            current += interval;
            arrs[i] = secToTime(current);
        }
        return arrs;

    }

    public static String secToTime(float time) {
        String timeStr = null;
        int hour = 0;
        int minute = 0;
        float second = 0;
        if (time <= 0)
            return "00:00:00";
        else {
            int int60 = 60;
            int int99 = 99;
            minute = (int) (time / int60);
            if (minute < int60) {
                second = time % int60;
                timeStr = "00:" + unitFormat(minute, true) + ":" + unitFormat(second, false);
            } else {
                hour = minute / int60;
                if (hour > int99) {
                    return "99:59:59";
                }
                minute = minute % int60;
                second = time - hour * 3600 - minute * int60;
                timeStr = unitFormat(hour, true) + ":" + unitFormat(minute, true) + ":" + unitFormat(second, false);
            }
        }
        return timeStr;
    }

    public static String unitFormat(float i, boolean isInt) {
        String retStr = null;
        int int10 = 10;
        if (i >= 0 && i < int10) {
            retStr = isInt ? ("0" + (int) i) : ("0" + Float.toString(i));
        } else {
            retStr = isInt ? ("" + (int) i) : ("" + i);
        }
        System.out.println(retStr);
        return retStr;
    }

}
