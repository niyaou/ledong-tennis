package com.desay.cd.factory.service;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysRole;

/**
 * 角色服务
 * 
 * @author pengdengfu
 *
 */
public interface ISysRoleService {
    /**
     * 增加角色
     * 
     * @param roleName
     * @param roleDesc
     * @param permissionIds
     * @param subsystemId
     * @return
     */
    SysRole addRole(String roleName, String roleDesc, Set<String> permissionIds, String subsystemId);

    /**
     * 删除角色
     * 
     * @param roleId
     */
    void deleteRole(String roleId);

    /**
     * 更新角色
     * 
     * @param roleId
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @param subsystemId
     */
    void updateRole(String roleId, String roleName, String roleDesc, Set<String> permissions, String subsystemId);

    /**
     * 角色管理-更新角色-删除权限
     * 
     * @param roleId
     * @param permissionId
     */
    void updateRoleDeletePermission(String roleId, String permissionId);

    /**
     * 获取系统角色
     * 
     * @param pageNo
     * @param pageSize
     * @param roleId
     * @param roleName
     * @param subsystemId
     * @param userId
     * @param properties
     * @param sortDirection
     * @param status
     * @return
     */
    Page<SysRole> getSysRoles(String pageNo, String pageSize, String roleId, String roleName, String subsystemId, String userId, List<String> properties, String sortDirection, String status);

}
