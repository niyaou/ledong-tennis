package com.desay.cd.factory.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

import org.apache.commons.lang.StringUtils;
import org.apache.http.util.TextUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Page;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.entity.ThumbNail;
import com.desay.cd.factory.entity.mysql.SysChunksLog;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.transaction.base.FileElement;
import com.desay.cd.factory.utils.StringUtil;
import com.desay.cd.factory.utils.ThumbNailUtil;
import com.desay.cd.hdfs.HdfsUtils;

/**
 * 
 * @author uidq1343
 *
 */
@Component
public class EventObserver {
    private Logger logger = LoggerFactory.getLogger(EventObserver.class);
    @Autowired
    private ApplicationContext applicationContext;
    @Autowired
    private HdfsFileServiceImpl hdfsService;
    @Autowired
    private FileServiceImpl fileService;
    @Autowired
    private IndexServiceImpl indexService;
    @Autowired
    private SysChunksLogServiceImpl chunksLogService;

    private final String THUMBPATH = "thumbPath";

    private ConcurrentLinkedQueue<HashMap<String, Object>> queue = new ConcurrentLinkedQueue<HashMap<String, Object>>();
    Semaphore semaphore = new Semaphore(1);

    @Async
    @EventListener
    public void handler(FileElement element) {
        String chunksPath = "";
        SysChunksLog log = element.getChunksLogId();
        logger.info("  get async message element:" + element.getFileId());

        if (element.getChunk().getCurrent().intValue() == element.getChunk().getChunks().intValue()) {
            String targetPath = element.getFilePath();
            String pathChunks = hdfsService.getChunksFolderPath(element.getChunk().getFileId());
            chunksPath = pathChunks;
            log.setCurrent(element.getChunk().getCurrent() + 1);
            try {
                chunksLogService.uploadChunksLog(log);
            } catch (Exception e) {
                e.printStackTrace();
            }

            hdfsService.mergeHdfsFile(pathChunks.toString(), targetPath, element.getVo().getFileName());
            String path = new StringBuffer(targetPath).append(Constanst.FORWORD_SLASH).append(element.getVo().getFileName()).toString();
            chunksLogService.deleteChunksLog(log.getChunksLogId());
            if (!element.getChunk().getSize().equals(hdfsService.getFileSize(path))) {
                // 删除文件，将文件状态设为未完成
                if (!StringUtils.isEmpty(chunksPath)) {
                    try {
                        hdfsService.deleteDirectoryRecursively(chunksPath);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                element.getFileIndex().setStatus(FileStatusEnum.UN_FINISHED.getCode());
                indexService.updateFileInfomation(JSON.toJSONString(element.getFileIndex()), element.getChunk().getFileId());
            }
            applicationContext.publishEvent(new ThumbNail(this));
        }

    }

    @Async
    @EventListener
    public void handler(ThumbNail event) {
        logger.info("  get async create---- ThumbNail:-----");
        boolean flag = scanningMediaFiles();
        try {
            semaphore.acquire();
        } catch (InterruptedException e) {
            semaphore.release();
            logger.info("   ThumbNail circle  was interrupted:");
            e.printStackTrace();
            Thread.currentThread().interrupt();
            return;
        }

        while (!queue.isEmpty() && flag) {
            logger.info("  start Create  ThumbNail circle:");
            HashMap<String, Object> hashMap = null;
            try {
                hashMap = queue.element();
                if (StringUtil.isNotEmpty((String) hashMap.get(THUMBPATH))) {
                    queue.remove(hashMap);
                    logger.info("   current  ThumbNail is not empty:");
                    continue;
                }

                String id = (String) hashMap.get(IndexServiceImpl.FILEID);
                String type = (String) hashMap.get(IndexServiceImpl.FILETYPE);
                if (StringUtil.containsContent(type, "mp4") || StringUtil.containsContent(type, "avi")) {
                    String path = (String) hashMap.get(IndexServiceImpl.FILEPATH);
                    String name = (String) hashMap.get(IndexServiceImpl.FILENAME);
                    InputStream ins = HdfsUtils.downloadFileFromHdfs(new StringBuffer(path).append(name).append(Constanst.POINT).append(type).toString());
                    if (ins == null) {
                        logger.info("can not download file :" + name);
                        queue.remove(hashMap);
                        continue;
                    }
                    try {
                        String target = ThumbNailUtil.createGif(name, hdfsService.getCurrentFolderPath(HdfsFileServiceImpl.THUMBNAIL), ins);
                        logger.info(" createGif: " + target);
                        if (!TextUtils.isEmpty(target)) {
                            hashMap.put(IndexServiceImpl.THUMBPATH, target);
                            indexService.updateFileInfomation(JSON.toJSONString(hashMap), id);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        logger.info("finnall remove :" + name);
                        queue.remove(hashMap);
                    }
                }
            } catch (Exception no) {
                no.printStackTrace();
                if (hashMap != null) {
                    queue.remove(hashMap);
                }
            }
        }
        semaphore.release();
        logger.info("  release semaphore ---- ThumbNail done -----");
    }

    /**
     * 扫描文件仓库，添加未制作缩略图的媒体文件
     */
    @SuppressWarnings("unchecked")
    private boolean scanningMediaFiles() {
        int timeOut = 30;
        boolean addedElement = false;
        while (timeOut > 0) {
            timeOut--;
            Page<HashMap<String, Object>> result = (Page<HashMap<String, Object>>) fileService.exploreFilesByParams(null, "1", null, null, null, null, null, null, null, "0", null,
                    null, null, null, null, null);
            if (result.getNumberOfElements() != 0) {
                List<HashMap<String, Object>> fileArr = (List<HashMap<String, Object>>) result.getContent();
                for (HashMap<String, Object> hashMap : fileArr) {
                    if (!queue.contains(hashMap)) {
                        queue.add(hashMap);
                        addedElement = true;
                    }
                }
            }
        }
        return addedElement;

    }

}
