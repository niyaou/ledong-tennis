package com.desay.cd.factory.transaction.base;

import java.io.InputStream;
import java.sql.Date;
import java.text.ParseException;

import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.FileIndex;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysChunksLog;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.rest.vo.UploadChunkVo;
import com.desay.cd.factory.rest.vo.UploadFileVo;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.validate.Validate;
import com.desay.cd.factory.utils.validate.ValidateVO;

/**
 * 文件业务事务处理实体类
 * 
 * @author uidq1343
 *
 */
public class FileElement extends ValidateVO {

    private static final long serialVersionUID = -8532394067512815942L;

    @Validate(nullable = false, description = "文件名称,不包含后缀名")
    String fileName;

    @Validate(nullable = false, description = "用户id")
    String userId;

    @Validate(nullable = false, description = "操作时间")
    String operationTime;

    /** 所在目录 包含文件名称 包含末尾分隔符'/ */
    String filePath;

    /** 文件信息 */
    UploadFileVo vo;

    /** 文件分块信息 */
    UploadChunkVo chunk;

    /** 上传的临时文件存放路径 */
    String chunksPath;

    /** 日志文档id */
    String uploadLogId;

    /** 分块文件记录文档 */
    SysChunksLog chunksLogId;

    /** 用户ip */
    String ip;

    /** 文件id */
    String fileId;

    /** 文件大小 kb */
    Double fileSize = 0.0;

    /** 文件文档信息 */
    JSONObject doc;

    /** 文件索引信息 */
    FileIndex fileIndex;

    String auditMessage;

    /** 审核人 */
    String auditor;

    /** true 逻辑删除. false 物理删除 . */
    boolean logicDelete;

    /** 文件流 */
    InputStream ins;

    CustumException error;

    public FileElement() {
        try {
            setOperationTime(DateUtil.getDateTime(new Date(System.currentTimeMillis())));
        } catch (ParseException e) {
            e.printStackTrace();
            throw new CustumException(ResultCodeEnum.UPLOAD_LOG_DATE_PARSE_ERROR.getCode(), ResultCodeEnum.UPLOAD_LOG_DATE_PARSE_ERROR.getMessage());

        }
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(String operationTime) {
        this.operationTime = operationTime;
    }

    public String getUploadLogId() {
        return uploadLogId;
    }

    public void setUploadLogId(String uploadLogId) {
        this.uploadLogId = uploadLogId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Double getFileSize() {
        return fileSize;
    }

    public void setFileSize(Double fileSize) {
        this.fileSize = fileSize;
    }

    public JSONObject getDoc() {
        return doc;
    }

    public void setDoc(JSONObject doc) {
        this.doc = doc;
    }

    public boolean isLogicDelete() {
        return logicDelete;
    }

    public void setLogicDelete(boolean logicDelete) {
        this.logicDelete = logicDelete;
    }

    public InputStream getIns() {
        return ins;
    }

    public void setIns(InputStream ins) {
        this.ins = ins;
    }

    public CustumException getError() {
        return error;
    }

    public void setError(CustumException error) {
        this.error = error;
    }

    public UploadFileVo getVo() {
        return vo;
    }

    public void setVo(UploadFileVo vo) {
        this.vo = vo;
    }

    public UploadChunkVo getChunk() {
        return chunk;
    }

    public void setChunk(UploadChunkVo chunk) {
        this.chunk = chunk;
    }

    public String getChunksPath() {
        return chunksPath;
    }

    public void setChunksPath(String chunksPath) {
        this.chunksPath = chunksPath;
    }

    public String getAuditMessage() {
        return auditMessage;
    }

    public void setAuditMessage(String auditMessage) {
        this.auditMessage = auditMessage;
    }

    public String getAuditor() {
        return auditor;
    }

    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    public FileIndex getFileIndex() {
        return fileIndex;
    }

    public void setFileIndex(FileIndex fileIndex) {
        this.fileIndex = fileIndex;
    }

    public SysChunksLog getChunksLogId() {
        return chunksLogId;
    }

    public void setChunksLogId(SysChunksLog chunksLogId) {
        this.chunksLogId = chunksLogId;
    }

}
