package com.desay.cd.factory.service;

/**
 * 
 * @ClassName: IDockerImagesService
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:22:23
 */
public interface IDockerImagesService {
    /**
     * 查询镜像信息<br/>
     * 1，镜像列表<br/>
     * 2，镜像版本<br/>
     * 
     * @param type
     * @param imageName
     * @return
     */
    Object getImagesInfo(String type, String imageName);

}
