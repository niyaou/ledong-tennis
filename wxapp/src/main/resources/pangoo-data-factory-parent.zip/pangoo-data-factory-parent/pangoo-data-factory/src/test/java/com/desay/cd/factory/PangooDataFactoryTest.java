package com.desay.cd.factory;

import java.util.Random;

import org.junit.Test;

/**
 * 测试启动类
 * 
 * @author pengdengfu
 *
 */

public class PangooDataFactoryTest {

    @Test
    public void test() {
        Random df = new Random();

        System.out.println(df.nextInt(2));
        System.out.println(df.nextInt(2));

    }

}
