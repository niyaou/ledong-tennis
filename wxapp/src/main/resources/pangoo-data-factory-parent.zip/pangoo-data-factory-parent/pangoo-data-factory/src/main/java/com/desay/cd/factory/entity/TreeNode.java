package com.desay.cd.factory.entity;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;


/**
 * 文件树结构
 * @author uidq1343
 *
 * @param <T>
 */
public class TreeNode<T>  {

   
    int level;
    T root;
    LinkedList<T> currentLevel;
    ConcurrentHashMap<Integer,LinkedList<T>> levelNodes;
    
    
    public TreeNode(T data) {
        root=data;
        currentLevel= new LinkedList<T> ();
        currentLevel.add(data);
        levelNodes=new ConcurrentHashMap<Integer,LinkedList<T>>();
        levelNodes.put(0, currentLevel);
    }
   
    
    /**
     * 获取树结构的总层级
     * @return
     */
    public  int getTotalLevel() {
        level=levelNodes.size();
        return level;
    }
    
    
    /**
     * 获取最顶层的树节点数据
     * @return
     */
    public  List<T> getTopLevelNodes(){
        return levelNodes.remove(getTotalLevel()-1);
    }
    
    public  List<T> getNodesInLevel(int level){

        return levelNodes.get(level-1);
    }
    
    /**
     * 判断树结构是否包含数据
     * @return
     */
    public boolean hasNext() {
        return getTotalLevel()!=0;
    }
    
    
    /**
     * 向树结构添加数据
     * @param level
     * @param data
     */
    public void addNodes(int level,T data) {
        if(levelNodes.containsKey(level)) {
            levelNodes.get(level).add(data);
        }else {
            LinkedList<T> nodes=new LinkedList<T>();
            nodes.add(data);
            levelNodes.put(level, nodes);
        }
    }

}
