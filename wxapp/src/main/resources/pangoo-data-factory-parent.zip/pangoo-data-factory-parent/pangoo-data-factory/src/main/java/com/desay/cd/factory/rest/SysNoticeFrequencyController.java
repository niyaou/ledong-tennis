package com.desay.cd.factory.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysNoticeFrequency;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddNoticeFrequencyVo;
import com.desay.cd.factory.service.ISysNoticeFrequencyService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/***
 * 通知频率管理
 * 
 * @author pengdengfu
 *
 */
@RestController
@Api(value = "通知频率管理", tags = "SysNoticeFrequencyController")
@ApiIgnore
public class SysNoticeFrequencyController {
    @Autowired
    private ISysNoticeFrequencyService sysNoticeFrequencyService;

    /**
     * 添加通知事件
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/noticeFrequency/backup", method = RequestMethod.POST)
    @ApiOperation(value = "添加通知事件频率")
    @ApiIgnore
    @ApiImplicitParams({ @ApiImplicitParam(name = "noticeFrequencyName", value = "通知频率名称(长度<=30)", required = true, dataType = "string", paramType = "form") })
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "添加通知事件频率")
    public ResponseEntity<?> addNoticeFrequency(@RequestParam(value = "noticeFrequencyName", required = true) String noticeFrequencyName) {
        SysNoticeFrequency sysNoticeFrequency = sysNoticeFrequencyService.addNoticeFrequency(noticeFrequencyName);
        return new ResponseEntity<Object>(CommonResponse.success(sysNoticeFrequency.getFrequencyId()), HttpStatus.OK);
    }

    /**
     * 添加通知事件
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/noticeFrequency", method = RequestMethod.POST)
    @ApiOperation(value = "添加通知事件频率")
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "添加通知事件频率(json请求)")
    public ResponseEntity<?> addNoticeFrequency(@RequestBody AddNoticeFrequencyVo addNoticeFrequency) {
        SysNoticeFrequency sysNoticeFrequency = sysNoticeFrequencyService.addNoticeFrequency(addNoticeFrequency.getNoticeFrequencyName());
        return new ResponseEntity<Object>(CommonResponse.success(sysNoticeFrequency.getFrequencyId()), HttpStatus.OK);
    }

    /**
     * 删除通知事件频率
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/noticeFrequency/{noticeFrequencyId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除通知事件频率")
    @ApiImplicitParams({ @ApiImplicitParam(name = "noticeFrequencyId", value = "通知事件频率ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "删除通知事件频率")
    public ResponseEntity<?> deleteNoticeEvent(@PathVariable(value = "noticeFrequencyId", required = true) String noticeFrequencyId) {
        sysNoticeFrequencyService.deleteNoticeFrequency(noticeFrequencyId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取通知频率
     * 
     * @return
     */
    @RequestMapping(value = "/management/noticeFrequency", method = RequestMethod.GET)
    @ApiOperation(value = "获取通知频率")
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "获取通知频率")
    public ResponseEntity<?> getNoticeFrequencys() {
        List<SysNoticeFrequency> noticeFrequencys = sysNoticeFrequencyService.getNoticeFrequencys();
        return new ResponseEntity<Object>(CommonResponse.success(noticeFrequencys), HttpStatus.OK);
    }
}
