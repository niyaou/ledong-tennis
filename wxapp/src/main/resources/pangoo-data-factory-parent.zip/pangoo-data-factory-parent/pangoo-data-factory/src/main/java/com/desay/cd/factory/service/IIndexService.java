package com.desay.cd.factory.service;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.search.sort.SortOrder;

/**
 * es索引管理服务
 * 
 * @author pengdengfu
 *
 */
public interface IIndexService {

    /**
     * 向es添加文件信息
     * 
     * @param doc
     * @return
     */
    DocWriteResponse createFileInfomation(String doc);

    /**
     * 向es添加指定id的文件信息
     * 
     * @param doc
     * @param id
     * @return
     */
    DocWriteResponse createFileInfomationById(String doc, String id);

    /**
     * 向es更新文件信息
     * 
     * @param doc
     * @param id
     * @return
     */
    DocWriteResponse updateFileInfomation(String doc, String id);

    /**
     * 向es更新带版本号的文件信息
     * 
     * @param doc
     * @param id
     * @param version
     * @return
     * @throws ElasticsearchException
     */
    DocWriteResponse updateFileInfomationWithVersion(String doc, String id, long version) throws ElasticsearchException;

    /**
     * 删除es文件信息
     * 
     * @param id
     * @return
     */
    DocWriteResponse deleteFileInfomation(String id);

    /**
     * 根据id查询es文件信息
     * 
     * @param id
     * @return
     */
    HashMap<String, Object> queryFileInfomation(String id);

    /**
     * 根据参数查询文档
     * 
     * @param fileId
     * @param status
     * @param userId
     * @param startTime
     * @param endTime
     * @param productId
     * @param productName
     * @param deviceId
     * @param deviceName
     * @param fileType
     * @param minSize
     * @param maxSize
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @param sortOrder
     * @return
     */
    Object exploreFilesByParams(String fileId, String status, String userId, String startTime, String endTime, String productId, String productName, String deviceId,
            String deviceName, String fileType, Integer minSize, Integer maxSize, Integer pageNo, Integer pageSize, List<String> sortProperties, SortOrder sortOrder);

    /**
     * 构造不等于指定值的查询条件
     * 
     * @param status
     * @param productId
     * @param deviceId
     * @return
     */
    Object exploreFilesByStatusNotMatch(String status, String productId, String deviceId);

    /**
     * 根据查询参数统计文档数量
     * 
     * @param fileId
     * @param status
     * @param userId
     * @param startTime
     * @param endTime
     * @param productId
     * @param productName
     * @param deviceId
     * @param deviceName
     * @param fileType
     * @param minSize
     * @param maxSize
     * @return
     */
    long exploreFilesByParamsWithoutSize(String fileId, String status, String userId, String startTime, String endTime, String productId, String productName, String deviceId,
            String deviceName, String fileType, Integer minSize, Integer maxSize);

    /**
     * 根据文件状态查询es文件信息
     * 
     * @param status
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfomationByStatus(int status, Integer pageNo, Integer size);

    /**
     * 根据创建人查询es文件信息
     * 
     * @param userId
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfomationByUserId(String userId, Integer pageNo, Integer size);

    /**
     * 根据产品名称查询es文件信息
     * 
     * @param productName
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfomationByProductName(String productName, Integer pageNo, Integer size);

    /**
     * 根据设备名称查询es文件信息
     * 
     * @param deviceName
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfomationByDeviceName(String deviceName, Integer pageNo, Integer size);

    /**
     * 根据文件类型查询文档
     * 
     * @param types
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfomationByFileType(Integer pageNo, Integer size, String... types);

    /**
     * 根据大小范围查询文件
     * 
     * @param minSize
     * @param maxSize
     * @param order
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfomationBySize(int minSize, int maxSize, Integer pageNo, Integer size);

    /**
     * 根据时间范围查询文件
     * 
     * @param timeStamp
     *            秒类型时间戳
     * @param type
     *            0 。早于时间 1.晚于时间
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfoByTerm(String timeStamp, int type, Integer pageNo, Integer size);

    /**
     * 根据时间范围查询文件
     * 
     * @param startTime
     * @param endTime
     * @param pageNo
     * @param size
     * @return
     */
    LinkedList<HashMap<String, Object>> queryFileInfoByTimeRange(String startTime, String endTime, Integer pageNo, Integer size);

    /**
     * 根据条件统计文件信息
     * 
     * @param autoType
     * @param deviceId
     * @param productId
     * @param fileType
     * @param userId
     * @param startTime
     * @param endTime
     * @return
     */
    LinkedList<HashMap<String, Object>> fileStatisticsByParamsDetails(String autoType, String deviceId, String productId, String fileType, String userId, String startTime,
            String endTime);

    /**
     * 根据条件统计每一天的文件信息
     * 
     * @param autoType
     * @param deviceId
     * @param productId
     * @param status
     * @param fileType
     * @param userId
     * @param startTime
     * @param endTime
     * @return
     */
    HashMap<String, Object> fileStatisticsByParams(String autoType, String deviceId, String productId, Integer status, String fileType, String userId, String startTime,
            String endTime);

    /**
     * 根据id获取文件完整路径
     * 
     * @param fileId
     * @return
     */
    String getIntegratedPath(String fileId);

    /**
     * *插入文件校验码
     * 
     * @param fileId
     * @param checkSum
     * @param path
     * @return
     */
    String createFileCheckSum(String fileId, String checkSum, String path);

    /**
     ** 验证文件是否已存在
     * 
     * @param fileId
     * @param checkSum
     * @return id:已存在 ; Null 不存在
     */
    String uniqueValid(String fileId, String checkSum);

    /***
     * 根据状态和更新时间查询数据(pengdengfu)
     * 
     * @param status
     * @param startTime
     * @param endTime
     * @param fileType
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @param sortOrder
     * @return
     */
    Object exploreFilesByUpdateStatus(Set<String> status, String startTime, String endTime, String fileType, Integer pageNo, Integer pageSize, List<String> sortProperties,
            SortOrder sortOrder);

}
