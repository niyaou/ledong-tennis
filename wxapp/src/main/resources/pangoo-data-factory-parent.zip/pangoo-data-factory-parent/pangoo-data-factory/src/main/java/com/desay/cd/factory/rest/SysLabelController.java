package com.desay.cd.factory.rest;

import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysLevelData;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.SysLevelDataVo;
import com.desay.cd.factory.service.ISysLevelDataService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/***
 * 标注管理
 * 
 * @author pengdengfu
 *
 */

@Api(tags = "SysLabelController", value = "NEW-标注管理")
@RestController
@Validated
public class SysLabelController {
    @Autowired
    ISysLevelDataService sysLabelService;

    @RequestMapping(value = "/management/labels", method = RequestMethod.POST)
    @ApiOperation(value = "标注管理-添加标注", notes = "")
    @LogAnnotation(action = LogActionEnum.LABEL, message = "标注管理-添加标注")
    public ResponseEntity<?> addLabel(@RequestBody @Validated SysLevelDataVo sysLabelVo) {
        try {
            String tagId = sysLabelService.add(sysLabelVo, "2");
            return new ResponseEntity<Object>(CommonResponse.success(tagId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/labels/{labelId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "标注管理-删除标注", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "labelId", value = "标注ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.LABEL, message = "标注管理-删除标注")
    public ResponseEntity<?> deleteLabel(@PathVariable(value = "labelId", required = true) String labelId) {
        try {
            sysLabelService.delete(labelId, "2");
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @RequestMapping(value = "/management/labels/{labelId}", method = RequestMethod.PUT)
    @ApiOperation(value = "标注管理-更新标注", notes = "")
    @LogAnnotation(action = LogActionEnum.LABEL, message = "标注管理-更新标注")
    public ResponseEntity<?> updateLabel(@PathVariable(value = "labelId", required = true) String labelId, @RequestBody @Validated SysLevelDataVo sysLabelVo) {
        try {
            sysLabelService.update(labelId, sysLabelVo, true, "2");
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/labels/{labelId}", method = RequestMethod.PATCH)
    @ApiOperation(value = "标注管理-更新标注", notes = "")
    @LogAnnotation(action = LogActionEnum.LABEL, message = "标注管理-更新标注")
    public ResponseEntity<?> updateLabelPart(@PathVariable(value = "labelId", required = true) String labelId, @RequestBody SysLevelDataVo sysLabelVo) {
        try {
            sysLabelService.update(labelId, sysLabelVo, false, "2");
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/labels", method = RequestMethod.GET)
    @ApiOperation(value = "标注管理-查询标注", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "labelId", value = "labelId", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "labelName", value = "label名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "labelNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.LABEL, message = "标注管理-查询标注")
    public ResponseEntity<?> getLabels(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "labelId", required = false) String labelId,
            @RequestParam(value = "labelName", required = false) String labelName, @RequestParam(value = "labelNameLike", required = false) String labelNameLike,
            @RequestParam(value = "status", required = false) String status) {
        Page<SysLevelData> labels = sysLabelService.search("2", labelId, labelName, labelNameLike, status, pageNo, pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(labels), HttpStatus.OK);
    }
}
