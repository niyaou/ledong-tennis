package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddNoticeEventNameVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午4:06:00
 */
@ApiModel(value = "通知事件")
public class AddNoticeEventNameVo {
    @ApiModelProperty(value = "通知事件名称(0<size<=30)", required = true)
    private String noticeEventName;

    public String getNoticeEventName() {
        return noticeEventName;
    }

    public void setNoticeEventName(String noticeEventName) {
        this.noticeEventName = noticeEventName;
    }
}
