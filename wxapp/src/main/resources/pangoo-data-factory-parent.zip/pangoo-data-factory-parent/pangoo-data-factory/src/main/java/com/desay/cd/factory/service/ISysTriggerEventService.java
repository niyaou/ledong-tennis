package com.desay.cd.factory.service;

import java.util.List;

import com.desay.cd.factory.entity.mysql.SysTriggerEvent;

/**
 * ISysTriggerEventService
 * 
 * @author pengdengfu
 *
 */
public interface ISysTriggerEventService {
    /**
     * 添加触发事件
     * 
     * @param noticeEventName
     * @return
     */
    SysTriggerEvent addNoticeEvent(String noticeEventName);

    /**
     * 删除触发事件
     * 
     * @param noticeEventId
     */
    void deleteNoticeEvent(String noticeEventId);

    /**
     * 获取触发事件
     * 
     * @return
     */
    List<SysTriggerEvent> getSysTriggerEvents();
}
