package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysDeviceAttributeDao;
import com.desay.cd.factory.dao.ISysDeviceDao;
import com.desay.cd.factory.dao.ISysDeviceTypeDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.CleanStrategy;
import com.desay.cd.factory.entity.mysql.SysDevice;
import com.desay.cd.factory.entity.mysql.SysDeviceAttribute;
import com.desay.cd.factory.entity.mysql.SysDeviceType;
import com.desay.cd.factory.entity.mysql.SysProduct;
import com.desay.cd.factory.entity.mysql.TaskAssignStrategy;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.IFileService;
import com.desay.cd.factory.service.ISysDeviceService;
import com.desay.cd.factory.service.ISysProductService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: DeviceServiceImpl
 * @author: pengdengfu
 * @date: 2019年4月8日 上午10:56:27
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class SysDeviceServiceImpl implements ISysDeviceService {
    @Autowired
    private ISysDeviceDao sysDeviceDao;
    @Autowired
    private ISysDeviceAttributeDao sysDeviceAttributeDao;
    @Autowired
    private ISysDeviceTypeDao sysDeviceTypeDao;
    @Autowired
    ISysProductService sysProductService;
    @Autowired
    IFileService fileService;

    @Override
    public SysDevice addDevice(String deviceName, Map<String, String> deviceAttrinuteNames, String deviceTypeId, String status) {
        // 检查设备名称
        checkDeviceName(deviceName, true, null);

        SysDevice sysDevice = new SysDevice();
        if (StringUtils.isNotEmpty(deviceName)) {
            // 如果存在同名的，并且状态是删除的,则恢复状态
            SysDevice sysDeviceCheck = sysDeviceDao.findByDeviceName(deviceName);
            if (sysDeviceCheck != null && Constanst.ACTIVE_STATUS_0.equals(sysDeviceCheck.getIsActive())) {
                throw new CustumException(ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getCode(), ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getMessage(), sysDeviceCheck);
            }
            sysDevice.setDeviceName(deviceName);
        }
        if (StringUtils.isNotEmpty(status)) {
            ControllerCommonUtils.checkStatus(status);
            sysDevice.setIsActive(status);
        }
        // 添加设备类型
        if (StringUtils.isNotEmpty(deviceTypeId)) {
            SysDeviceType sysDeviceType = sysDeviceTypeDao.findOne(deviceTypeId);
            if (sysDeviceType == null) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getMessage());
            }
            sysDevice.setDeviceType(sysDeviceType);
        }
        // 添加或者更新设备属性
        updateDeviceAtts(deviceAttrinuteNames, sysDevice);
        SysDevice device = null;
        try {
            device = sysDeviceDao.saveAndFlush(sysDevice);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.DEVICE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_NAME_EXISTED.getMessage());
        }
        return device;
    }

    @Override
    public void updateDevice(String deviceId, String deviceName, Map<String, String> deviceAttrinuteNames, String deviceTypeId, String status) {
        SysDevice findOne = checkDeviceId(deviceId);
        // 检查设备名称
        checkDeviceName(deviceName, false, deviceId);
        if (StringUtils.isNotEmpty(deviceName)) {
            findOne.setDeviceName(deviceName);
        }
        // 添加设备类型
        if (StringUtils.isNotEmpty(deviceTypeId)) {
            SysDeviceType sysDeviceType = sysDeviceTypeDao.findOne(deviceTypeId);
            if (sysDeviceType == null) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getMessage());
            }
            findOne.setDeviceType(sysDeviceType);
        }
        // 添加或者更新设备属性
        updateDeviceAtts(deviceAttrinuteNames, findOne);
        // 更新状态
        if (StringUtils.isNotEmpty(status)) {
            ControllerCommonUtils.checkStatus(status);
            findOne.setIsActive(status);
        }
        try {
            sysDeviceDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.DEVICE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public void updateDevice(String deviceId, String deviceName, Set<Map<String, String>> deviceAttrinuteNames, String deviceTypeId, String status) {
        SysDevice findOne = checkDeviceId(deviceId);
        // 检查设备名称
        checkDeviceName(deviceName, false, deviceId);
        if (StringUtils.isNotEmpty(deviceName)) {
            findOne.setDeviceName(deviceName);
        }
        // 添加设备类型
        if (StringUtils.isNotEmpty(deviceTypeId)) {
            SysDeviceType sysDeviceType = sysDeviceTypeDao.findOne(deviceTypeId);
            if (sysDeviceType == null) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getMessage());
            }
            findOne.setDeviceType(sysDeviceType);
        }
        // 添加或者更新设备属性
        updateDeviceAtts(deviceAttrinuteNames, findOne);
        // 更新状态
        if (StringUtils.isNotEmpty(status)) {
            ControllerCommonUtils.checkStatus(status);
            findOne.setIsActive(status);
        }
        try {
            sysDeviceDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.DEVICE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_NAME_EXISTED.getMessage());
        }

    }

    public void deleteDevice2(String deviceId) {
        // 检查设备Id
        SysDevice sysDevice = checkDeviceId(deviceId);
        sysDevice.setIsActive(Constanst.ACTIVE_STATUS_0);
        try {
            sysDeviceDao.saveAndFlush(sysDevice);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public void deleteDevice(String deviceId) {
        // 检查设备Id
        checkDeviceId(deviceId);
        // 确认是否有产品在使用
        Page<SysProduct> listProduct = sysProductService.listProduct(null, null, null, null, null, null, deviceId, null, null);
        Map<String, Long> referencedCount = new HashMap<>(2);
        if (listProduct != null && listProduct.getContent().size() > 0) {
            referencedCount.put("referencedProductsCount", listProduct.getTotalElements());
        }
        // 确认是否有文件在使用
        long referencedFilesCount = (long) fileService.exploreFilesByStatusNotMatch("5", null, deviceId);
        if (referencedFilesCount > 0) {
            referencedCount.put("referencedFilesCount", referencedFilesCount);
        }
        if (!referencedCount.isEmpty()) {
            throw new CustumException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getCode(), ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage(), referencedCount);
        }
        sysDeviceDao.delete(deviceId);

    }

    @Override
    public void updateDeviceDeleteAttribute(String deviceId, String attributeId) {
        // 检查设备Id
        SysDevice findOne = checkDeviceId(deviceId);
        // 检查属性Id
        if (StringUtils.isEmpty(attributeId)) {
            throw new CustumException(ResultCodeEnum.DEVICE_ATTRIBUTE_CANNOT_NULL.getCode(), ResultCodeEnum.DEVICE_ATTRIBUTE_CANNOT_NULL.getMessage());
        }
        SysDeviceAttribute sysDeviceAttribute = sysDeviceAttributeDao.findOne(attributeId);
        if (sysDeviceAttribute == null) {
            throw new CustumException(ResultCodeEnum.ATTRIBUTE_NOT_EXISTED.getCode(), ResultCodeEnum.ATTRIBUTE_NOT_EXISTED.getMessage());
        }
        Set<SysDeviceAttribute> deviceAttributes = findOne.getDeviceAttributes();
        if (!deviceAttributes.contains(sysDeviceAttribute)) {
            throw new CustumException(ResultCodeEnum.DEVICE_HAVING_NOT_ATTRIBUTE.getCode(), ResultCodeEnum.DEVICE_HAVING_NOT_ATTRIBUTE.getMessage());
        }
        deviceAttributes.remove(sysDeviceAttribute);

        try {
            sysDeviceAttributeDao.delete(sysDeviceAttribute);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.DEVICE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public void updateDeviceDeleteDeviceType(String deviceId, String deviceTypeId) {
        // 检查设备Id
        SysDevice findOne = checkDeviceId(deviceId);
        if (StringUtils.isEmpty(deviceTypeId)) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.DEVICE_TYPE_ID_CANNOT_NULL.getMessage());
        }

        SysDeviceType deviceType = sysDeviceTypeDao.findOne(deviceTypeId);
        if (deviceType == null) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getMessage());
        }
        if (findOne.getDeviceType() != deviceType) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_HAVING_NOT_TYPE.getCode(), ResultCodeEnum.DEVICE_TYPE_HAVING_NOT_TYPE.getMessage());
        }
        findOne.setDeviceType(null);

        try {
            sysDeviceDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public Page<SysDevice> listDevice(String pageNo, String pageSize, String deviceId, String deviceName, String status, String deviceTypeId, String hasCleanStrategy,
            String hasTaskStrategy, List<String> properties, String sortDirection) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, properties, sortDirection, "deviceName");

        // 特殊字符转义
        if (StringUtils.isNotEmpty(deviceName)) {
            deviceName = deviceName.replaceAll("%", "\\\\%");
            deviceName = deviceName.replaceAll("_", "\\\\_");
        }
        final String deviceNameTmp = deviceName;

        Specification<SysDevice> specification = new Specification<SysDevice>() {
            @Override
            public Predicate toPredicate(Root<SysDevice> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(deviceId)) {
                    predicates.add(cb.equal(root.get("deviceId"), deviceId));
                }
                if (StringUtils.isNotEmpty(deviceNameTmp)) {
                    predicates.add(cb.like(root.get("deviceName"), "%" + deviceNameTmp + "%"));
                }
                if (StringUtils.isNotEmpty(status)) {
                    ControllerCommonUtils.checkStatus(status);
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                if (StringUtils.isNotEmpty(deviceTypeId)) {
                    Join<SysDevice, SysDeviceType> join = root.join("deviceType", JoinType.INNER);
                    predicates.add(cb.equal(join.get("deviceTypeId"), deviceTypeId));
                }

                if (StringUtils.isNotEmpty(hasCleanStrategy)) {
                    Join<SysDevice, CleanStrategy> join = root.join("cleanStrategy", JoinType.LEFT);
                    // 未分配清洗策略的设备
                    String hasClean0 = "0";
                    String hasClean1 = "1";
                    if (StringUtils.equals(hasClean0, hasCleanStrategy)) {
                        predicates.add(cb.isNull(join.get("strgyId")));

                    } else if (StringUtils.equals(hasClean1, hasCleanStrategy)) {
                        predicates.add(cb.isNotNull(join.get("strgyId")));
                    }
                }
                if (StringUtils.isNotEmpty(hasTaskStrategy)) {
                    Join<SysDevice, TaskAssignStrategy> join = root.join("taskAssignStrategy", JoinType.LEFT);
                    // 未分配清洗策略的设备
                    String hasTask0 = "0";
                    String hasTask1 = "1";
                    if (StringUtils.equals(hasTask0, hasTaskStrategy)) {
                        predicates.add(cb.isNull(join.get("strgyId")));

                    } else if (StringUtils.equals(hasTask1, hasTaskStrategy)) {
                        predicates.add(cb.isNotNull(join.get("strgyId")));
                    }
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        return sysDeviceDao.findAll(specification, pageable);
    }

    /**
     * 检查设备名称
     * 
     * @param deviceName
     * @param checkEmpty
     * @param deviceId
     * @return
     */
    private void checkDeviceName(String deviceName, boolean checkEmpty, String deviceId) {
        // 如果设备名称为空
        if (checkEmpty) {
            if (StringUtils.isEmpty(deviceName)) {
                throw new CustumException(ResultCodeEnum.DEVICE_NAME_CANNOT_NULL.getCode(), ResultCodeEnum.DEVICE_NAME_CANNOT_NULL.getMessage());
            }
            if (deviceName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.DEVICE_NAME_TOO_LONG.getCode(), ResultCodeEnum.DEVICE_NAME_TOO_LONG.getMessage());
            }
        } else {
            if (StringUtils.isNotEmpty(deviceName) && deviceName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.DEVICE_NAME_TOO_LONG.getCode(), ResultCodeEnum.DEVICE_NAME_TOO_LONG.getMessage());
            }
        }
        if (StringUtils.isEmpty(deviceName)) {
            return;
        }
    }

    /**
     * 添加或者更新设备属性
     * 
     * @param deviceAttrinuteNames
     * @param sysDevice
     */
    private void updateDeviceAtts(Map<String, String> deviceAttrinuteNames, SysDevice sysDevice) {
        if (sysDevice == null || deviceAttrinuteNames == null) {
            return;
        }
        Set<SysDeviceAttribute> deviceAttributes = sysDevice.getDeviceAttributes();
        // 添加设备属性
        Set<Entry<String, String>> entrySet = deviceAttrinuteNames.entrySet();
        if (deviceAttributes == null) {
            deviceAttributes = new HashSet<>(entrySet.size());
        }
        for (Entry<String, String> entry : entrySet) {
            // 属性名称
            String keyDeviceAttrinuteName = entry.getKey();
            // 属性值
            String valueDeviceAttrinuteName = entry.getValue();
            if (StringUtils.isNotEmpty(keyDeviceAttrinuteName) && keyDeviceAttrinuteName.length() <= Constanst.NAME_LENGTH) {
                SysDeviceAttribute sysDeviceAttribute = sysDeviceAttributeDao.findByDeviceAndAttributeName(sysDevice.getDeviceId(), keyDeviceAttrinuteName);
                if (sysDeviceAttribute != null) {
                    // 如果已经存在，则更新相应属性值
                    sysDeviceAttribute.setAttributeValue(valueDeviceAttrinuteName);
                }

                sysDeviceAttribute = new SysDeviceAttribute();
                sysDeviceAttribute.setAttributeName(keyDeviceAttrinuteName);
                sysDeviceAttribute.setAttributeValue(valueDeviceAttrinuteName);

                deviceAttributes.add(sysDeviceAttribute);
            }
            sysDevice.setDeviceAttributes(deviceAttributes);
        }
    }

    /**
     * 添加或者更新设备属性
     * 
     * @param deviceAttrinuteNames
     * @param sysDevice
     */
    private void updateDeviceAtts(Set<Map<String, String>> deviceAttrinuteNames, SysDevice sysDevice) {
        if (sysDevice == null || deviceAttrinuteNames == null) {
            return;
        }
        Set<SysDeviceAttribute> deviceAttributes = new HashSet<>(deviceAttrinuteNames.size());
        // 添加设备属性
        if (deviceAttrinuteNames != null && deviceAttrinuteNames.size() > 0) {
            for (Map<String, String> deviceAttrinuteName : deviceAttrinuteNames) {
                // 更新
                String attributeId = deviceAttrinuteName.get("attributeId");
                String attributeName = deviceAttrinuteName.get("attributeName");
                String attributeValue = deviceAttrinuteName.get("attributeValue");
                if (StringUtils.isNotEmpty(attributeId)) {
                    SysDeviceAttribute existedAttribute = sysDeviceAttributeDao.findOne(attributeId);
                    if (existedAttribute != null) {
                        existedAttribute.setAttributeName(attributeName);
                        existedAttribute.setAttributeValue(attributeValue);
                        deviceAttributes.add(existedAttribute);
                    }
                } else {
                    // 新增
                    if (StringUtils.isNotEmpty(attributeName) && attributeName.length() <= Constanst.NAME_LENGTH) {
                        SysDeviceAttribute sysDeviceAttribute = sysDeviceAttributeDao.findByDeviceAndAttributeName(sysDevice.getDeviceId(), attributeName);
                        if (sysDeviceAttribute != null) {
                            // 如果已经存在，则忽略
                            continue;
                        }
                        sysDeviceAttribute = new SysDeviceAttribute();
                        sysDeviceAttribute.setAttributeName(attributeName);
                        sysDeviceAttribute.setAttributeValue(attributeValue);
                        deviceAttributes.add(sysDeviceAttribute);
                    }
                }
            }
        }
        sysDevice.setDeviceAttributes(deviceAttributes);
    }

    /**
     * 检查设备Id
     * 
     * @param deviceId
     * @return
     */
    private SysDevice checkDeviceId(String deviceId) {
        if (StringUtils.isEmpty(deviceId)) {
            throw new CustumException(ResultCodeEnum.DEVICE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.DEVICE_ID_CANNOT_NULL.getMessage());
        }
        SysDevice findOne = sysDeviceDao.findOne(deviceId);
        if (findOne == null) {
            throw new CustumException(ResultCodeEnum.DEVICE_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_NOT_EXISTED.getMessage());
        }
        return findOne;
    }

}
