package com.desay.cd.factory.transaction.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysChunksLog;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.transaction.base.BaseChunksServiceHandler;
import com.desay.cd.factory.transaction.base.FileElement;

/**
 * 断点续传任务记录事务处理类
 * 
 * @author uidq1343
 *
 */
public class ChunksProcessHandler extends BaseChunksServiceHandler {

    private Logger logger = LoggerFactory.getLogger(ChunksProcessHandler.class);

    @Override
    public void doHandleReal(FileElement element) throws CustumException {

        SysChunksLog log = chunksLogService.queryLogById(element.getChunk().getFileId());
        if (log == null) {
            log = new SysChunksLog();
            log.setChunks(element.getChunk().getChunks());
            log.setFileName(element.getVo().getFileName());
            log.setFileId(element.getChunk().getFileId());
            log.setUserId(element.getUserId());
        }
        log.setCurrent(element.getChunk().getCurrent());
        try {
            chunksLogService.uploadChunksLog(log);
            element.setChunksLogId(log);
            logger.info("element.Chunk:" + element.getChunk().getChunks().intValue() + "   element.chunk.current: " + element.getChunk().getCurrent().intValue());
            if (element.getChunk().getChunks().intValue() == 0 && element.getChunk().getCurrent().intValue() == 0) {
                chunksLogService.deleteChunksLog(log.getChunksLogId());
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustumException(ResultCodeEnum.DELETE_DATA_FAILD.getCode(), ResultCodeEnum.DELETE_DATA_FAILD.getMessage());

        }
    }

    @Override
    public void rollBackReal(FileElement element) {
    }

}
