package com.desay.cd.factory.config;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.Log;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.service.ISysUserService;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.LoggerUtil;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.SizeAndTimeBasedFNATP;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;
import ch.qos.logback.core.util.FileSize;

/**
 * 操作日志切面
 * 
 * @author uidq1163
 *
 */
@Aspect
@Component
public class LogAopAction {
    @Autowired
    private ISysUserService userService;
    private String fileDir;
    public Logger logger;

    public LogAopAction(@Value("${operation.log.filedir}") String fileDir) {
        this.fileDir = fileDir;
        // 操作日志初始化
        this.logger = getLogger();
    }

    /**
     * 记录操作日志
     */
    @After("@annotation(la)")
    public void recordLog(JoinPoint joinPoint, LogAnnotation la) {
        Log log = new Log();
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                .getRequest();
        Object token = request.getHeader("access_token");
        TokenDto tokenDto = null;
        if (null != token) {
            tokenDto = (TokenDto) userService.tokenAuthorize((String) token);
            if (null != tokenDto) {
                log.setUser(tokenDto.cid);
            }
        }
        try {
            Map<String, Object> map = getLogMark(joinPoint);
            log.setAction((LogActionEnum) map.get(LoggerUtil.LOG_ACTION));
            log.setIp(LoggerUtil.getCliectIp(request));
            log.setMessage((String) map.get(LoggerUtil.LOG_REMARK));
            log.setCreateTime(new Date());
            logger.info(JSON.toJSONStringWithDateFormat(log, DateUtil.FORMAT_DATE_TIME,
                    SerializerFeature.WriteMapNullValue));
        } catch (Exception e) {
            // logger.error("插入日志异常", e.getMessage());
        }
    }

    /**
     * 获取注解上信息
     * 
     * @param joinPoint
     * @return
     * @throws ClassNotFoundException
     */
    private Map<String, Object> getLogMark(JoinPoint joinPoint) throws ClassNotFoundException {
        Map<String, Object> map = new HashMap<>(16);
        String methodName = joinPoint.getSignature().getName();
        String targetName = joinPoint.getTarget().getClass().getName();
        Class<?> targetClass = Class.forName(targetName);
        Method[] methods = targetClass.getMethods();
        for (Method method : methods) {
            if (method.getName().equals(methodName)) {
                LogAnnotation logAnnotation = method.getAnnotation(LogAnnotation.class);
                if (null != logAnnotation) {
                    map.put(LoggerUtil.LOG_ACTION, logAnnotation.action());
                    map.put(LoggerUtil.LOG_REMARK, logAnnotation.message());
                }
            }
        }
        return map;
    }

    /**
     * 自定义日志
     * 
     * @param jobName
     * @param cls
     * @return
     * @throws ParseException
     */
    private Logger getLogger() {
        Logger logger = (Logger) LoggerFactory.getLogger(LogAopAction.class);
        LoggerContext loggerContext = logger.getLoggerContext();
        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(loggerContext);
        encoder.setPattern("%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %logger{50} - %msg%n");
        encoder.start();
        RollingFileAppender<ILoggingEvent> appender = new RollingFileAppender<ILoggingEvent>();
        appender.setContext(loggerContext);
        // 日志滚动策略
        TimeBasedRollingPolicy<Object> rollingPolicyBase = new TimeBasedRollingPolicy<>();
        rollingPolicyBase.setContext(loggerContext);
        rollingPolicyBase.setParent(appender);
        // 自动归档压缩
        rollingPolicyBase.setFileNamePattern((String.format("%s/opt/%s", fileDir, "opt") + ".%d{yyyy-MM-dd}.%i.log"));
        SizeAndTimeBasedFNATP<Object> sizeAndTimeBasedFNATP = new SizeAndTimeBasedFNATP<Object>();
        // 单个文件最大100M
        FileSize maxFileSize = new FileSize(100 * FileSize.MB_COEFFICIENT);
        sizeAndTimeBasedFNATP.setMaxFileSize(maxFileSize);
        rollingPolicyBase.setTimeBasedFileNamingAndTriggeringPolicy(sizeAndTimeBasedFNATP);
        rollingPolicyBase.setMaxHistory(7);
        // 最大日志：20GB
        FileSize totalSizeCap = new FileSize(20 * FileSize.GB_COEFFICIENT);
        rollingPolicyBase.setTotalSizeCap(totalSizeCap);
        rollingPolicyBase.setCleanHistoryOnStart(true);
        rollingPolicyBase.start();

        appender.setEncoder(encoder);
        appender.setRollingPolicy(rollingPolicyBase);
        appender.start();

        logger.setAdditive(false);
        logger.addAppender(appender);
        return logger;
    }
}
