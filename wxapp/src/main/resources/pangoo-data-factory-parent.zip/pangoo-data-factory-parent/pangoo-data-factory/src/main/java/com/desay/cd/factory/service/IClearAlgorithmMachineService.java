/**
 * @author: create by pengdengfu
 * @version: v1.0
 * @description: com.desay.cd.factory.service
 * @date:2019年12月4日
 */
package com.desay.cd.factory.service;

/**
 * @author uidq1070
 *
 */
public interface IClearAlgorithmMachineService {
    /**
     * 查询算法机器资源使用信息
     * 
     * @param ip
     * @param hostName
     * @param hostNameLike
     * @return
     */
    Object search(String ip, String hostName, String hostNameLike);

}
