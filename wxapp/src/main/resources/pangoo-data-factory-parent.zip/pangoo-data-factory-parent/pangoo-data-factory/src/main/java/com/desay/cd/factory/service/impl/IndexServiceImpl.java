package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.http.util.TextUtils;
import org.desay.common.es.search.SearchApi;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.metrics.sum.ParsedSum;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.enums.FileTypeEnum;
import com.desay.cd.factory.service.IIndexService;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;

/**
 * IndexService
 * 
 * @author pengdengfu
 *
 */
@Service
public class IndexServiceImpl implements IIndexService {

    public final static String FILE_INFORMATION_INDEX = "pangoo_das.file_information";
    public final static String DAS_DUPLICATION_CHECK = "das_duplication_check";
    public final static String FILEPATH = "filePath";
    public final static String FILEID = "fileId";
    public final static String FILENAME = "fileName";
    public final static String FILETYPE = "fileType";
    public final static String FILESIZE = "fileSize";
    public final static String CREATOR = "creator";
    public final static String AUDIT = "audit";
    public final static String DELETETIME = "deleteTime";
    public final static String CREATETIME = "createTime";
    public final static String UPDATETIME = "updateTime";
    public final static String AUDITTIME = "auditTime";
    public final static String SUMMARIZEDTIME = "summarizedTime";
    public final static String CANCELTIME = "cancelTime";
    public final static String PRODUCTID = "productId";
    public final static String PRODUCTNAME = "productName";
    public final static String DEVICEID = "deviceId";
    public final static String DEVICENAME = "deviceName";
    public final static String AUDITMESSAGE = "auditMessage";
    public final static String STATUS = "status";
    public final static String SUMMARY = "summary";
    public final static String DATE = "date";
    public final static String ID = "_id";
    public final static String THUMBPATH = "thumbPath";
    public static final String VERSION = "version";
    public final static String SEPARATOR = "/";
    public final static String BLANKDATE = "9999999999";
    public final static String TOTAL = "total";
    public final static String RESULT = "result";
    public final static String CONTENT = "content";
    public final static String TOTAL_SIZE = "totalSize";
    public final static String TOTAL_FILES = "totalFiles";
    public final static String CHECKSUM = "checkSum";
    public final static String PATH = "path";

    @Override
    public DocWriteResponse createFileInfomation(String doc) {
        DocWriteResponse result = SearchApi.insertDocument(FILE_INFORMATION_INDEX, SearchApi.TYPE, doc);
        return result.getResult().equals(Result.CREATED) ? result : null;
    }

    @Override
    public DocWriteResponse createFileInfomationById(String doc, String id) {
        DocWriteResponse result = SearchApi.insertDocument(FILE_INFORMATION_INDEX, SearchApi.TYPE, doc, id);
        return result.getResult().equals(Result.CREATED) ? result : null;
    }

    @Override
    public DocWriteResponse updateFileInfomation(String doc, String id) {
        DocWriteResponse result = SearchApi.updateDocument(FILE_INFORMATION_INDEX, SearchApi.TYPE, doc, id);
        return result.getResult().equals(Result.UPDATED) ? result : null;
    }

    @Override
    public DocWriteResponse updateFileInfomationWithVersion(String doc, String id, long version)
            throws ElasticsearchException {
        DocWriteResponse result;
        try {
            result = SearchApi.updateDocumentByLock(FILE_INFORMATION_INDEX, SearchApi.TYPE, doc, id, version);
            return result.getResult().equals(Result.UPDATED) ? result : null;
        } catch (ElasticsearchException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public DocWriteResponse deleteFileInfomation(String id) {
        DocWriteResponse result = SearchApi.deleteDocument(FILE_INFORMATION_INDEX, SearchApi.TYPE, id);
        return result.getResult().equals(Result.DELETED) ? result : null;
    }

    @Override
    public HashMap<String, Object> queryFileInfomation(String id) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByField(FILE_INFORMATION_INDEX, ID, id, null, null);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic.get(0);
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfoByTerm(String timeStamp, int type, Integer pageNo,
            Integer size) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByTerm(FILE_INFORMATION_INDEX, CREATETIME, timeStamp,
                type, pageNo, size);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfoByTimeRange(String startTime, String endTime,
            Integer pageNo, Integer size) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByTimeRange(FILE_INFORMATION_INDEX, CREATETIME,
                startTime, endTime, pageNo, size);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfomationByStatus(int status, Integer pageNo, Integer size) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByFieldSorted(FILE_INFORMATION_INDEX, STATUS,
                String.valueOf(status), CREATETIME, SortOrder.DESC, pageNo, size);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfomationBySize(int minSize, int maxSize, Integer pageNo,
            Integer size) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByGeneralRange(FILE_INFORMATION_INDEX, FILESIZE,
                minSize, maxSize, FILESIZE, SortOrder.DESC, pageNo, size);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public String getIntegratedPath(String fileId) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByField(FILE_INFORMATION_INDEX, ID, fileId, null,
                null);
        if (dic == null || dic.size() == 0) {
            return null;
        }

        String path = (String) dic.get(0).get(FILEPATH);
        String name = (String) dic.get(0).get(FILENAME);
        String type = (String) dic.get(0).get(FILETYPE);
        return new StringBuffer(path).append(name).append(".").append(type).toString();
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfomationByUserId(String userId, Integer pageNo,
            Integer size) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByFieldSorted(FILE_INFORMATION_INDEX, CREATOR, userId,
                CREATETIME, SortOrder.DESC, pageNo, size);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfomationByProductName(String productName, Integer pageNo,
            Integer size) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.fussySearchByFieldSorted(FILE_INFORMATION_INDEX,
                PRODUCTNAME, productName, CREATETIME, SortOrder.DESC, pageNo, size);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfomationByDeviceName(String deviceName, Integer pageNo,
            Integer size) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.fussySearchByFieldSorted(FILE_INFORMATION_INDEX, DEVICENAME,
                deviceName, CREATETIME, SortOrder.DESC, pageNo, size);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public LinkedList<HashMap<String, Object>> queryFileInfomationByFileType(Integer pageNo, Integer size,
            String... types) {
        LinkedList<HashMap<String, Object>> dic = SearchApi.searchByFieldSortedWithValues(FILE_INFORMATION_INDEX,
                FILETYPE, CREATETIME, SortOrder.DESC, pageNo, size, types);
        if (dic == null || dic.size() == 0) {
            return null;
        }
        return dic;
    }

    @Override
    public Object exploreFilesByParams(String fileId, String status, String userId, String startTime, String endTime,
            String productId, String productName, String deviceId, String deviceName, String fileType, Integer minSize,
            Integer maxSize, Integer pageNo, Integer pageSize, List<String> sortProperties, SortOrder sortOrder) {
        ArrayList<QueryBuilder> params = createQueryBuilders(fileId, status, userId, startTime, endTime, productId,
                productName, deviceId, deviceName, fileType, minSize, maxSize);
        if (params.size() == 0) {
            return null;
        }
        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        SearchResponse searchResponse = SearchApi.searchByMultiQueries(FILE_INFORMATION_INDEX, sortProperties,
                sortOrder, pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            m.put(FILEID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);
        return page;
    }

    @Override
    public Object exploreFilesByStatusNotMatch(String status, String productId, String deviceId) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
        if (StringUtils.isNotEmpty(status)) {
            params.add(SearchApi.createNotSearchSource(STATUS, status));
        }
        if (StringUtils.isNotEmpty(productId)) {
            params.add(SearchApi.createSearchByFieldSource(PRODUCTID, productId));
        }
        if (StringUtils.isNotEmpty(deviceId)) {
            params.add(SearchApi.createSearchByFieldSource(DEVICEID, deviceId));
        }
        QueryBuilder[] values = new QueryBuilder[3];
        SearchResponse searchResponse = SearchApi.searchByQueryBuilder(FILE_INFORMATION_INDEX, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        return searchResponse.getHits().totalHits;
    }

    @Override
    public long exploreFilesByParamsWithoutSize(String fileId, String status, String userId, String startTime,
            String endTime, String productId, String productName, String deviceId, String deviceName, String fileType,
            Integer minSize, Integer maxSize) {
        ArrayList<QueryBuilder> params = createQueryBuilders(fileId, status, userId, startTime, endTime, productId,
                productName, deviceId, deviceName, fileType, minSize, maxSize);
        if (params.size() == 0) {
            return 0;
        }
        QueryBuilder[] values = new QueryBuilder[8];
        return SearchApi.searchByMultiQueriesWithOutSize(FILE_INFORMATION_INDEX, CREATETIME, SortOrder.DESC,
                params.toArray(values));
    }

    @Override
    public LinkedList<HashMap<String, Object>> fileStatisticsByParamsDetails(String autoType, String deviceId,
            String productId, String fileType, String userId, String startTime, String endTime) {

        ArrayList<ArrayList<String>> ranges = DateUtil.getDailyRanges(startTime, endTime);
        LinkedList<HashMap<String, Object>> multiTypes = new LinkedList<HashMap<String, Object>>();
        for (ArrayList<String> arrayList : ranges) {
            HashMap<String, Object> result = new HashMap<String, Object>(16);
            result.put(IndexServiceImpl.DATE, DateUtil.getDateByTimeStamp(arrayList.get(0), DateUtil.FORMAT_DATE));
            LinkedList<HashMap<String, Object>> daliyArray = new LinkedList<HashMap<String, Object>>();
            for (FileStatusEnum status : FileStatusEnum.values()) {
                HashMap<String, Object> statusResult = new HashMap<String, Object>(16);
                HashMap<String, Object> detail = fileStatisticsByParams(autoType, deviceId, productId, status.getCode(),
                        fileType, userId, arrayList.get(0), arrayList.get(1));
                if (detail != null) {
                    statusResult.put(STATUS, status.getCode());
                    statusResult.put(RESULT, detail);
                    daliyArray.add(statusResult);
                }
                result.put(SUMMARY, daliyArray);
            }
            multiTypes.add(result);
        }
        return multiTypes.size() != 0 ? multiTypes : null;
    }

    @Override
    public HashMap<String, Object> fileStatisticsByParams(String autoType, String deviceId, String productId,
            Integer status, String fileType, String userId, String startTime, String endTime) {

        ArrayList<QueryBuilder> params = createQueryBuilders(null, status == null ? null : String.valueOf(status),
                userId, startTime, endTime, productId, null, deviceId, null, fileType, null, null);
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        QueryBuilder[] values = new QueryBuilder[8];

        SearchResponse result = SearchApi.fileStatiscByParams(FILE_INFORMATION_INDEX,
                params.size() == 0 ? null : params.toArray(values));
        if (result != null) {
            ParsedSum parse = result.getAggregations().get(SearchApi.SUM);
            map.put(TOTAL_FILES, result.getHits().totalHits);
            map.put(TOTAL_SIZE, parse.getValue());
            return map;
        }
        return null;
    }

    /**
     * 构造多参数查询条件
     * 
     * @param fileId
     * @param status
     * @param userId
     * @param startTime
     * @param endTime
     * @param productId
     * @param productName
     * @param deviceId
     * @param deviceName
     * @param fileType
     * @param minSize
     * @param maxSize
     * @return
     */
    private ArrayList<QueryBuilder> createQueryBuilders(String fileId, String status, String userId, String startTime,
            String endTime, String productId, String productName, String deviceId, String deviceName, String fileType,
            Integer minSize, Integer maxSize) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
        if (StringUtil.isNotEmpty(startTime) && StringUtil.isNotEmpty(endTime)) {
            params.add(SearchApi.createSearchByFieldRangeSource(CREATETIME, startTime, endTime));
        }
        if (minSize != null && maxSize != null) {
            params.add(SearchApi.createSearchByFieldRangeSource(FILESIZE, minSize.toString(), maxSize.toString()));
        }
        if (StringUtil.isNotEmpty(productId)) {
            params.add(SearchApi.createSearchByFieldSource(PRODUCTID, productId));
        }
        if (StringUtil.isNotEmpty(productName)) {
            params.add(SearchApi.createFussySearchSource(PRODUCTNAME, productName));
        }
        if (StringUtil.isNotEmpty(deviceId)) {
            params.add(SearchApi.createSearchByFieldSource(DEVICEID, deviceId));
        }
        if (StringUtil.isNotEmpty(deviceName)) {
            params.add(SearchApi.createFussySearchSource(DEVICENAME, deviceName));
        }
        if (StringUtil.isNotEmpty(fileType)) {
            params.add(SearchApi.createSearchByMultiSource(FILETYPE,
                    FileTypeEnum.getMIMEType(Integer.valueOf(fileType)).getPrefix()));
        }
        if (StringUtil.isNotEmpty(fileId)) {
            params.add(SearchApi.createSearchByFieldSource(ID, fileId));
        }
        if (StringUtil.isNotEmpty(status)) {
//            List<QueryBuilder> q = QueryBuilders.boolQuery().should();
//            for (String param : status.split(",")) {
//                q.add(SearchApi.createSearchByMultiSource(STATUS, status.split(",")));
//            }
//            params.addAll(q);
            params.add(SearchApi.createSearchByMultiSource(STATUS, status.split(",")));
        }
        if (StringUtil.isNotEmpty(userId)) {
            params.add(SearchApi.createSearchByFieldSource(CREATOR, userId));
        }
        return params;
    }

    /**
     * 根据更新时间查询数据(pengdengfu)
     * 
     * @param status
     * @param startTime
     * @param endTime
     * @return
     */
    private ArrayList<QueryBuilder> createQueryBuilders(Set<String> statuss, String startTime, String endTime,
            String fileType) {
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
        if (statuss != null && statuss.size() > 0) {
            params.add(SearchApi.createSearchByMultiSource(STATUS, statuss.toArray(new String[statuss.size()])));
        }
        if (StringUtil.isNotEmpty(fileType)) {
            params.add(SearchApi.createSearchByMultiSource(FILETYPE,
                    FileTypeEnum.getMIMEType(Integer.valueOf(fileType)).getPrefix()));
        }
        if (StringUtil.isNotEmpty(startTime) && StringUtil.isNotEmpty(endTime)) {
            params.add(SearchApi.createSearchByFieldRangeSource(UPDATETIME, startTime, endTime));
        }
        return params;

    }

    @Override
    public Object exploreFilesByUpdateStatus(Set<String> status, String startTime, String endTime, String fileType,
            Integer pageNo, Integer pageSize, List<String> sortProperties, SortOrder sortOrder) {
        ArrayList<QueryBuilder> params = createQueryBuilders(status, startTime, endTime, fileType);
        if (params.size() == 0) {
            return null;
        }
        QueryBuilder[] values = new QueryBuilder[8];
        LinkedList<HashMap<String, Object>> dic = new LinkedList<HashMap<String, Object>>();
        SearchResponse searchResponse = SearchApi.searchByMultiQueries(FILE_INFORMATION_INDEX, sortProperties,
                sortOrder, pageNo, pageSize, params.toArray(values));
        if (searchResponse == null) {
            return null;
        }
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit hit : searchHits) {
            HashMap<String, Object> m = (HashMap<String, Object>) hit.getSourceAsMap();
            m.put(FILEID, hit.getId());
            m.put(VERSION, hit.getVersion());
            dic.add(m);
        }
        HashMap<String, Object> map = new HashMap<String, Object>(16);
        map.put(TOTAL, searchResponse.getHits().totalHits);
        map.put(RESULT, dic);
        int[] pageParams = SearchApi.createPageAbleArr(pageNo, pageSize, (int) searchResponse.getHits().totalHits);
        Pageable page1 = new PageRequest(pageParams[0], pageParams[1]);
        Page<HashMap<String, Object>> page = new PageImpl<HashMap<String, Object>>(dic, page1,
                searchResponse.getHits().totalHits);
        return page;
    }

    @Override
    public String createFileCheckSum(String fileId, String checkSum, String path) {
        JSONObject doc = new JSONObject();
        doc.put(FILEID, fileId);
        doc.put(CHECKSUM, checkSum);
        doc.put(PATH, path);
        doc.put(CREATETIME, DateUtil.getCurrentDate());
        DocWriteResponse result = SearchApi.insertDocument(DAS_DUPLICATION_CHECK, SearchApi.TYPE, doc.toJSONString());
        return result.getResult().equals(Result.CREATED) ? result.getId() : null;
    }

    @Override
    public String uniqueValid(String fileId, String checkSum) {
        List<QueryBuilder> queries = new ArrayList<QueryBuilder>();
        if (!TextUtils.isEmpty(fileId)) {
            queries.add(SearchApi.createSearchByFieldSource(FILEID, fileId));
        }

        if (!TextUtils.isEmpty(checkSum)) {
            queries.add(SearchApi.createSearchByFieldSource(CHECKSUM, checkSum));
        }
        QueryBuilder[] q = new QueryBuilder[2];
        queries.toArray(q);
        SearchResponse searchResponse = SearchApi.searchByQueryBuilder(DAS_DUPLICATION_CHECK, q);
        return searchResponse.getHits().totalHits == 0 ? null
                : (String) searchResponse.getHits().getHits()[0].getSourceAsMap().get(FILEID);
    }

}
