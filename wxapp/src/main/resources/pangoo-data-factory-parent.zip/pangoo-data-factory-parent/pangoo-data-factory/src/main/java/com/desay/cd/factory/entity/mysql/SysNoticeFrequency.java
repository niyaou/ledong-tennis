package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * 通知频率
 * 
 * @author pengdengfu
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_notice_frequency", uniqueConstraints = { @UniqueConstraint(columnNames = { "frequency_name" }) })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "frequencyId")
public class SysNoticeFrequency implements Serializable {

    private static final long serialVersionUID = -853931866612074706L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "frequency_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String frequencyId;

    /** 事件名称 */
    @Column(name = "frequency_name", nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '权限名称'")
    private String frequencyName;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    @JsonIgnore
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((frequencyId == null) ? 0 : frequencyId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysNoticeFrequency other = (SysNoticeFrequency) obj;
        if (frequencyId == null) {
            if (other.frequencyId != null) {
                return false;
            }
        } else if (!frequencyId.equals(other.frequencyId)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "SysNoticeFrequency [frequencyId=" + frequencyId + ", frequencyName=" + frequencyName + "]";
    }

    public String getFrequencyId() {
        return frequencyId;
    }

    public void setFrequencyId(String frequencyId) {
        this.frequencyId = frequencyId;
    }

    public String getFrequencyName() {
        return frequencyName;
    }

    public void setFrequencyName(String frequencyName) {
        this.frequencyName = frequencyName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

}
