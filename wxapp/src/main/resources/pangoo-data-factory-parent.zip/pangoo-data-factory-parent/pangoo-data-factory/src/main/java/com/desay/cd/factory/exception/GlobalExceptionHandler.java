package com.desay.cd.factory.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;

/**
 * GlobalExceptionHandler
 * 
 * @author pengdengfu
 *
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /*
     * @ExceptionHandler(Exception.class) public ResponseEntity<?>
     * handleException(Exception e) { e.printStackTrace(); return new
     * ResponseEntity<Object>(new
     * CommonResponse(ResultCodeEnum.UNKOWN_ERROR.getCode(), e.getMessage()),
     * HttpStatus.OK); }
     */

    @ExceptionHandler(CustumException.class)
    public ResponseEntity<?> handleException(CustumException e) {
        if (e.getCode() == ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getCode() || e.getCode() == ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getCode()) {
            return new ResponseEntity<Object>(new CommonResponse(e.getCode(), e.getMsg(), e.getData()), HttpStatus.OK);
        }
        return new ResponseEntity<Object>(new CommonResponse(e.getCode(), e.getMsg()), HttpStatus.OK);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<?> handleException(HttpMessageNotReadableException e) {
        return new ResponseEntity<Object>(new CommonResponse(ResultCodeEnum.FILE_PARAMS_PARSE_ERROR.getCode(), ResultCodeEnum.FILE_PARAMS_PARSE_ERROR.getMessage()), HttpStatus.OK);
    }
}