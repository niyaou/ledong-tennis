package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.desay.cd.factory.entity.mysql.SysRole;

/**
 * ISysRoleDao
 * 
 * @author pengdengfu
 *
 */
public interface ISysRoleDao extends JpaRepository<SysRole, Serializable>, JpaSpecificationExecutor<SysRole> {

    /**
     * 根据角色名称查询角色相关信息
     * 
     * @param roleName
     * @return
     */
    public SysRole findByRoleName(String roleName);

    /**
     * 查询引用
     * 
     * @param roleId
     * @return
     */
    @Query(value = "select count(*) from sys_user_role where role_id=?1", nativeQuery = true)
    Integer countRolesUsedBy(String roleId);

}
