package com.desay.cd.factory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.GenericPropertyMatchers;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.dao.ISysChunksLogDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysChunksLog;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.ISysChunksLogService;

/**
 * SysChunksLogServiceImpl
 * 
 * @author nixuchun
 *
 */
@Service
public class SysChunksLogServiceImpl implements ISysChunksLogService {

    public static final int PAGE = 1;
    public static final int DEFAULT_SIZE = 20;

    @Autowired
    ISysChunksLogDao sysChunksLogDao;

    @Override
    public SysChunksLog createChunksLog(SysChunksLog log) {
        return sysChunksLogDao.saveAndFlush(log);
    }

    @Override
    public List<SysChunksLog> exploreLogs() {
        return sysChunksLogDao.findAll();
    }

    @Override
    public SysChunksLog queryLogByName(String parentId, String displayName) {
        return null;
        // return sysChunksLogDao.findByParentIdAndDisplayName(parentId,displayName);
    }

    @Override
    public SysChunksLog uploadChunksLog(SysChunksLog log) {
        return sysChunksLogDao.saveAndFlush(log);
    }

    @Override
    public boolean deleteChunksLog(String id) {
        try {
            sysChunksLogDao.delete(id);
        } catch (EmptyResultDataAccessException e) {
            throw new CustumException(ResultCodeEnum.UPLOAD_LOG_NOT_EXISTED.getCode(), ResultCodeEnum.UPLOAD_LOG_NOT_EXISTED.getMessage());
        }
        return true;
    }

    @Override
    public SysChunksLog queryLogById(String id) {
        List<SysChunksLog> list = sysChunksLogDao.findByFileId(id);
        return !list.isEmpty() ? list.get(0) : null;
    }

    @Override
    public Page<SysChunksLog> queryLogByUserId(String userId, Integer pageNo, Integer pageSize) {

        if (pageNo == null || pageSize == null) {
            pageNo = PAGE;
            pageSize = DEFAULT_SIZE;
        }
        if (pageNo <= 0) {
            pageNo = 1;
        }
        if (pageSize <= 0) {
            pageSize = 1;
        }
        pageNo--;
        SysChunksLog log = new SysChunksLog();
        log.setUserId(userId);
        Pageable pageable = new PageRequest(pageNo, pageSize, new Sort(Sort.Direction.DESC, "userId"));
        ExampleMatcher matcher = ExampleMatcher.matching().withMatcher("userId", GenericPropertyMatchers.exact());
        Example<SysChunksLog> example = Example.of(log, matcher);
        return sysChunksLogDao.findAll(example, pageable);

    }

}