package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysEnvConfigDao;
import com.desay.cd.factory.entity.mysql.SysEnvConfig;
import com.desay.cd.factory.service.ISysEnvConfigService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: SysEnvConfigServiceImpl
 * @author: pengdengfu
 * @date: 2019年11月1日 下午12:01:07
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class SysEnvConfigServiceImpl implements ISysEnvConfigService {
    @Autowired
    private ISysEnvConfigDao sysEnvConfigDao;

    @Override
    public String addOrUpdate(SysEnvConfig sysEnvConfig) {
        String envId = sysEnvConfig.getEnvId();
        if (StringUtils.isEmpty(envId)) {
            SysEnvConfig envConfig = sysEnvConfigDao.saveAndFlush(sysEnvConfig);
            envId = envConfig.getEnvId();
        } else {
            SysEnvConfig findOne = sysEnvConfigDao.findOne(envId);
            BeanUtils.copyProperties(sysEnvConfig, findOne, "createTime");
            sysEnvConfigDao.saveAndFlush(findOne);
        }
        return envId;
    }

    @Override
    public void delete(String envId) {
        sysEnvConfigDao.delete(envId);

    }

    @Override
    public Page<SysEnvConfig> search(String envId, String type, String ip, String hostName, String hostNameLike, Integer pageNo, Integer pageSize, List<String> sortProperties) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, sortProperties, "createTime");

        final String hostNameTmp = hostName;
        Specification<SysEnvConfig> specification = new Specification<SysEnvConfig>() {
            @Override
            public Predicate toPredicate(Root<SysEnvConfig> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(envId)) {
                    predicates.add(cb.equal(root.get("envId"), envId));
                }
                if (StringUtils.isNotEmpty(type)) {
                    predicates.add(cb.equal(root.get("type"), type));
                }
                if (StringUtils.isNotEmpty(ip)) {
                    predicates.add(cb.equal(root.get("ip"), ip));
                }
                if (StringUtils.isNotEmpty(hostNameTmp)) {
                    if (StringUtils.equalsIgnoreCase(hostNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.like(root.get("hostName"), "%" + hostNameTmp + "%"));
                    } else {
                        predicates.add(cb.equal(root.get("hostName"), hostNameTmp));
                    }
                }
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        return sysEnvConfigDao.findAll(specification, pageable);
    }

}
