package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.TaskAssignStrategy;
import com.desay.cd.factory.rest.vo.TaskAssignStrategyVo;

/**
 * 
 * @ClassName: ICleanStrategyService
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:22:23
 */
public interface ITaskAssignStrategyService {
    /**
     * 添加
     * 
     * @param taskAssignStrategyVo
     * @return
     */
    String add(TaskAssignStrategyVo taskAssignStrategyVo);

    /**
     * 删除
     * 
     * @param strgyId
     */
    void delete(String strgyId);

    /**
     * 更新
     * 
     * @param strgyId
     * @param taskAssignStrategyVo
     * @param isOverall
     */
    void update(String strgyId, TaskAssignStrategyVo taskAssignStrategyVo, boolean isOverall);

    /**
     * 查询
     * 
     * @param strgyId
     * @param strygName
     * @param strygNameLike
     * @param deviceId
     * @param deviceName
     * @param deviceNameLike
     * @param groupId
     * @param groupName
     * @param groupNameLike
     * @param taskTypeId
     * @param taskTypeName
     * @param taskTypeNameLike
     * @param priorityId
     * @param priorityName
     * @param priorityNameLike
     * @param status
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @return
     */
    Page<TaskAssignStrategy> search(String strgyId, String strygName, String strygNameLike, String deviceId, String deviceName, String deviceNameLike, String groupId,
            String groupName, String groupNameLike, String taskTypeId, String taskTypeName, String taskTypeNameLike, String priorityId, String priorityName,
            String priorityNameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties);
}
