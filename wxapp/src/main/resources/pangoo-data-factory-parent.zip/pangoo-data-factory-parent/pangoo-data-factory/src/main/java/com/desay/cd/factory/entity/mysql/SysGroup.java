package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @ClassName: ClearAlgorithm
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:18:19
 */
@Getter
@Setter
@Entity
@Table(name = "sys_group", uniqueConstraints = { @UniqueConstraint(columnNames = { "group_name" }) })
@EntityListeners(AuditingEntityListener.class)
public class SysGroup implements Serializable {

    private static final long serialVersionUID = -3884405292843766149L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "group_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String groupId;

    @Column(name = "group_name", unique = true, nullable = false, columnDefinition = "varchar(50) COMMENT '组名称'")
    private String groupName;

    @Column(name = "group_desc", columnDefinition = "text COMMENT '组描述'")
    private String groupDesc;

    /** 组内成员 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_group_members", joinColumns = @JoinColumn(name = "group_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
    @OrderBy("user_name DESC")
    @JsonIgnoreProperties({ "sysRoles", "sysSubSystems", "memberGroups", "masterGroups", "avatar" })
    private Set<SysUser> members;

    /** 组内管理者 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_group_masters", joinColumns = @JoinColumn(name = "group_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
    @OrderBy("user_name DESC")
    @JsonIgnoreProperties({ "sysRoles", "sysSubSystems", "memberGroups", "masterGroups", "avatar" })
    private Set<SysUser> masters;

    /** 组能力 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_group_abilities", joinColumns = @JoinColumn(name = "group_id"), inverseJoinColumns = @JoinColumn(name = "data_id"))
    @OrderBy("name DESC")
    private Set<DataDictionary> abilities;

    /** 所属子系统 */
    @ManyToOne
    @JoinColumn(name = "sub_system_id")
    @JsonIgnore
    private SysSubSystem sysSubsystem;

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private Integer isActive = 1;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
        result = prime * result + ((groupName == null) ? 0 : groupName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysGroup other = (SysGroup) obj;
        if (groupId == null) {
            if (other.groupId != null) {
                return false;
            }
        } else if (!groupId.equals(other.groupId)) {
            return false;
        }
        if (groupName == null) {
            if (other.groupName != null) {
                return false;
            }
        } else if (!groupName.equals(other.groupName)) {
            return false;
        }
        return true;
    }

}
