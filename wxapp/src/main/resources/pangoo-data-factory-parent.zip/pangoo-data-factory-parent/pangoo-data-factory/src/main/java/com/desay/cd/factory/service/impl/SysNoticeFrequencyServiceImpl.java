package com.desay.cd.factory.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysNoticeFrequencyDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysNoticeFrequency;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.ISysNoticeFrequencyService;

/**
 * SysNoticeFrequencyServiceImpl
 * 
 * @author pengdengfu
 *
 */
@Service
public class SysNoticeFrequencyServiceImpl implements ISysNoticeFrequencyService {

    @Autowired
    ISysNoticeFrequencyDao sysNoticeFrequencyDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public SysNoticeFrequency addNoticeFrequency(String noticeFrequencyName) {
        if (StringUtils.isEmpty(noticeFrequencyName)) {
            throw new CustumException(ResultCodeEnum.NOTICE_FREQUENCY_NAME_CANNOT_NULL.getCode(), ResultCodeEnum.NOTICE_FREQUENCY_NAME_CANNOT_NULL.getMessage());
        }
        if (noticeFrequencyName.length() > Constanst.NAME_LENGTH) {
            throw new CustumException(ResultCodeEnum.NOTICE_FREQUENCE_NAME_TOO_LONG.getCode(), ResultCodeEnum.NOTICE_FREQUENCE_NAME_TOO_LONG.getMessage());
        }
        SysNoticeFrequency sysNoticeFrequency = new SysNoticeFrequency();
        sysNoticeFrequency.setFrequencyName(noticeFrequencyName);
        try {
            return sysNoticeFrequencyDao.saveAndFlush(sysNoticeFrequency);
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.NOTICE_FREQUENCE_NAME_EXISTED.getCode(), ResultCodeEnum.NOTICE_FREQUENCE_NAME_EXISTED.getMessage());
        }

    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public void deleteNoticeFrequency(String noticeFrequencyId) {
        if (StringUtils.isEmpty(noticeFrequencyId)) {
            throw new CustumException(ResultCodeEnum.NOTICE_FREQUENCY_ID_CANNOT_NULL.getCode(), ResultCodeEnum.NOTICE_FREQUENCY_ID_CANNOT_NULL.getMessage());
        }
        SysNoticeFrequency findOne = sysNoticeFrequencyDao.findOne(noticeFrequencyId);
        if (findOne == null) {
            throw new CustumException(ResultCodeEnum.NOTICE_FREQUENCE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.NOTICE_FREQUENCE_ID_NOT_EXISTED.getMessage());
        }
        try {
            sysNoticeFrequencyDao.delete(noticeFrequencyId);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public List<SysNoticeFrequency> getNoticeFrequencys() {
        return sysNoticeFrequencyDao.findAll();
    }

}
