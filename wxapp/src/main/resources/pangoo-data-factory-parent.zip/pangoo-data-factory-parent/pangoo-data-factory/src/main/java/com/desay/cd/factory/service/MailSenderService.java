package com.desay.cd.factory.service;

/**
 * 发送邮件
 * 
 * @author uidq1163
 *
 */
public interface MailSenderService {

    /**
     * 单个邮件发送
     * 
     * @param title
     * @param message
     * @param mail
     * @throws Exception
     */
    void sendMail(String title, String message, String mail) throws Exception;

    /**
     * 批量发送邮件
     * 
     * @param title
     * @param message
     * @param mails
     * @throws Exception
     */
    void sendMail(String title, String message, String[] mails) throws Exception;
}
