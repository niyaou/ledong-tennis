package com.desay.cd.factory.enums;

/**
 * 用户角色
 * 
 * @author uidq1163
 *
 */
public enum UserRoleEnum {
    /** 文件审核 */
    FileAuditor("fileAuditor", "文件审核"),
    /** 文件上传 */
    FileUploader("fileUploader", "文件上传");

    private String enName;
    private String cnName;

    UserRoleEnum(String enName, String cnName) {
        this.enName = enName;
        this.cnName = cnName;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getCnName() {
        return cnName;
    }

    public void setCnName(String cnName) {
        this.cnName = cnName;
    }

    @Override
    public String toString() {
        return this.name();
    }

}
