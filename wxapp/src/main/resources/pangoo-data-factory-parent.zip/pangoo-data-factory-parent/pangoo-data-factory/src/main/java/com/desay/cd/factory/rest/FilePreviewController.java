package com.desay.cd.factory.rest;

import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.IFileService;
import com.desay.cd.factory.utils.ControllerCommonUtils;
import com.desay.cd.hdfs.HdfsUtils;
import com.madgag.gif.fmsware.AnimatedGifEncoder;
import com.madgag.gif.fmsware.GifDecoder;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 
 * @ClassName: FilePreviewController
 * @author: pengdengfu
 * @date: 2019年3月13日 上午9:47:48
 */
@RestController
@Api(value = "文件预览：文本，视频，图片", tags = "FilePreviewController")
@Slf4j
public class FilePreviewController {

    @Autowired
    private IFileService fileService;

    @Value("${pangoo.das.preview.path.dir}")
    private String previewPathDir;

    public static Set<String> textTypeSet = new HashSet<>();
    {
        textTypeSet.addAll(Arrays.asList("txt", "csv", "xml", "html", "log", "json"));
    }
    public static Set<String> imageTypeSet = new HashSet<>();
    {
        imageTypeSet.addAll(Arrays.asList("jpg", "png", "gif", "tif", "bmp", "jpeg"));
    }

    @RequestMapping(value = "/image/view", method = RequestMethod.GET)
    @ApiOperation(value = "图片查看", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "filePath", value = "文件路径", required = true, dataType = "string", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.FILE, message = "图片查看")
    public byte[] viewImage(@RequestParam(value = "filePath", required = true) String filePath, @RequestHeader(value = "Range", required = false) String requestRange,
            HttpServletResponse resp) {
        final long fileLen = HdfsUtils.getHdfsFileLength(filePath);
        String range = requestRange;

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        FSDataInputStream in = null;

        try {
            if (range == null) {
                String fileLastName = filePath.substring(filePath.lastIndexOf(Constanst.FORWORD_SLASH) + 1);
                resp.setHeader("Content-Disposition", "attachment; filename=" + fileLastName);
                resp.setContentType("application/octet-stream");
                resp.setContentLength((int) fileLen);
                in = HdfsUtils.downloadFileFromHdfs(filePath);
                IOUtils.copyBytes(in, out, fileLen, false);
                return out.toByteArray();
            } else {
                long start = Integer.valueOf(range.substring(range.indexOf("=") + 1, range.indexOf(Constanst.MIDDLE_LINE)));
                long count = fileLen - start;
                long end;
                if (range.endsWith(Constanst.MIDDLE_LINE)) {
                    end = fileLen - 1;
                } else {
                    end = Integer.valueOf(range.substring(range.indexOf(Constanst.MIDDLE_LINE) + 1));
                }
                String contentRange = "bytes " + String.valueOf(start) + Constanst.MIDDLE_LINE + end + Constanst.FORWORD_SLASH + String.valueOf(fileLen);
                resp.setStatus(206);
                resp.setHeader("Content-Range", contentRange);
                in = HdfsUtils.downloadFileFromHdfs(filePath, start);
                IOUtils.copyBytes(in, out, count, false);
                return out.toByteArray();
            }
        } catch (Exception e) {
            log.error("get hdfs file exception.", e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    @RequestMapping(value = "/preview/video", method = RequestMethod.GET, produces = "video/mp4")
    @ApiOperation(value = "文件预览-视频预览", notes = "")
    @ApiIgnore
    @ApiImplicitParams({ @ApiImplicitParam(name = "fileId", value = "文件ID", required = true, dataType = "string", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.FILE, message = "文件预览-视频预览")
    public byte[] previewVedio(@RequestParam(value = "fileId", required = true) String fileId, @RequestHeader(value = "Range", required = true) String requestRange,
            HttpServletResponse resp) {
        if (StringUtils.isEmpty(fileId)) {
            throw new CustumException(ResultCodeEnum.FILE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.FILE_ID_CANNOT_NULL.getMessage());
        }
        String fpath = fileService.getRealPath(fileId);
        String filename = fpath;

        final long fileLen = HdfsUtils.getHdfsFileLength(filename);
        String range = requestRange;

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        FSDataInputStream in = null;

        try {
            if (range == null) {
                String fileLastName = fpath.substring(fpath.lastIndexOf(Constanst.FORWORD_SLASH) + 1);
                resp.setHeader("Content-Disposition", "attachment; filename=" + fileLastName);
                resp.setContentType("application/octet-stream");
                resp.setContentLength((int) fileLen);
                in = HdfsUtils.downloadFileFromHdfs(filename);
                IOUtils.copyBytes(in, out, fileLen, false);
                return out.toByteArray();
            } else {
                long start = Integer.valueOf(range.substring(range.indexOf("=") + 1, range.indexOf(Constanst.MIDDLE_LINE)));
                long count = fileLen - start;
                long end;
                if (range.endsWith(Constanst.MIDDLE_LINE)) {
                    end = fileLen - 1;
                } else {
                    end = Integer.valueOf(range.substring(range.indexOf(Constanst.MIDDLE_LINE) + 1));
                }
                String contentRange = "bytes " + String.valueOf(start) + Constanst.MIDDLE_LINE + end + Constanst.FORWORD_SLASH + String.valueOf(fileLen);
                resp.setStatus(206);
                resp.setHeader("Content-Range", contentRange);
                in = HdfsUtils.downloadFileFromHdfs(filename, start);
                IOUtils.copyBytes(in, out, count, false);
                return out.toByteArray();
            }
        } catch (Exception e) {
            log.error("get hdfs file exception.", e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
        }
        return null;
    }

    @RequestMapping(value = "/preview/text", method = RequestMethod.GET)
    @ApiOperation(value = "文件预览-小型文本查看", notes = "默认返回1前100行(txt,csv,xml,html等一般的文本文件)")
    @ApiImplicitParams({ @ApiImplicitParam(name = "fileId", value = "文件Id", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "startLine", value = "startLine", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endLine", value = "endLine", required = false, dataType = "string", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.FILE, message = "小型文本查看")
    public ResponseEntity<?> previewTextFile(@RequestParam(value = "fileId", required = true) String fileId, @RequestParam(value = "startLine", required = false) String startLine,
            @RequestParam(value = "endLine", required = false) String endLine) {
        if (StringUtils.isEmpty(fileId)) {
            throw new CustumException(ResultCodeEnum.FILE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.FILE_ID_CANNOT_NULL.getMessage());
        }
        String filePath = fileService.getRealPath(fileId);
        if (filePath == null) {
            throw new CustumException(ResultCodeEnum.FILE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_ID_NOT_EXISTED.getMessage());
        }
        String fileType = filePath.substring(filePath.lastIndexOf(".") + 1);
        if (!textTypeSet.contains(fileType)) {
            throw new CustumException(ResultCodeEnum.FILE_PREVIEW_FILE_TYPE_NOT_SUPPORT.getCode(), ResultCodeEnum.FILE_PREVIEW_FILE_TYPE_NOT_SUPPORT.getMessage());
        }
        Long startLine1 = 1L;
        Long endLine1 = 100L;
        try {
            startLine1 = Long.parseLong(startLine);
        } catch (NumberFormatException e) {
            startLine1 = 1L;
        }
        try {
            endLine1 = Long.parseLong(endLine);
        } catch (NumberFormatException e) {
            endLine1 = 100L;
        }
        if (startLine1 <= 0) {
            startLine1 = 1L;
        }
        if (endLine1 <= 0) {
            endLine1 = 100L;
        }
        if (startLine1 > endLine1) {
            throw new CustumException(ResultCodeEnum.FILE_START_MUST_LT_END.getCode(), ResultCodeEnum.FILE_START_MUST_LT_END.getMessage());
        }
        if (StringUtils.isEmpty(filePath)) {
            throw new CustumException(ResultCodeEnum.FILE_PREVIEW_PATH_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_PREVIEW_PATH_NOT_EXISTED.getMessage());
        }
        List<String> newList = new ArrayList<String>();
        StringBuilder stringBuilder = new StringBuilder();
        InputStream instream = null;
        BufferedInputStream bin = null;
        try {
            instream = HdfsUtils.downloadFileFromHdfs(filePath);
            bin = new BufferedInputStream(instream);
            String codeString = "UTF-8";
            try {
                codeString = ControllerCommonUtils.codeString(bin);
            } catch (Exception e) {
                codeString = "UTF-8";
            }
            if (instream != null) {
                bin.reset();
                InputStreamReader inputreader = new InputStreamReader(bin, codeString);
                BufferedReader buffreader = new BufferedReader(inputreader);
                String line;
                // 分行读取
                long skipLines = 0L;
                while ((line = buffreader.readLine()) != null) {
                    skipLines = skipLines + 1;
                    if (skipLines >= startLine1 && skipLines <= endLine1) {
                        newList.add(line + "\n");
                        stringBuilder.append(line).append("\n");
                    }
                }
            }
        } catch (java.io.FileNotFoundException e) {
            log.error("hdfs file not found.", e);
        } catch (IOException e) {
            log.error("get hdfs file exception.", e);
        } finally {
            if (bin != null) {
                try {
                    bin.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
            if (instream != null) {
                try {
                    instream.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
        }
        return new ResponseEntity<Object>(CommonResponse.success(stringBuilder.toString()), HttpStatus.OK);
    }

    @RequestMapping(value = "/preview/image", method = RequestMethod.GET)
    @ApiOperation(value = "文件预览-图片预览", notes = "图片预览（视频缩略图）")
    @ApiImplicitParams({ @ApiImplicitParam(name = "fileId", value = "文件Id", required = true, dataType = "string", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.FILE, message = "文件预览-图片预览")
    public ResponseEntity<?> previewImageFile(@RequestParam(value = "fileId", required = true) String fileId, HttpServletResponse response) throws IOException {
        if (StringUtils.isEmpty(fileId)) {
            throw new CustumException(ResultCodeEnum.FILE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.FILE_ID_CANNOT_NULL.getMessage());
        }
        String fileRealPath = fileService.getRealPath(fileId);
        String filePathThumbNail = fileService.getThumbNailPath(fileId);
        if (fileRealPath == null && filePathThumbNail == null) {
            throw new CustumException(ResultCodeEnum.FILE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_ID_NOT_EXISTED.getMessage());
        }
        String filePath = "";

        if (StringUtils.isEmpty(filePathThumbNail)) {
            filePath = fileRealPath;
        } else {
            filePath = filePathThumbNail;
        }
        if (StringUtils.isEmpty(filePath)) {
            throw new CustumException(ResultCodeEnum.FILE_PREVIEW_PATH_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_PREVIEW_PATH_NOT_EXISTED.getMessage());
        }

        String fileType = filePath.substring(filePath.lastIndexOf(".") + 1);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        FSDataInputStream in = null;
        BufferedInputStream bin = null;
        long fileLen = 0L;

        try {
            fileLen = HdfsUtils.getHdfsFileLength(filePath);
            in = HdfsUtils.downloadFileFromHdfs(filePath);
            bin = new BufferedInputStream(in);
            if (!imageTypeSet.contains(fileType)) {
                throw new CustumException(ResultCodeEnum.FILE_PREVIEW_FILE_TYPE_NOT_SUPPORT.getCode(), ResultCodeEnum.FILE_PREVIEW_FILE_TYPE_NOT_SUPPORT.getMessage());
            }
            IOUtils.copyBytes(bin, out, fileLen, false);
            String base64Header = "data:image/" + fileType + ";base64,";
            String encodedBase64 = base64Header + Base64.getEncoder().encodeToString(out.toByteArray());
            return new ResponseEntity<Object>(CommonResponse.success(encodedBase64), HttpStatus.OK);
        } catch (IOException e1) {
            log.error("get hdfs file exception.", e1);
            throw e1;
        } finally {
            if (bin != null) {
                try {
                    bin.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
        }
    }

    @RequestMapping(value = "/preview/image/thumbnail", method = RequestMethod.GET)
    @ApiOperation(value = "文件预览-图片预览-缩略图", notes = "文件预览-图片预览-缩略图")
    @ApiImplicitParams({ @ApiImplicitParam(name = "fileId", value = "文件Id", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "outputQuality", value = "输出的图片质量，范围：0.0~1.0，1为最高质量,默认0.2", required = false, dataType = "string", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.FILE, message = "文件预览-图片预览-缩略图")
    public ResponseEntity<?> previewImageFileThumbnail(@RequestParam(value = "fileId", required = true) String fileId,
            @RequestParam(value = "outputQuality", required = false) String outputQuality, HttpServletResponse response) throws Exception {
        if (StringUtils.isEmpty(fileId)) {
            throw new CustumException(ResultCodeEnum.FILE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.FILE_ID_CANNOT_NULL.getMessage());
        }
        String fileRealPath = fileService.getRealPath(fileId);
        String filePathThumbNail = fileService.getThumbNailPath(fileId);
        if (fileRealPath == null && filePathThumbNail == null) {
            throw new CustumException(ResultCodeEnum.FILE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_ID_NOT_EXISTED.getMessage());
        }
        String filePath = "";

        if (StringUtils.isEmpty(filePathThumbNail)) {
            filePath = fileRealPath;
        } else {
            filePath = filePathThumbNail;
        }
        String fileType = filePath.substring(filePath.lastIndexOf(".") + 1);
        String fileName = filePath.substring(filePath.lastIndexOf("/") + 1, filePath.lastIndexOf("."));
        String md5Name = DigestUtils.md5Hex(filePath);
        int hashcode = filePath.hashCode();
        // 0--15
        int dir1 = hashcode & 0xf;
        // 0-15
        int dir2 = (hashcode & 0xf0) >> 4;
        float outputQualityT = 0.2f;
        try {
            outputQualityT = Float.parseFloat(outputQuality);
        } catch (Exception e) {
            outputQualityT = 0.2f;
        }
        if (StringUtils.isEmpty(filePath)) {
            throw new CustumException(ResultCodeEnum.FILE_PREVIEW_PATH_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_PREVIEW_PATH_NOT_EXISTED.getMessage());
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        InputStream in = null;
        BufferedInputStream bin = null;
        // 缩略图保存路径
        String previewPath = previewPathDir + dir1 + "/" + dir2;
        // 缩略图文件名
        String hdfsPreviewFile = previewPath + "/" + fileName + "_" + md5Name;
        try {
            in = HdfsUtils.downloadFileFromHdfs(filePath);
            bin = new BufferedInputStream(in);
            if (!imageTypeSet.contains(fileType)) {
                throw new CustumException(ResultCodeEnum.FILE_PREVIEW_FILE_TYPE_NOT_SUPPORT.getCode(), ResultCodeEnum.FILE_PREVIEW_FILE_TYPE_NOT_SUPPORT.getMessage());
            }
            String gif = "gif";
            String base64Header = "data:image/" + fileType + ";base64,";

            // 创建目录
            File dir = new File(previewPath);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            if (gif.equalsIgnoreCase(fileType)) {
                base64Header = "data:image/" + "gif" + ";base64,";
                // 判断预览文件是否存在
                hdfsPreviewFile = hdfsPreviewFile + ".gif";
                File file = new File(hdfsPreviewFile);
                if (!file.exists()) {
                    // 制作缩略图
                    OutputStream hdfsPreviewFileOs = new FileOutputStream(file);
                    zoomGifByQuality(in, outputQualityT, hdfsPreviewFileOs);
                    hdfsPreviewFileOs.close();
                    in.close();
                }
            } else {
                base64Header = "data:image/" + "png" + ";base64,";
                hdfsPreviewFile = hdfsPreviewFile + ".png";
                File file = new File(hdfsPreviewFile);
                if (!file.exists()) {
                    file.createNewFile();
                    OutputStream hdfsPreviewFileOs = new FileOutputStream(file);
                    Thumbnails.of(bin).scale(1.0).outputQuality(outputQualityT).outputFormat("png").toOutputStream(hdfsPreviewFileOs);
                    hdfsPreviewFileOs.close();
                    in.close();
                }
            }
            in = new FileInputStream(new File(hdfsPreviewFile));
            bin = new BufferedInputStream(in);
            IOUtils.copyBytes(bin, out, in.available(), false);

            String encodedBase64 = base64Header + Base64.getEncoder().encodeToString(out.toByteArray());
            return new ResponseEntity<Object>(CommonResponse.success(encodedBase64), HttpStatus.OK);
        } catch (IOException e) {
            log.error("get hdfs file exception.", e);
            throw e;
        } finally {
            if (bin != null) {
                try {
                    bin.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    log.error("close stream exception.", e);
                }
            }
        }
    }

    /**
     * GIF压缩质量，尺寸不变
     * 
     * @param inputStream
     * @param quality
     * @param outputStream
     * @throws IOException
     */
    public void zoomGifByQuality(InputStream inputStream, float quality, OutputStream outputStream) throws IOException {
        ByteArrayInputStream in = null;
        // 防止图片后缀与图片本身类型不一致的情况
        // outputPath = outputPath + "." + imgStyle;
        // GIF需要特殊处理
        GifDecoder decoder = new GifDecoder();
        int status = decoder.read(inputStream);
        if (status != GifDecoder.STATUS_OK) {
            throw new IOException("read image " + " error!");
        }

        // LZW算法压缩，拆分一帧一帧的压缩之后合成
        AnimatedGifEncoder encoder = new AnimatedGifEncoder();
        // 设置合成位置
        encoder.start(outputStream);
        // 设置GIF重复次数
        encoder.setRepeat(decoder.getLoopCount());
        // 获取GIF有多少个frame
        int frameCount = decoder.getFrameCount();

        for (int i = 0; i < frameCount; i++) {
            // 设置GIF延迟时间
            encoder.setDelay(decoder.getDelay(i));
            BufferedImage bufferedImage = decoder.getFrame(i);
            // 利用java SDK压缩BufferedImage
            byte[] tempByte = zoomBufferedImageByQuality(bufferedImage, quality);
            in = new ByteArrayInputStream(tempByte);
            BufferedImage zoomImage = ImageIO.read(in);
            // 合成
            encoder.addFrame(zoomImage);
        }

        encoder.finish();
    }

    /**
     * JDK压缩图片BufferedImage质量
     * 
     * @param bufferedImage
     * @param quality
     * @throws IOException
     * @return
     */
    public byte[] zoomBufferedImageByQuality(BufferedImage bufferedImage, float quality) throws IOException {
        ImageOutputStream imageOutputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        ImageWriter writer = null;
        // 获取压缩后的btye
        byte[] tempByte = null;

        // 得到指定Format图片的writer
        // 得到迭代器
        Iterator<ImageWriter> iter = ImageIO.getImageWritersByFormatName("jpeg");
        // 得到writer
        writer = (ImageWriter) iter.next();

        // 得到指定writer的输出参数设置(ImageWriteParam)
        ImageWriteParam iwp = writer.getDefaultWriteParam();
        // 设置可否压缩
        iwp.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        // 设置压缩质量参数
        iwp.setCompressionQuality(quality);
        iwp.setProgressiveMode(ImageWriteParam.MODE_DISABLED);

        ColorModel colorModel = ColorModel.getRGBdefault();
        // 指定压缩时使用的色彩模式
        iwp.setDestinationType(new ImageTypeSpecifier(colorModel, colorModel.createCompatibleSampleModel(16, 16)));

        // 开始打包图片，写入byte[]
        // 取得内存输出流
        byteArrayOutputStream = new ByteArrayOutputStream();
        IIOImage iIamge = new IIOImage(bufferedImage, null, null);
        // 此处因为ImageWriter中用来接收write信息的output要求必须是ImageOutput
        imageOutputStream = ImageIO.createImageOutputStream(byteArrayOutputStream);
        // 通过ImageIo中的静态方法，得到byteArrayOutputStream的ImageOutput
        writer.setOutput(imageOutputStream);
        writer.write(null, iIamge, iwp);

        tempByte = byteArrayOutputStream.toByteArray();

        return tempByte;
    }

}
