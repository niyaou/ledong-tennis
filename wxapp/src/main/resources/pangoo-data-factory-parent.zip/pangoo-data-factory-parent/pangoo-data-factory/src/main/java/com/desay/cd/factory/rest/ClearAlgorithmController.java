package com.desay.cd.factory.rest;

import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.CleanAlgorithm;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.ClearAlgorithmVo;
import com.desay.cd.factory.service.IClearAlgorithmService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: ClearAlgorithmController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "ClearAlgorithmController", value = "NEW-清洗算法管理")
@RestController
@Validated
public class ClearAlgorithmController {
    @Autowired
    private IClearAlgorithmService clearAlgorithmService;

    @RequestMapping(value = "/management/cleanAlgorithm", method = RequestMethod.POST)
    @ApiOperation(value = "清洗算法管理-添加算法", notes = "")
    @LogAnnotation(action = LogActionEnum.CLEAR_ALGORITHM, message = "清洗算法管理-添加算法")
    public ResponseEntity<?> add(@RequestBody @Validated ClearAlgorithmVo clearAlgorithmVo) {
        CleanAlgorithm clearAlgorithm = new CleanAlgorithm();
        BeanUtils.copyProperties(clearAlgorithmVo, clearAlgorithm, ControllerCommonUtils.getNullPropertyNames(clearAlgorithmVo));
        try {
            String algId = clearAlgorithmService.add(clearAlgorithm);
            return new ResponseEntity<Object>(CommonResponse.success(algId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    @RequestMapping(value = "/management/cleanAlgorithm/{algId}", method = RequestMethod.DELETE)
    @ApiImplicitParams({ @ApiImplicitParam(name = "algId", value = "算法ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "清洗算法管理-删除算法", notes = "")
    @LogAnnotation(action = LogActionEnum.CLEAR_ALGORITHM, message = "清洗算法管理-删除算法")
    public ResponseEntity<?> add(@PathVariable(value = "algId", required = true) String algId) {
        try {
            clearAlgorithmService.delete(algId);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_ALG, null, ResultCodeEnum.CAN_NOT_DELETE_USING_ALG.getMessage());
        }
    }

    @RequestMapping(value = "/management/cleanAlgorithm/{algId}", method = RequestMethod.PUT)
    @ApiImplicitParams({ @ApiImplicitParam(name = "algId", value = "算法ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "清洗算法管理-更新算法-整体更新", notes = "用提供的对象数据，替换原始数据,必填字段必须填写")
    @LogAnnotation(action = LogActionEnum.CLEAR_ALGORITHM, message = "清洗算法管理-更新算法-整体更新")
    public ResponseEntity<?> put(@PathVariable(value = "algId", required = true) String algId, @Validated @RequestBody ClearAlgorithmVo clearAlgorithmVo) {
        CleanAlgorithm clearAlgorithm = new CleanAlgorithm();
        BeanUtils.copyProperties(clearAlgorithmVo, clearAlgorithm);
        clearAlgorithm.setAlgId(algId);
        try {
            clearAlgorithmService.update(clearAlgorithm, true);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/cleanAlgorithm/{algId}", method = RequestMethod.PATCH)
    @ApiImplicitParams({ @ApiImplicitParam(name = "algId", value = "算法ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "清洗算法管理-更新算法-局部更新", notes = "用提供对象的指定字段，替换原始对象的指定字段。")
    @LogAnnotation(action = LogActionEnum.CLEAR_ALGORITHM, message = "清洗算法管理-更新算法-局部更新")
    public ResponseEntity<?> update(@PathVariable(value = "algId", required = true) String algId, @RequestBody ClearAlgorithmVo clearAlgorithmVo) {
        CleanAlgorithm clearAlgorithm = new CleanAlgorithm();
        BeanUtils.copyProperties(clearAlgorithmVo, clearAlgorithm);
        clearAlgorithm.setAlgId(algId);
        try {
            clearAlgorithmService.update(clearAlgorithm, false);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/cleanAlgorithm", method = RequestMethod.GET)
    @ApiOperation(value = "清洗算法管理-查询算法", notes = "当pageNo，pageSize为空时，默认返回第一页10条数据.")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "algId", value = "算法Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "algName", value = "算法名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "algNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "imageName", value = "镜像名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "imageNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.CLEAR_ALGORITHM, message = "清洗算法管理-查询算法")
    public ResponseEntity<?> search(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "algId", required = false) String algId,
            @RequestParam(value = "algName", required = false) String algName, @RequestParam(value = "algNameLike", required = false) String algNameLike,
            @RequestParam(value = "imageName", required = false) String imageName, @RequestParam(value = "imageNameLike", required = false) String imageNameLike,
            @RequestParam(value = "status", required = false) String status) {
        Page<CleanAlgorithm> rlt = clearAlgorithmService.search(algId, algName, algNameLike, imageName, imageNameLike, status, pageNo, pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(rlt), HttpStatus.OK);
    }

}
