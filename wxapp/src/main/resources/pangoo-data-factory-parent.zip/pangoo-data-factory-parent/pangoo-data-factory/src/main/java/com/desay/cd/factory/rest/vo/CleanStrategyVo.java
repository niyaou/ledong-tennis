package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: CleanStrategyVo
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:37:13
 */
@Data
public class CleanStrategyVo implements Serializable {
    private static final long serialVersionUID = 8597533682669337821L;
    @NotEmpty
    @ApiModelProperty(value = "策略名称")
    @Length(min = 1, max = 50, message = "length长度在[1,50]之间")
    private String strygName;

    @ApiModelProperty(value = "策略描述")
    private String strygDesc;

    @ApiModelProperty(value = "算法Id")
    private String algId;

    @ApiModelProperty(value = "设备Id")
    private String deviceId;

    @ApiModelProperty(value = "优先级Id")
    private String priorityId;

    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", allowableValues = "1,0", example = "1", required = false)
    @Range(min = 0, max = 1, message = "状态必须在[0,1]")
    private Integer isActive = 1;

}
