package com.desay.cd.factory.transaction.impl;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang.StringUtils;

import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.transaction.base.BaseHdfsServiceHandler;
import com.desay.cd.factory.transaction.base.FileElement;

/**
 * hdfs创建文件事务处理类
 * 
 * @author uidq1343
 *
 */
public class HdfsCreateFileHandler extends BaseHdfsServiceHandler {

    private String chunksPath = "";

    /**
     * 上传文件 若失败则回滚
     */
    @Override
    public void doHandleReal(FileElement element) throws CustumException {
        InputStream ins = element.getIns();
        /** 不包含后缀名的文件名 */
        String pathChunks = hdfsFileService.getChunksFolderPath(element.getChunk().getFileId());
        chunksPath = pathChunks;
        if (hdfsFileService.fileExists(pathChunks) && element.getChunk().getCurrent().intValue() == 1) {
            throw new CustumException(ResultCodeEnum.FILE_ALREADY_EXISTED.getCode(), ResultCodeEnum.FILE_ALREADY_EXISTED.getMessage());
        }
        try {
            StringBuffer part = new StringBuffer(element.getChunk().getFileId());
            part.append(String.format("%06d", element.getChunk().getCurrent())).append("_chuck.part");
            hdfsFileService.writeToHdfs(ins, pathChunks, part.toString());
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustumException(ResultCodeEnum.UPLOAD_FILE_FAILED.getCode(), ResultCodeEnum.UPLOAD_FILE_FAILED.getMessage());
        }
    }

    /**
     * 失败回滚 目前无回滚业务
     */
    @Override
    public void rollBackReal(FileElement element) {
        if (!StringUtils.isEmpty(chunksPath)) {
            try {
                hdfsFileService.deleteDirectoryRecursively(chunksPath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

}
