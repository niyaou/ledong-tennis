package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.cd.factory.entity.mysql.TaskAssignStrategy;

/**
 * 
 * @ClassName: ITaskAssignStrategyDao
 * @author: pengdengfu
 * @date: 2019年11月1日 上午11:08:31
 */
public interface ITaskAssignStrategyDao extends JpaRepository<TaskAssignStrategy, Serializable>, JpaSpecificationExecutor<TaskAssignStrategy> {

}
