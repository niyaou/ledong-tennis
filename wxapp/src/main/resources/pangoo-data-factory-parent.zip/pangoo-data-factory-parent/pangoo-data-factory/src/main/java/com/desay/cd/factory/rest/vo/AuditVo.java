package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AuditVo
 * @author: nixuchun
 * @date: 2019年4月17日 下午4:11:27
 */
@ApiModel(value = "文件审核")
public class AuditVo {
    @ApiModelProperty(value = "审核结果    2:通过,4:拒绝", required = true)
    private String status;
    @ApiModelProperty(value = "审核信息", required = true)
    private String auditMessage;
    @ApiModelProperty(value = "版本号，根据返回的数据填入，勿修改，否则审核不通过", required = true)
    private String version;
    
    
    public String getAuditMessage() {
        return auditMessage;
    }
    public void setAuditMessage(String auditMessage) {
        this.auditMessage = auditMessage;
    }
    public String getVersion() {
        return version;
    }
    public void setVersion(String version) {
        this.version = version;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }


}
