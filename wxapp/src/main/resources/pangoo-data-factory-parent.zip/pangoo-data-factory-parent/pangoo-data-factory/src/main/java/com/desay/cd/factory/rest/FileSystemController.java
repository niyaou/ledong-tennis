package com.desay.cd.factory.rest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.rest.vo.AuditVo;
import com.desay.cd.factory.rest.vo.UploadChunkVo;
import com.desay.cd.factory.rest.vo.UploadFileVo;
import com.desay.cd.factory.service.IFileService;
import com.desay.cd.factory.service.ISysUserService;
import com.desay.cd.factory.service.impl.IndexServiceImpl;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 
 * @author uidq1343
 *
 */
@RestController
@RequestMapping
@Api(value = "文件系统管理", tags = "FileSystemController")
public class FileSystemController {

    @Autowired
    private IFileService fileService;

    @Autowired
    private IndexServiceImpl indexService;

    @Autowired
    private ISysUserService userService;

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据id查询文档 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/{id}", method = RequestMethod.GET)
    @ApiImplicitParam(name = "id", value = "ID", required = true, dataType = "string", paramType = "path")
    public Object exploreid(@PathVariable(value = "id", required = true) String id) {
        return new ResponseEntity<Object>(CommonResponse.success(indexService.queryFileInfomation(id)), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-根据参数查询文档 ", notes = "")
    @RequestMapping(value = "/fileSystem/files", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "fileId", value = "文件Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "文件状态(支持多个状态) { 0：未完成，1：待审核，2，待清洗，3：入库，4：拒绝，5：已删除，6：已取消 ，7：预留,91:清洗排队中；92：排队到达；93：成功发送任务,99:清洗失败}", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "productId", value = "产品Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "productName", value = "产品名", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceId", value = "设备名", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceName", value = "设备名", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "fileType", value = "文件类型 {0：视频，1：图片，2，文档，3：音频}", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "minSize", value = "文件大小最小值 Kb", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "maxSize", value = "文件大小最大值 Kb", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "startTime", value = "开始时间  YYYY-MM-DD", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间 YYYY-MM-DD", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query") })
    public Object exploreFileByQueryParams(@RequestParam(value = "fileId", required = false) String fileId, @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "userId", required = false) String userId, @RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime, @RequestParam(value = "productId", required = false) String productId,
            @RequestParam(value = "productName", required = false) String productName, @RequestParam(value = "deviceId", required = false) String deviceId,
            @RequestParam(value = "deviceName", required = false) String deviceName, @RequestParam(value = "fileType", required = false) String fileType,
            @RequestParam(value = "minSize", required = false) String minSize, @RequestParam(value = "maxSize", required = false) String maxSize,
            @RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreFilesByParams(fileId, status, userId, startTime, endTime, productId, productName, deviceId,
                deviceName, fileType, minSize, maxSize, pageNo, pageSize, sortProperties, sortDirection)), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-数据统计（时间范围的总计）", notes = "")
    @RequestMapping(value = "/fileSystem/files/statistics/summary", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "用户id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "productId", value = "产品Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "fileType", value = "文件类型 {0：视频，1：图片，2，文档，3：音频}", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceId", value = "设备名", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "startTime", value = "开始时间  YYYY-MM-DD", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间 YYYY-MM-DD", required = false, dataType = "string", paramType = "query") })
    public Object getFilesTotalByQueryParams(@RequestParam(value = "userId", required = false) String userId, @RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime, @RequestParam(value = "productId", required = false) String productId,
            @RequestParam(value = "fileType", required = false) String fileType, @RequestParam(value = "deviceId", required = false) String deviceId) {
        if (StringUtil.isNotEmpty(startTime) && DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) == null) {
            throw new CustumException(ResultCodeEnum.DATE_PARAMS_ERROR.getCode(), ResultCodeEnum.DATE_PARAMS_ERROR.getMessage());
        }
        if (StringUtil.isNotEmpty(endTime) && DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) == null) {
            throw new CustumException(ResultCodeEnum.DATE_PARAMS_ERROR.getCode(), ResultCodeEnum.DATE_PARAMS_ERROR.getMessage());
        }
        if (StringUtil.isNotEmpty(fileType)) {
            try {
                Integer.valueOf(fileType);
            } catch (NumberFormatException n) {
                throw new CustumException(ResultCodeEnum.FILE_TYPE_ERROR.getCode(), ResultCodeEnum.FILE_TYPE_ERROR.getMessage());

            }
        }
        return new ResponseEntity<Object>(CommonResponse.success(fileService.fileStatisticsByParamsMultiTypes(null, deviceId, productId, fileType, userId, startTime, endTime)),
                HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-数据明细（按天的明细统计） ", notes = "")
    @RequestMapping(value = "/fileSystem/files/statistics/details", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "用户id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "productId", value = "产品Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "fileType", value = "文件类型 {0：视频，1：图片，2，文档，3：音频}", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceId", value = "设备名", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "startTime", value = "开始时间  YYYY-MM-DD", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间 YYYY-MM-DD", required = false, dataType = "string", paramType = "query") })
    public Object getFilesTotalByQueryParamsDetail(@RequestParam(value = "userId", required = false) String userId,
            @RequestParam(value = "startTime", required = false) String startTime, @RequestParam(value = "endTime", required = false) String endTime,
            @RequestParam(value = "productId", required = false) String productId, @RequestParam(value = "fileType", required = false) String fileType,
            @RequestParam(value = "deviceId", required = false) String deviceId) {

        if (StringUtil.isNotEmpty(startTime) && DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE) == null) {
            throw new CustumException(ResultCodeEnum.DATE_PARAMS_ERROR.getCode(), ResultCodeEnum.DATE_PARAMS_ERROR.getMessage());
        }
        if (StringUtil.isNotEmpty(endTime) && DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE) == null) {
            throw new CustumException(ResultCodeEnum.DATE_PARAMS_ERROR.getCode(), ResultCodeEnum.DATE_PARAMS_ERROR.getMessage());
        }
        if (StringUtil.isNotEmpty(fileType)) {
            try {
                Integer.valueOf(fileType);
            } catch (NumberFormatException n) {
                throw new CustumException(ResultCodeEnum.FILE_TYPE_ERROR.getCode(), ResultCodeEnum.FILE_TYPE_ERROR.getMessage());

            }
        }

        return new ResponseEntity<Object>(
                CommonResponse.success(fileService.fileStatisticsByParamsMultiTypiesDetails(null, deviceId, productId, fileType, userId, startTime, endTime)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据时间范围查询文档 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/timeRange", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "startTime", value = "开始时间  YYYY-MM-DD", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "endTime", value = "结束时间 YYYY-MM-DD", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreFileByTimeRange(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "startTime", required = true) String startTime, @RequestParam(value = "endTime", required = true) String endTime,
            @RequestParam(value = "userId", required = true) String userId) {
        startTime = DateUtil.getTimeStamp(startTime, DateUtil.FORMAT_DATE);
        endTime = DateUtil.getTimeStamp(endTime, DateUtil.FORMAT_DATE);
        return new ResponseEntity<Object>(CommonResponse.success(fileService.queryFileInfoByTimeRange(startTime, endTime, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据文件状态查询文档 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/status/{status}", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "status", value = "文件状态 { 0：未完成，1：待审核，2，待清洗，3：入库，4：拒绝，5：已删除，6：已取消 ，7：预留}", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreFileByStatus(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @PathVariable(value = "status", required = true) String status) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreFilesByStatus(Integer.parseInt(status), pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-查询待审核文件 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/unVerifiedFiles", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreUnVerifiedFile(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreFilesByStatus(1, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据用户名查询文档 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/userId/{userId}", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "用户id", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreFileByUserId(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @PathVariable(value = "userId", required = true) String userId) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreFilesByUserId(userId, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据产品名查询文档 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/productName/", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "productName", value = "产品名", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreFileByProductName(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "productName", required = true) String productName) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreFilesByProductName(productName, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据设备名查询文档", notes = "")
    @RequestMapping(value = "/fileSystem/files/deviceName/", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceName", value = "设备名", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreFileByDeviceName(@RequestParam(value = "deviceName", required = true) String deviceName, @RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreFilesByDeviceName(deviceName, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据文件类型查询文档", notes = "")
    @RequestMapping(value = "/fileSystem/files/fileType/{fileType}", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "fileType", value = "文件类型 {0：视频，1：图片，2，文档，3：音频}", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreFileByFileType(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @PathVariable(value = "fileType", required = true) int fileType) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreFilesByFileType(fileType, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据文件大小查询文档", notes = "")
    @RequestMapping(value = "/fileSystem/files/fileSize/", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "minSize", value = "文件大小最小值 Kb", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "maxSize", value = "文件大小最大值 Kb", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreFileByFileSize(@RequestParam(value = "minSize", required = true) String minSize, @RequestParam(value = "maxSize", required = true) String maxSize,
            @RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize) {
        return new ResponseEntity<Object>(CommonResponse.success(fileService.queryFileInfomationBySize(minSize, maxSize, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-查看未完成的断点续传任务 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/chunks", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public Object exploreChunksLog(HttpServletRequest request, @RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize) {
        String userId = getUserId(request);
        return new ResponseEntity<Object>(CommonResponse.success(fileService.exploreChunksLog(userId, pageNo, pageSize)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-根据id查询文档 ", notes = "")
    @RequestMapping(value = "/mangement/file/explore/test", method = RequestMethod.GET)
    public Object test(HttpServletRequest request, @RequestParam(value = "starttime", required = false) String starttime,
            @RequestParam(value = "endtime", required = false) String endtime) {
        return "_black";
    }

    @ApiOperation(value = "文件管理-删除文件 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/{id}", method = RequestMethod.DELETE)
    @ApiImplicitParam(name = "id", value = "文件ID", required = true, dataType = "string", paramType = "path")
    public Object deleteFiles(HttpServletRequest request, @PathVariable(value = "id", required = true) String id) {
        String userId = getUserId(request);
        String ip = getIpAddress(request);
        return new ResponseEntity<Object>(CommonResponse.success(fileService.deleteFiles(userId, ip, id)), HttpStatus.OK);
    }

    @ApiIgnore
    @ApiOperation(value = "文件管理-取消未完成的文件上传任务 ", notes = "")
    @RequestMapping(value = "/fileSystem/files/task/{id}", method = RequestMethod.DELETE)
    @ApiImplicitParam(name = "id", value = "文件ID", required = true, dataType = "string", paramType = "path")
    public Object deleteFileTasks(HttpServletRequest request, @PathVariable(value = "id", required = true) String id) {
        String userId = getUserId(request);
        String ip = getIpAddress(request);
        return new ResponseEntity<Object>(CommonResponse.success(fileService.cancelUploadTask(userId, ip, id)), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-创建文件档案，返回文件唯一标识id", notes = "")
    @RequestMapping(value = "/fileSystem/files/info", method = RequestMethod.POST)
    public Object createFileDocument(HttpServletRequest request, @RequestBody UploadFileVo vo) {
        String userId = getUserId(request);
        String ip = getIpAddress(request);
        if (StringUtil.isEmpty(vo.getFileName())) {
            throw new CustumException(ResultCodeEnum.FILENAME_NOT_EMPTY.getCode(), ResultCodeEnum.FILENAME_NOT_EMPTY.getMessage());
        } else if (!vo.getFileName().contains(Constanst.POINT)) {
            throw new CustumException(ResultCodeEnum.PREFIX_NOT_EMPTY.getCode(), ResultCodeEnum.PREFIX_NOT_EMPTY.getMessage());
        }
        if (StringUtil.isEmpty(vo.getDeviceId()) || StringUtil.isEmpty(vo.getDeviceName())) {
            throw new CustumException(ResultCodeEnum.DEVICE_NOT_EMPTY.getCode(), ResultCodeEnum.DEVICE_NOT_EMPTY.getMessage());
        }
        return new ResponseEntity<Object>(CommonResponse.success(fileService.createFileDocument(userId, ip, vo)), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-根据文件id修改文件档案信息", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "fileId", value = "文件ID", required = true, dataType = "string", paramType = "path"), })
    @RequestMapping(value = "/fileSystem/files/info/{fileId}", method = RequestMethod.POST)
    public Object updateFileDocument(HttpServletRequest request, @PathVariable(value = "fileId", required = true) String fileId, @RequestBody UploadFileVo vo) {
        String userId = getUserId(request);
        String ip = getIpAddress(request);
        if (StringUtil.isEmpty(vo.getDeviceId()) || StringUtil.isEmpty(vo.getDeviceName())) {
            throw new CustumException(ResultCodeEnum.DEVICE_NOT_EMPTY.getCode(), ResultCodeEnum.DEVICE_NOT_EMPTY.getMessage());
        }
        if (vo.getVersion() < 1) {
            throw new CustumException(ResultCodeEnum.FILE_ALREADY_EDITED.getCode(), ResultCodeEnum.FILE_ALREADY_EDITED.getMessage());
        }
        return new ResponseEntity<Object>(CommonResponse.success(fileService.updateFileDocument(userId, ip, fileId, vo, vo.getVersion())), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-文件断点续传  将文件按照50MB的大小分割成小文件，依次上传", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "chunks", value = "文件分块信息:\r\n"
            + "      {\r\n \"fileId\":  文件id(文件若已经上传一部分，则在此填入文件id，文件若从未上传，则先调用其他接口生成文件id),  \"size\":  文件大小(以byte为单位的长整型),\r\n  \"chunks\": 文件总块数  ,\"current\": 当前块数,从1开始计算 }", required = true, dataType = "string", paramType = "query"), })
    @RequestMapping(value = "/fileSystem/files", method = RequestMethod.POST, headers = "content-type=multipart/form-data")
    public Object uploadChunkFile(@ApiParam(value = "将分块文件以此参数传入", required = true) MultipartFile file, HttpServletRequest request,
            @RequestParam(value = "chunks") String chunkvo) {
        String userId = getUserId(request);
        String ip = getIpAddress(request);
        UploadChunkVo chunks = JSON.parseObject(chunkvo, UploadChunkVo.class);

        if (chunks == null) {
            throw new CustumException(ResultCodeEnum.FILE_CHUNKS__ERROR.getCode(), ResultCodeEnum.FILE_CHUNKS__ERROR.getMessage());
        } else if (chunks.getCurrent() == null) {
            throw new CustumException(ResultCodeEnum.CURRENT_NOT_EMPTY.getCode(), ResultCodeEnum.CURRENT_NOT_EMPTY.getMessage());
        } else if (chunks.getCurrent() < 1) {
            throw new CustumException(ResultCodeEnum.FILE_CHUNKS__ERROR.getCode(), ResultCodeEnum.FILE_CHUNKS__ERROR.getMessage());
        } else if (chunks.getSize() == null || chunks.getSize() <= 0) {
            throw new CustumException(ResultCodeEnum.SIZE_NOT_EMPTY.getCode(), ResultCodeEnum.SIZE_NOT_EMPTY.getMessage());
        } else if (chunks.getChunks() == null) {
            throw new CustumException(ResultCodeEnum.CHUNKS_NOT_EMPTY.getCode(), ResultCodeEnum.CHUNKS_NOT_EMPTY.getMessage());
        } else if (chunks.getCurrent() > chunks.getChunks()) {
            throw new CustumException(ResultCodeEnum.UPLOAD_FILE_FAILED.getCode(), ResultCodeEnum.UPLOAD_FILE_FAILED.getMessage());
        }

        return new ResponseEntity<Object>(CommonResponse.success(fileService.saveChunksFile(userId, ip, chunks, file)), HttpStatus.OK);
    }

    @ApiOperation(value = "文件管理-审核文件", notes = "")
    @RequestMapping(value = "/fileSystem/files/audit/{fileId}", method = RequestMethod.POST)
    @ApiImplicitParam(name = "fileId", value = "文件id", required = true, dataType = "string", paramType = "path")
    public Object verifiedFile(HttpServletRequest request, @PathVariable(value = "fileId", required = true) String fileId, @RequestBody AuditVo vo) {
        String userId = getUserId(request);
        String ip = getIpAddress(request);
        if (StringUtil.isEmpty(vo.getAuditMessage())) {
            throw new CustumException(ResultCodeEnum.AUDIT_MESSAGE_MUST_NOT_BLANK.getCode(), ResultCodeEnum.AUDIT_MESSAGE_MUST_NOT_BLANK.getMessage());
        }

        try {
            FileStatusEnum fileStatus = FileStatusEnum.getStatusByCode(Integer.valueOf(vo.getStatus()));
            boolean checkStatus = fileStatus != null && (FileStatusEnum.PENDING_TO_CLEANED.equals(fileStatus) || FileStatusEnum.DENIED.equals(fileStatus));
            if (checkStatus) {
                long versionL = Long.parseLong(vo.getVersion());
                return new ResponseEntity<Object>(CommonResponse.success(fileService.verifiedFiles(userId, ip, fileId, fileStatus, versionL, vo.getAuditMessage())), HttpStatus.OK);
            } else {
                throw new CustumException(ResultCodeEnum.AUDIT_STATUS_PARSE_ERROR.getCode(), ResultCodeEnum.AUDIT_STATUS_PARSE_ERROR.getMessage());
            }
        } catch (NumberFormatException e) {
            throw new CustumException(ResultCodeEnum.AUDIT_STATUS_PARSE_ERROR.getCode(), ResultCodeEnum.AUDIT_STATUS_PARSE_ERROR.getMessage());

        }

    }

    /**
     * 获取userId
     * 
     * @param request
     * @return
     */
    private String getUserId(HttpServletRequest request) {
        Object token = request.getHeader("access_token");
        TokenDto tokenDto = null;
        if (null != token) {
            tokenDto = (TokenDto) userService.tokenAuthorize((String) token);
            if (null != tokenDto) {
                return tokenDto.cid;
            }
        }
        return null;
    }

    /**
     * 获取user ip
     * 
     * @param request
     * @return
     */
    private String getIpAddress(HttpServletRequest request) {
        return request.getRemoteAddr();
    }

}
