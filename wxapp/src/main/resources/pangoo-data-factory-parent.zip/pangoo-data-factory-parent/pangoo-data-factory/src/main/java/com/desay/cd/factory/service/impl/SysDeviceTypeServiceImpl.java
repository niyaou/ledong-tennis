package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysDeviceTypeDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysDevice;
import com.desay.cd.factory.entity.mysql.SysDeviceType;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.ISysDeviceService;
import com.desay.cd.factory.service.ISysDeviceTypeService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: SysDeviceTypeServiceImpl
 * @author: pengdengfu
 * @date: 2019年4月16日 下午4:51:04
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class SysDeviceTypeServiceImpl implements ISysDeviceTypeService {
    @Autowired
    private ISysDeviceTypeDao sysDeviceTypeDao;
    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    ISysDeviceService deviceService;

    @Override
    public SysDeviceType addDeviceType(String deviceTypeName, String parentDeviceTypeId, Set<String> childrenNames) {
        // 检查deviceTypeName
        SysDeviceType sysDeviceType = checkDeviceTypeName(deviceTypeName, parentDeviceTypeId, true, null);

        // 添加子节点
        Set<SysDeviceType> newChildren = addChildernNames(parentDeviceTypeId, childrenNames, sysDeviceType);
        SysDeviceType saveAndFlush = null;
        try {
            saveAndFlush = sysDeviceTypeDao.saveAndFlush(sysDeviceType);
            if (childrenNames != null && childrenNames.size() > 0) {
                sysDeviceTypeDao.save(newChildren);
            }
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getMessage());
        }
        return saveAndFlush;
    }

    public void deleteDeviceType2(String deviceTypeId) {
        // 检查deviceTypeId
        SysDeviceType sysDeviceType = checkDeviceTypeId(deviceTypeId);
        // 如果存在子节点
        if (CollectionUtils.isNotEmpty(sysDeviceType.getChildren())) {
            List<SysDeviceType> list = sysDeviceTypeDao.findByParentAndIsActive(sysDeviceType, Constanst.ACTIVE_STATUS_1);
            // 并且子节点有可用的状态
            if (CollectionUtils.isNotEmpty(list)) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_HAVE_CHILD.getCode(), ResultCodeEnum.DEVICE_TYPE_HAVE_CHILD.getMessage());
            }
        }
        // 更新状态
        updateStatus(Constanst.ACTIVE_STATUS_0, sysDeviceType);
        try {
            sysDeviceTypeDao.saveAndFlush(sysDeviceType);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public void deleteDeviceType(String deviceTypeId) {
        // 检查deviceTypeId
        SysDeviceType sysDeviceType = checkDeviceTypeId(deviceTypeId);
        Page<SysDevice> listDevice = deviceService.listDevice(null, null, null, null, null, deviceTypeId, null, null, null, null);
        Map<String, Long> referencedCount = new HashMap<>(2);
        if (listDevice != null && listDevice.getContent().size() > 0) {
            referencedCount.put("referencedDevicesCount", listDevice.getTotalElements());
        }
        Long deleteCheckChild = deleteCheck(sysDeviceType);
        if (deleteCheckChild > 0) {
            referencedCount.put("referencedChildrenDevicesCount", deleteCheckChild);
        }
        if (!referencedCount.isEmpty()) {
            throw new CustumException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getCode(), ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage(), referencedCount);
        }
        try {
            sysDeviceTypeDao.delete(sysDeviceType);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private Long deleteCheck(SysDeviceType sysDeviceType) {
        Long referencedChildrenCount = 0L;
        // 确定是否有被引用
        Page<SysDevice> listDevice = deviceService.listDevice(null, null, null, null, null, sysDeviceType.getDeviceTypeId(), null, null, null, null);
        if (listDevice != null && listDevice.getContent().size() > 0) {
            referencedChildrenCount = referencedChildrenCount + listDevice.getTotalElements();
        }
        // 1、有子节点
        // 2、子节点被设备引用
        Set<SysDeviceType> children = sysDeviceType.getChildren();
        if (children.size() <= 0) {
            return referencedChildrenCount;
        }
        for (SysDeviceType deviceType : children) {
            referencedChildrenCount = referencedChildrenCount + deleteCheck(deviceType);
        }
        return referencedChildrenCount;

    }

    /**
     * 递归更新节点状态
     * 
     * @param sysDeviceType
     * @param isActive
     */
    private void updateDeviceTypeStatus(SysDeviceType sysDeviceType, String isActive) {
        sysDeviceType.setIsActive(isActive);
        if (sysDeviceType.getChildren() == null || sysDeviceType.getChildren().size() <= 0) {
            return;
        }
        Set<SysDeviceType> children = sysDeviceType.getChildren();
        for (SysDeviceType child : children) {
            child.setIsActive(isActive);
            updateDeviceTypeStatus(child, isActive);
        }
    }

    @Override
    public void updateDeviceType(String deviceTypeId, String deviceTypeName, Set<String> childrenNames, String status, String parentId) {
        // 检查deviceTypeId
        SysDeviceType sysDeviceType = checkDeviceTypeId(deviceTypeId);
        SysDeviceType parent = sysDeviceType.getParent();
        String parentDeviceTypeId = "";
        if (parent != null) {
            parentDeviceTypeId = parent.getDeviceTypeId();
        }
        // 检查deviceTypeName
        checkDeviceTypeName(deviceTypeName, parentDeviceTypeId, false, deviceTypeId);

        if (StringUtils.isNotEmpty(deviceTypeName)) {
            sysDeviceType.setDeviceTypeName(deviceTypeName);
        }
        // 添加子节点
        Set<SysDeviceType> newChildren = addChildernNames(deviceTypeId, childrenNames, sysDeviceType);
        // 更新状态
        updateStatus(status, sysDeviceType);
        if (StringUtils.isNotEmpty(parentId)) {
            SysDeviceType parentChange = sysDeviceTypeDao.findOne(parentId);
            if (parentChange == null) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_PARENT_ID_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_PARENT_ID_NOT_EXISTED.getMessage());
            } else {
                sysDeviceType.setParent(parentChange);
            }
        }
        try {
            if (childrenNames != null && childrenNames.size() > 0) {
                sysDeviceTypeDao.save(newChildren);
            }
            sysDeviceTypeDao.saveAndFlush(sysDeviceType);

        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getMessage());
        }

    }

    /**
     * 更新状态
     * 
     * @param status
     * @param sysDeviceType
     */
    private void updateStatus(String status, SysDeviceType sysDeviceType) {
        if (status != null) {
            ControllerCommonUtils.checkStatus(status);
            updateDeviceTypeStatus(sysDeviceType, status);
        }
    }

    /**
     * 添加子节点
     * 
     * @param deviceTypeId
     * @param childrenNames
     * @param sysDeviceType
     * @return
     */
    private Set<SysDeviceType> addChildernNames(String deviceTypeId, Set<String> childrenNames, SysDeviceType sysDeviceType) {
        if (sysDeviceType == null || childrenNames == null) {
            return null;
        }
        Set<SysDeviceType> newChildren = new HashSet<>(childrenNames.size());
        if (childrenNames != null && childrenNames.size() > 0) {
            Set<SysDeviceType> children = sysDeviceType.getChildren();
            if (children == null) {
                children = new HashSet<>(childrenNames.size());
            }
            for (String childrenName : childrenNames) {
                try {
                    SysDeviceType child = checkDeviceTypeName(childrenName, deviceTypeId, false, null);
                    if (child != null) {
                        child.setParent(sysDeviceType);
                        children.add(child);
                        newChildren.add(child);
                    }
                } catch (CustumException e) {
                    continue;
                }
            }
            sysDeviceType.setChildren(children);
        }

        return newChildren;
    }

    @Override
    public List<SysDeviceType> getDeviceTypes(String deviceTypeId, String status, List<String> properties, String sortDirection) {
        Pageable pageable = ControllerCommonUtils.getPager(Integer.toString(Constanst.FIRST_PAGE_NO), Integer.toString(Integer.MAX_VALUE), properties, sortDirection,
                "deviceTypeName");
        Specification<SysDeviceType> specification = new Specification<SysDeviceType>() {
            @Override
            public Predicate toPredicate(Root<SysDeviceType> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(deviceTypeId)) {
                    predicates.add(cb.equal(root.get("deviceTypeId"), deviceTypeId));
                } else {
                    predicates.add(cb.isNull(root.get("parent")));
                }
                if (StringUtils.isNotEmpty(status)) {
                    ControllerCommonUtils.checkStatus(status);
                    predicates.add(cb.equal(root.get("isActive"), status));
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        List<SysDeviceType> list = sysDeviceTypeDao.findAll(specification, pageable).getContent();
        if (StringUtils.isNotEmpty(status)) {
            for (SysDeviceType sysDeviceType : list) {
                getDeviceTypeStatus(sysDeviceType, status);
            }
        }
        return list;
    }

    /**
     * 过滤不符合状态的数据
     * 
     * @param sysDeviceType
     * @param isActive
     */
    private void getDeviceTypeStatus(SysDeviceType sysDeviceType, String isActive) {
        entityManager.detach(sysDeviceType);
        Set<SysDeviceType> children = sysDeviceType.getChildren();
        if (sysDeviceType.getChildren() == null || sysDeviceType.getChildren().size() <= 0) {
            return;
        }
        Iterator<SysDeviceType> iterator = children.iterator();
        while (iterator.hasNext()) {
            SysDeviceType child = (SysDeviceType) iterator.next();
            if (!isActive.equals(child.getIsActive())) {
                iterator.remove();
            } else {
                getDeviceTypeStatus(child, isActive);
            }
        }
    }

    /**
     * 检查deviceTypeId
     * 
     * @param deviceTypeId
     * @return
     */
    private SysDeviceType checkDeviceTypeId(String deviceTypeId) {
        if (StringUtils.isEmpty(deviceTypeId)) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.DEVICE_TYPE_ID_CANNOT_NULL.getMessage());
        }
        SysDeviceType sysDeviceType = sysDeviceTypeDao.findOne(deviceTypeId);
        if (sysDeviceType == null) {
            throw new CustumException(ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_ID_NOT_EXISTED.getMessage());
        }
        return sysDeviceType;
    }

    /**
     * 检查deviceTypeName
     * 
     * @param deviceTypeName
     * @param parentDeviceTypeId
     * @param checkLength
     * @return
     */
    private SysDeviceType checkDeviceTypeName(String deviceTypeName, String parentDeviceTypeId, boolean checkLength, String deviceTypeId) {
        if (checkLength) {
            if (StringUtils.isEmpty(deviceTypeName)) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_CONNOT_NULL.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_CONNOT_NULL.getMessage());
            }
            if (deviceTypeName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_TOO_LONG.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_TOO_LONG.getMessage());
            }
        } else {
            if (StringUtils.isNotEmpty(deviceTypeName) && deviceTypeName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_TOO_LONG.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_TOO_LONG.getMessage());
            }
        }
        if (StringUtils.isEmpty(deviceTypeName)) {
            return null;
        }
        // 特殊字符转义
        if (StringUtils.isNotEmpty(deviceTypeName)) {
            deviceTypeName = deviceTypeName.replaceAll("%", "\\\\%");
            deviceTypeName = deviceTypeName.replaceAll("_", "\\\\_");
        }
        final String deviceTypeNameTmp = deviceTypeName;
        SysDeviceType sysDeviceType = new SysDeviceType();
        sysDeviceType.setDeviceTypeName(deviceTypeName);
        // 判断上级数据是否存在
        if (StringUtils.isNotEmpty(parentDeviceTypeId)) {
            SysDeviceType findParent = sysDeviceTypeDao.findOne(parentDeviceTypeId);
            if (findParent != null) {
                sysDeviceType.setParent(findParent);
            } else {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_PARENT_ID_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_PARENT_ID_NOT_EXISTED.getMessage());
            }
        }
        Specification<SysDeviceType> specification = new Specification<SysDeviceType>() {
            @Override
            public Predicate toPredicate(Root<SysDeviceType> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(deviceTypeNameTmp)) {
                    predicates.add(cb.equal(root.get("deviceTypeName"), deviceTypeNameTmp));
                }
                if (StringUtils.isNotEmpty(parentDeviceTypeId)) {
                    Join<SysDeviceType, SysDeviceType> join = root.join("parent", JoinType.INNER);
                    predicates.add(cb.equal(join.get("deviceTypeId"), parentDeviceTypeId));
                }
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        SysDeviceType existed = sysDeviceTypeDao.findOne(specification);
        // 添加
        if (StringUtils.isEmpty(deviceTypeId) && existed != null) {
            if (Constanst.ACTIVE_STATUS_1.equals(existed.getIsActive())) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getMessage());
            } else {
                throw new CustumException(ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getCode(), ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getMessage(), existed);
            }

        }
        if (StringUtils.isNotEmpty(deviceTypeId) && existed != null && deviceTypeId != existed.getDeviceTypeId()) {
            if (Constanst.ACTIVE_STATUS_1.equals(existed.getIsActive())) {
                throw new CustumException(ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getCode(), ResultCodeEnum.DEVICE_TYPE_NAME_EXISTED.getMessage());
            } else {
                throw new CustumException(ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getCode(), ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getMessage(), existed);
            }
        }
        return sysDeviceType;
    }

}
