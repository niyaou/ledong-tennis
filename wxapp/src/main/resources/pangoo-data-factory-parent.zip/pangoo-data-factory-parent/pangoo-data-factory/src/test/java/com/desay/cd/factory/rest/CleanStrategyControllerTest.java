package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ICleanStrategyDao;
import com.desay.cd.factory.entity.mysql.CleanStrategy;
import com.desay.cd.factory.rest.vo.CleanStrategyVo;

/**
 * ClearAlgorithmControllerTest
 * 
 * @author pengdengfu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class CleanStrategyControllerTest {

    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    private ICleanStrategyDao cleanStrategyDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testClearAlgorithm() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        CleanStrategyVo cleanStrategyVo = new CleanStrategyVo();

        cleanStrategyVo.setStrygName("test_strygName");
        cleanStrategyVo.setStrygDesc("test_strygDesc");
        String requestJson = JSONObject.toJSONString(cleanStrategyVo);

        // 添加
        mvc.perform(post("/management/cleanStrategy").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        // 更新
        CleanStrategy cleanStrategy = new CleanStrategy();
        cleanStrategy.setStrygName("test_strygName");
        Example<CleanStrategy> example = Example.of(cleanStrategy);
        CleanStrategy findOne = cleanStrategyDao.findOne(example);

        cleanStrategy.setStrygName("test_strygName_update");
        cleanStrategy.setStrygDesc("test_strygDesc_update");
        requestJson = JSONObject.toJSONString(cleanStrategy);
        mvc.perform(put("/management/cleanStrategy/" + findOne.getStrgyId()).contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        // 查询
        params.clear();
        params.add("pageNo", "1");
        params.add("pageSize", "1");
        MvcResult mvcResult = mvc.perform(get("/management/cleanStrategy")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 删除
        params.clear();
        mvc.perform(delete("/management/cleanStrategy/" + findOne.getStrgyId()).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
    }
}
