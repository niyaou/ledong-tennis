package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.cd.factory.entity.mysql.SysProduct;

/**
 * 
 * @ClassName: ISysProductDao
 * @author: pengdengfu
 * @date: 2019年4月9日 上午8:58:52
 */
public interface ISysProductDao extends JpaRepository<SysProduct, Serializable>, JpaSpecificationExecutor<SysProduct> {

    /**
     * 根据名称查询
     * 
     * @param productName
     * @return
     */
    SysProduct findByProductName(String productName);
}
