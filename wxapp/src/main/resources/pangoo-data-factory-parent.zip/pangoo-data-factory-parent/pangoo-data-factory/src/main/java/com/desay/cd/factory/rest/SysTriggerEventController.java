package com.desay.cd.factory.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysTriggerEvent;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddNoticeEventNameVo;
import com.desay.cd.factory.service.ISysTriggerEventService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/***
 * 通知事件管理
 * 
 * @author pengdengfu
 *
 */
@RestController
@Api(value = "通知事件管理", tags = "SysTriggerEventController")
@ApiIgnore
public class SysTriggerEventController {
    @SuppressWarnings("unused")
    private static final Logger logger = LoggerFactory.getLogger(SysTriggerEventController.class);
    @Autowired
    private ISysTriggerEventService sysTriggerEventService;

    /**
     * 添加通知事件
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/noticeEvents/backup", method = RequestMethod.POST)
    @ApiIgnore
    @ApiOperation(value = "添加通知事件", notes = "通知事件 {\n" + "noticeEventName (string): 通知事件名称(长度<=30)\n" + "}")
    @ApiImplicitParams({ @ApiImplicitParam(name = "noticeEventName", value = "通知事件名称(长度<=30)", required = true, dataType = "string", paramType = "form") })
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "添加通知事件")
    public ResponseEntity<?> addNoticeEvent(@RequestParam(value = "noticeEventName", required = true) String noticeEventName) {
        SysTriggerEvent sysTriggerEvent = sysTriggerEventService.addNoticeEvent(noticeEventName);
        return new ResponseEntity<Object>(CommonResponse.success(sysTriggerEvent.getEventId()), HttpStatus.OK);
    }

    /**
     * 添加通知事件
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/noticeEvents", method = RequestMethod.POST)
    @ApiOperation(value = "添加通知事件", notes = "通知事件 {\n" + "noticeEventName (string): 通知事件名称(长度<=30)\n" + "}")
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "添加通知事件(json请求)")
    public ResponseEntity<?> addNoticeEvent(@RequestBody AddNoticeEventNameVo addNoticeEventName) {
        SysTriggerEvent sysTriggerEvent = sysTriggerEventService.addNoticeEvent(addNoticeEventName.getNoticeEventName());
        return new ResponseEntity<Object>(CommonResponse.success(sysTriggerEvent.getEventId()), HttpStatus.OK);
    }

    /**
     * 删除角色
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/noticeEvents/{noticeEventId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除通知事件", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "noticeEventId", value = "通知事件ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "删除通知事件")
    public ResponseEntity<?> deleteNoticeEvent(@PathVariable(value = "noticeEventId", required = true) String noticeEventId) {
        sysTriggerEventService.deleteNoticeEvent(noticeEventId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取通知事件
     * 
     * @return
     */
    @RequestMapping(value = "/management/noticeEvents", method = RequestMethod.GET)
    @ApiOperation(value = "获取通知事件", notes = "")
    @LogAnnotation(action = LogActionEnum.NOTICE, message = "获取通知事件")
    public ResponseEntity<?> deleteNoticeEvent() {
        List<SysTriggerEvent> sysTriggerEvents = sysTriggerEventService.getSysTriggerEvents();
        return new ResponseEntity<Object>(CommonResponse.success(sysTriggerEvents), HttpStatus.OK);
    }
}
