package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddProductVo
 * @author: pengdengfu
 * @date: 2019年4月9日 上午10:09:32
 */
public class AddProductVo {
    @ApiModelProperty(value = "产品名称(0<size<=30)", required = true)
    private String productName;
    @ApiModelProperty(value = "产品说明", required = false)
    private String productDesc;
    @ApiModelProperty(value = "客户名称(0<size<=30)", required = false)
    private String customName;
    @ApiModelProperty(value = "设备Id列表,忽略不存在的Id", required = false)
    private Set<String> deviceIds;
    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", example = "1", required = false)
    private String status;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public Set<String> getDeviceIds() {
        return deviceIds;
    }

    public void setDeviceIds(Set<String> deviceIds) {
        this.deviceIds = deviceIds;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return " [productName=" + productName + ", productDesc=" + productDesc + ", customName=" + customName + ", deviceIds=" + deviceIds + ", status=" + status + "]";
    }

}
