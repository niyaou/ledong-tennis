package com.desay.cd.factory.config;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.desay.cd.factory.utils.DateUtil;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.SizeAndTimeBasedFNATP;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;
import ch.qos.logback.core.util.FileSize;

/**
 * 操作日志切面
 * 
 * @author uidq1163
 *
 */
@Component
public class LogFile {
    private String fileDir;
    public static Logger loggerFile;

    public LogFile(@Value("${operation.log.filedir}") String fileDir) {
        this.fileDir = fileDir;
        // 文件日志初始化
        LogFile.loggerFile = loggerFactory();
    }

    /**
     * 
     * @param object
     *            日志内容
     */
    public static void writeLogger(Object object) {
        loggerFile.info(JSON.toJSONStringWithDateFormat(object, DateUtil.FORMAT_DATE_TIME,
                SerializerFeature.WriteMapNullValue));
    }

    /**
     * 写日志内容
     * 
     * @param object
     * @param logger
     */
    private Logger loggerFactory() {
        Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
        LoggerContext loggerContext = logger.getLoggerContext();
        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(loggerContext);
        encoder.setPattern("%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %logger{50} - %msg%n");
        encoder.start();

        RollingFileAppender<ILoggingEvent> appender = new RollingFileAppender<ILoggingEvent>();
        appender.setContext(loggerContext);
        TimeBasedRollingPolicy<Object> rollingPolicyBase = new TimeBasedRollingPolicy<>();
        rollingPolicyBase.setContext(loggerContext);
        rollingPolicyBase.setParent(appender);
        rollingPolicyBase
                .setFileNamePattern((String.format("%s/file/%s", fileDir, "fileOpt") + ".%d{yyyy-MM-dd}.%i.log"));
        SizeAndTimeBasedFNATP<Object> sizeAndTimeBasedFNATP = new SizeAndTimeBasedFNATP<Object>();
        // 单个文件最大100M
        FileSize maxFileSize = new FileSize(100 * FileSize.MB_COEFFICIENT);
        sizeAndTimeBasedFNATP.setMaxFileSize(maxFileSize);
        rollingPolicyBase.setTimeBasedFileNamingAndTriggeringPolicy(sizeAndTimeBasedFNATP);
        // 最大保存7天日志
        rollingPolicyBase.setMaxHistory(7);
        // 最大日志：20GB
        FileSize totalSizeCap = new FileSize(20 * FileSize.GB_COEFFICIENT);
        rollingPolicyBase.setTotalSizeCap(totalSizeCap);
        rollingPolicyBase.start();

        appender.setEncoder(encoder);
        appender.setRollingPolicy(rollingPolicyBase);
        appender.start();
        logger.setAdditive(false);
        logger.addAppender(appender);
        return logger;
    }
}
