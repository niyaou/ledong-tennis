/**
 * @author: create by pengdengfu
 * @version: v1.0
 * @description: com.desay.cd.factory.service.impl
 * @date:2019年12月4日
 */
package com.desay.cd.factory.service.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;
import org.storage.engine.common.shell.SshClient;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.mysql.SysEnvConfig;
import com.desay.cd.factory.service.IClearAlgorithmMachineService;
import com.desay.cd.factory.service.ISysEnvConfigService;

import ch.ethz.ssh2.Connection;

/**
 * @author uidq1070
 *
 */
@Service
public class ClearAlgorithmMachineServiceImpl implements IClearAlgorithmMachineService {
    @Autowired
    private ISysEnvConfigService sysEnvConfigService;

    @Value("${dcs.script.path}")
    private String dcsScript;

    @Value("${dcs.script.servers}")
    private String[] scriptServers;

    @Value("${dcs.script.port}")
    private String port;

    @Value("${dcs.script.userName}")
    private String scriptUserName;

    @Value("${dcs.script.password}")
    private String scriptpassword;

    private static final String CMD_GET_RESOURCE = "python {0} ''{1}''";

    @Override
    public Object search(String ip, String hostName, String hostNameLike) {
        Page<SysEnvConfig> algorithmMachines = sysEnvConfigService.search(null, "1", ip, hostName, hostNameLike, null, Integer.MAX_VALUE, null);
        /*
         * [{ "ip": "", "port": "", "userName": "", "password": "" }]
         */
        List<Map<String, String>> params = new ArrayList<Map<String, String>>(16);
        for (SysEnvConfig sysEnvConfig : algorithmMachines) {
            Map<String, String> param = new HashMap<String, String>(4);
            param.put("ip", sysEnvConfig.getIp());
            param.put("port", sysEnvConfig.getSshPort() == null ? "22" : Integer.toString(sysEnvConfig.getSshPort()));
            param.put("userName", sysEnvConfig.getUserName());
            param.put("password", sysEnvConfig.getPassword());

            params.add(param);
        }
        String execmdRlt = "{}";
        if (params.size() > 0) {
            Random df = new Random();
            int nextInt = df.nextInt(scriptServers.length);
            String formatCmd = MessageFormat.format(CMD_GET_RESOURCE, dcsScript + "get_res_dls.py", JSON.toJSONString(params));
            Connection connection = null;
            try {
                connection = SshClient.login(scriptServers[nextInt], Integer.parseInt(port), scriptUserName, scriptpassword);
            } catch (BusinessException e) {
                nextInt = df.nextInt(scriptServers.length);
                connection = SshClient.login(scriptServers[nextInt], Integer.parseInt(port), scriptUserName, scriptpassword);
            }
            execmdRlt = SshClient.execmd(connection, formatCmd, true);
        }
        return JSONObject.parse(execmdRlt);
    }

}
