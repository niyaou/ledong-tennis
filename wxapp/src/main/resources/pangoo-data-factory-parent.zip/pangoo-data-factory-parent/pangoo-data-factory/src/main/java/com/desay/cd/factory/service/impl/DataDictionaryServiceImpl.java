package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.dao.IDataDictionaryDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.service.IDataDictionaryService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: DataDictionaryServiceImpl
 * @author: pengdengfu
 * @date: 2019年11月1日 下午12:01:07
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class DataDictionaryServiceImpl implements IDataDictionaryService {
    @Autowired
    private IDataDictionaryDao dataDictionaryDao;

    @Override
    public String add(DataDictionary dataDictionary) {
        try {
            dataDictionaryDao.saveAndFlush(dataDictionary);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
        return dataDictionary.getDataId();
    }

    @Override
    public void delete(String dataId) {
        DataDictionary findOne = dataDictionaryDao.findOne(dataId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            dataDictionaryDao.delete(dataId);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @Override
    public void update(DataDictionary dataDictionary, boolean isOverall) {
        DataDictionary findOne = dataDictionaryDao.findOne(dataDictionary.getDataId());
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            if (isOverall) {
                BeanUtils.copyProperties(dataDictionary, findOne, "createTime");
            } else {
                BeanUtils.copyProperties(dataDictionary, findOne, ControllerCommonUtils.getNullPropertyNames(dataDictionary));
            }
            dataDictionaryDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public Page<DataDictionary> search(String dataId, String classId, String status, List<String> sortProperties) {
        Pageable pageable = ControllerCommonUtils.getPager(1, Integer.MAX_VALUE, sortProperties, "createTime");
        Specification<DataDictionary> specification = new Specification<DataDictionary>() {
            @Override
            public Predicate toPredicate(Root<DataDictionary> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(dataId)) {
                    predicates.add(cb.equal(root.get("dataId"), dataId));
                }
                if (StringUtils.isNotEmpty(classId)) {
                    predicates.add(cb.equal(root.get("classId"), classId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    predicates.add(cb.equal(root.get("isActive"), status));
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        return dataDictionaryDao.findAll(specification, pageable);
    }

}
