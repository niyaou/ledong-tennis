package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * 
 * @ClassName: SysEnvConfig
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:18:19
 */
@Data
@Entity
@Table(name = "sys_env_config", uniqueConstraints = { @UniqueConstraint(columnNames = { "type", "ip" }) })
@EntityListeners(AuditingEntityListener.class)
public class SysEnvConfig implements Serializable {

    private static final long serialVersionUID = 7378050314727850447L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "env_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String envId;

    @Column(name = "type", nullable = false, length = 1, columnDefinition = "char(1) COMMENT '数据类型：1，算法机器；2：镜像仓库；3：hdfs client'")
    private String type;

    @Column(name = "ip", nullable = false, length = 20, columnDefinition = "varchar(20) COMMENT 'IP地址'")
    private String ip;

    @Column(name = "host_name", nullable = true, length = 50, columnDefinition = "varchar(50) COMMENT '主机名'")
    private String hostName;

    @Column(name = "ssh_port", nullable = false, columnDefinition = "int COMMENT 'ssh端口'")
    private Integer sshPort;

    @JsonIgnore
    @Column(name = "user_name", nullable = true, columnDefinition = "text COMMENT '用户名'")
    @ColumnTransformer(read = "CAST(AES_DECRYPT(UNHEX(user_name), 'ankon') as char(128))", write = "HEX(AES_ENCRYPT(?, 'ankon'))")
    private String userName;

    @JsonIgnore
    @Column(name = "password", nullable = true, length = 50, columnDefinition = "text COMMENT '密码'")
    @ColumnTransformer(read = "CAST(AES_DECRYPT(UNHEX(password), 'ankon') as char(128))", write = "HEX(AES_ENCRYPT(?, 'ankon'))")
    private String password;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

}
