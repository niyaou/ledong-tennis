package com.desay.cd.factory.transaction.base;

import com.desay.cd.factory.service.impl.IndexServiceImpl;


/**
 * es文件操作事务基类
 * @author uidq1343
 *
 */
public abstract class BaseIndexServiceHandler  extends AbstractFileHandler{
    protected IndexServiceImpl indexService;
    
    @Override
    protected void clean() {
        if(indexService!=null) {
            indexService=null;
        }
        
    }

    @Override
    public <T> void setResource(T resouce) {
        if( resouce instanceof IndexServiceImpl) {
            indexService=(IndexServiceImpl)resouce;
        }
    }
}
