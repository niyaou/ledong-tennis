package com.desay.cd.factory.constance;

/**
 * 常量类
 * 
 * @author pengdengfu
 *
 */
public interface Constanst {
    /** 在通知管理中，代表所有用户 */
    public static final String ALL_USER = "all";
    /** 翻页的默认页码 */
    public static final Integer FIRST_PAGE_NO = 1;
    /** 翻页的默认页大小 */
    public static final Integer PAGE_SIZE = 10;

    /** 名称长度30 */
    public static final Integer NAME_LENGTH = 40;
    /** 名称长度60 */
    public static final Integer PERMISSION_NAME_LENGTH = 60;

    /** userId长度20 */
    public static final Integer USER_ID_LENGTH = 20;
    /** 日志未知IP */
    public static final String UNKNOWN = "unknown";
    /** point：'.' */
    public static final String POINT = ".";

    /** user status 0 */
    public static final String ACTIVE_STATUS_0 = "0";
    /** user status 1 */
    public static final String ACTIVE_STATUS_1 = "1";

    /** - */
    public static final String MIDDLE_LINE = "-";
    /** "/" */
    public static final String FORWORD_SLASH = "/";
    /** 和子系统没有关联关系 */
    public static final String GLOABLE_FLG = "global";

    /** 降序 排序方向-DESC */
    public static final String SORT_DIRECTION_DESC = "desc";
    /** 升序 排序方向-ASC */
    public static final String SORT_DIRECTION_ASC = "ASC";

    /** 模糊查询 */
    public static final String SEARCH_LIKE = "like";
    /** 删除子系统或者删除用户需要发送消息的topic */
    public static final String DELETE_SYS_USER_TOPIC = "deletedSubsystemUserTopic";
    /** 删除用户需要发送消息的topic */
    public static final String DELETE_USER_TOPIC = "deletedUserTopic";

}
