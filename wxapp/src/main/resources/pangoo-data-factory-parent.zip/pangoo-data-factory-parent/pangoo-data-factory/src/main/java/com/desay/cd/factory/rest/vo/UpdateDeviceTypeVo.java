package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: UpdateDeviceTypeVo
 * @author: pengdengfu
 * @date: 2019年4月17日 下午1:44:13
 */
public class UpdateDeviceTypeVo {
    @ApiModelProperty(value = "设备类型名称(0<size<=30)", required = false)
    private String deviceTypeName;

    @ApiModelProperty(value = "添加的子节点名称列表", required = false)
    private Set<String> childrenNames;

    @ApiModelProperty(value = "状态：0，不启用。1，启用", required = false)
    private String status;

    @ApiModelProperty(value = "父节点Id", required = false)
    private String parentId;

    public String getDeviceTypeName() {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    public Set<String> getChildrenNames() {
        return childrenNames;
    }

    public void setChildrenNames(Set<String> childrenNames) {
        this.childrenNames = childrenNames;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    @Override
    public String toString() {
        return "UpdateDeviceTypeVo [deviceTypeName=" + deviceTypeName + ", childrenNames=" + childrenNames + ", status=" + status + ", parentId=" + parentId + "]";
    }

}
