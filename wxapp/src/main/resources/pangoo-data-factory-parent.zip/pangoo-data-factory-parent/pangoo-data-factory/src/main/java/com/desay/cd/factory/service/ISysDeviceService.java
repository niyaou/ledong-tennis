package com.desay.cd.factory.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysDevice;

/**
 * 
 * @ClassName: IDeviceService
 * @author: pengdengfu
 * @date: 2019年4月8日 上午10:50:53
 */
public interface ISysDeviceService {
    /**
     * 添加设备
     * 
     * @param deviceName
     * @param deviceAttrinuteNames
     * @param deviceTypeId
     * @param status
     * @return
     */
    SysDevice addDevice(String deviceName, Map<String, String> deviceAttrinuteNames, String deviceTypeId, String status);

    /**
     * 更新设备
     * 
     * @param deviceId
     * @param deviceName
     * @param deviceAttrinuteNames
     * @param deviceTypeId
     * @param status
     */
    void updateDevice(String deviceId, String deviceName, Map<String, String> deviceAttrinuteNames, String deviceTypeId, String status);

    /**
     * 更新设备
     * 
     * @param deviceId
     * @param deviceName
     * @param deviceAttrinuteNames
     * @param deviceTypeId
     * @param status
     */
    void updateDevice(String deviceId, String deviceName, Set<Map<String, String>> deviceAttrinuteNames, String deviceTypeId, String status);

    /**
     * 删除设备
     * 
     * @param deviceId
     */
    void deleteDevice(String deviceId);

    /**
     * 更新设备-删除设备属性
     * 
     * @param deviceId
     * @param attributeId
     */
    void updateDeviceDeleteAttribute(String deviceId, String attributeId);

    /**
     * 更新设备-删除设备类型
     * 
     * @param deviceId
     * @param deviceTypeId
     */
    void updateDeviceDeleteDeviceType(String deviceId, String deviceTypeId);

    /**
     * 查询所有设备或者根据条件查询设备（deviceId，精确查询；deviceName，模糊查询）
     * 
     * @param pageNo
     * @param pageSize
     * @param deviceId
     * @param deviceName
     * @param status
     * @param deviceTypeId
     * @param hasCleanStrategy
     * @param hasTaskStrategy
     * @param properties
     * @param sortDirection
     * @return
     */
    Page<SysDevice> listDevice(String pageNo, String pageSize, String deviceId, String deviceName, String status, String deviceTypeId, String hasCleanStrategy,
            String hasTaskStrategy, List<String> properties, String sortDirection);

}
