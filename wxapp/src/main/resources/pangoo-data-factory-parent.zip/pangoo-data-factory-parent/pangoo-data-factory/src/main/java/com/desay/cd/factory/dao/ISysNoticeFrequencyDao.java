package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.desay.cd.factory.entity.mysql.SysNoticeFrequency;

/**
 * ISysNoticeFrequencyDao
 * 
 * @author pengdengfu
 *
 */
public interface ISysNoticeFrequencyDao extends JpaRepository<SysNoticeFrequency, Serializable> {

}
