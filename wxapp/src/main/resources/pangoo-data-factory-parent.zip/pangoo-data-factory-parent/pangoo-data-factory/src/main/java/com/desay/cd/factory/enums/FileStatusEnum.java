package com.desay.cd.factory.enums;

/**
 * 文件状态枚举
 * 
 * @author uidq1343
 *
 */
public enum FileStatusEnum {
    /** 文件状态 0：未完成，1：待审核，2，待清洗，3：入库，4：拒绝，5：已删除，6：已取消 ，7：预留 */
    UN_FINISHED(0, "未完成"),
    /** 待审核 */
    PENDING_TO_AUDITED(1, "待审核"),
    /** 待清洗 */
    PENDING_TO_CLEANED(2, "待清洗"),
    /** 入库 */
    STORED(3, "入库"),
    /** 拒绝 */
    DENIED(4, "拒绝"),
    /** 已删除 */
    DELETED(5, "已删除"),
    /** 已取消 */
    CANCELED(6, "已取消"),
    /** 清洗任务重复（文件重复） */
    TASKDUMP(90, "清洗任务重复（文件重复）"),
    /** 清洗任务队列中 */
    INQUEUE(91, "清洗任务队列中"),
    /** 出清洗任务队列 */
    OUTQUEUE(92, "出清洗任务队列"),
    /** 清洗任务进行中 */
    INTASK(93, "发送到清洗任务"),
    /** 清洗失败 */
    CLEANTASKFAILD(99, "清洗失败"),
    /** 预留 */
    RESERVED(7, "预留");

    private Integer code;

    private String message;

    FileStatusEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static FileStatusEnum getStatusByCode(Integer code) {
        for (FileStatusEnum item : FileStatusEnum.values()) {
            if (item.code.equals(code)) {
                return item;
            }
        }
        return null;

    }

    public static String getMessage(String name) {
        for (FileStatusEnum item : FileStatusEnum.values()) {
            if (item.name().equals(name)) {
                return item.message;
            }
        }
        return name;
    }

    public static Integer getCode(String name) {
        for (FileStatusEnum item : FileStatusEnum.values()) {
            if (item.name().equals(name)) {
                return item.code;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return this.name();
    }

}
