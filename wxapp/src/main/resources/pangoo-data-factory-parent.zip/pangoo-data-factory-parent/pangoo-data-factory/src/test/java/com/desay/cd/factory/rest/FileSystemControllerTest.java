package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.fileUpload;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.rest.vo.UploadChunkVo;
import com.desay.cd.factory.rest.vo.UploadFileVo;
import com.desay.cd.factory.service.impl.FileServiceImpl;
import com.desay.cd.factory.service.impl.HdfsFileServiceImpl;
import com.desay.cd.factory.service.impl.IndexServiceImpl;
import com.desay.cd.hdfs.HdfsUtils;

/**
 * 
 * @ClassName: FileSystemControllerTest
 * @author: NiXuChun
 * @date: 2019年4月9日 下午3:58:07
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class FileSystemControllerTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;

    @Autowired
    HdfsFileServiceImpl hdfsFileService;

    @Autowired
    IndexServiceImpl indexService;

    @Autowired
    FileServiceImpl fileService;

    @LocalServerPort
    private int port;
    UploadFileVo vo;
    UploadChunkVo chunks;
    private final int interval = 2000;
    private String cookie = null;

    @Before()
    public void setup() {
        System.out.println(port);
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        vo = new UploadFileVo();
        chunks = new UploadChunkVo();

        vo.setDeviceId("test1");
        vo.setDeviceName("testName1");
        vo.setProductId("test2");
        vo.setProductName("testName2");

        Properties properties = new Properties();
        // 获取配置信息
        try {
            properties.load(ClassLoader.getSystemResourceAsStream("application-dev.properties"));
            properties.put("pangoo-data-factory.intercepter", false);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String mvcResult;
        try {

            mvcResult = mvc.perform(post("/getPassWordRSA").param("password", "fiorile1F")).andExpect(status().isOk()).andDo(MockMvcResultHandlers.print())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn().getResponse().getContentAsString();
            JSONObject success = (JSONObject) JSONObject.parse(mvcResult);
            RestTemplate restTemplate = new RestTemplate();
            String url = String.format("http://localhost:%d/user/login", port);
            System.out.println(url);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.add("access_token", "1");
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("userId", "uidq1343");
            map.add("password", success.getString("data"));

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
            System.out.println(response.getBody());

            success = (JSONObject) JSONObject.parse(response.getBody());
            cookie = ((JSONObject) success.get("data")).getString("token");
            System.out.println(cookie);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    public void test1() {
        assertNotNull(cookie);
    }

    /**
     * 上传文件
     * 
     * @throws Exception
     */
    @Test
    public void uploadFile() throws Exception {

        String displayName = "test.txt";
        String path = "d:\\" + displayName;
        File file = new File(path);
        file.createNewFile();
        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write("test123648874014545411344trgfvdcsdfghgfds");
        bw.flush();
        bw.close();
        fw.close();

        String child = "";

        /* 上传文件 */
        InputStream inputStream = new FileInputStream(file);
        MockMultipartFile files = new MockMultipartFile("file", "test.txt", "multipart/form-data", inputStream);

        mvc.perform(fileUpload("/fileSystem/files/").file(files).param("vo", JSON.toJSONString(vo)).param("chunks", JSON.toJSONString(vo)).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn().getResponse()
                .getContentAsString();

        Thread.sleep(interval * 2);

        String childPath = fileService.getRealPath(child);
        assertNotNull(childPath);

        assertNotNull(indexService.queryFileInfomation(child));
        assertTrue(hdfsFileService.fileExists(childPath));
        assertEquals(HdfsUtils.getHdfsFileLength(childPath), file.length());

        /** 删除文件 */
        mvc.perform(delete("/fileSystem/file/" + child).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk()).andDo(MockMvcResultHandlers.print())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn();
        file.delete();
        Thread.sleep(interval * 3);

    }

    /**
     * 
     * 构造文件 上传文件 删除文件
     * 
     * @throws Exception
     */
    @Test
    public void deleteFile() throws Exception {
        String displayName = "test.txt";
        String path = "d:\\" + displayName;
        File file = new File(path);
        file.createNewFile();
        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write("test123648874014545411344trgfvdcsdfghgfds");
        bw.flush();
        bw.close();
        fw.close();

        String parent = "";
        String child = "";

        /* 获取根目录id */
        String mvcResult = mvc.perform(get("/fileSystem/rootFolders")).andExpect(status().isOk()).andDo(MockMvcResultHandlers.print())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn().getResponse().getContentAsString();
        JSONObject success = (JSONObject) JSONArray.parse(mvcResult);
        JSONArray arrs = (JSONArray) success.get("data");
        JSONObject root = (JSONObject) arrs.get(0);
        Assert.assertNotNull(arrs);
        Assert.assertNotEquals(arrs.size(), 0);

        /* 创建一级子目录 */
        mvcResult = mvc
                .perform(put("/fileSystem/folders/" + (String) root.get("directoryId") + "/" + "pangoo_data_fanctory_test").contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn().getResponse()
                .getContentAsString();
        Thread.sleep(interval * 2);

        /* 上传文件 */
        InputStream inputStream = new FileInputStream(file);
        MockMultipartFile files = new MockMultipartFile("file", "test.txt", "multipart/form-data", inputStream);

        mvc.perform(fileUpload("/fileSystem/single/" + parent).file(files).param("vo", JSON.toJSONString(vo)).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn().getResponse().getContentAsString();

        Thread.sleep(interval * 2);

        String childPath = fileService.getRealPath(child);
        assertNotNull(childPath);

        String url = "/fileSystem/folder/";

        /** 删除文件 */
        mvc.perform(delete("/fileSystem/file/" + child).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk()).andDo(MockMvcResultHandlers.print())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andReturn();
        file.delete();
        Thread.sleep(interval * 3);

        assertNull(indexService.queryFileInfomation(child));
        assertFalse(hdfsFileService.fileExists(childPath));

        /* 删除目录 */
        mvc.perform(delete(url + parent)).andDo(MockMvcResultHandlers.print()).andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andReturn();
        Thread.sleep(interval * 3);

    }

}
