package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.cd.factory.entity.mysql.SysSubSystem;

/**
 * 
 * @ClassName: ISysSubSystemDao
 * @author: pengdengfu
 * @date: 2019年4月17日 下午2:38:41
 */
public interface ISysSubSystemDao extends JpaRepository<SysSubSystem, Serializable>, JpaSpecificationExecutor<SysSubSystem> {

    /**
     * 通过系统名称查询子系统
     * 
     * @param subSystemName
     * @return
     */
    SysSubSystem findBySubsystemName(String subSystemName);
}
