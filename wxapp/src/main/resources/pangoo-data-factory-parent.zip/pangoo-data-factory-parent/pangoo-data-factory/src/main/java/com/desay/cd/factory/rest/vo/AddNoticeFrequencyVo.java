package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddNoticeFrequencyVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午4:06:00
 */
@ApiModel(value = "通知频率")
public class AddNoticeFrequencyVo {
    @ApiModelProperty(value = "通知频率名称(0<size<=30)", required = true)
    private String noticeFrequencyName;

    public String getNoticeFrequencyName() {
        return noticeFrequencyName;
    }

    public void setNoticeFrequencyName(String noticeFrequencyName) {
        this.noticeFrequencyName = noticeFrequencyName;
    }

}
