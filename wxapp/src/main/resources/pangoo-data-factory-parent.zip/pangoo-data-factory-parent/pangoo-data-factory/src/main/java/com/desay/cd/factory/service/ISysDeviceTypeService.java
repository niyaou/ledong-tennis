package com.desay.cd.factory.service;

import java.util.List;
import java.util.Set;

import com.desay.cd.factory.entity.mysql.SysDeviceType;

/**
 * 
 * @ClassName: ISysDeviceTypeService
 * @author: pengdengfu
 * @date: 2019年4月16日 下午4:47:13
 */
public interface ISysDeviceTypeService {

    /**
     * 添加设备类型
     * 
     * @param deviceTypeName
     * @param parentDeviceTypeId
     * @param childrenNames
     * @return
     */
    SysDeviceType addDeviceType(String deviceTypeName, String parentDeviceTypeId, Set<String> childrenNames);

    /**
     * 删除设备类型
     * 
     * @param deviceTypeId
     */
    void deleteDeviceType(String deviceTypeId);

    /**
     * 更新设备类型
     * 
     * @param deviceTypeId
     * @param deviceTypeName
     * @param childrenNames
     * @param status
     * @param parentId
     */
    void updateDeviceType(String deviceTypeId, String deviceTypeName, Set<String> childrenNames, String status, String parentId);

    /**
     * 获取顶级设备类型
     * 
     * @param deviceTypeId
     * @param status
     * @param properties
     * @param sortDirection
     * @return
     */
    List<SysDeviceType> getDeviceTypes(String deviceTypeId, String status, List<String> properties, String sortDirection);

}
