package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.IDataDictionaryDao;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.rest.vo.DataDictionaryVo;

/**
 * DataDictionaryControllerTest
 * 
 * @author pengdengfu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DataDictionaryControllerTest {

    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    private IDataDictionaryDao dataDictionaryDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testDataDictionary() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        DataDictionary dataDictionary = new DataDictionary();

        dataDictionary.setClassId(5);
        dataDictionary.setName("test");
        dataDictionary.setValue("test_value");
        String requestJson = JSONObject.toJSONString(dataDictionary);

        // 添加
        mvc.perform(post("/management/dictionary").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        // 更新
        Example<DataDictionary> example = Example.of(dataDictionary);
        DataDictionary findOne = dataDictionaryDao.findOne(example);

        DataDictionaryVo updateVo = new DataDictionaryVo();
        updateVo.setValue("value_update");
        requestJson = JSONObject.toJSONString(updateVo);
        mvc.perform(put("/management/dictionary/" + findOne.getDataId()).contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        // 查询
        params.clear();
        params.add("classId", "5");
        MvcResult mvcResult = mvc.perform(get("/management/dictionary")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 删除
        params.clear();
        mvc.perform(delete("/management/dictionary/" + findOne.getDataId()).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
    }
}
