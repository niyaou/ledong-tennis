package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 
 * @ClassName: SysProduct
 * @author: pengdengfu
 * @date: 2019年4月9日 上午8:38:45
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_product", uniqueConstraints = { @UniqueConstraint(columnNames = { "product_name" }) })
public class SysProduct implements Serializable {

    private static final long serialVersionUID = -6130550543080141315L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "product_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String productId;

    /** 产品名称 */
    @Column(name = "product_name", nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '产品名称'")
    private String productName;

    /** 产品描述 */
    @Column(name = "product_desc", columnDefinition = "text COMMENT '产品描述 '")
    private String productDesc;

    /** 客户名称 */
    @Column(name = "custom_name", nullable = true, length = 60, columnDefinition = "varchar(60) COMMENT '顾客名称'")
    private String customName;

    /** 产品所拥有的设备 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_product_devices", joinColumns = @JoinColumn(name = "product_id"), inverseJoinColumns = @JoinColumn(name = "device_id"))
    @OrderBy("device_name DESC")
    private Set<SysDevice> sysDevices;

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private String isActive = "1";

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public Set<SysDevice> getSysDevices() {
        return sysDevices;
    }

    public void setSysDevices(Set<SysDevice> sysDevices) {
        this.sysDevices = sysDevices;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }
}
