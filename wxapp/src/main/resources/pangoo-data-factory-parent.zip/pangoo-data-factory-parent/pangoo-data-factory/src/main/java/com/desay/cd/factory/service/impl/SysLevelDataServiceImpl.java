package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysLevelDataDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysLevelData;
import com.desay.cd.factory.rest.vo.SysLevelDataVo;
import com.desay.cd.factory.service.ISysLevelDataService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * SysLevelDataServiceImpl
 * 
 * @author pengdengfu
 *
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class SysLevelDataServiceImpl implements ISysLevelDataService {
    @Autowired
    private ISysLevelDataDao sysLevelDataDao;

    @Override
    public String add(SysLevelDataVo sysLevelDataVo, String dataType) {
        SysLevelData sysLevelData = new SysLevelData();
        BeanUtils.copyProperties(sysLevelDataVo, sysLevelData);
        sysLevelData.setDataType(dataType);
        checkParentId(sysLevelDataVo, sysLevelData, null, dataType);
        checkChildren(sysLevelDataVo, sysLevelData, null, dataType);
        try {
            SysLevelData tag = sysLevelDataDao.saveAndFlush(sysLevelData);
            sysLevelDataDao.save(tag.getChildren());
            return tag.getId();
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    private void checkChildren(SysLevelDataVo sysLevelDataVo, SysLevelData sysLevelData, String id, String dataType) {
        Set<String> childrenNames = sysLevelDataVo.getChildrenNames();
        Set<SysLevelData> children = new HashSet<>(16);

        Set<SysLevelData> existedDatas = new HashSet<>(16);
        Set<SysLevelData> result = new HashSet<SysLevelData>();
        result.clear();
        if (childrenNames != null && childrenNames.size() > 0) {
            for (String childrenName : childrenNames) {
                SysLevelData child = new SysLevelData();
                SysLevelData existedData = searchSameData(childrenName, sysLevelData.getId(), sysLevelData, dataType);

                if (existedData != null) {
                    child.setName(existedData.getName());
                    child.setDesc(existedData.getDesc());
                    child.setParent(sysLevelData);
                    child.setDataType(dataType);
                    child.setStyle(existedData.getStyle());
                    existedDatas.add(existedData);
                } else {
                    child.setName(childrenName);
                    child.setParent(sysLevelData);
                    child.setDataType(dataType);
                    child.setStyle(sysLevelDataVo.getStyle());
                    children.add(child);
                }
            }
        } else if (childrenNames != null && childrenNames.size() == 0) {
            children.clear();
        }
        result.addAll(sysLevelData.getChildren());
        result.removeAll(existedDatas);
        sysLevelDataDao.deleteInBatch(result);
        sysLevelData.setChildren(children);
    }

    private void checkParentId(SysLevelDataVo sysLevelDataVo, SysLevelData sysLevelData, String id, String dataType) {
        // 判断父节点是否存在
        String parentId = sysLevelDataVo.getParentId();
        if (StringUtils.isNotEmpty(parentId)) {
            SysLevelData findOne = sysLevelDataDao.findOne(parentId);
            if (findOne == null) {
                throw new BusinessException(ResultCodeEnum.PARENT_TAG_ID_NOT_EXISTED, null, ResultCodeEnum.PARENT_TAG_ID_NOT_EXISTED.getMessage());
            }
            sysLevelData.setParent(findOne);
        } else if (StringUtils.equals(parentId, StringUtils.EMPTY)) {
            sysLevelData.setParent(null);
        }
        if (StringUtils.isNotEmpty(sysLevelDataVo.getName())) {
            checkSameData(sysLevelDataVo.getName(), sysLevelDataVo.getParentId(), sysLevelData, id, dataType);
        }

    }

    private SysLevelData checkSameData(String name, String parentId, SysLevelData sysLevelData, String id, String dataType) {
        SysLevelData existed = searchSameData(name, parentId, sysLevelData, dataType);
        // 添加
        if (StringUtils.isEmpty(id) && existed != null) {
            if (StringUtils.equals(Constanst.ACTIVE_STATUS_1, Integer.toString(existed.getIsActive()))) {
                throw new BusinessException(ResultCodeEnum.LEVEL_TYPE_NAME_EXISTED, null, ResultCodeEnum.LEVEL_TYPE_NAME_EXISTED.getMessage());
            } else {
                throw new BusinessException(ResultCodeEnum.DATA_DELETED_HAS_EXISTED, null, ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getMessage());
            }

        }
        // 更新
        if (StringUtils.isNotEmpty(id) && existed != null && id != existed.getId()) {
            if (StringUtils.equals(Constanst.ACTIVE_STATUS_1, Integer.toString(existed.getIsActive()))) {
                throw new BusinessException(ResultCodeEnum.LEVEL_TYPE_NAME_EXISTED, null, ResultCodeEnum.LEVEL_TYPE_NAME_EXISTED.getMessage());
            } else {
                throw new BusinessException(ResultCodeEnum.DATA_DELETED_HAS_EXISTED, null, ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getMessage());
            }
        }
        return existed;
    }

    private SysLevelData searchSameData(String name, String parentId, SysLevelData sysLevelData, String dataType) {
        // 判断同节点下是否有相同的数据
        Specification<SysLevelData> specification = new Specification<SysLevelData>() {
            @Override
            public Predicate toPredicate(Root<SysLevelData> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(dataType)) {
                    predicates.add(cb.equal(root.get("dataType"), sysLevelData.getDataType()));
                }
                if (StringUtils.isNotEmpty(name)) {
                    predicates.add(cb.equal(root.get("name"), name));
                }
                if (StringUtils.isNotEmpty(parentId)) {
                    Join<SysLevelData, SysLevelData> join = root.join("parent", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("id"), parentId));
                } else {
                    Join<SysLevelData, SysLevelData> join = root.join("parent", JoinType.LEFT);
                    predicates.add(cb.isNull(join.get("id")));
                }
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        SysLevelData existed = sysLevelDataDao.findOne(specification);
        return existed;
    }

    @Override
    public void delete(String id, String dataType) {
        SysLevelData findOne = sysLevelDataDao.findOne(id);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        Set<SysLevelData> children = findOne.getChildren();
        if (children != null && children.size() > 0) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }
        try {
            sysLevelDataDao.delete(id);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @Override
    public void update(String id, SysLevelDataVo sysLevelDataVo, boolean isOverall, String dataType) {
        SysLevelData findOne = sysLevelDataDao.findOne(id);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        checkParentId(sysLevelDataVo, findOne, id, dataType);
        checkChildren(sysLevelDataVo, findOne, id, dataType);
        try {
            if (isOverall) {
                BeanUtils.copyProperties(sysLevelDataVo, findOne, "createTime");
            } else {
                BeanUtils.copyProperties(sysLevelDataVo, findOne, ControllerCommonUtils.getNullPropertyNames(sysLevelDataVo));
            }

            sysLevelDataDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    @Override
    public Page<SysLevelData> search(String dataType, String id, String name, String nameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, sortProperties, "createTime");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(name)) {
            name = name.replaceAll("%", "\\\\%");
            name = name.replaceAll("_", "\\\\_");
        }

        final String nameTmp = name;

        Specification<SysLevelData> specification = new Specification<SysLevelData>() {
            @Override
            public Predicate toPredicate(Root<SysLevelData> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(dataType)) {
                    predicates.add(cb.equal(root.get("dataType"), dataType));
                }
                if (StringUtils.isNotEmpty(id)) {
                    predicates.add(cb.equal(root.get("id"), id));
                }
                if (StringUtils.isNotEmpty(nameTmp)) {
                    if (StringUtils.equalsIgnoreCase(nameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.like(root.get("name"), "%" + nameTmp + "%"));
                    } else {
                        predicates.add(cb.equal(root.get("name"), nameTmp));
                    }
                }
                if (StringUtils.isNotEmpty(status)) {
                    predicates.add(cb.equal(root.get("isActive"), status));
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        return sysLevelDataDao.findAll(specification, pageable);
    }

}
