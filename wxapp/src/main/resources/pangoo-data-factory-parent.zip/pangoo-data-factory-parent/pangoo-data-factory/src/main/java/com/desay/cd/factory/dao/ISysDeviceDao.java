package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.cd.factory.entity.mysql.SysDevice;

/**
 * 
 * @ClassName: ISysDeviceDao
 * @author: pengdengfu
 * @date: 2019年4月8日 上午10:59:49
 */
public interface ISysDeviceDao extends JpaRepository<SysDevice, Serializable>, JpaSpecificationExecutor<SysDevice> {

    /**
     * 根据设备名称查询设备
     * 
     * @param deviceName
     * @return
     */
    SysDevice findByDeviceName(String deviceName);

}
