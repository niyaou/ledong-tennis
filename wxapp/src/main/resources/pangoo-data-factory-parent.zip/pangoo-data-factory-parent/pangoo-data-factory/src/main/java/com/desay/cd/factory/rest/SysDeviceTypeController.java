package com.desay.cd.factory.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysDeviceType;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddDeviceTypeVo;
import com.desay.cd.factory.rest.vo.UpdateDeviceTypeVo;
import com.desay.cd.factory.service.ISysDeviceTypeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 设备类型管理
 * 
 * @ClassName: SysDeviceTypeController
 * @author: pengdengfu
 * @date: 2019年4月16日 下午4:43:15
 */
@RestController
@Api(value = "产品管理-设备类型管理", tags = "SysDeviceTypeController")
public class SysDeviceTypeController {
    @Autowired
    ISysDeviceTypeService sysDeviceTypeService;

    /**
     * 添加设备类型
     * 
     * @param addDeviceTypeVo
     * @return
     */
    @RequestMapping(value = "/management/deviceTypes", method = RequestMethod.POST)
    @ApiOperation(value = "设备类型管理-添加设备类型", notes = "example:<br>" + "{<br>" + "  \"childrenNames\": [ // 包含的子类型,字符串数组，<b>可选</b><br>" + "    \"string\"<br>" + "  ],<br>"
            + "  \"deviceTypeName\": \"string\", // 设备类型名称，<b>必选</b><br>" + "  \"parentDeviceTypeId\": \"string\"  // 父节点Id,如果该参数为空，则添加的类型为顶级类型,<b>可选</b><br>" + "}")
    @LogAnnotation(action = LogActionEnum.DEVICE_TYPE, message = "添加设备类型")
    public ResponseEntity<?> addDeviceType(@RequestBody AddDeviceTypeVo addDeviceTypeVo) {
        SysDeviceType addDeviceType = sysDeviceTypeService.addDeviceType(addDeviceTypeVo.getDeviceTypeName(), addDeviceTypeVo.getParentDeviceTypeId(), addDeviceTypeVo.getChildrenNames());
        return new ResponseEntity<Object>(CommonResponse.success(addDeviceType.getDeviceTypeId()), HttpStatus.OK);
    }

    /**
     * 删除设备类型
     * 
     * @param deviceTypeId
     * @return
     */
    @RequestMapping(value = "/management/deviceTypes/{deviceTypeId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "设备类型管理-删除设备类型", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceTypeId", value = "设备类型ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.DEVICE_TYPE, message = "删除设备类型")
    public ResponseEntity<?> deleteDeviceType(@PathVariable(value = "deviceTypeId", required = true) String deviceTypeId) {
        sysDeviceTypeService.deleteDeviceType(deviceTypeId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 更新设备类型
     * 
     * @param tagId
     * @param tagName
     * @param tagDesc
     * @return
     */
    @RequestMapping(value = "/management/deviceTypes/{deviceTypeId}", method = RequestMethod.PUT)
    @ApiOperation(value = "设备类型管理-更新设备类型", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceTypeId", value = "设备类型ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.DEVICE_TYPE, message = "设备类型管理-更新设备类型")
    public ResponseEntity<?> updateDeviceType(@PathVariable(value = "deviceTypeId", required = true) String deviceTypeId, @RequestBody UpdateDeviceTypeVo updateDeviceTypeVo) {
        sysDeviceTypeService.updateDeviceType(deviceTypeId, updateDeviceTypeVo.getDeviceTypeName(), updateDeviceTypeVo.getChildrenNames(), updateDeviceTypeVo.getStatus(),
                updateDeviceTypeVo.getParentId());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取系统标签,返回层级结构
     * 
     * @param tagId
     * @return
     */
    @RequestMapping(value = "/management/deviceTypes", method = RequestMethod.GET)
    @ApiOperation(value = "设备类型管理-设备类型查询", notes = "查询指定ID的标签及子标签，当deviceTypeId为空时，返回顶级标签结构")
    @ApiImplicitParams({ @ApiImplicitParam(name = "deviceTypeId", value = "需要查询的设备类型Id（精确查询）", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.DEVICE_TYPE, message = "设备类型管理-设备类型查询")
    public ResponseEntity<?> getDeviceType(@RequestParam(value = "deviceTypeId", required = false) String deviceTypeId, @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection) {
        return new ResponseEntity<Object>(CommonResponse.success(sysDeviceTypeService.getDeviceTypes(deviceTypeId, status, sortProperties, sortDirection)), HttpStatus.OK);
    }
}
