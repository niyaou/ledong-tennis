package com.desay.cd.factory.utils.validate;

/**
 * 
 * @ClassName: RegexType
 * @author: pengdengfu
 * @date: 2019年4月17日 下午1:44:55
 */
public enum RegexType {
    /** 无 */
    NONE,
    /** 分隔符 */
    SPECIALCHAR,
    /** 中文 */
    CHINESE,
    /** email */
    EMAIL,
    /** IP */
    IP,
    /** 数字 */
    NUMBER,
    /** NO_SPECIALCHAR */
    NO_SPECIALCHAR,
    /** 电话号码 */
    PHONENUMBER
}
