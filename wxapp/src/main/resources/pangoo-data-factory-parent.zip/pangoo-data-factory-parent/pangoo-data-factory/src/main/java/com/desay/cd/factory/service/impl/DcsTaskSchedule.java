
package com.desay.cd.factory.service.impl;

import java.sql.Date;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.desay.common.es.search.SearchApi;
import org.elasticsearch.search.sort.SortOrder;
import org.redisson.api.RBoundedBlockingQueue;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.storage.engine.common.shell.SshClient;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.mysql.CleanAlgorithm;
import com.desay.cd.factory.entity.mysql.CleanStrategy;
import com.desay.cd.factory.entity.mysql.SysDeviceAttribute;
import com.desay.cd.factory.entity.mysql.SysDeviceType;
import com.desay.cd.factory.entity.mysql.SysEnvConfig;
import com.desay.cd.factory.service.ICleanStrategyService;
import com.desay.cd.factory.service.IClearAlgorithmMachineService;
import com.desay.cd.factory.service.IFileService;
import com.desay.cd.factory.service.IIndexService;
import com.desay.cd.factory.service.ISysEnvConfigService;
import com.desay.cd.factory.utils.DateUtil;

import ch.ethz.ssh2.Connection;
import lombok.extern.slf4j.Slf4j;

/**
 * @author uidq1070 <br/>
 *         1 获取清洗策略：各个设备，优先级权重<br/>
 *         2 从文件索引中，根据权重选择预定的数据条数（如100），同时根据crc码进行文件去重，重复的重新加入一条<br/>
 *         3 将数据放入阻塞有界队列
 *
 */
@Component
@EnableAsync
@Slf4j
public class DcsTaskSchedule {
    @Autowired
    private RedissonClient redissonClient;
    @Autowired
    private ICleanStrategyService cleanStrategyService;

    @Autowired
    private IFileService fileService;
    @Autowired
    private IIndexService indexService;

    @Autowired
    private ISysEnvConfigService sysEnvConfigService;

    @Autowired
    private IClearAlgorithmMachineService clearAlgorithmMachineService;

    @Value("${dcs.script.path}")
    private String dcsScript;

    @Value("${dcs.script.runPath}")
    private String runPath;

    @Value("${schedule.switch}")
    private boolean scheduleSwitch;

    /**
     * 当前环境
     */
    @Value("${spring.profiles.active}")
    private String profile;

    private final static String ENV_PROD = "prod";
    private final static String ENV_TEST = "test";

    private static final String CHECKSUM_CMD = "hadoop fs -checksum ''{0}'' | awk '\''{ print $3 }\'''";

    private static final String DOCKER_CMD = "sh {0}/dcs_task_running.sh {1} {2} {3} {4} {5} ''{6}''  {7} {8} > /dev/null 2>&1 &";

    public final static String PANGOO_DCS_CLEAN_TASK_LOG = "pangoo_dcs_clean_task_log";

    private static final int QUEUE_SIZE = 100;

    private static final String CMD_RESULT_OK = "0";
    private static final double RESOURCE_MAX = 0.7D;

    @Scheduled(cron = "0 0/5 * * * ?")
    @Async
    public void dataSelectProcess() throws InterruptedException {
        if (!scheduleSwitch) {
            return;
        }
        RLock dataLock = redissonClient.getLock("dcs_data_dataLock");
        // 尝试加锁，最多等待1秒(说明已经有其他节点在运行)，上锁以后60秒自动解锁
        boolean res = false;
        try {
            res = dataLock.tryLock(0, -1, TimeUnit.SECONDS);
            if (res) {
                if (log.isDebugEnabled()) {
                    log.info("dataSelectProcess:0 0/5 * * * ?");
                }
                RBoundedBlockingQueue<Object> queue = redissonClient.getBoundedBlockingQueue("dcs_task_queue");
                queue.trySetCapacity(QUEUE_SIZE);
                getDataByStrategyr(queue);
            }
        } finally {
            if (res) {
                dataLock.unlock();
            }

        }

    }

    // 每30s执行一次
    @Scheduled(cron = "*/30 * * * * ?")
    @Async
    public void taskDispatch() throws InterruptedException, ParseException {
        if (!scheduleSwitch) {
            return;
        }
        RBoundedBlockingQueue<Object> queue = redissonClient.getBoundedBlockingQueue("dcs_task_queue");
        queue.trySetCapacity(QUEUE_SIZE);

        RLock taskLock = redissonClient.getLock("dcs_task_taskLock");
        boolean res = false;
        try {
            // 尝试加锁，最多等待1秒(说明已经有其他节点在运行)，上锁以后60秒自动解锁
            res = taskLock.tryLock(0, -1, TimeUnit.SECONDS);
            if (res) {
                if (log.isDebugEnabled()) {
                    log.debug("30s taskDispatch:*/30 * * * * ?");
                }
                taskProcess(queue);
            }
        } finally {
            if (res) {
                taskLock.unlock();
            }
        }
    }

    /**
     * 任务检查： 2：需要清洗的任务；91:清洗排队中；92：排队到达；93：成功发送任务,99:清洗失败<br/>
     * 状态为92,93的数据，清洗日志是否存在？不存在，更新状态为2；存在：成功，更新为3，失败更新为2
     * 
     * @throws InterruptedException
     */
    @SuppressWarnings({ "unchecked" })
    @Scheduled(cron = "0 0 0/2 * * ?")
    @Async
    public void taskCheck() throws InterruptedException {
        if (!scheduleSwitch) {
            return;
        }
        RLock taskLock = redissonClient.getLock("dcs_task_check_taskLock");
        boolean res = false;
        try {
            // 尝试加锁，最多等待1秒(说明已经有其他节点在运行)，上锁以后60秒自动解锁
            res = taskLock.tryLock(0, -1, TimeUnit.SECONDS);
            if (res) {
                if (log.isDebugEnabled()) {
                    log.info("clean task Check:* * 0/2 * * ? (每2小时)");
                }

                String clearStatusOk = "0";
                JSONObject status = new JSONObject();
                status.put("status", 3);
                status.put("updateTime", System.currentTimeMillis() / 1000L);

                Date now = new Date(System.currentTimeMillis());
                Date yestoday = new Date(System.currentTimeMillis() - 3 * 1000 * 60 * 60 * 24);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String yesterday = simpleDateFormat.format(yestoday);
                String today = simpleDateFormat.format(now);

                String start = DateUtil.getTimeStamp(yesterday, DateUtil.FORMAT_DATE);
                String end = DateUtil.getTimeStamp(today, DateUtil.FORMAT_DATE);
                Set<String> statusSet = new HashSet<>(2);
                statusSet.add("91");
                statusSet.add("92");
                statusSet.add("93");
                Page<HashMap<String, Object>> exploreFilesByParams = (Page<HashMap<String, Object>>) indexService.exploreFilesByUpdateStatus(statusSet, start, end, "0", 1, 100,
                        null, null);
                if (log.isDebugEnabled()) {
                    log.debug("clear tast status process:total:{},startTime:{},endTime:{}", exploreFilesByParams.getTotalElements(), new Date(Long.parseLong(start) * 1000L),
                            new Date(Long.parseLong(end) * 1000L));
                }

                if (exploreFilesByParams != null && exploreFilesByParams.getTotalElements() > 0) {
                    for (HashMap<String, Object> searchData : exploreFilesByParams) {
                        String fileId = searchData.get("fileId").toString();
                        LinkedList<HashMap<String, Object>> searchByField = SearchApi.searchByFieldSorted(PANGOO_DCS_CLEAN_TASK_LOG, "fileId", fileId, "startTime", SortOrder.DESC,
                                1, 10);
                        if (searchByField != null && searchByField.size() > 0) {
                            // 任务正常发起
                            String clearStatus = searchByField.get(0).get("clearStatus").toString();
                            if (StringUtils.equals(clearStatusOk, clearStatus)) {
                                // 入库
                                updateDataStatus(3, fileId);
                                if (log.isDebugEnabled()) {
                                    log.debug("{}:任务正常入库", fileId);
                                }

                            } else {
                                // 清洗失败
                                updateDataStatus(99, fileId);
                                if (log.isDebugEnabled()) {
                                    log.debug("{}:任务清洗失败", fileId);
                                }
                            }

                        } else {
                            // 任务没有正常调度，恢复状态，使得任务可以继续发起
                            updateDataStatus(2, fileId);
                            if (log.isDebugEnabled()) {
                                log.debug("{}:任务没有正常调度，恢复状态，使得任务可以继续发起", fileId);
                            }
                        }
                    }
                }
            }
        } finally {
            if (res) {
                taskLock.unlock();
            }
        }

    }

    @SuppressWarnings("unchecked")
    private void taskProcess(RBoundedBlockingQueue<Object> queue) throws InterruptedException, ParseException {
        HashMap<String, Object> task = (HashMap<String, Object>) queue.take();
        // 更新数据状态(出队列)
        updateDataStatus(92, task.get("fileId").toString());

        HashMap<String, Object> runAtts = (HashMap<String, Object>) task.remove("runAtts");
        String imageEnv = runAtts.get("imageEnv").toString();
        String imageVer = runAtts.get("imageVer").toString();
        String fileId = task.get("fileId").toString();
        String imageName = runAtts.get("imageName").toString();
        String imageParams = "\"-c PHash\"";
        if (runAtts.get("imageParams") != null) {
            imageParams = "\"-c " + runAtts.get("imageParams").toString() + "\"";
        }

        boolean checkParams = StringUtils.isEmpty(imageEnv) || StringUtils.isEmpty(imageName) || StringUtils.isEmpty(imageVer);
        Page<SysEnvConfig> dockerRepostorys = sysEnvConfigService.search(null, "2", null, null, null, null, Integer.MAX_VALUE, null);
        boolean checkDockerRepo = dockerRepostorys == null || dockerRepostorys.getTotalElements() <= 0;
        // 资源计算
        boolean checkResource = checkResource(imageEnv);
        if (checkParams || checkDockerRepo || !checkResource) {
            updateDataStatus(2, task.get("fileId").toString());
            return;
        }

        SysEnvConfig dockerRepostory = dockerRepostorys.getContent().get(0);
        String ip = dockerRepostory.getIp();
        Integer sshPort = dockerRepostory.getSshPort();
        String env = "";
        if (StringUtils.isNotEmpty(profile)) {
            env = "-pt=P";
        }
        if (StringUtils.isNotEmpty(profile)) {
            if (profile.contains(ENV_PROD)) {
                env = "-pt=P";
            } else if (profile.contains(ENV_TEST)) {
                env = "-pt=T";
            }
        }
        String fullCmd = MessageFormat.format(DOCKER_CMD, runPath, ip, Integer.toString(sshPort), imageName, imageVer, fileId, JSON.toJSONString(task), imageParams, env);
        if (log.isDebugEnabled()) {
            log.info(fullCmd);
        }

        Connection connection = getSshConnect("1", imageEnv);
        SshClient.execmd(connection, fullCmd, false);
        String execmdRlt = SshClient.execmd(connection, "echo $?", true).replaceAll("[\\t\\n\\r]", "");
        if (log.isDebugEnabled()) {
            log.info(imageEnv + ":" + fullCmd + " =>result:" + execmdRlt);
        }

        // 更新状态
        if (StringUtils.equals(CMD_RESULT_OK, execmdRlt)) {
            updateDataStatus(93, task.get("fileId").toString());
        } else {
            updateDataStatus(2, task.get("fileId").toString());
        }

    }

    /**
     * 更新数据状态
     * 
     * @param statusFlg
     * @param fileId
     */
    private void updateDataStatus(int statusFlg, String fileId) {
        JSONObject status = new JSONObject();
        status.put("status", statusFlg);
        status.put("updateTime", System.currentTimeMillis() / 1000L);
        indexService.updateFileInfomation(status.toJSONString(), fileId);
    }

    /**
     * 检查指定的机器资源是否符合
     * 
     * @param algIp
     * @return
     * @throws ParseException
     */
    private boolean checkResource(String algIp) throws ParseException {
        // 资源计算
        JSONObject machineResource = (JSONObject) clearAlgorithmMachineService.search(algIp, null, null);
        if (machineResource == null) {
            return false;
        }
        Set<Entry<String, Object>> entrySet = machineResource.entrySet();
        if (entrySet == null || entrySet.size() <= 0) {
            return false;
        }
        Entry<String, Object> entry = entrySet.iterator().next();
        NumberFormat nf = NumberFormat.getPercentInstance();
        if (entry == null) {
            return false;
        }
        JSONObject res = (JSONObject) entry.getValue();
        double mem = nf.parse(res.get("mem_usage").toString()).doubleValue();
        double cpu = nf.parse(res.get("cpu_usage").toString()).doubleValue();
        if (mem > RESOURCE_MAX || cpu > RESOURCE_MAX) {
            return false;
        }
        JSONObject gpu = res.getJSONObject("gpu_usage");
        Set<Entry<String, Object>> entrySetGpu = gpu.entrySet();
        boolean flag = true;
        for (Entry<String, Object> gpuInfo : entrySetGpu) {
            JSONObject valueGpu = (JSONObject) gpuInfo.getValue();
            double gpuUtil = nf.parse(valueGpu.getJSONObject("gpu_util").get("util").toString()).doubleValue();
            if (gpuUtil > RESOURCE_MAX) {
                flag = false;
            }
            String memUsedStr = valueGpu.getJSONObject("gpu_util").get("mem_used").toString();
            double memUsed = Double.parseDouble(memUsedStr.substring(0, memUsedStr.indexOf("MiB")));
            String memTotalStr = valueGpu.getJSONObject("gpu_util").get("mem_total").toString();
            double memTotal = Double.parseDouble(memTotalStr.substring(0, memTotalStr.indexOf("MiB")));
            double memUtil = memUsed / memTotal;
            if (memUtil > RESOURCE_MAX) {
                flag = false;
            }
        }
        return flag;
    }

    @SuppressWarnings("unchecked")
    private void getDataByStrategyr(RBoundedBlockingQueue<Object> queue) throws InterruptedException {
        List<String> sortProperties = new ArrayList<>(1);
        sortProperties.add("-priority.value");
        Page<CleanStrategy> stgys = cleanStrategyService.search(null, null, null, null, null, null, null, null, null, "1", null, Integer.MAX_VALUE, sortProperties);
        List<CleanStrategy> content = stgys.getContent();

        for (CleanStrategy cleanStrategy : content) {
            // 算法
            Map<String, String> runAtts = new HashMap<>(16);
            CleanAlgorithm cleanAlgorithm = cleanStrategy.getCleanAlgorithm();
            if (cleanAlgorithm != null) {
                String imageEnv = cleanAlgorithm.getImageEnv();
                String imageParams = cleanAlgorithm.getImageParams();
                String imageVer = cleanAlgorithm.getImageVer();
                String imageName = cleanAlgorithm.getImageName();

                if (StringUtils.isEmpty(imageEnv) || StringUtils.isEmpty(imageName) || StringUtils.isEmpty(imageVer)) {
                    continue;
                }
                runAtts.put("imageEnv", imageEnv);
                runAtts.put("imageParams", imageParams);
                runAtts.put("imageVer", imageVer);
                runAtts.put("imageName", imageName);
            }

            // 优先级
            cleanStrategy.getPriority().getName();
            String value = cleanStrategy.getPriority().getValue();

            // 设备
            String deviceId = cleanStrategy.getSysDevice().getDeviceId();
            cleanStrategy.getSysDevice().getDeviceName();
            // 设备类型
            SysDeviceType deviceType = cleanStrategy.getSysDevice().getDeviceType();
            String typeName = deviceType.getDeviceTypeName();
            List<String> deviceTypes = new ArrayList<String>(16);
            deviceTypes.add(typeName);
            while (deviceType.getParent() != null) {
                deviceTypes.add(deviceType.getParent().getDeviceTypeName());
                deviceType = deviceType.getParent();
            }
            Collections.reverse(deviceTypes);
            String deviceTypeName = StringUtils.join(deviceTypes, ":");

            // 设备属性
            Set<SysDeviceAttribute> deviceAttributes = cleanStrategy.getSysDevice().getDeviceAttributes();
            Map<String, String> deviceAtts = new HashMap<>(16);
            for (SysDeviceAttribute sysDeviceAttribute : deviceAttributes) {
                deviceAtts.put(sysDeviceAttribute.getAttributeName(), sysDeviceAttribute.getAttributeValue());
            }

            // 2，待清洗,0：视频
            Page<HashMap<String, Object>> exploreFilesByParams = (Page<HashMap<String, Object>>) fileService.exploreFilesByParams(null, "2", null, null, null, null, null, deviceId,
                    null, "0", null, null, null, Integer.toString(Integer.parseInt(value)), null, null);
            // when no data,wait 5 minutes
            if (exploreFilesByParams == null || exploreFilesByParams.getTotalElements() <= 0) {
                continue;
            }
            Connection connection = getSshConnect("3", null);
            for (HashMap<String, Object> data : exploreFilesByParams) {
                if (log.isDebugEnabled()) {
                    log.info("slected data : " + data.toString());
                }
                dataProcess(queue, runAtts, deviceTypeName, deviceAtts, connection, data);
            }
            connection.close();
        }

    }

    /**
     * 根据配置信息，获取连接
     * 
     * @return
     */
    private Connection getSshConnect(String type, String ipAdd) {
        Page<SysEnvConfig> hdfsclient = sysEnvConfigService.search(null, type, ipAdd, null, null, null, Integer.MAX_VALUE, null);
        long totalElements = hdfsclient.getTotalElements();
        Random df = new Random();
        SysEnvConfig sysEnvConfig = hdfsclient.getContent().get(df.nextInt((int) totalElements));
        String ip = sysEnvConfig.getIp();
        int port = sysEnvConfig.getSshPort() == null ? 22 : sysEnvConfig.getSshPort();
        String user = sysEnvConfig.getUserName();
        String password = sysEnvConfig.getPassword();
        Connection connection = SshClient.login(ip, port, user, password);
        return connection;
    }

    /**
     * 数据处理
     * 
     * @param queue
     * @param runAtts
     * @param deviceTypeName
     * @param deviceAtts
     * @param connection
     * @param data
     */
    private void dataProcess(RBoundedBlockingQueue<Object> queue, Map<String, String> runAtts, String deviceTypeName, Map<String, String> deviceAtts, Connection connection,
            HashMap<String, Object> data) {
        data.remove("creator");
        data.remove("updateTime");
        data.remove("auditMessage");
        data.remove("auditTime");
        data.remove("cancelTime");
        data.remove("createTime");
        data.remove("deleteTime");
        data.remove("audit");
        data.remove("thumbPath");
        data.remove("status");

        data.put("deviceType", deviceTypeName);
        data.put("deviceAtts", deviceAtts);
        data.put("runAtts", runAtts);

        String fileId = data.get("fileId").toString();

        String filePath = data.get("filePath").toString() + data.get("fileName") + "." + data.get("fileType");
        String cmd = MessageFormat.format(CHECKSUM_CMD, filePath);

        String checkSum = SshClient.execmd(connection, cmd, false);
        if (log.isDebugEnabled()) {
            log.debug("[{}] checksum  is {}", filePath, checkSum);
        }
        if (StringUtils.isEmpty(checkSum)) {
            return;
        }
        checkSum = checkSum.replaceAll("[\\t\\n\\r]", "");
        String existedFileId = indexService.uniqueValid(null, checkSum);
        if (StringUtils.isEmpty(existedFileId)) {
            // 初次进行数据选择
            try {
                if (log.isDebugEnabled()) {
                    log.debug("first get data");
                }
                // 添加checksum
                indexService.createFileCheckSum(data.get("fileId").toString(), checkSum, filePath);
                // 更新状态
                updateDataStatus(91, fileId);
                // 向队列插入数据
                queue.put(data);

            } catch (InterruptedException e) {
                log.error("queue put InterruptedException ", e);
                Thread.currentThread().interrupt();
            }
        } else if (StringUtils.equals(fileId, existedFileId)) {
            if (log.isDebugEnabled()) {
                log.debug("redo selected data");
            }
            // 非初次，进行任务重跑
            // 更新状态
            updateDataStatus(91, fileId);
            // 向队列插入数据
            try {
                queue.put(data);
            } catch (InterruptedException e) {
                log.error("queue put InterruptedException ", e);
                Thread.currentThread().interrupt();
            }
        } else {
            if (log.isDebugEnabled()) {
                log.debug("dumplication data");
            }
            // 重复数据
            // 更新状态
            updateDataStatus(90, fileId);
            log.info("dumplication:fileId is {},filePath is {};existed fileId is {}", fileId, filePath, existedFileId);
        }
    }

}
