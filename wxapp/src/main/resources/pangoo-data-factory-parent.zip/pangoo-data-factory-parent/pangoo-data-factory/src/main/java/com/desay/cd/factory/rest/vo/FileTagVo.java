package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: FileTagVo
 * @author: nixuchun
 */
@ApiModel(value = "文件标签")
public class FileTagVo {
    @ApiModelProperty(value = "父类标签id", required = true)
    private String parentTagId;
    @ApiModelProperty(value = "标签id", required = true)
    private String tagId;
    public String getParentTagId() {
        return parentTagId;
    }
    public void setParentTagId(String parentId) {
        this.parentTagId = parentId;
    }
    public String getTagId() {
        return tagId;
    }
    public void setTagId(String tagId) {
        this.tagId = tagId;
    }


}
