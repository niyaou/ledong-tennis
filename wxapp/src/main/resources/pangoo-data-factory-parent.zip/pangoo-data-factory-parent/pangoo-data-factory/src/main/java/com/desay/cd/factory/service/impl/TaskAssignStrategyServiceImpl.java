package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.IDataDictionaryDao;
import com.desay.cd.factory.dao.ISysDeviceDao;
import com.desay.cd.factory.dao.ISysGroupDao;
import com.desay.cd.factory.dao.ITaskAssignStrategyDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.entity.mysql.SysDevice;
import com.desay.cd.factory.entity.mysql.SysGroup;
import com.desay.cd.factory.entity.mysql.TaskAssignStrategy;
import com.desay.cd.factory.rest.vo.TaskAssignStrategyVo;
import com.desay.cd.factory.service.ITaskAssignStrategyService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: TaskAssignStrategyServiceImpl
 * @author: pengdengfu
 * @date: 2019年11月1日 下午12:01:07
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class TaskAssignStrategyServiceImpl implements ITaskAssignStrategyService {
    @Autowired
    private ITaskAssignStrategyDao taskAssignStrategyDao;
    @Autowired
    private ISysDeviceDao sysDeviceDao;
    @Autowired
    private IDataDictionaryDao dataDictionaryDao;
    @Autowired
    private ISysGroupDao sysGroupDao;

    @Override
    public String add(TaskAssignStrategyVo taskAssignStrategyVo) {
        try {
            TaskAssignStrategy saved = taskAssignStrategyDao.saveAndFlush(check(taskAssignStrategyVo, true, null));
            return saved.getStrgyId();
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    /**
     * 数据检查
     * 
     * @param taskAssignStrategyVo
     * @param isOverall
     * @param taskAssignStrategy
     * @return
     */
    private TaskAssignStrategy check(TaskAssignStrategyVo taskAssignStrategyVo, boolean isOverall, TaskAssignStrategy taskAssignStrategy) {
        if (taskAssignStrategy == null) {
            taskAssignStrategy = new TaskAssignStrategy();
        }
        if (isOverall) {
            BeanUtils.copyProperties(taskAssignStrategyVo, taskAssignStrategy, "createTime");
        } else {
            BeanUtils.copyProperties(taskAssignStrategyVo, taskAssignStrategy, ControllerCommonUtils.getNullPropertyNames(taskAssignStrategyVo));
        }

        String deviceId = taskAssignStrategyVo.getDeviceId();
        if (StringUtils.isNotEmpty(deviceId)) {
            SysDevice findOne = sysDeviceDao.findOne(deviceId);
            if (findOne == null) {
                throw new BusinessException(ResultCodeEnum.DEVICE_NOT_EXISTED, null, ResultCodeEnum.DEVICE_NOT_EXISTED.getMessage());
            }
            taskAssignStrategy.setSysDevice(findOne);
        } else if (deviceId != null && StringUtils.EMPTY.equals(deviceId)) {
            taskAssignStrategy.setSysDevice(null);
        }

        String priorityId = taskAssignStrategyVo.getPriorityId();
        if (StringUtils.isNotEmpty(priorityId)) {
            DataDictionary findOne = dataDictionaryDao.findOne(priorityId);
            if (findOne == null) {
                throw new BusinessException(ResultCodeEnum.DICTIONARY_ID_NOT_EXISTED, null, ResultCodeEnum.DICTIONARY_ID_NOT_EXISTED.getMessage());
            }
            taskAssignStrategy.setPriority(findOne);
        } else if (priorityId != null && StringUtils.EMPTY.equals(priorityId)) {
            taskAssignStrategy.setPriority(null);
        }

        String taskTypeId = taskAssignStrategyVo.getTaskTypeId();
        if (StringUtils.isNotEmpty(taskTypeId)) {
            DataDictionary findOne = dataDictionaryDao.findOne(taskTypeId);
            if (findOne == null) {
                throw new BusinessException(ResultCodeEnum.TASK_TYPE_ID_NOT_EXISTED, null, ResultCodeEnum.TASK_TYPE_ID_NOT_EXISTED.getMessage());
            }
            taskAssignStrategy.setTaskType(findOne);
        } else if (taskTypeId != null && StringUtils.EMPTY.equals(taskTypeId)) {
            taskAssignStrategy.setTaskType(null);
        }

        Set<String> groupIds = taskAssignStrategyVo.getGroupIds();
        if (groupIds != null && groupIds.size() > 0) {
            Set<SysGroup> groups = new HashSet<>(16);
            for (String groupId : groupIds) {
                SysGroup findOne = sysGroupDao.findOne(groupId);
                if (findOne != null) {
                    groups.add(findOne);
                }
            }
            taskAssignStrategy.setSysGroups(groups);
        } else if (groupIds != null && groupIds.size() <= 0) {
            taskAssignStrategy.setSysGroups(null);
        }

        return taskAssignStrategy;
    }

    @Override
    public void delete(String strgyId) {
        TaskAssignStrategy findOne = taskAssignStrategyDao.findOne(strgyId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            taskAssignStrategyDao.delete(strgyId);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @Override
    public void update(String strgyId, TaskAssignStrategyVo taskAssignStrategyVo, boolean isOverall) {
        TaskAssignStrategy findOne = taskAssignStrategyDao.findOne(strgyId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            taskAssignStrategyDao.saveAndFlush(check(taskAssignStrategyVo, isOverall, findOne));
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public Page<TaskAssignStrategy> search(String strgyId, String strygName, String strygNameLike, String deviceId, String deviceName, String deviceNameLike, String groupId,
            String groupName, String groupNameLike, String taskTypeId, String taskTypeName, String taskTypeNameLike, String priorityId, String priorityName,
            String priorityNameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, sortProperties, "createTime");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(strygName)) {
            strygName = strygName.replaceAll("%", "\\\\%");
            strygName = strygName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(deviceName)) {
            deviceName = deviceName.replaceAll("%", "\\\\%");
            deviceName = deviceName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(groupName)) {
            groupName = groupName.replaceAll("%", "\\\\%");
            groupName = groupName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(taskTypeName)) {
            taskTypeName = taskTypeName.replaceAll("%", "\\\\%");
            taskTypeName = taskTypeName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(priorityName)) {
            priorityName = priorityName.replaceAll("%", "\\\\%");
            priorityName = priorityName.replaceAll("_", "\\\\_");
        }
        final String strygNameTmp = strygName;
        final String deviceNameTmp = deviceName;
        final String groupNameTmp = groupName;
        final String taskTypeNameTmp = taskTypeName;
        final String priorityNameTmp = priorityName;
        Specification<TaskAssignStrategy> specification = new Specification<TaskAssignStrategy>() {
            @Override
            public Predicate toPredicate(Root<TaskAssignStrategy> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();

                if (StringUtils.isNotEmpty(strgyId)) {
                    predicates.add(cb.equal(root.get("strgyId"), strgyId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                if (StringUtils.isNotEmpty(strygNameTmp)) {
                    if (StringUtils.equalsIgnoreCase(strygNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.like(root.get("strygName"), "%" + strygNameTmp + "%"));
                    } else {
                        predicates.add(cb.equal(root.get("strygName"), strygNameTmp));
                    }
                }
                if (StringUtils.isNotEmpty(deviceId)) {
                    Join<TaskAssignStrategy, SysDevice> join = root.join("sysDevice", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("deviceId"), deviceId));
                }
                if (StringUtils.isNotEmpty(deviceNameTmp)) {
                    Join<TaskAssignStrategy, SysDevice> join = root.join("sysDevice", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(deviceNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(join.get("deviceName"), "%" + deviceNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(join.get("deviceName"), deviceNameTmp));
                    }
                }

                if (StringUtils.isNotEmpty(groupId)) {
                    Join<TaskAssignStrategy, SysGroup> join = root.join("sysGroups", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("groupId"), groupId));
                }
                if (StringUtils.isNotEmpty(groupNameTmp)) {
                    Join<TaskAssignStrategy, SysGroup> join = root.join("sysGroups", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(deviceNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(join.get("groupName"), "%" + groupNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(join.get("groupName"), groupNameTmp));
                    }
                }

                if (StringUtils.isNotEmpty(taskTypeId)) {
                    Join<TaskAssignStrategy, DataDictionary> join = root.join("taskType", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("dataId"), taskTypeId));
                }
                if (StringUtils.isNotEmpty(taskTypeNameTmp)) {
                    Join<TaskAssignStrategy, DataDictionary> join = root.join("taskType", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(taskTypeNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(join.get("name"), "%" + taskTypeNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(join.get("name"), taskTypeNameTmp));
                    }
                }

                if (StringUtils.isNotEmpty(priorityId)) {
                    Join<TaskAssignStrategy, DataDictionary> join = root.join("priority", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("dataId"), priorityId));
                }
                if (StringUtils.isNotEmpty(priorityNameTmp)) {
                    Join<TaskAssignStrategy, DataDictionary> join = root.join("priority", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(priorityNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(join.get("name"), "%" + priorityNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(join.get("name"), priorityNameTmp));
                    }
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        return taskAssignStrategyDao.findAll(specification, pageable);
    }

}
