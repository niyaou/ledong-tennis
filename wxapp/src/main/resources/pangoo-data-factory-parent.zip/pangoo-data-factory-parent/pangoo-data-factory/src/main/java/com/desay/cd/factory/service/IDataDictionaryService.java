package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.DataDictionary;

/**
 * 
 * @ClassName: IDataDictionaryService
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:22:23
 */
public interface IDataDictionaryService {
    /**
     * 添加
     * 
     * @param dataDictionary
     * @return
     */
    String add(DataDictionary dataDictionary);

    /**
     * 删除
     * 
     * @param dataId
     */
    void delete(String dataId);

    /**
     * 更新
     * 
     * @param dataDictionary
     * @param isOverall
     */
    void update(DataDictionary dataDictionary, boolean isOverall);

    /**
     * 查询
     * 
     * @param dataId
     * @param classId
     * @param status
     * @param sortProperties
     * @return
     */
    Page<DataDictionary> search(String dataId, String classId, String status, List<String> sortProperties);
}
