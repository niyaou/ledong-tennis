package com.desay.cd.factory.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.service.IDockerImagesService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: DockerRepositoryController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "DockerRepositoryController", value = "NEW-Docker算法鏡像")
@RestController
@Validated
public class DockerRepositoryController {
    @Autowired
    private IDockerImagesService dockerImagesService;

    @RequestMapping(value = "/management/images", method = RequestMethod.GET)
    @ApiOperation(value = "Docker算法鏡像-镜像列表", notes = "")
    @LogAnnotation(action = LogActionEnum.DOCKER_IMAGES, message = "Docker算法鏡像-镜像列表")
    public ResponseEntity<?> getImages() {
        Object imagesInfo = dockerImagesService.getImagesInfo("1", null);
        return new ResponseEntity<Object>(CommonResponse.success(imagesInfo), HttpStatus.OK);
    }

    @RequestMapping(value = "/management/images/tags", method = RequestMethod.GET)
    @ApiImplicitParams({ @ApiImplicitParam(name = "imageName", value = "镜像名称", required = true, dataType = "String", paramType = "query") })
    @ApiOperation(value = "Docker算法鏡像-镜像版本列表", notes = "")
    @LogAnnotation(action = LogActionEnum.DOCKER_IMAGES, message = "Docker算法鏡像-镜像版本列表")
    public ResponseEntity<?> getImageTags(@RequestParam(value = "imageName", required = true) String imageName) {
        Object imagesInfo = dockerImagesService.getImagesInfo("2", imageName);
        return new ResponseEntity<Object>(CommonResponse.success(imagesInfo), HttpStatus.OK);
    }

}
