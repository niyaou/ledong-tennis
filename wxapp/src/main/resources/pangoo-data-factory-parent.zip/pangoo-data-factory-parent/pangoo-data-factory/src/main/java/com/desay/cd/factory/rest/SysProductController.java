package com.desay.cd.factory.rest;

import java.util.LinkedHashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysProduct;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddProductVo;
import com.desay.cd.factory.service.ISysProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 产品管理
 * 
 * @ClassName: SysProductController
 * @author: pengdengfu
 * @date: 2019年4月8日 上午11:28:00
 */
@RestController
@Api(value = "产品管理-产品管理", tags = "SysProductController")
public class SysProductController {
    @Autowired
    ISysProductService sysProductService;

    /**
     * 添加产品
     * 
     * @param addProductVo
     * @return
     */
    @RequestMapping(value = "/management/products", method = RequestMethod.POST)
    @ApiOperation(value = "产品管理-添加产品", notes = "" + "  \"productName\": \"string\" //产品名称，<b>必选</b><br>" + "}")
    @LogAnnotation(action = LogActionEnum.PRODUCT, message = "产品管理-添加产品")
    public ResponseEntity<?> addProduct(@RequestBody AddProductVo addProductVo) {
        SysProduct addProduct = sysProductService.addProduct(addProductVo.getProductName(), addProductVo.getProductDesc(), addProductVo.getCustomName(), addProductVo.getDeviceIds(),
                addProductVo.getStatus());
        return new ResponseEntity<Object>(CommonResponse.success(addProduct.getProductId()), HttpStatus.OK);
    }

    /**
     * 删除产品
     * 
     * @param productId
     * @return
     */
    @RequestMapping(value = "/management/products/{productId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "产品管理-删除产品", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "productId", value = "产品Id", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.PRODUCT, message = "产品管理-删除产品")
    public ResponseEntity<?> deleteProduct(@PathVariable(value = "productId", required = true) String productId) {
        sysProductService.deleteProduct(productId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 产品管理-更新产品
     * 
     * @param addProductVo
     * @return
     */
    @RequestMapping(value = "/management/products/{productId}", method = RequestMethod.PUT)
    @ApiOperation(value = "产品管理-更新产品", notes = "example:<br>" + "{<br>" + "  \"customName\": \"string\",//客户名称，<b>可选</b><br>" + "  \"deviceIds\": [//该产品包含的设备Id，忽略不存在的设备Id，<b>可选</b><br>"
            + "    \"string\"<br>" + "  ],<br>" + "  \"productName\": \"string\" //产品名称，<b>可选</b><br>" + "}")
    @LogAnnotation(action = LogActionEnum.PRODUCT, message = "产品管理-更新产品")
    public ResponseEntity<?> updateProduct(@PathVariable(value = "productId", required = true) String productId, @RequestBody AddProductVo updateProductVo) {
        sysProductService.updateProduct(productId, updateProductVo.getProductName(), updateProductVo.getProductDesc(), updateProductVo.getDeviceIds(), updateProductVo.getCustomName(),
                updateProductVo.getStatus());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 产品管理-更新产品-删除产品设备
     * 
     * @param productId
     * @param deviceId
     * @return
     */
    @RequestMapping(value = "/management/products/{productId}/devices/{deviceId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "产品管理-更新产品-删除产品设备", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "productId", value = "产品Id", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "deviceId", value = "设备Id", required = true, dataType = "string", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.PRODUCT, message = "产品管理-更新产品-删除产品设备")
    public ResponseEntity<?> updateProductDeleteDevice(@PathVariable(value = "productId", required = true) String productId, @PathVariable(value = "deviceId", required = true) String deviceId) {
        sysProductService.updateProductDeleteDevice(productId, deviceId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取产品
     * 
     * @param pageNo
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/management/products", method = RequestMethod.GET)
    @ApiOperation(value = "产品管理-获取产品列表", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "productId", value = "产品ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "productName", value = "产品名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "customName", value = "客户名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceId", value = "设备Id，返回包含该设备的产品", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.PRODUCT, message = "产品管理-获取产品列表")
    public ResponseEntity<?> getProducts(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "productId", required = false) String productId, @RequestParam(value = "productName", required = false) String productName,
            @RequestParam(value = "customName", required = false) String customName, @RequestParam(value = "deviceId", required = false) String deviceId,
            @RequestParam(value = "status", required = false) String status, @RequestParam(value = "sortProperties", required = false) List<String> sortProperties,
            @RequestParam(value = "sortDirection", required = false) String sortDirection) {
        Page<SysProduct> products = sysProductService.listProduct(pageNo, pageSize, productId, productName, customName, status, deviceId, sortProperties, sortDirection);
        return new ResponseEntity<Object>(CommonResponse.success(products), HttpStatus.OK);
    }

    /**
     * 产品管理-获取客户名称
     * 
     * @param productName
     * @param customName
     * @param sortDirection
     * @return
     */
    @RequestMapping(value = "/management/products/customers", method = RequestMethod.GET)
    @ApiOperation(value = "产品管理-获取客户名称", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "productName", value = "产品名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "customName", value = "客户名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.PRODUCT, message = "产品管理-获取客户名称")
    public ResponseEntity<?> getCustomsName(@RequestParam(value = "productName", required = false) String productName, @RequestParam(value = "customName", required = false) String customName,
            @RequestParam(value = "sortDirection", required = false) String sortDirection) {
        LinkedHashSet<String> customsNames = sysProductService.getCustomsName(productName, customName, sortDirection);
        return new ResponseEntity<Object>(CommonResponse.success(customsNames), HttpStatus.OK);
    }
}
