package com.desay.cd.factory.transaction.impl;

import java.io.IOException;

import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.transaction.base.FileElement;
import com.desay.cd.factory.transaction.base.BaseHdfsServiceHandler;


/**
 * hdfs删除文件事务处理类
 * @author uidq1343
 *
 */
public class HdfsDeleteFileHandler extends  BaseHdfsServiceHandler {
    
   
    /**
     * 删除文件
     * 若失败，则抛出异常进行回滚
     * 逻辑删除则不做动作
     */
    @Override
    public void doHandleReal(FileElement element) throws CustumException {
        
            String dataPath=element.getFilePath();
            
            String originalPath=new StringBuffer(dataPath).append(element.getVo().getFileName()).toString();
            String chunksPath=hdfsFileService.getChunksFolderPath(element.getChunk().getFileId());
            
            try {
                 hdfsFileService.deleteDirectory(originalPath);
                 hdfsFileService.deleteDirectoryRecursively(chunksPath) ;
            } catch (IOException e) {
                throw  new CustumException(ResultCodeEnum.DELETE_FILE_FAILD.getCode(), ResultCodeEnum.DELETE_FILE_FAILD.getMessage());
            }
    }

    @Override
    public void rollBackReal(FileElement element) {
    }

}
