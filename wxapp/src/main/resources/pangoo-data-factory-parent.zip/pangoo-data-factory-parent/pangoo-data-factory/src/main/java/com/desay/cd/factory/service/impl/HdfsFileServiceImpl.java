package com.desay.cd.factory.service.impl;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.stereotype.Service;

import com.desay.cd.factory.service.IHdfsFileService;
import com.desay.cd.factory.utils.DateUtil;
import com.desay.cd.factory.utils.StringUtil;
import com.desay.cd.hdfs.HdfsUtils;

/**
 * HdfsFileService
 * 
 * @author pengdengfu
 *
 */
@Service
public class HdfsFileServiceImpl implements IHdfsFileService {
    
    @Override
    public boolean mkdirs(String path) {
        return HdfsUtils.mkdir(path);
    }

    @Override
    public  boolean fileExists(String path) {
        return HdfsUtils.directoryExist(path);
    }

    
    @Override
    public boolean mergeHdfsFile(String sourcePath,String targetPath, String file) {
                try {
                   return  HdfsUtils.mergePartFiles( sourcePath, targetPath, file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return false;

    }

    @Override
    public boolean writeToHdfs(InputStream stream, String savePath, String fileName) {
        String hdfsPath = savePath + "/" + fileName;
        return HdfsUtils.uploadFileToHdfs(stream, hdfsPath);
    }

    @Override
    public boolean updateDirectoryName(String originalPath, String newPath) {
        return HdfsUtils.moveFile(originalPath, newPath);
    }

    @Override
    public boolean deleteDirectory(String path) throws IOException {
        return HdfsUtils.deleteFile(path, false);
    }

    @Override
    public boolean deleteDirectoryRecursively(String path) throws IOException {
        return  HdfsUtils.deleteFile(path, true);
    }

    @Override
    public String createFileName(String path) {
       int multi=0;
       String folder=StringUtil.getFileFolder(path);
       String name="";
       String type="";
       String tempPath=path;
       
       while( HdfsUtils.directoryExist(tempPath)) {
           multi++;
           name=StringUtil.getFileNameWithoutPrefix(path);
           type=StringUtil.getPrefixFileName(path);
           tempPath=folder+name+String.valueOf(multi)+"."+type;
       };
       return tempPath.substring(tempPath.lastIndexOf("/")+1,tempPath.length());
    }

    
    @Override
    public String getCurrentFolderPath(int type) {
        String prefix=null;
        switch(type) {
        case DATA:
            prefix=DATA_PREFIX;
            break;
        case THUMBNAIL:
            prefix=THUMBNAIL_PREFIX;
            break;
        case CHUNKS:
            prefix=CHUNKS_PREFIX;
            return new StringBuffer(HDFSDIR).append(prefix).toString();
        case RESERVED:
            prefix=RESERVED_PREFIX;
            break;
         default:
             prefix=RESERVED_PREFIX;
             break;
        }
        return new StringBuffer(HDFSDIR).append(prefix).append(DateUtil.getCurrentDateNumber()).append("/").toString();
    }

    @Override
    public String getChunksFolderPath(String fileId) {
        StringBuffer pathChunks= new StringBuffer(getCurrentFolderPath(CHUNKS));
        return  pathChunks.append(fileId).toString();
    }

    

    @Override
    public Long getFileSize(String path) {
        if (StringUtil.isEmpty(path)) {
            return null;
        }
        return HdfsUtils.getHdfsFileLength(path);
    }

}
