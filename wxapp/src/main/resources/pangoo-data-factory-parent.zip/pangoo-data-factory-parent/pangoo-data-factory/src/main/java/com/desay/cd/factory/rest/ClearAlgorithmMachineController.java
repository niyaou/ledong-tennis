package com.desay.cd.factory.rest;

import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.service.IClearAlgorithmMachineService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: ClearAlgorithmMachineController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "ClearAlgorithmMachineController", value = "NEW-算法机器资源")
@RestController
@Validated
public class ClearAlgorithmMachineController {
    @Autowired
    private IClearAlgorithmMachineService clearAlgorithmMachineService;

    @RequestMapping(value = "/management/cleanAlgorithm/machines", method = RequestMethod.GET)
    @ApiOperation(value = "算法机器资源-查询", notes = "当pageNo，pageSize为空时，默认返回第一页10条数据.")

    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "ip", value = "ip", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "hostName", value = "主机名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "hostNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.ALG_MACHINE, message = "算法机器资源-查询")
    public ResponseEntity<?> search(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "ip", required = false) String ip,
            @RequestParam(value = "hostName", required = false) String hostName, @RequestParam(value = "hostNameLike", required = false) String hostNameLike) {
        Object rlt = clearAlgorithmMachineService.search(ip, hostName, hostNameLike);
        return new ResponseEntity<Object>(CommonResponse.success(rlt), HttpStatus.OK);
    }

}
