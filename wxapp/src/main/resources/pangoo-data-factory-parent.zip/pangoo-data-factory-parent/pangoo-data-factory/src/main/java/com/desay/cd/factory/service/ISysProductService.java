package com.desay.cd.factory.service;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysProduct;

/**
 * 
 * @ClassName: ISysProductService
 * @author: pengdengfu
 * @date: 2019年4月9日 上午9:01:06
 */
public interface ISysProductService {
    /**
     * 添加产品
     * 
     * @param productName
     * @param customName
     * @param productDesc
     * @param deviceIds
     * @param status
     * @return
     */
    SysProduct addProduct(String productName, String customName, String productDesc, Set<String> deviceIds, String status);

    /**
     * 删除产品
     * 
     * @param productId
     */
    void deleteProduct(String productId);

    /**
     * 更新产品
     * 
     * @param productId
     * @param productName
     * @param productDesc
     * @param deviceIds
     * @param customName
     * @param status
     */
    void updateProduct(String productId, String productName, String productDesc, Set<String> deviceIds, String customName, String status);

    /**
     * 删除产品设备
     * 
     * @param productId
     * @param deviceId
     */
    void updateProductDeleteDevice(String productId, String deviceId);

    /**
     * 查询所有设备或者根据条件查询设备（productId，精确查询；productName，模糊查询）
     * 
     * @param pageNo
     * @param pageSize
     * @param productId
     * @param productName
     * @param customName
     * @param status
     * @param deviceId
     * @param properties
     * @param sortDirection
     * @return
     */
    Page<SysProduct> listProduct(String pageNo, String pageSize, String productId, String productName, String customName, String status, String deviceId, List<String> properties,
            String sortDirection);

    /**
     * 获取客户名称列表
     * 
     * @param productName
     * @param customName
     * @param sortDirection
     * @return
     */
    LinkedHashSet<String> getCustomsName(String productName, String customName, String sortDirection);

}
