package com.desay.cd.factory.entity;

import java.io.Serializable;
import java.util.Date;

import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.enums.LogFileOptEnum;

/**
 * 操作日志
 * 
 * @author uidq1163
 *
 */
public class Log implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -3423204956264545900L;
    /** 操作IP :Y */
    private String ip;
    /** 用户名称：Y */
    private String user;
    /** 说明信息 */
    private String message;
    private String auditor;
    /** 操作动作 :1文件管理、2权限管理()、3通知管理、4用户管理---Y */
    private LogActionEnum action;
    /** 文件审核详细信息 */
    private String auditMessage;
    /** 操作时间 (yyyy-MM-dd HH:mm:ss):Y */
    private Date createTime;
    /** 文件ID:Y */
    private String fileId;

    /** 文件操作动作--Y：增、删、回收、恢复、改（打tag、lable、名称、属性） */
    private LogFileOptEnum optType;
    /** 文件名 */
    private String fileName;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public LogActionEnum getAction() {
        return action;
    }

    public void setAction(LogActionEnum action) {
        this.action = action;
    }

    public String getAuditMessage() {
        return auditMessage;
    }

    public void setAuditMessage(String auditMessage) {
        this.auditMessage = auditMessage;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public LogFileOptEnum getOptType() {
        return optType;
    }

    public void setOptType(LogFileOptEnum optType) {
        this.optType = optType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getAuditor() {
        return auditor;
    }

    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
