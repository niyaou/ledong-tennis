package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: UserVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午3:30:21
 */
@ApiModel(value = "更新用户")
@Data
public class UpdateUserVo {
    /** 用户角色Id */
    @ApiModelProperty(value = "添加用户角色Id列表", required = false)
    private Set<String> roleIds;
    /** 用户状态 */
    @ApiModelProperty(value = "用户状态：1：启用，0：不启用", required = false, allowableValues = "0,1", example = "1")
    private String status;
    @ApiModelProperty(value = "用户所属子系统Id列表（忽略不存在的id）", required = false)
    private Set<String> subsystemId;

    @ApiModelProperty(value = "组能力Id")
    private Set<String> abilityIds;

    @ApiModelProperty(value = "用户所属组")
    private Set<GroupVO> groups;

}
