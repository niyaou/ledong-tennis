package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: UploadChunkVo
 * @author: nixuchun
 */
@ApiModel(value = "断点续传文件")
public class UploadChunkVo {

    @ApiModelProperty(value = "文件id", required = true)
    private String fileId;

    @ApiModelProperty(value = "文件总大小,byte为单位的无小数点长整型", required = true)
    private Long size;

    @ApiModelProperty(value = "文件总块数", required = true)
    private Integer chunks;


    @ApiModelProperty(value = "已上传块数", required = true)
    private Integer current;

    public UploadChunkVo() {

    }
    public UploadChunkVo(String fileId) {
        this.fileId=fileId;
    }


    public String getFileId() {
        return fileId;
    }


    public void setFileId(String fileId) {
        this.fileId = fileId;
    }


    public Long getSize() {
        return size;
    }


    public void setSize(Long size) {
        this.size = size;
    }


    public Integer getChunks() {
        return chunks;
    }


    public void setChunks(Integer chunks) {
        this.chunks = chunks;
    }


    public Integer getCurrent() {
        return current;
    }


    public void setCurrent(Integer current) {
        this.current = current;
    }


}
