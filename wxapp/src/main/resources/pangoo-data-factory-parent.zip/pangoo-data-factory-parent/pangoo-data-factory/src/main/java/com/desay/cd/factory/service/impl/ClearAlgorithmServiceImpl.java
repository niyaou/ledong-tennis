package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.IClearAlgorithmDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.CleanAlgorithm;
import com.desay.cd.factory.service.IClearAlgorithmService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: ClearAlgorithmServiceImpl
 * @author: pengdengfu
 * @date: 2019年11月1日 下午12:01:07
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class ClearAlgorithmServiceImpl implements IClearAlgorithmService {
    @Autowired
    private IClearAlgorithmDao clearAlgorithmDao;

    @Override
    public String add(CleanAlgorithm clearAlgorithm) {
        try {
            clearAlgorithmDao.saveAndFlush(clearAlgorithm);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
        return clearAlgorithm.getAlgId();
    }

    @Override
    public void delete(String algId) {
        CleanAlgorithm findOne = clearAlgorithmDao.findOne(algId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            clearAlgorithmDao.delete(algId);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_ALG, null, ResultCodeEnum.CAN_NOT_DELETE_USING_ALG.getMessage());
        }

    }

    @Override
    public void update(CleanAlgorithm clearAlgorithm, boolean isOverall) {
        CleanAlgorithm findOne = clearAlgorithmDao.findOne(clearAlgorithm.getAlgId());
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            if (isOverall) {
                BeanUtils.copyProperties(clearAlgorithm, findOne, "createTime");
            } else {
                BeanUtils.copyProperties(clearAlgorithm, findOne, ControllerCommonUtils.getNullPropertyNames(clearAlgorithm));
            }

            clearAlgorithmDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    @Override
    public Page<CleanAlgorithm> search(String algId, String algName, String algNameLike, String imageName, String imageNameLike, String status, Integer pageNo, Integer pageSize,
            List<String> sortProperties) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, sortProperties, "createTime");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(algName)) {
            algName = algName.replaceAll("%", "\\\\%");
            algName = algName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(imageName)) {
            imageName = imageName.replaceAll("%", "\\\\%");
            imageName = imageName.replaceAll("_", "\\\\_");
        }
        final String algNameTmp = algName;
        final String imageNameTmp = imageName;
        Specification<CleanAlgorithm> specification = new Specification<CleanAlgorithm>() {
            @Override
            public Predicate toPredicate(Root<CleanAlgorithm> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(algId)) {
                    predicates.add(cb.equal(root.get("algId"), algId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                if (StringUtils.isNotEmpty(algNameTmp)) {
                    if (StringUtils.equalsIgnoreCase(algNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.like(root.get("algName"), "%" + algNameTmp + "%"));
                    } else {
                        predicates.add(cb.equal(root.get("algName"), algNameTmp));
                    }
                }
                if (StringUtils.isNotEmpty(imageNameTmp)) {
                    if (StringUtils.equalsIgnoreCase(imageNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(root.get("imageName"), "%" + imageNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(root.get("imageName"), imageNameTmp));
                    }
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        return clearAlgorithmDao.findAll(specification, pageable);
    }

}
