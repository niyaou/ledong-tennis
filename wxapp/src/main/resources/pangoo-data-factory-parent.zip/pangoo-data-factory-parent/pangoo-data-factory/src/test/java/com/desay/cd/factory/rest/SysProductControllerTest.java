package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ISysDeviceDao;
import com.desay.cd.factory.rest.vo.AddDeviceVo;
import com.desay.cd.factory.rest.vo.AddProductVo;

/**
 * 
 * @ClassName: SysProductControllerTest
 * @author: pengdengfu
 * @date: 2019年4月9日 下午3:10:28
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SysProductControllerTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    private ISysDeviceDao sysDeviceDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testProduct() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        AddDeviceVo addDeviceVo = new AddDeviceVo();
        addDeviceVo.setDeviceName("testDeviceName");
        Set<String> deviceAttrinuteNames = new HashSet<>(3);
        deviceAttrinuteNames.add("testDeviceName_att1");
        deviceAttrinuteNames.add("testDeviceName_att2");
        deviceAttrinuteNames.add("testDeviceName_att3");

        String requestJson = JSONObject.toJSONString(addDeviceVo);
        // 添加设备
        String contentAsStringDevice = mvc
                .perform(post("/management/devices").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

        int code = (int) JSONObject.parseObject(contentAsStringDevice).get("code");
        assertEquals(0, code);
        String deviceId = (String) JSONObject.parseObject(contentAsStringDevice).get("data");

        AddProductVo addProductVo = new AddProductVo();
        addProductVo.setProductName("testProductName");
        String requestJsonPro = JSONObject.toJSONString(addProductVo);

        // 添加产品
        String contentAsStringProduct = mvc
                .perform(post("/management/products").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJsonPro).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        int codePro = (int) JSONObject.parseObject(contentAsStringProduct).get("code");
        assertEquals(0, codePro);
        String productId = (String) JSONObject.parseObject(contentAsStringProduct).get("data");

        // 重复添加
        mvc.perform(post("/management/products").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJsonPro).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.code").value(20044));
        // 查询
        params.clear();
        params.add("pageNo", "1");
        params.add("pageSize", "1");
        MvcResult mvcResult = mvc.perform(get("/management/products")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 添加产品设备
        params.clear();
        params.add("deviceId", deviceId);
        mvc.perform(post("/management/products/" + productId + "/devices").contentType(MediaType.APPLICATION_JSON_UTF8).params(params).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.code").value(0));
        // 更新产品名称
        params.clear();
        params.add("productName", "testUpdateProductName");
        mvc.perform(put("/management/products/" + productId).contentType(MediaType.APPLICATION_JSON_UTF8).params(params).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.code").value(0));

        // 删除产品设备
        mvc.perform(delete("/management/products/" + productId + "/devices/" + deviceId).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.code").value(0));

        // 删除产品
        mvc.perform(delete("/management/products/" + productId).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        sysDeviceDao.delete(deviceId);
    }

}
