package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ISysRoleDao;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.rest.vo.AddRoleVo;

/**
 * SysRoleControllerTest
 * 
 * @author pengdengfu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SysRoleControllerTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    private ISysRoleDao sysRoleDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testRole() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

        AddRoleVo addRole = new AddRoleVo();
        addRole.setRoleName("testRoleName");
        addRole.setRoleDesc("testRoleDesc");
        String requestJson = JSONObject.toJSONString(addRole);
        // 添加
        mvc.perform(post("/management/roles").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 重复添加
        mvc.perform(post("/management/roles").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20029));
        // 查询
        params.clear();
        params.add("pageNo", "1");
        params.add("pageSize", "1");
        MvcResult mvcResult = mvc.perform(get("/management/roles")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 更新
        params.clear();
        params.add("roleName", "testRoleNameXXX");
        params.add("roleDesc", "testRoleDescXXX");
        SysRole sysRole = new SysRole();
        sysRole.setRoleName("testRoleName");
        Example<SysRole> example = Example.of(sysRole);
        SysRole findOne = sysRoleDao.findOne(example);

        mvc.perform(put("/management/roles/" + findOne.getRoleId()).contentType(MediaType.APPLICATION_JSON_UTF8).params(params).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        // 更新不存在的数据
        mvc.perform(put("/management/roles/testNotExistData").contentType(MediaType.APPLICATION_JSON_UTF8).params(params).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20030));

        // 删除
        params.clear();
        SysRole sysRole2 = new SysRole();
        sysRole2.setRoleName("testRoleNameXXX");
        Example<SysRole> example2 = Example.of(sysRole2);
        SysRole findOne2 = sysRoleDao.findOne(example2);
        mvc.perform(delete("/management/roles/" + findOne2.getRoleId()).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 删除不存在的数据
        mvc.perform(delete("/management/roles/testNotExistData").contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20030));

    }

}
