package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @ClassName: CleanStrategy
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:18:19
 */
@Getter
@Setter
@Entity
@Table(name = "task_assign_strategy", uniqueConstraints = { @UniqueConstraint(columnNames = { "stryg_name" }) })
@EntityListeners(AuditingEntityListener.class)
public class TaskAssignStrategy implements Serializable {

    private static final long serialVersionUID = -6135201381225228942L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "strgy_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String strgyId;

    @Column(name = "stryg_name", unique = true, nullable = false, columnDefinition = "varchar(50) COMMENT '策略名称'")
    private String strygName;
    @Column(name = "stryg_desc", columnDefinition = "text COMMENT '策略描述'")
    private String strygDesc;

    @OneToOne
    @JoinColumn(name = "device_id")
    private SysDevice sysDevice;

    @OneToOne
    private DataDictionary taskType;

    @OneToOne
    private DataDictionary priority;

    @Column(name = "task_load", columnDefinition = "int  COMMENT '任务量（图片张数）'")
    private Integer taskLoad;

    @ManyToMany(fetch = FetchType.EAGER)
    @OrderBy("group_name DESC")
    @JoinTable(name = "task_assign_strategy_groups", joinColumns = @JoinColumn(name = "strgy_id"), inverseJoinColumns = @JoinColumn(name = "group_id"))
    private Set<SysGroup> sysGroups;

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private Integer isActive = 1;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((strgyId == null) ? 0 : strgyId.hashCode());
        result = prime * result + ((strygName == null) ? 0 : strygName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        TaskAssignStrategy other = (TaskAssignStrategy) obj;
        if (strgyId == null) {
            if (other.strgyId != null) {
                return false;
            }
        } else if (!strgyId.equals(other.strgyId)) {
            return false;
        }
        if (strygName == null) {
            if (other.strygName != null) {
                return false;
            }
        } else if (!strygName.equals(other.strygName)) {
            return false;
        }
        return true;
    }

}
