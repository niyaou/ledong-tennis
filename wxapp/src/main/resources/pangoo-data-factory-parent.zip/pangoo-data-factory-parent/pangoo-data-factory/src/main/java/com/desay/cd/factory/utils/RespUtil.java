package com.desay.cd.factory.utils;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * 
 * @author uidq1163
 *
 */
public class RespUtil {
	public static void returnResult(HttpServletRequest request, HttpServletResponse response,Map<String, Object> result) {
		returnResult(request, response, new Gson().toJson(result));
	}

	public static void returnResult(HttpServletRequest request, HttpServletResponse response, String result) {
		try {
			response.setContentType("text/html;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			PrintWriter out = response.getWriter();
			out.write(result == null ? "" : result);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
