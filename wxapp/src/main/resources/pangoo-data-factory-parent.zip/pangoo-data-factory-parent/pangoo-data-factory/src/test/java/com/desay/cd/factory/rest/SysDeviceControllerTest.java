package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.GenericPropertyMatchers;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ISysDeviceAttributeDao;
import com.desay.cd.factory.dao.ISysDeviceDao;
import com.desay.cd.factory.entity.mysql.SysDeviceAttribute;
import com.desay.cd.factory.rest.vo.AddDeviceVo;

/**
 * 
 * @ClassName: SysDeviceControllerTest
 * @author: pengdengfu
 * @date: 2019年4月9日 下午1:57:52
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SysDeviceControllerTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    private ISysDeviceDao sysDeviceDao;
    @Autowired
    private ISysDeviceAttributeDao sysDeviceAttributeDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testDevice() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        AddDeviceVo addDeviceVo = new AddDeviceVo();
        addDeviceVo.setDeviceName("testDeviceName");
        Set<String> deviceAttrinuteNames = new HashSet<>(3);
        deviceAttrinuteNames.add("testDeviceName_att1");
        deviceAttrinuteNames.add("testDeviceName_att2");
        deviceAttrinuteNames.add("testDeviceName_att3");

        String requestJson = JSONObject.toJSONString(addDeviceVo);
        // 添加
        String contentAsString = mvc.perform(post("/management/devices").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

        int code = (int) JSONObject.parseObject(contentAsString).get("code");
        assertEquals(0, code);
        String deviceId = (String) JSONObject.parseObject(contentAsString).get("data");

        sysDeviceDao.findOne(deviceId);

        // 重复添加
        mvc.perform(post("/management/devices").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.code").value(20039));
        // 查询
        params.clear();
        params.add("pageNo", "1");
        params.add("pageSize", "1");
        MvcResult mvcResult = mvc.perform(get("/management/devices")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 添加设备属性 /management/devices/{deviceId}/attributes
        params.clear();
        params.add("deviceAttributeName", "testDeviceName_att4");
        mvc.perform(post("/management/devices/" + deviceId + "/attributes").params(params).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.code").value(0));

        // 删除设备属性
        SysDeviceAttribute sysDeviceAttribute = new SysDeviceAttribute();
        sysDeviceAttribute.setAttributeName("testDeviceName_att4");

        ExampleMatcher matcher = ExampleMatcher.matching().withMatcher("attributeName", GenericPropertyMatchers.exact()).withMatcher("device", GenericPropertyMatchers.exact());
        Example<SysDeviceAttribute> example = Example.of(sysDeviceAttribute, matcher);
        SysDeviceAttribute found = sysDeviceAttributeDao.findOne(example);

        mvc.perform(delete("/management/devices/" + deviceId + "/attributes/" + found.getAttributeId()).contentType(MediaType.APPLICATION_JSON_UTF8)
                .accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk()).andDo(MockMvcResultHandlers.print())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        // 更新设备-该-修改设备名
        params.clear();
        params.add("deviceName", "testUpdateDeviceName");
        mvc.perform(put("/management/devices/" + deviceId).contentType(MediaType.APPLICATION_JSON_UTF8).params(params).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.code").value(0));

        // 删除设备
        mvc.perform(delete("/management/devices/" + deviceId).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
    }

}
