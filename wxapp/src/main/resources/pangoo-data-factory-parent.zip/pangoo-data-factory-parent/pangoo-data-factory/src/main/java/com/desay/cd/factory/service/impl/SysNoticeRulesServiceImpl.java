package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysNoticeFrequencyDao;
import com.desay.cd.factory.dao.ISysNoticeRulesDao;
import com.desay.cd.factory.dao.ISysTriggerEventDao;
import com.desay.cd.factory.dao.ISysUserDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysNoticeFrequency;
import com.desay.cd.factory.entity.mysql.SysNoticeRules;
import com.desay.cd.factory.entity.mysql.SysTriggerEvent;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.ISysNoticeRulesService;

/**
 * SysNoticeRulesServiceImpl
 * 
 * @author pengdengfu
 *
 */
@Service
public class SysNoticeRulesServiceImpl implements ISysNoticeRulesService {
    @Autowired
    ISysNoticeRulesDao sysNoticeRulesDao;
    @Autowired
    ISysTriggerEventDao sysTriggerEventDao;
    @Autowired
    ISysNoticeFrequencyDao sysNoticeFrequencyDao;
    @Autowired
    ISysUserDao sysUserDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public SysNoticeRules addNoticeRule(String userId, Set<String> triggerEventIds, String noticeFreqId) {
        if (StringUtils.isEmpty(userId)) {
            throw new CustumException(ResultCodeEnum.USER_ID_CANNOT_NULL.getCode(), ResultCodeEnum.USER_ID_CANNOT_NULL.getMessage());
        }
        if (sysUserDao.findOne(userId) == null) {
            throw new CustumException(ResultCodeEnum.USER_NOT_EXIST.getCode(), ResultCodeEnum.USER_NOT_EXIST.getMessage());
        }
        if (userId.length() > Constanst.USER_ID_LENGTH) {
            throw new CustumException(ResultCodeEnum.USER_ID_TOO_LONG.getCode(), ResultCodeEnum.USER_ID_TOO_LONG.getMessage());
        }
        SysNoticeRules sysNoticeRules = sysNoticeRulesDao.findOne(userId);
        if (sysNoticeRules == null) {
            sysNoticeRules = new SysNoticeRules();
            sysNoticeRules.setUserId(userId);
        }
        if (triggerEventIds != null) {
            Set<SysTriggerEvent> sysTriggerEvents = new HashSet<>(16);
            for (String triggerEventId : triggerEventIds) {
                SysTriggerEvent sysTriggerEvent = sysTriggerEventDao.findOne(triggerEventId);
                if (sysTriggerEvent != null) {
                    sysTriggerEvents.add(sysTriggerEvent);
                }

            }
            sysNoticeRules.setTriggerEvents(sysTriggerEvents);
        }

        if (StringUtils.isNotEmpty(noticeFreqId)) {
            SysNoticeFrequency sysNoticeFrequency = sysNoticeFrequencyDao.findOne(noticeFreqId);
            if (sysNoticeFrequency != null) {
                sysNoticeRules.setSysNoticeFrequency(sysNoticeFrequency);
            }
        }
        try {
            return sysNoticeRulesDao.saveAndFlush(sysNoticeRules);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public void deleteNoticeRule(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new CustumException(ResultCodeEnum.USER_ID_CANNOT_NULL.getCode(), ResultCodeEnum.USER_ID_CANNOT_NULL.getMessage());
        }
        SysNoticeRules sysNoticeRules = sysNoticeRulesDao.findOne(userId);
        if (sysNoticeRules == null) {
            throw new CustumException(ResultCodeEnum.USER_NOT_EXIST.getCode(), ResultCodeEnum.USER_NOT_EXIST.getMessage());
        }
        try {
            sysNoticeRules.setTriggerEvents(null);
            sysNoticeRules.setSysNoticeFrequency(null);
            sysNoticeRulesDao.delete(userId);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }
    }

    @Override
    public List<SysNoticeRules> getNoticeRules(String userId) {
        if (StringUtils.isEmpty(userId)) {
            throw new CustumException(ResultCodeEnum.USER_ID_CANNOT_NULL.getCode(), ResultCodeEnum.USER_ID_CANNOT_NULL.getMessage());
        }
        if (StringUtils.isEmpty(userId)) {
            return sysNoticeRulesDao.findAll();
        } else {
            // 首先获取通用设置
            // 如果只有通用设置，修改userId后，则直接返回通用设置
            // 如果只有用户设置，直接返回用户设置
            // 如果通用设置和用户设置都有，返回用户设置
            //
            List<SysNoticeRules> sysNoticeRules = new ArrayList<>(16);
            SysNoticeRules normalRule = sysNoticeRulesDao.findOne(Constanst.ALL_USER);
            if (StringUtils.equals(userId, Constanst.ALL_USER)) {
                sysNoticeRules.add(normalRule);
            } else {
                SysNoticeRules userRule = sysNoticeRulesDao.findOne(userId);
                if (normalRule == null) {
                    sysNoticeRules.add(userRule);
                } else {
                    if (userRule != null) {
                        userRule.setUserId(normalRule.getUserId());
                        sysNoticeRules.add(userRule);
                    } else {
                        normalRule.setUserId(userId);
                        sysNoticeRules.add(normalRule);
                    }
                }
            }

            return sysNoticeRules;
        }

    }

}
