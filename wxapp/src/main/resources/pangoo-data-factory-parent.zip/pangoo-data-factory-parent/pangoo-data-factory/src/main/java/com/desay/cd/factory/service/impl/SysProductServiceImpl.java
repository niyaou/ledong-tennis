package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysDeviceDao;
import com.desay.cd.factory.dao.ISysProductDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysDevice;
import com.desay.cd.factory.entity.mysql.SysProduct;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.IFileService;
import com.desay.cd.factory.service.ISysProductService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: SysProductServiceImpl
 * @author: pengdengfu
 * @date: 2019年4月9日 上午9:09:08
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class SysProductServiceImpl implements ISysProductService {
    @Autowired
    private ISysProductDao sysProductDao;
    @Autowired
    private ISysDeviceDao sysDeviceDao;
    @Autowired
    IFileService fileService;

    @Override
    public SysProduct addProduct(String productName, String productDesc, String customName, Set<String> deviceIds, String status) {
        // 检查productName
        checkProductName(productName, true, null);
        SysProduct sysProduct = new SysProduct();
        if (StringUtils.isNotEmpty(productName)) {
            // 如果存在同名的，并且状态是删除的,则恢复状态
            SysProduct sysProductCheck = sysProductDao.findByProductName(productName);
            if (sysProductCheck != null && Constanst.ACTIVE_STATUS_0.equals(sysProductCheck.getIsActive())) {
                throw new CustumException(ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getCode(), ResultCodeEnum.DATA_DELETED_HAS_EXISTED.getMessage(), sysProductCheck);
            }
            sysProduct.setProductName(productName);
        }
        if (StringUtils.isNotEmpty(customName)) {
            sysProduct.setCustomName(customName);
        }
        if (StringUtils.isNotEmpty(productDesc)) {
            sysProduct.setProductDesc(productDesc);
        }
        // 更新产品设备信息
        updateProduceDevice(deviceIds, sysProduct);
        if (StringUtils.isNotEmpty(status)) {
            ControllerCommonUtils.checkStatus(status);
            sysProduct.setIsActive(status);
        }
        SysProduct product = null;
        try {
            product = sysProductDao.saveAndFlush(sysProduct);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.PRODUCT_NAME_EXISTED.getCode(), ResultCodeEnum.PRODUCT_NAME_EXISTED.getMessage());
        }

        return product;
    }

    public void deleteProduct2(String productId) {
        // 检查productId
        SysProduct sysProduct = checkProductId(productId);
        sysProduct.setIsActive(Constanst.ACTIVE_STATUS_0);
        try {
            sysProductDao.saveAndFlush(sysProduct);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }

    }

    @Override
    public void deleteProduct(String productId) {
        // 检查productId
        checkProductId(productId);
        Map<String, Long> referencedCount = new HashMap<>(1);
        // 确认没有文件使用
        long referencedFilesCount = (long) fileService.exploreFilesByStatusNotMatch("5", productId, null);
        if (referencedFilesCount > 0) {
            referencedCount.put("referencedFilesCount", referencedFilesCount);
        }
        if (!referencedCount.isEmpty()) {
            throw new CustumException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getCode(), ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage(), referencedCount);
        }
        sysProductDao.delete(productId);

    }

    @Override
    public void updateProduct(String productId, String productName, String productDesc, Set<String> deviceIds, String customName, String status) {
        // 检查productId
        SysProduct findOne = checkProductId(productId);
        // 检查productName
        checkProductName(productName, false, productId);
        if (StringUtils.isNotEmpty(productName)) {
            findOne.setProductName(productName);
        }
        if (StringUtils.isNotEmpty(customName)) {
            findOne.setCustomName(customName);
        }
        if (StringUtils.isNotEmpty(productDesc)) {
            findOne.setProductDesc(productDesc);
        }
        // 更新产品设备信息
        updateProduceDevice(deviceIds, findOne);
        // 更新状态
        if (StringUtils.isNotEmpty(status)) {
            ControllerCommonUtils.checkStatus(status);
            findOne.setIsActive(status);
        }
        try {
            sysProductDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.PRODUCT_NAME_EXISTED.getCode(), ResultCodeEnum.PRODUCT_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public void updateProductDeleteDevice(String productId, String deviceId) {
        // 检查productId
        SysProduct findOne = checkProductId(productId);

        if (StringUtils.isEmpty(deviceId)) {
            throw new CustumException(ResultCodeEnum.DEVICE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.DEVICE_ID_CANNOT_NULL.getMessage());
        }
        SysDevice sysDevice = sysDeviceDao.findOne(deviceId);
        if (sysDevice == null) {
            throw new CustumException(ResultCodeEnum.DEVICE_NOT_EXISTED.getCode(), ResultCodeEnum.DEVICE_NOT_EXISTED.getMessage());
        }
        Set<SysDevice> sysDevices = findOne.getSysDevices();
        if (sysDevices == null) {
            sysDevices = new HashSet<>(1);
        }
        if (!sysDevices.contains(sysDevice)) {
            throw new CustumException(ResultCodeEnum.PRODUCT_HAVING_NOT_DEVICE.getCode(), ResultCodeEnum.PRODUCT_HAVING_NOT_DEVICE.getMessage());
        }
        sysDevices.remove(sysDevice);
        try {
            sysProductDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.PRODUCT_NAME_EXISTED.getCode(), ResultCodeEnum.PRODUCT_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public Page<SysProduct> listProduct(String pageNo, String pageSize, String productId, String productName, String customName, String status, String deviceId, List<String> properties,
            String sortDirection) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, properties, sortDirection, "productName");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(productName)) {
            productName = productName.replaceAll("%", "\\\\%");
            productName = productName.replaceAll("_", "\\\\_");
        }
        final String productNameTmp = productName;

        if (StringUtils.isNotEmpty(customName)) {
            customName = customName.replaceAll("%", "\\\\%");
            customName = customName.replaceAll("_", "\\\\_");
        }
        final String customNameTmp = customName;
        Specification<SysProduct> specification = new Specification<SysProduct>() {
            @Override
            public Predicate toPredicate(Root<SysProduct> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(productId)) {
                    predicates.add(cb.equal(root.get("productId"), productId));
                }
                if (StringUtils.isNotEmpty(productNameTmp)) {
                    predicates.add(cb.like(root.get("productName"), "%" + productNameTmp + "%"));
                }
                if (StringUtils.isNotEmpty(customNameTmp)) {
                    predicates.add(cb.like(root.get("customName"), "%" + customNameTmp + "%"));
                }
                if (StringUtils.isNotEmpty(status)) {
                    ControllerCommonUtils.checkStatus(status);
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                if (StringUtils.isNotEmpty(deviceId)) {
                    Join<SysProduct, SysDevice> join = root.join("sysDevices", JoinType.INNER);
                    predicates.add(cb.equal(join.get("deviceId"), deviceId));
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        return sysProductDao.findAll(specification, pageable);
    }

    @Override
    public LinkedHashSet<String> getCustomsName(String productName, String customName, String sortDirection) {
        Pageable pageable = ControllerCommonUtils.getPager(Constanst.FIRST_PAGE_NO.toString(), Integer.toString(Integer.MAX_VALUE), null, sortDirection, "customName");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(productName)) {
            productName = productName.replaceAll("%", "\\\\%");
            productName = productName.replaceAll("_", "\\\\_");
        }
        final String productNameTmp = productName;

        if (StringUtils.isNotEmpty(customName)) {
            customName = customName.replaceAll("%", "\\\\%");
            customName = customName.replaceAll("_", "\\\\_");
        }
        final String customNameTmp = customName;
        Specification<SysProduct> specification = new Specification<SysProduct>() {
            @Override
            public Predicate toPredicate(Root<SysProduct> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();

                if (StringUtils.isNotEmpty(productNameTmp)) {
                    predicates.add(cb.like(root.get("productName"), "%" + productNameTmp + "%"));
                }
                if (StringUtils.isNotEmpty(customNameTmp)) {
                    predicates.add(cb.like(root.get("customName"), "%" + customNameTmp + "%"));
                }
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        Page<SysProduct> findAll = sysProductDao.findAll(specification, pageable);
        List<SysProduct> content = findAll.getContent();
        LinkedHashSet<String> customNames = new LinkedHashSet<String>(content.size());

        for (SysProduct sysProduct : content) {
            customNames.add(sysProduct.getCustomName());
        }
        return customNames;
    }

    /**
     * 检查productId
     * 
     * @param productId
     * @return
     */
    private SysProduct checkProductId(String productId) {
        if (StringUtils.isEmpty(productId)) {
            throw new CustumException(ResultCodeEnum.PRODUCT_ID_CANNOT_NULL.getCode(), ResultCodeEnum.PRODUCT_ID_CANNOT_NULL.getMessage());
        }
        SysProduct findOne = sysProductDao.findOne(productId);
        if (findOne == null) {
            throw new CustumException(ResultCodeEnum.PRODUCT_NOT_EXISTED.getCode(), ResultCodeEnum.PRODUCT_NOT_EXISTED.getMessage());
        }
        return findOne;
    }

    /**
     * 检查productName
     * 
     * @param productName
     * @param checkEmpty
     * @param productId
     * @return
     */
    private void checkProductName(String productName, boolean checkEmpty, String productId) {
        // 如果设备名称为空
        if (checkEmpty) {
            if (StringUtils.isEmpty(productName)) {
                throw new CustumException(ResultCodeEnum.PRODUCT_NAME_CANNOT_NULL.getCode(), ResultCodeEnum.PRODUCT_NAME_CANNOT_NULL.getMessage());
            }
            if (productName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.PRODUCT_NAME_TOO_LONG.getCode(), ResultCodeEnum.PRODUCT_NAME_TOO_LONG.getMessage());
            }
        } else {
            if (StringUtils.isNotEmpty(productName) && productName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.PRODUCT_NAME_TOO_LONG.getCode(), ResultCodeEnum.PRODUCT_NAME_TOO_LONG.getMessage());
            }
        }
        if (checkEmpty && StringUtils.isEmpty(productName)) {
            throw new CustumException(ResultCodeEnum.PRODUCT_NAME_CANNOT_NULL.getCode(), ResultCodeEnum.PRODUCT_NAME_CANNOT_NULL.getMessage());
        }

        if (checkEmpty && productName.length() > Constanst.NAME_LENGTH) {
            throw new CustumException(ResultCodeEnum.PRODUCT_NAME_TOO_LONG.getCode(), ResultCodeEnum.PRODUCT_NAME_TOO_LONG.getMessage());
        }

        if (StringUtils.isEmpty(productName)) {
            return;
        }
    }

    /**
     * 更新产品设备信息
     * 
     * @param deviceIds
     * @param findOne
     */
    private void updateProduceDevice(Set<String> deviceIds, SysProduct findOne) {
        if (findOne == null) {
            return;
        }
        // 设备列表
        if (deviceIds == null) {
            return;
        }
        Set<SysDevice> sysDevices = new HashSet<>(deviceIds.size());
        for (String deviceId : deviceIds) {
            SysDevice device = sysDeviceDao.findOne(deviceId);
            if (device != null) {
                sysDevices.add(device);
            }
        }
        // 替换为最新的设备列表
        findOne.setSysDevices(sysDevices);

    }

}
