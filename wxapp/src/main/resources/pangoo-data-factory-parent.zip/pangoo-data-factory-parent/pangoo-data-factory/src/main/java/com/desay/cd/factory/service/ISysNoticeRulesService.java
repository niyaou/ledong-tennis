package com.desay.cd.factory.service;

import java.util.List;
import java.util.Set;

import com.desay.cd.factory.entity.mysql.SysNoticeRules;

/**
 * ISysNoticeRulesService
 * 
 * @author pengdengfu
 *
 */
public interface ISysNoticeRulesService {
    /**
     * 添加用户通知规则
     * 
     * @param userId
     * @param triggerEvens
     * @param noticeFreq
     * @return
     */
    SysNoticeRules addNoticeRule(String userId, Set<String> triggerEvens, String noticeFreq);

    /**
     * 删除用户的通知规则
     * 
     * @param userId
     */
    void deleteNoticeRule(String userId);

    /**
     * 查询指定用户通知规则
     * 
     * @param userId
     * @return
     */
    List<SysNoticeRules> getNoticeRules(String userId);
}
