package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.transaction.annotation.Transactional;

import com.desay.cd.factory.entity.mysql.SysChunksLog;

/**
 * mysql文件断点续传记录
 * 
 * @author uidq1343
 *
 */
public interface ISysChunksLogService {
    
    
    /**
     * 向mysql写入断点续传记录
     * 
     * @param log
     * @return
     */
    SysChunksLog createChunksLog(SysChunksLog log);

    /**
     * 返回所有断点续传记录
     * 
     * @return
     */
    List<SysChunksLog> exploreLogs();
    
    
    
    /**
     * 根据名称和路径查询断点续传记录
     * @param parentId
     * @param displayName
     * @return
     */
    SysChunksLog queryLogByName(String parentId,String displayName);
    
    
    
    /**
     * 根据文件id查询断点续传记录
     * @param id
     * @return
     */
    SysChunksLog queryLogById(String id);
    
    /**
     * 根据用户id查询记录
     * @param userId
     * @param pageNo
     * @param pageSize
     * @return
     */
    Page<SysChunksLog> queryLogByUserId(String userId,Integer pageNo,Integer pageSize);
    
    /**
     * 更新记录
     * @param log
     * @return
     */
    SysChunksLog uploadChunksLog(SysChunksLog log);
    
    /**
     * 删除mysql断点续传记录
     * 
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    boolean deleteChunksLog(String id);

   

}
