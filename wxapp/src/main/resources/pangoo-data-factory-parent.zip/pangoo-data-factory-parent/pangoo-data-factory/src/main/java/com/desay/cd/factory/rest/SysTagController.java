package com.desay.cd.factory.rest;

import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysLevelData;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.SysLevelDataVo;
import com.desay.cd.factory.service.ISysLevelDataService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/***
 * 标签管理
 * 
 * @author pengdengfu
 *
 */

@Api(tags = "SysTagController", value = "NEW-标签管理")
@RestController
@Validated
public class SysTagController {
    @Autowired
    ISysLevelDataService sysTagService;

    @RequestMapping(value = "/management/tags", method = RequestMethod.POST)
    @ApiOperation(value = "标签管理-添加标签", notes = "")
    @LogAnnotation(action = LogActionEnum.TAG, message = "标签管理-添加标签")
    public ResponseEntity<?> addTag(@RequestBody @Validated SysLevelDataVo sysLevelDataVo) {
        try {
            String tagId = sysTagService.add(sysLevelDataVo, "1");
            return new ResponseEntity<Object>(CommonResponse.success(tagId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/tags/{tagId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "标签管理-删除标签", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "tagId", value = "标签ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.TAG, message = "标签管理-删除标签")
    public ResponseEntity<?> deleteTag(@PathVariable(value = "tagId", required = true) String tagId) {
        try {
            sysTagService.delete(tagId, "1");
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @RequestMapping(value = "/management/tags/{tagId}", method = RequestMethod.PUT)
    @ApiOperation(value = "标签管理-更新标签", notes = "")
    @LogAnnotation(action = LogActionEnum.TAG, message = "标签管理-更新标签")
    public ResponseEntity<?> updateTag(@PathVariable(value = "tagId", required = true) String tagId, @RequestBody @Validated SysLevelDataVo sysTagVo) {
        try {
            sysTagService.update(tagId, sysTagVo, true, "1");
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/tags/{tagId}", method = RequestMethod.PATCH)
    @ApiOperation(value = "标签管理-更新标签", notes = "")
    @LogAnnotation(action = LogActionEnum.TAG, message = "标签管理-更新标签")
    public ResponseEntity<?> updateTagPart(@PathVariable(value = "tagId", required = true) String tagId, @RequestBody SysLevelDataVo sysTagVo) {
        try {
            sysTagService.update(tagId, sysTagVo, false, "1");
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/tags", method = RequestMethod.GET)
    @ApiOperation(value = "标签管理-查询标签", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "tagId", value = "tagId", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "tagName", value = "tag名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "tagNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.TAG, message = "标签管理-查询标签")
    public ResponseEntity<?> getTags(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "tagId", required = false) String tagId,
            @RequestParam(value = "tagName", required = false) String tagName, @RequestParam(value = "tagNameLike", required = false) String tagNameLike,
            @RequestParam(value = "status", required = false) String status) {
        Page<SysLevelData> tags = sysTagService.search("1", tagId, tagName, tagNameLike, status, pageNo, pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(tags), HttpStatus.OK);
    }
}
