package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.auth.LdapAuthorize;
import com.desay.cd.auth.dto.PersonDto;
import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.IDataDictionaryDao;
import com.desay.cd.factory.dao.ISysGroupDao;
import com.desay.cd.factory.dao.ISysSubSystemDao;
import com.desay.cd.factory.dao.ISysUserDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.CleanStrategy;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.entity.mysql.SysGroup;
import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.rest.vo.SysGroupVo;
import com.desay.cd.factory.service.ISysGroupService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: SysGroupServiceImpl
 * @author: pengdengfu
 * @date: 2019年11月1日 下午12:01:07
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class SysGroupServiceImpl implements ISysGroupService {
    @Autowired
    private ISysGroupDao sysGroupDao;
    @Autowired
    private ISysSubSystemDao sysSubSystemDao;
    @Autowired
    private IDataDictionaryDao dataDictionaryDao;
    @Autowired
    private ISysUserDao sysUserDao;
    @Autowired
    LdapAuthorize ldapAuthorize;
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public String add(SysGroupVo sysGroupVo) {
        try {
            SysGroup saved = sysGroupDao.saveAndFlush(check(sysGroupVo, true, null));
            return saved.getGroupId();
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    private SysGroup check(SysGroupVo sysGroupVo, boolean isOverall, SysGroup sysGroup) {
        if (sysGroup == null) {
            sysGroup = new SysGroup();
        }
        if (isOverall) {
            BeanUtils.copyProperties(sysGroupVo, sysGroup, "createTime");
        } else {
            BeanUtils.copyProperties(sysGroupVo, sysGroup, ControllerCommonUtils.getNullPropertyNames(sysGroupVo));
        }

        String subsystemId = sysGroupVo.getSubsystemId();
        if (StringUtils.isNotEmpty(subsystemId)) {
            SysSubSystem findOne = sysSubSystemDao.findOne(subsystemId);
            if (findOne == null) {
                throw new BusinessException(ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED, null, ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED.getMessage());
            }
            sysGroup.setSysSubsystem(findOne);
        } else if (subsystemId != null && StringUtils.EMPTY.equals(subsystemId)) {
            sysGroup.setSysSubsystem(null);
        }

        Set<String> abilityIds = sysGroupVo.getAbilityIds();
        if (abilityIds != null && abilityIds.size() > 0) {
            Set<DataDictionary> anilities = new HashSet<>(16);
            for (String abilityId : abilityIds) {
                DataDictionary findOne = dataDictionaryDao.findOne(abilityId);
                if (findOne != null) {
                    anilities.add(findOne);
                }
            }
            sysGroup.setAbilities(anilities);
        } else if (abilityIds != null && abilityIds.size() <= 0) {
            sysGroup.setAbilities(null);
        }

        Set<String> masterIds = sysGroupVo.getMasterIds();
        Set<String> memberIds = sysGroupVo.getMemberIds();

        if (masterIds != null && memberIds != null && masterIds.size() > 0 && memberIds.size() > 0) {
            Set<String> result = new HashSet<String>();
            result.clear();
            result.addAll(masterIds);
            result.retainAll(memberIds);
            if (result.size() > 0) {
                throw new BusinessException(ResultCodeEnum.CAN_NOT_TWO_ROLE_SAME_TIME, null, ResultCodeEnum.CAN_NOT_TWO_ROLE_SAME_TIME.getMessage());
            }
        }

        if (masterIds != null && masterIds.size() > 0) {
            Set<SysUser> masters = new HashSet<>(16);
            for (String masterId : masterIds) {
                checkUserId(sysGroup, masters, masterId);
            }
            sysGroup.setMasters(masters);
        } else if (masterIds != null && masterIds.size() <= 0) {
            sysGroup.setMasters(null);
        }

        if (memberIds != null && memberIds.size() > 0) {
            Set<SysUser> members = new HashSet<>(16);
            for (String memberId : memberIds) {
                checkUserId(sysGroup, members, memberId);
            }
            sysGroup.setMembers(members);
        } else if (memberIds != null && memberIds.size() <= 0) {
            sysGroup.setMembers(null);
        }
        return sysGroup;
    }

    private void checkUserId(SysGroup sysGroup, Set<SysUser> masters, String masterId) {
        SysUser findOne = sysUserDao.findOne(masterId);
        if (findOne != null) {
            masters.add(findOne);
        } else {
            Map<String, ArrayList<String>> searchUserById = null;
            try {
                searchUserById = ldapAuthorize.searchUserById(masterId);
            } catch (Exception e) {
                throw new CustumException(ResultCodeEnum.LDAP_CONNECT_FAILED.getCode(), ResultCodeEnum.LDAP_CONNECT_FAILED.getMessage());
            }
            if (searchUserById == null) {
                throw new CustumException(ResultCodeEnum.UID_USER_NOT_EXIST.getCode(), ResultCodeEnum.UID_USER_NOT_EXIST.getMessage());
            }
            SysUser sysUser = new SysUser();
            sysUser.setUserId(masterId);
            // 从缓存中取用户信息
            getInfoFromCache(sysUser);
            sysGroup.getSysSubsystem();
            Set<SysSubSystem> sysSubSystems = new HashSet<>(1);
            sysSubSystems.add(sysGroup.getSysSubsystem());
            sysUser.setSysSubSystems(sysSubSystems);
            masters.add(sysUserDao.save(sysUser));
        }
    }

    /**
     * 从缓存中取用户信息
     * 
     * @param sysUser
     */
    private void getInfoFromCache(SysUser sysUser) {
        PersonDto person = (PersonDto) ldapAuthorize.get(sysUser.getUserId());
        if (person != null) {
            ArrayList<String> mail = person.getMail();
            if (mail != null && mail.size() > 0) {
                sysUser.setEmail(mail.get(0));
            }
            ArrayList<String> mailnickname = person.getName();
            if (mailnickname != null && mailnickname.size() > 0) {
                sysUser.setUserName(mailnickname.get(0));
            }
            ArrayList<String> thumbnailPhoto = person.getThumbnailPhoto();
            if (thumbnailPhoto != null && thumbnailPhoto.size() > 0) {
                sysUser.setAvatar(thumbnailPhoto.get(0));
            }
        }
    }

    @Override
    public void delete(String groupId) {
        SysGroup findOne = sysGroupDao.findOne(groupId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        // 判断组是否有任务
        // boolean checkTask = ControllerCommonUtils.checkTask(groupId, null);
        // if (!checkTask) {
        // throw new BusinessException(ResultCodeEnum.TASK_NOT_FINISHED, null,
        // ResultCodeEnum.TASK_NOT_FINISHED.getMessage());
        // }
        try {
            sysGroupDao.delete(groupId);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @Override
    public void update(String groupId, SysGroupVo sysGroupVo, boolean isOverall) {
        SysGroup findOne = sysGroupDao.findOne(groupId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            sysGroupDao.saveAndFlush(check(sysGroupVo, isOverall, findOne));
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public Page<SysGroup> search(String userId, String groupId, String subsystemId, String groupName, String groupNameLike, Set<String> abilityIds, String abilityIdsCondition,
            String abilityName, String abilityNameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, sortProperties, "createTime");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(groupName)) {
            groupName = groupName.replaceAll("%", "\\\\%");
            groupName = groupName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(abilityName)) {
            abilityName = abilityName.replaceAll("%", "\\\\%");
            abilityName = abilityName.replaceAll("_", "\\\\_");
        }

        final String groupNameTmp = groupName;
        final String abilityNameTmp = abilityName;
        Specification<SysGroup> specification = new Specification<SysGroup>() {
            @Override
            public Predicate toPredicate(Root<SysGroup> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(groupId)) {
                    predicates.add(cb.equal(root.get("groupId"), groupId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                if (StringUtils.isNotEmpty(groupNameTmp)) {
                    if (StringUtils.equalsIgnoreCase(groupNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.like(root.get("groupName"), "%" + groupNameTmp + "%"));
                    } else {
                        predicates.add(cb.equal(root.get("groupName"), groupNameTmp));
                    }
                }
                if (StringUtils.isNotEmpty(userId)) {
                    Join<SysGroup, SysUser> joinMember = root.join("members", JoinType.LEFT);
                    Join<SysGroup, SysUser> joinMaster = root.join("masters", JoinType.LEFT);
                    predicates.add(cb.or(cb.equal(joinMember.get("userId"), userId), cb.equal(joinMaster.get("userId"), userId)));
                }
                if (StringUtils.isNotEmpty(subsystemId)) {
                    Join<SysGroup, SysSubSystem> join = root.join("sysSubsystem", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("subsystemId"), subsystemId));
                }

                if (abilityIds != null && abilityIds.size() > 0) {
                    Join<SysGroup, DataDictionary> join = root.join("abilities", JoinType.LEFT);
                    List<Predicate> restrictions = new ArrayList<>(16);

                    for (String abilityId : abilityIds) {
                        restrictions.add(cb.equal(join.get("dataId"), abilityId));
                    }
                    String and = "and";
                    if (StringUtils.equalsIgnoreCase(and, abilityIdsCondition)) {
                        predicates.add(cb.and(restrictions.toArray(new Predicate[] {})));
                    } else {
                        predicates.add(cb.or(restrictions.toArray(new Predicate[] {})));
                    }

                }

                if (StringUtils.isNotEmpty(abilityNameTmp)) {
                    Join<CleanStrategy, DataDictionary> join = root.join("abilities", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(abilityNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(join.get("name"), "%" + abilityNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(join.get("name"), abilityNameTmp));
                    }
                }
                query.distinct(true);
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        return sysGroupDao.findAll(specification, pageable);
    }

}
