package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ISysNoticeFrequencyDao;
import com.desay.cd.factory.entity.mysql.SysNoticeFrequency;
import com.desay.cd.factory.rest.vo.AddNoticeFrequencyVo;

/**
 * SysNoticeFrequencyControllerTest
 * 
 * @author pengdengfu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SysNoticeFrequencyControllerTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    ISysNoticeFrequencyDao sysNoticeFrequencyDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testNoticeFrequency() throws Exception {
        // 获取密钥
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

        AddNoticeFrequencyVo addNoticeFrequencyVo = new AddNoticeFrequencyVo();
        addNoticeFrequencyVo.setNoticeFrequencyName("testNoticeFrequencyName");

        String requestJson = JSONObject.toJSONString(addNoticeFrequencyVo);
        // 添加
        mvc.perform(post("/management/noticeFrequency").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 重复添加
        mvc.perform(post("/management/noticeFrequency").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20035));
        // 查询
        params.clear();

        MvcResult mvcResult = mvc.perform(get("/management/noticeFrequency")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 删除
        params.clear();
        SysNoticeFrequency sysNoticeFrequency = new SysNoticeFrequency();
        sysNoticeFrequency.setFrequencyName("testNoticeFrequencyName");
        Example<SysNoticeFrequency> example2 = Example.of(sysNoticeFrequency);
        SysNoticeFrequency findOne2 = sysNoticeFrequencyDao.findOne(example2);
        mvc.perform(delete("/management/noticeFrequency/" + findOne2.getFrequencyId()).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 删除不存在的数据
        mvc.perform(delete("/management/noticeFrequency/testNotExistData").contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20036));

    }

}
