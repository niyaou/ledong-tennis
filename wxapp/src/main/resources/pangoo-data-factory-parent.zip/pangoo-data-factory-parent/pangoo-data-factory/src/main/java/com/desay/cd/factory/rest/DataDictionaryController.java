package com.desay.cd.factory.rest;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.DataDictionaryVo;
import com.desay.cd.factory.service.IDataDictionaryService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: DataDictionaryController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "DataDictionaryController", value = "NEW-数据字典管理")
@RestController
@Validated
public class DataDictionaryController {
    @Autowired
    private IDataDictionaryService dataDictionaryService;

    @RequestMapping(value = "/management/dictionary", method = RequestMethod.POST)
    @ApiOperation(value = "数据字典管理-添加数据", notes = "")
    @LogAnnotation(action = LogActionEnum.DATA_DICTIONARY, message = "数据字典管理-添加数据")
    public ResponseEntity<?> add(@RequestBody @Validated DataDictionaryVo dataDictionaryVo) {
        DataDictionary dataDictionary = new DataDictionary();
        BeanUtils.copyProperties(dataDictionaryVo, dataDictionary, ControllerCommonUtils.getNullPropertyNames(dataDictionaryVo));

        try {
            String dataId = dataDictionaryService.add(dataDictionary);
            return new ResponseEntity<Object>(CommonResponse.success(dataId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/dictionary/{dataId}", method = RequestMethod.DELETE)
    @ApiImplicitParams({ @ApiImplicitParam(name = "dataId", value = "数据ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "数据字典管理-删除数据", notes = "")
    @LogAnnotation(action = LogActionEnum.DATA_DICTIONARY, message = "数据字典管理-删除数据")
    public ResponseEntity<?> add(@PathVariable(value = "dataId", required = true) String dataId) {
        try {
            dataDictionaryService.delete(dataId);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @RequestMapping(value = "/management/dictionary/{dataId}", method = RequestMethod.PUT)
    @ApiImplicitParams({ @ApiImplicitParam(name = "dataId", value = "数据ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "数据字典管理-更新数据-整体更新", notes = "用提供的对象数据，替换原始数据,必填字段必须填写")
    @LogAnnotation(action = LogActionEnum.DATA_DICTIONARY, message = "数据字典管理-更新数据-整体更新")
    public ResponseEntity<?> put(@PathVariable(value = "dataId", required = true) String dataId, @Validated @RequestBody DataDictionaryVo dataDictionaryVo) {
        DataDictionary dataDictionary = new DataDictionary();
        BeanUtils.copyProperties(dataDictionaryVo, dataDictionary);
        dataDictionary.setDataId(dataId);

        try {
            dataDictionaryService.update(dataDictionary, true);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/dictionary/{dataId}", method = RequestMethod.PATCH)
    @ApiImplicitParams({ @ApiImplicitParam(name = "dataId", value = "数据ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "数据字典管理-更新数据-局部更新", notes = "用提供对象的指定字段，替换原始对象的指定字段。")
    @LogAnnotation(action = LogActionEnum.DATA_DICTIONARY, message = "数据字典管理-更新数据-局部更新")
    public ResponseEntity<?> update(@PathVariable(value = "dataId", required = true) String dataId, @RequestBody DataDictionaryVo dataDictionaryVo) {
        DataDictionary dataDictionary = new DataDictionary();
        BeanUtils.copyProperties(dataDictionaryVo, dataDictionary);
        dataDictionary.setDataId(dataId);

        try {
            dataDictionaryService.update(dataDictionary, false);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/dictionary", method = RequestMethod.GET)
    @ApiOperation(value = "数据字典管理-查询数据", notes = "")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "dataId", value = "数据Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "classId", value = "数据类别Id，清洗优先级：0,标注优先级：1,标注能力：2", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.DATA_DICTIONARY, message = "数据字典管理-查询数据")
    public ResponseEntity<?> search(@RequestParam(value = "sortProperties", required = false) List<String> sortProperties,
            @RequestParam(value = "dataId", required = false) String dataId, @RequestParam(value = "classId", required = false) String classId,
            @RequestParam(value = "status", required = false) String status) {
        Page<DataDictionary> rlt = dataDictionaryService.search(dataId, classId, status, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(rlt.getContent()), HttpStatus.OK);
    }

}
