package com.desay.cd.factory.entity;

import java.io.Serializable;

import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.utils.StringUtil;

/**
 * es文件索引
 * 
 * @author uidq1343
 *
 */
public class FileIndex implements Serializable {

    private static final long serialVersionUID = -4708879796669319427L;
    /** 文件名称 */
    private String fileName="";
    /** 文件类型 */
    private String fileType="";
    /**文件全路径 */
    private String filePath="";
    /** 创建者 */
    private String creator="";
    /** 审核者 */
    private String audit="";
    /** 创建时间 */
    private String createTime="0";
    /** 更新时间 */
    private String updateTime="0";
    /** 审核时间 */
    private String auditTime="0";
    /** 取消时间 */
    private String cancelTime="0";
    /** 删除时间 */
    private String deleteTime="0" ;
    /** 产品id*/
    private String productId="";
    /** 产品名称*/
    private String productName="";
    /** 设备id*/
    private String deviceId="";
    /** 设备名称*/
    private String deviceName="";
    /** 车型名称*/
    private String vehicleType="";
    /** 审核详细信息 */
    private String auditMessage="";
    /** 文件大小*/
    private Double fileSize=0.0;
    
    /** 文件状态   0：未完成，1：待审核，2，待清洗，3：入库，4：拒绝，5：已删除，6：已取消 ，7：预留       */
    private Integer status=FileStatusEnum.UN_FINISHED.getCode();

    /** 缩略图路径*/
    private String thumbPath="";
    
    
    public FileIndex(String fileName,String fileType,String filePath, String creator,String createTime,Double fileSize,String productId,
            String productName, String deviceId ,String deviceName ) {
      if(StringUtil.isNotEmpty(fileName)) {
          this.fileName=fileName;
      }
      if(StringUtil.isNotEmpty(fileType)) {
          this.fileType=fileType;
      }
      if(StringUtil.isNotEmpty(filePath)) {
          this.filePath=filePath;
      }
      if(StringUtil.isNotEmpty(creator)) {
          this.creator=creator;
      }
      if(StringUtil.isNotEmpty(createTime)) {
          this.createTime=createTime;
          this.updateTime=createTime;
      }
          this.fileSize=fileSize;
      if(StringUtil.isNotEmpty(productId)) {
          this.productId=productId;
      }
      if(StringUtil.isNotEmpty(productName)) {
          this.productName=productName;
      }
      if(StringUtil.isNotEmpty(deviceId)) {
          this.deviceId=deviceId;
      }
      if(StringUtil.isNotEmpty(deviceName)) {
          this.deviceName=deviceName;
      }
    }

    
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getAudit() {
        return audit;
    }

    public void setAudit(String audit) {
        this.audit = audit;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }


    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }


    public String getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(String auditTime) {
        this.auditTime = auditTime;
    }

    public String getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(String cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(String deleteTime) {
        this.deleteTime = deleteTime;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getAuditMessage() {
        return auditMessage;
    }

    public void setAuditMessage(String auditMessage) {
        this.auditMessage = auditMessage;
    }

    public Double getFileSize() {
        return fileSize;
    }

    public void setFileSize(Double fileSize) {
        this.fileSize = fileSize;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getThumbPath() {
        return thumbPath;
    }

    public void setThumbPath(String thumbPath) {
        this.thumbPath = thumbPath;
    }


    public String getVehicleType() {
        return vehicleType;
    }


    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }
    
 
    
    
  
   
}
