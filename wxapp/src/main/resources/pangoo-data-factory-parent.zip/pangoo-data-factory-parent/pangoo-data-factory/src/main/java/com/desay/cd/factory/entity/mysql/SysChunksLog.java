package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 *断点续传未完成任务记录
 * 
 * @author nixuchun
 *
 */
@Entity
@Table(name = "sys_chunks_log") 
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "chunksLogId")
public class SysChunksLog implements Serializable {

    
    private static final long serialVersionUID = 2957714536432653172L;


    public SysChunksLog() {
        
    }
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    @Column(name = "chunkslog_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String chunksLogId;

    /** 文件夹id*/
    @Column(name = "file_id", unique = false, nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '文件id '")
    private String fileId;

    
    /** 文件名 */
    @Column(name = "file_name", unique = false, nullable = false,  columnDefinition = "text COMMENT '文件名'")
    private String fileName;
    
    /** 总块数 */
    @Column(name = "chunks",nullable = false,  columnDefinition = "int COMMENT '总块数'")
    private Integer chunks;

    
    
    /**当前块数 */
    @Column(name = "current",  nullable = false,  columnDefinition = "int COMMENT '当前块数'")
    private Integer current;

    /**用户id */
    @Column(name = "user_Id",  nullable = false,  columnDefinition = "text COMMENT '上传者'")
    private String userId;

    public String getChunksLogId() {
        return chunksLogId;
    }



    public void setChunksLogId(String chunksLogId) {
        this.chunksLogId = chunksLogId;
    }



    public String getFileId() {
        return fileId;
    }



    public void setFileId(String fileId) {
        this.fileId = fileId;
    }



    public String getFileName() {
        return fileName;
    }



    public void setFileName(String fileName) {
        this.fileName = fileName;
    }



    public Integer getChunks() {
        return chunks;
    }



    public void setChunks(Integer chunks) {
        this.chunks = chunks;
    }



    public Integer getCurrent() {
        return current;
    }



    public void setCurrent(Integer current) {
        this.current = current;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }



    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((chunks == null) ? 0 : chunks.hashCode());
        result = prime * result + ((chunksLogId == null) ? 0 : chunksLogId.hashCode());
        result = prime * result + ((current == null) ? 0 : current.hashCode());
        result = prime * result + ((fileId == null) ? 0 : fileId.hashCode());
        result = prime * result + ((fileName == null) ? 0 : fileName.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        return result;
    }



    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysChunksLog other = (SysChunksLog) obj;
        if (chunks == null) {
            if (other.chunks != null) {
                return false;
            }
        } else if (!chunks.equals(other.chunks)) {
            return false;
        }
        if (chunksLogId == null) {
            if (other.chunksLogId != null) {
                return false;
            }
        } else if (!chunksLogId.equals(other.chunksLogId)) {
            return false;
        }
        if (current == null) {
            if (other.current != null) {
                return false;
            }
        } else if (!current.equals(other.current)) {
            return false;
        }
        if (fileId == null) {
            if (other.fileId != null) {
                return false;
            }
        } else if (!fileId.equals(other.fileId)) {
            return false;
        }
        if (fileName == null) {
            if (other.fileName != null) {
                return false;
            }
        } else if (!fileName.equals(other.fileName)) {
            return false;
        }
        if (userId == null) {
            if (other.userId != null) {
                return false;
            }
        } else if (!userId.equals(other.userId)) {
            return false;
        }
        return true;
    }



    @Override
    public String toString() {
        return "SysChunksLog [chunksLogId=" + chunksLogId + ", fileId=" + fileId + ", fileName=" + fileName
                + ", chunks=" + chunks + ", current=" + current + ", userId=" + userId + "]";
    }

}
