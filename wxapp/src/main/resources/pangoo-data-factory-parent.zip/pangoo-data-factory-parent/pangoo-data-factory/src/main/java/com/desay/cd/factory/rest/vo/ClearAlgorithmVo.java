package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: ClearAlgorithmVo
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:37:13
 */
@Data
public class ClearAlgorithmVo implements Serializable {
    private static final long serialVersionUID = -8420251510052857928L;

    @NotEmpty
    @ApiModelProperty(value = "算法名称")
    @Length(min = 1, max = 50, message = "length长度在[1,50]之间")
    private String algName;

    @ApiModelProperty(value = "算法描述")
    private String algDesc;

    @ApiModelProperty(value = "镜像名称")
    private String imageName;

    @ApiModelProperty(value = "镜像版本")
    private String imageVer;

    @ApiModelProperty(value = "镜像参数")
    private String imageParams;

    @ApiModelProperty(value = "运行环境")
    private String imageEnv;

    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", allowableValues = "1,0", example = "1", required = false)
    @Range(min = 0, max = 1, message = "状态必须在[0,1]")
    private Integer isActive = 1;
}
