package com.desay.cd.factory.enums;

/**
 * 文件操作动作枚举
 * 
 * @author uidq1163
 *
 */
public enum LogFileOptEnum {
    /** 增加 */
    CREATED("增加"),
    
    /** 删除 */
    DELETE("删除"),
    /** 取消*/
    CANCELED("取消"),
    /** 上传完成*/
    UPLOADED("上传完成"),
    /** 审核通过 */
    AUDITED("审核通过"),
    /** 审核拒绝 */
    DENIED("审核拒绝"),
    /** 清洗完成 */
    CLEANED("清洗完成"),
    /**入库 */
    STORED("入库");

    String value;

    LogFileOptEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
