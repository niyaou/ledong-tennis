package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysLevelData;
import com.desay.cd.factory.rest.vo.SysLevelDataVo;

/**
 * 标签服务
 * 
 * @author pengdengfu
 *
 */
public interface ISysLevelDataService {
    /**
     * 增加
     * 
     * @param sysLevelDataVo
     * @param dataType
     * @return
     */
    String add(SysLevelDataVo sysLevelDataVo, String dataType);

    /**
     * 删除
     * 
     * @param id
     * @param dataType
     */
    void delete(String id, String dataType);

    /**
     * 更新
     * 
     * @param id
     * @param sysLevelDataVo
     * @param isOverall
     * @param dataType
     */
    void update(String id, SysLevelDataVo sysLevelDataVo, boolean isOverall, String dataType);

    /**
     * 查询
     * 
     * @param dataType
     * @param id
     * @param name
     * @param nameLike
     * @param status
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @return
     */
    Page<SysLevelData> search(String dataType, String id, String name, String nameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties);

}
