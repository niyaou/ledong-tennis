package com.desay.cd.factory.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddRoleVo;
import com.desay.cd.factory.rest.vo.UpdateRoleVo;
import com.desay.cd.factory.service.ISysRoleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/***
 * 用户角色管理
 * 
 * @author pengdengfu
 *
 */
@RestController
@Api(value = "用户管理-角色管理", tags = "SysRoleController")
public class SysRoleController {
    @Autowired
    private ISysRoleService sysRoleService;

    /**
     * 添加角色
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/roles", method = RequestMethod.POST)
    @ApiOperation(value = "角色管理-添加角色", notes = "")
    @LogAnnotation(action = LogActionEnum.ROLE, message = "角色管理-添加角色")
    public ResponseEntity<?> addRole(@RequestBody AddRoleVo addRole) {
        SysRole sysRole = sysRoleService.addRole(addRole.getRoleName(), addRole.getRoleDesc(), addRole.getPermissions(), addRole.getSubsystemId());
        return new ResponseEntity<Object>(CommonResponse.success(sysRole.getRoleId()), HttpStatus.OK);
    }

    /**
     * 删除角色
     * 
     * @param roleName
     * @param roleDesc
     * @param permissions
     * @return
     */
    @RequestMapping(value = "/management/roles/{roleId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "角色管理-删除角色", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.ROLE, message = "删除角色")
    public ResponseEntity<?> deleteRole(@PathVariable(value = "roleId", required = true) String roleId) {
        sysRoleService.deleteRole(roleId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 角色管理-更新角色
     * 
     * @param roleId
     * @param updateRoleVo
     * @return
     */
    @RequestMapping(value = "/management/roles/{roleId}", method = RequestMethod.PUT)
    @ApiOperation(value = "角色管理-更新角色", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.ROLE, message = "角色管理-更新角色")
    public ResponseEntity<?> updateRole(@PathVariable(value = "roleId", required = true) String roleId, @RequestBody UpdateRoleVo updateRoleVo) {
        sysRoleService.updateRole(roleId, updateRoleVo.getRoleName(), updateRoleVo.getRoleDesc(), updateRoleVo.getPermissionIds(), updateRoleVo.getSubsystemId());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 角色管理-更新角色-删除权限
     * 
     * @param roleId
     * @param permissionId
     * @return
     */
    @RequestMapping(value = "/management/roles/{roleId}/permissions/{permissionId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "角色管理-更新角色-删除权限", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "String", paramType = "path"),
            @ApiImplicitParam(name = "permissionId", value = "权限Id", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.ROLE, message = "角色管理-更新角色-删除权限")
    public ResponseEntity<?> updateRoleDeletePermission(@PathVariable(value = "roleId", required = true) String roleId, @PathVariable(value = "permissionId", required = true) String permissionId) {
        sysRoleService.updateRoleDeletePermission(roleId, permissionId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取系统角色
     * 
     * @param pageNo
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/management/roles", method = RequestMethod.GET)
    @ApiOperation(value = "角色管理-获取系统角色", notes = "当pageNo，pageSize为空时，默认返回第一页10条数据.")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "角色ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleName", value = "角色名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "子系统Id（精确查询）.通过关键词“global”查询全局角色", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户Id，查询该用户拥有的角色", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.ROLE, message = "获取系统角色")
    public ResponseEntity<?> getRoles(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "roleId", required = false) String roleId, @RequestParam(value = "roleName", required = false) String roleName,
            @RequestParam(value = "subsystemId", required = false) String subsystemId, @RequestParam(value = "userId", required = false) String userId,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection,
            @RequestParam(value = "status", required = false) String status) {
        Page<SysRole> sysRoles = sysRoleService.getSysRoles(pageNo, pageSize, roleId, roleName, subsystemId, userId, sortProperties, sortDirection, status);
        return new ResponseEntity<Object>(CommonResponse.success(sysRoles), HttpStatus.OK);
    }

}
