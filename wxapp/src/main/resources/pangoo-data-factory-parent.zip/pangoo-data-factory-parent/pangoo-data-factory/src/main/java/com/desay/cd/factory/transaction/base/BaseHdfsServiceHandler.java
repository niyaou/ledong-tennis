package com.desay.cd.factory.transaction.base;

import com.desay.cd.factory.service.impl.HdfsFileServiceImpl;


/**
 * hdfs文件操作事务基类
 * @author uidq1343
 *
 */
public abstract class BaseHdfsServiceHandler extends  AbstractFileHandler {
    protected HdfsFileServiceImpl hdfsFileService;

    @Override
    protected void clean() {
        if(hdfsFileService!=null) {
            hdfsFileService=null;
        }
    }

    @Override
    public <T> void setResource(T resouce) {
        if( resouce instanceof HdfsFileServiceImpl) {
            hdfsFileService=(HdfsFileServiceImpl)resouce;
        }
        
    }

}
