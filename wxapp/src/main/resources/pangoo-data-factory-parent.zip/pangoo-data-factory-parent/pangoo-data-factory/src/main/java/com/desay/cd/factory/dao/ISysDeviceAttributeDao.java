package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.cd.factory.entity.mysql.SysDeviceAttribute;

/**
 * 
 * @ClassName: ISysDeviceAttributeDao
 * @author: pengdengfu
 * @date: 2019年4月8日 上午11:00:56
 */
public interface ISysDeviceAttributeDao extends JpaRepository<SysDeviceAttribute, Serializable> {
    /**
     * 查询属性是否存在
     * 
     * @param deviceId
     * @param attributeName
     * @return
     */
    @Query(nativeQuery = true, value = "select * from sys_device_attribute where device_id=:deviceId and attribute_name=:attributeName ")
    SysDeviceAttribute findByDeviceAndAttributeName(@Param(value = "deviceId") String deviceId, @Param(value = "attributeName") String attributeName);

}
