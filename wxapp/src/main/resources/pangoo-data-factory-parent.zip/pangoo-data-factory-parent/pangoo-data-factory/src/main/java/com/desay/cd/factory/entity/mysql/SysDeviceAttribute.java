package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 
 * @ClassName: DeviceAttribute
 * @author: pengdengfu
 * @date: 2019年4月8日 上午9:26:38
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_device_attribute", uniqueConstraints = { @UniqueConstraint(columnNames = { "device_id", "attribute_name" }) })
public class SysDeviceAttribute implements Serializable {

    private static final long serialVersionUID = -2928695175442867843L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "attribute_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String attributeId;

    /** 设备属性名称 */
    @Column(name = "attribute_name", nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '设备属性名称'")
    private String attributeName;

    /** 设备属性值 */
    @Column(name = "attribute_Value", nullable = true, length = 60, columnDefinition = "varchar(60) COMMENT '设备属性值'")
    private String attributeValue;

    /** 版本 */
    @Version
    @JsonIgnore
    private Long version;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((attributeId == null) ? 0 : attributeId.hashCode());
        result = prime * result + ((attributeName == null) ? 0 : attributeName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysDeviceAttribute other = (SysDeviceAttribute) obj;
        if (attributeId == null) {
            if (other.attributeId != null) {
                return false;
            }
        } else if (!attributeId.equals(other.attributeId)) {
            return false;
        }
        if (attributeName == null) {
            if (other.attributeName != null) {
                return false;
            }
        } else if (!attributeName.equals(other.attributeName)) {
            return false;
        }
        return true;
    }

    public String getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(String attributeId) {
        this.attributeId = attributeId;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

}
