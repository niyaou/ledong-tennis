package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysPermissionDao;
import com.desay.cd.factory.dao.ISysRoleDao;
import com.desay.cd.factory.dao.ISysSubSystemDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.ISysRoleService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * SysRoleServiceImpl
 * 
 * @author pengdengfu
 *
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class SysRoleServiceImpl implements ISysRoleService {
    @Autowired
    private ISysRoleDao sysRoleDao;
    @Autowired
    private ISysPermissionDao syspermissionDao;
    @Autowired
    private ISysSubSystemDao sysSubSystemDao;

    @Override
    public SysRole addRole(String roleName, String roleDesc, Set<String> permissionIds, String subsystemId) {
        // 检查roleName
        checkRoleName(roleName, true, null);
        SysRole sysRole = new SysRole();
        if (StringUtils.isNotEmpty(roleName)) {
            sysRole.setRoleName(roleName);
        }
        if (StringUtils.isNotEmpty(roleDesc)) {
            sysRole.setRoleDesc(roleDesc);
        }
        if (permissionIds != null && permissionIds.size() > 0) {
            Set<SysPermission> permissions = new HashSet<>();
            for (String permissionId : permissionIds) {
                SysPermission permission = syspermissionDao.findOne(permissionId);
                if (permission != null) {
                    permissions.add(syspermissionDao.findOne(permissionId));
                }
            }
            sysRole.setPermissions(permissions);
        }
        // 检查subsystemId
        checkSubsystemId(subsystemId, sysRole);
        SysRole role = null;
        try {
            role = sysRoleDao.saveAndFlush(sysRole);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.ROLE_NAME_EXISTED.getCode(), ResultCodeEnum.ROLE_NAME_EXISTED.getMessage());
        }
        return role;

    }

    @Override
    public void deleteRole(String roleId) {
        // 检查roleId
        checkRoleId(roleId);
        // 检查是否被使用
        Integer countRolesUsedBy = sysRoleDao.countRolesUsedBy(roleId);
        if (countRolesUsedBy > 0) {
            Map<String, Integer> referencedCount = new HashMap<>(1);
            referencedCount.put("referencedCount", countRolesUsedBy);
            throw new CustumException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getCode(), ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage(), referencedCount);
        }
        try {
            sysRoleDao.delete(roleId);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.ROLE_NAME_EXISTED.getCode(), ResultCodeEnum.ROLE_NAME_EXISTED.getMessage());
        }
    }

    @Override
    public void updateRole(String roleId, String roleName, String roleDesc, Set<String> permissionIds, String subsystemId) {
        // 检查roleId
        SysRole sysRole = checkRoleId(roleId);

        // 检查roleName
        checkRoleName(roleName, false, roleId);

        if (StringUtils.isNotEmpty(roleName)) {
            sysRole.setRoleName(roleName);
        }
        if (StringUtils.isNotEmpty(roleDesc)) {
            sysRole.setRoleDesc(roleDesc);
        }
        // 更新权限
        if (permissionIds != null) {
            Set<SysPermission> permissions = new HashSet<>(permissionIds.size());
            for (String permissionId : permissionIds) {
                SysPermission permission = syspermissionDao.findOne(permissionId);
                if (permission != null) {
                    permissions.add(syspermissionDao.findOne(permissionId));
                }
            }
            // 替换角色最新权限
            sysRole.setPermissions(permissions);
        }

        // 检查subsystemId
        checkSubsystemId(subsystemId, sysRole);
        try {
            sysRoleDao.saveAndFlush(sysRole);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.ROLE_NAME_EXISTED.getCode(), ResultCodeEnum.ROLE_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public void updateRoleDeletePermission(String roleId, String permissionId) {
        // 检查roleId
        SysRole sysRole = checkRoleId(roleId);
        SysPermission sysPermission = syspermissionDao.findOne(permissionId);
        if (sysPermission == null) {
            throw new CustumException(ResultCodeEnum.PERMISSION_ID_NOT_EXISTED.getCode(), ResultCodeEnum.PERMISSION_ID_NOT_EXISTED.getMessage());
        }
        Set<SysPermission> permissions = sysRole.getPermissions();
        if (!permissions.contains(sysPermission)) {
            throw new CustumException(ResultCodeEnum.ROLE_HAVING_NOT_PERMISSION.getCode(), ResultCodeEnum.ROLE_HAVING_NOT_PERMISSION.getMessage());
        }
        permissions.remove(sysPermission);
        try {
            sysRoleDao.saveAndFlush(sysRole);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.ROLE_NAME_EXISTED.getCode(), ResultCodeEnum.ROLE_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public Page<SysRole> getSysRoles(String pageNo, String pageSize, String roleId, String roleName, String subsystemId, String userId, List<String> properties, String sortDirection, String status) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, properties, sortDirection, "roleName");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(roleName)) {
            roleName = roleName.replaceAll("%", "\\\\%");
            roleName = roleName.replaceAll("_", "\\\\_");
        }
        final String roleNameTmp = roleName;
        Specification<SysRole> specification = new Specification<SysRole>() {
            @Override
            public Predicate toPredicate(Root<SysRole> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(roleId)) {
                    predicates.add(cb.equal(root.get("roleId"), roleId));
                }
                if (StringUtils.isNotEmpty(roleNameTmp)) {
                    predicates.add(cb.or(cb.like(root.get("roleName"), "%" + roleNameTmp + "%"), cb.like(root.get("roleDesc"), "%" + roleNameTmp + "%")));
                }
                if (StringUtils.isNotEmpty(subsystemId)) {
                    if (Constanst.GLOABLE_FLG.equalsIgnoreCase(subsystemId)) {
                        predicates.add(cb.isNull(root.get("sysSubsystem")));
                    } else {
                        Join<SysRole, SysSubSystem> join = root.join("sysSubsystem", JoinType.INNER);
                        predicates.add(cb.equal(join.get("subsystemId"), subsystemId));
                    }
                }
                if (StringUtils.isNotEmpty(userId)) {
                    Join<SysRole, SysUser> join = root.join("users", JoinType.INNER);
                    predicates.add(cb.equal(join.get("userId"), userId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    ControllerCommonUtils.checkStatus(status);
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        return sysRoleDao.findAll(specification, pageable);
    }

    /**
     * 检查roleId
     * 
     * @param roleId
     * @return
     */
    private SysRole checkRoleId(String roleId) {
        if (StringUtils.isEmpty(roleId)) {
            throw new CustumException(ResultCodeEnum.ROLE_ID_CANNOT_NULL.getCode(), ResultCodeEnum.ROLE_ID_CANNOT_NULL.getMessage());
        }

        SysRole sysRole = sysRoleDao.findOne(roleId);
        if (sysRole == null) {
            throw new CustumException(ResultCodeEnum.ROLE_ID_NOT_EXISTED.getCode(), ResultCodeEnum.ROLE_ID_NOT_EXISTED.getMessage());
        }
        return sysRole;
    }

    /**
     * 检查roleName
     * 
     * @param roleName
     * @param checkEmpty
     * @param roleId
     * @return
     */
    private void checkRoleName(String roleName, boolean checkEmpty, String roleId) {
        // 要求必填的情况
        if (checkEmpty) {
            if (StringUtils.isEmpty(roleName)) {
                throw new CustumException(ResultCodeEnum.ROLE_NAME_CANNOT_NULL.getCode(), ResultCodeEnum.ROLE_NAME_CANNOT_NULL.getMessage());
            }
            if (roleName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.ROLE_NAME_TOO_LONG.getCode(), ResultCodeEnum.ROLE_NAME_TOO_LONG.getMessage());
            }
        } else {
            // 不要求必填，但是填写则需要检查
            if (StringUtils.isNotEmpty(roleName) && roleName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.ROLE_NAME_TOO_LONG.getCode(), ResultCodeEnum.ROLE_NAME_TOO_LONG.getMessage());
            }
        }
        if (StringUtils.isEmpty(roleName)) {
            return;
        }
    }

    /**
     * 检查subsystemId
     * 
     * @param subsystemId
     * @param sysRole
     */
    private void checkSubsystemId(String subsystemId, SysRole sysRole) {
        if (StringUtils.isNotEmpty(subsystemId)) {
            // 切换为全局权限
            if (Constanst.GLOABLE_FLG.equalsIgnoreCase(subsystemId)) {
                sysRole.setSysSubsystem(null);
            } else {
                SysSubSystem subSystem = sysSubSystemDao.findOne(subsystemId);
                if (subSystem != null) {
                    sysRole.setSysSubsystem(subSystem);
                } else {
                    throw new CustumException(ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED.getCode(), ResultCodeEnum.SUB_SYSTEM_ID_NOT_EXISTED.getMessage());
                }
            }

        }
    }
}
