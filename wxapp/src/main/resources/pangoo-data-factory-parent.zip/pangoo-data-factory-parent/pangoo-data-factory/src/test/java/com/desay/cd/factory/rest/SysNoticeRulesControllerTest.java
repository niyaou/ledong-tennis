package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ISysNoticeRulesDao;
import com.desay.cd.factory.rest.vo.AddNoticeRulesVo;

/**
 * SysNoticeRulesControllerTest
 * 
 * @author pengdengfu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SysNoticeRulesControllerTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    ISysNoticeRulesDao sysNoticeRulesDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testNoticeFrequency() throws Exception {
        // 获取密钥
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

        AddNoticeRulesVo addNoticeRulesVo = new AddNoticeRulesVo();
        addNoticeRulesVo.setUserId("uidq1070");

        String requestJson = JSONObject.toJSONString(addNoticeRulesVo);
        // 添加
        mvc.perform(post("/management/noticeRules").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 重复添加
        mvc.perform(post("/management/noticeRules").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 查询
        params.clear();

        MvcResult mvcResult = mvc.perform(get("/management/noticeRules/uidq1070")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 删除
        params.clear();
        mvc.perform(delete("/management/noticeRules/" + sysNoticeRulesDao.findOne("uidq1070").getUserId()).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 删除不存在的数据
        mvc.perform(delete("/management/noticeRules/testNotExistData").contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20004));

    }

}
