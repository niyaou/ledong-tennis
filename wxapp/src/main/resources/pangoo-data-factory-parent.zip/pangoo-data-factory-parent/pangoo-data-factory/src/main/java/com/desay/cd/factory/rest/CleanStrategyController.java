package com.desay.cd.factory.rest;

import java.util.List;

import javax.validation.constraints.Min;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.CleanAlgorithm;
import com.desay.cd.factory.entity.mysql.CleanStrategy;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.entity.mysql.SysDevice;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.CleanStrategyVo;
import com.desay.cd.factory.service.ICleanStrategyService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: ClearAlgorithmController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "CleanStrategyController", value = "NEW-清洗策略管理")
@RestController
@Validated
public class CleanStrategyController {
    @Autowired
    private ICleanStrategyService cleanStrategyService;

    @RequestMapping(value = "/management/cleanStrategy", method = RequestMethod.POST)
    @ApiOperation(value = "清洗策略管理-添加策略", notes = "")
    @LogAnnotation(action = LogActionEnum.CLEAN_STRATEGY, message = "清洗策略管理-添加策略")
    public ResponseEntity<?> add(@RequestBody @Validated CleanStrategyVo cleanStrategyVo) {
        CleanStrategy cleanStrategy = new CleanStrategy();
        BeanUtils.copyProperties(cleanStrategyVo, cleanStrategy, ControllerCommonUtils.getNullPropertyNames(cleanStrategyVo));
        checkIds(cleanStrategyVo, cleanStrategy);

        try {
            String strgyId = cleanStrategyService.add(cleanStrategy);
            return new ResponseEntity<Object>(CommonResponse.success(strgyId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    private void checkIds(CleanStrategyVo cleanStrategyVo, CleanStrategy cleanStrategy) {
        if (StringUtils.isNotEmpty(cleanStrategyVo.getDeviceId())) {
            SysDevice device = new SysDevice();
            device.setDeviceId(cleanStrategyVo.getDeviceId());
            cleanStrategy.setSysDevice(device);
        } else if (cleanStrategyVo.getDeviceId() != null && cleanStrategyVo.getDeviceId().length() == 0) {
            cleanStrategy.setSysDevice(null);
        }
        if (StringUtils.isNotEmpty(cleanStrategyVo.getAlgId())) {
            CleanAlgorithm cleanAlgorithm = new CleanAlgorithm();
            cleanAlgorithm.setAlgId(cleanStrategyVo.getAlgId());
            cleanStrategy.setCleanAlgorithm(cleanAlgorithm);
        } else if (cleanStrategyVo.getAlgId() != null && cleanStrategyVo.getAlgId().length() == 0) {
            cleanStrategy.setCleanAlgorithm(null);
        }
        if (StringUtils.isNotEmpty(cleanStrategyVo.getPriorityId())) {
            DataDictionary dataDictionary = new DataDictionary();
            dataDictionary.setDataId(cleanStrategyVo.getPriorityId());
            cleanStrategy.setPriority(dataDictionary);
        } else if (cleanStrategyVo.getPriorityId() != null && cleanStrategyVo.getPriorityId().length() == 0) {
            cleanStrategy.setPriority(null);
        }
    }

    @RequestMapping(value = "/management/cleanStrategy/{strgyId}", method = RequestMethod.DELETE)
    @ApiImplicitParams({ @ApiImplicitParam(name = "strgyId", value = "策略ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "清洗策略管理-删除策略", notes = "")
    @LogAnnotation(action = LogActionEnum.CLEAN_STRATEGY, message = "清洗策略管理-删除策略")
    public ResponseEntity<?> add(@PathVariable(value = "strgyId", required = true) String strgyId) {
        try {
            cleanStrategyService.delete(strgyId);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }
    }

    @RequestMapping(value = "/management/cleanStrategy/{strgyId}", method = RequestMethod.PUT)
    @ApiImplicitParams({ @ApiImplicitParam(name = "strgyId", value = "策略ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "清洗策略管理-更新策略-整体更新", notes = "用提供的对象数据，替换原始数据,必填字段必须填写")
    @LogAnnotation(action = LogActionEnum.CLEAN_STRATEGY, message = "清洗策略管理-更新策略-整体更新")
    public ResponseEntity<?> put(@PathVariable(value = "strgyId", required = true) String strgyId, @Validated @RequestBody CleanStrategyVo cleanStrategyVo) {
        CleanStrategy cleanStrategy = new CleanStrategy();
        BeanUtils.copyProperties(cleanStrategyVo, cleanStrategy);
        cleanStrategy.setStrgyId(strgyId);
        checkIds(cleanStrategyVo, cleanStrategy);
        try {
            cleanStrategyService.update(cleanStrategy, true);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/cleanStrategy/{strgyId}", method = RequestMethod.PATCH)
    @ApiImplicitParams({ @ApiImplicitParam(name = "strgyId", value = "策略ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "清洗策略管理-更新策略-局部更新", notes = "用提供对象的指定字段，替换原始对象的指定字段。")
    @LogAnnotation(action = LogActionEnum.CLEAN_STRATEGY, message = "清洗策略管理-更新策略-局部更新")
    public ResponseEntity<?> update(@PathVariable(value = "strgyId", required = true) String strgyId, @RequestBody CleanStrategyVo cleanStrategyVo) {
        CleanStrategy cleanStrategy = new CleanStrategy();
        BeanUtils.copyProperties(cleanStrategyVo, cleanStrategy);
        cleanStrategy.setStrgyId(strgyId);
        checkIds(cleanStrategyVo, cleanStrategy);
        try {
            cleanStrategyService.update(cleanStrategy, false);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/cleanStrategy", method = RequestMethod.GET)
    @ApiOperation(value = "清洗策略管理-查询策略", notes = "当pageNo，pageSize为空时，默认返回第一页10条数据.")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "strgyId", value = "策略Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "strygName", value = "策略名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "strygNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "deviceId", value = "设备Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceName", value = "设备名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "algId", value = "算法Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "algName", value = "算法名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "algNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.CLEAN_STRATEGY, message = "清洗策略管理-查询策略")
    public ResponseEntity<?> search(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "strgyId", required = false) String strgyId,
            @RequestParam(value = "strygName", required = false) String strygName, @RequestParam(value = "strygNameLike", required = false) String strygNameLike,
            @RequestParam(value = "deviceId", required = false) String deviceId, @RequestParam(value = "deviceName", required = false) String deviceName,
            @RequestParam(value = "deviceNameLike", required = false) String deviceNameLike, @RequestParam(value = "algId", required = false) String algId,
            @RequestParam(value = "algName", required = false) String algName, @RequestParam(value = "algNameLike", required = false) String algNameLike,
            @RequestParam(value = "status", required = false) String status) {
        Page<CleanStrategy> rlt = cleanStrategyService.search(strgyId, strygName, strygNameLike, deviceId, deviceName, deviceNameLike, algId, algName, algNameLike, status, pageNo,
                pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(rlt), HttpStatus.OK);
    }

}
