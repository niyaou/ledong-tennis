package com.desay.cd.factory.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.desay.cd.factory.entity.mysql.SysPermission;

/**
 * ISysPermissionDao
 * 
 * @author pengdengfu
 *
 */
public interface ISysPermissionDao extends JpaRepository<SysPermission, Serializable>, JpaSpecificationExecutor<SysPermission> {
    /**
     * 根据方法名称和url判断是否存在
     * 
     * @param methord
     * @param url
     * @return
     */
    SysPermission findByMethodAndUrl(String methord, String url);

    /**
     * 通过权限名称模糊匹配
     * 
     * @param permissionName
     * @return
     */
    @Query("select permission from SysPermission permission where permission.permissionName like %?1%")
    List<SysPermission> findbyPermissionNameLike(String permissionName);

    /**
     * 查询引用
     * 
     * @param permissionId
     * @return
     */
    @Query(value = "select count(*) from sys_role_permission where permission_id=?1", nativeQuery = true)
    Integer countPermissionUsedBy(String permissionId);
}
