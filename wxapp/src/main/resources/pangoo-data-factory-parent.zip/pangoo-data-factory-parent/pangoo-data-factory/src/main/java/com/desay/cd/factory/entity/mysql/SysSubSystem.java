package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 
 * @ClassName: SysSubSystem
 * @author: pengdengfu
 * @date: 2019年4月17日 下午2:11:16
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_sub_system", uniqueConstraints = { @UniqueConstraint(columnNames = "sub_system_name") })
public class SysSubSystem implements Serializable {

    private static final long serialVersionUID = 1194442628973784835L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "sub_system_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String subsystemId;

    /** 子系统名称 */
    @Column(name = "sub_system_name", unique = true, nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '子系统名称'")
    private String subsystemName;

    /** 子系统描述 */
    @Column(name = "sub_system_desc", columnDefinition = "text COMMENT '子系统描述'")
    private String subsystemDesc;

    /** 该系统所有的用户 */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "sys_user_sub_system", joinColumns = { @JoinColumn(name = "sub_system_id") }, inverseJoinColumns = { @JoinColumn(name = "user_id") })
    @JsonIgnore
    private Set<SysUser> sysUsers;

    @OneToMany(mappedBy = "sysSubsystem")
    @JsonIgnore
    private Set<SysPermission> sysPermissions;

    @OneToMany(mappedBy = "sysSubsystem")
    @JsonIgnore
    private Set<SysRole> sysRoles;

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private String isActive = "1";

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((subsystemId == null) ? 0 : subsystemId.hashCode());
        result = prime * result + ((subsystemName == null) ? 0 : subsystemName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysSubSystem other = (SysSubSystem) obj;
        if (subsystemId == null) {
            if (other.subsystemId != null) {
                return false;
            }
        } else if (!subsystemId.equals(other.subsystemId)) {
            return false;
        }
        if (subsystemName == null) {
            if (other.subsystemName != null) {
                return false;
            }
        } else if (!subsystemName.equals(other.subsystemName)) {
            return false;
        }
        return true;
    }

    public String getSubsystemId() {
        return subsystemId;
    }

    public void setSubsystemId(String subsystemId) {
        this.subsystemId = subsystemId;
    }

    public String getSubsystemName() {
        return subsystemName;
    }

    public void setSubsystemName(String subsystemName) {
        this.subsystemName = subsystemName;
    }

    public String getSubsystemDesc() {
        return subsystemDesc;
    }

    public void setSubsystemDesc(String subsystemDesc) {
        this.subsystemDesc = subsystemDesc;
    }

    public Set<SysUser> getSysUsers() {
        return sysUsers;
    }

    public void setSysUsers(Set<SysUser> sysUsers) {
        this.sysUsers = sysUsers;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Set<SysPermission> getSysPermissions() {
        return sysPermissions;
    }

    public void setSysPermissions(Set<SysPermission> sysPermissions) {
        this.sysPermissions = sysPermissions;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public Set<SysRole> getSysRoles() {
        return sysRoles;
    }

    public void setSysRoles(Set<SysRole> sysRoles) {
        this.sysRoles = sysRoles;
    }

}
