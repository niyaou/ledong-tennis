package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * 层级数据
 * 
 * @author pengdengfu
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_level_data", uniqueConstraints = { @UniqueConstraint(columnNames = { "data_type", "name", "parent_id" }) })
@Getter
@Setter
public class SysLevelData implements Serializable {

    private static final long serialVersionUID = 6633876503795556021L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String id;

    @Column(name = "data_type", nullable = false, length = 60, columnDefinition = "char(1) COMMENT '数据类型：1，tag；2，label'")
    @JsonIgnore
    private String dataType;

    @Column(name = "name", nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '名称'")
    private String name;

    @Column(name = "name_desc", columnDefinition = "text COMMENT '描述'")
    private String desc;

    @Column(name = "style", columnDefinition = "text COMMENT '样式'")
    private String style;

    @ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.REFRESH }, optional = true)
    @JoinColumn(name = "parent_id")
    @JsonIgnoreProperties({ "children" })
    private SysLevelData parent;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "parent", cascade = { CascadeType.REFRESH, CascadeType.REMOVE, CascadeType.MERGE })
    @JsonIgnoreProperties({ "parent" })
    @OrderBy("name desc")
    private Set<SysLevelData> children = new HashSet<SysLevelData>(16);

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private Integer isActive = 1;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    @JsonIgnore
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((dataType == null) ? 0 : dataType.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysLevelData other = (SysLevelData) obj;
        if (dataType == null) {
            if (other.dataType != null) {
                return false;
            }
        } else if (!dataType.equals(other.dataType)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        return true;
    }

}
