package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.CleanAlgorithm;

/**
 * 
 * @ClassName: ClearAlgorithmService
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:22:23
 */
public interface IClearAlgorithmService {
    /**
     * 添加
     * 
     * @param clearAlgorithm
     * @return
     */
    String add(CleanAlgorithm clearAlgorithm);

    /**
     * 删除
     * 
     * @param algId
     */
    void delete(String algId);

    /**
     * 更新
     * 
     * @param clearAlgorithm
     * @param isOverall
     */
    void update(CleanAlgorithm clearAlgorithm, boolean isOverall);

    /**
     * 查询
     * 
     * @param algId
     * @param algName
     * @param algNameLike
     * @param imageName
     * @param imageNameLike
     * @param status
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @return
     */
    Page<CleanAlgorithm> search(String algId, String algName, String algNameLike, String imageName, String imageNameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties);
}
