package com.desay.cd.factory.service;

import java.util.List;

import com.desay.cd.factory.entity.mysql.SysNoticeFrequency;

/**
 * ISysNoticeFrequencyService
 * 
 * @author pengdengfu
 *
 */
public interface ISysNoticeFrequencyService {
    /**
     * 添加触发事件频率
     * 
     * @param noticeFrequencyName
     * @return
     */
    SysNoticeFrequency addNoticeFrequency(String noticeFrequencyName);

    /**
     * 删除触发事件频率
     * 
     * @param noticeFrequencyId
     */
    void deleteNoticeFrequency(String noticeFrequencyId);

    /**
     * 获取通知频率
     * 
     * @return
     */
    List<SysNoticeFrequency> getNoticeFrequencys();
}
