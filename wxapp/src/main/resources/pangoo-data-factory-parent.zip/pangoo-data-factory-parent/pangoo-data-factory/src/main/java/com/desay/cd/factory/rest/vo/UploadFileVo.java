package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: UploadFileVo
 * @author: nixuchun
 */
@ApiModel(value = "上传文件")
public class UploadFileVo {

    @ApiModelProperty(value = "文件名,修改文件状态时不需要填写，填写了也不会修改文件名", required = true)
    private String fileName;

    @ApiModelProperty(value = "产品id", required = false)
    private String productId;

    @ApiModelProperty(value = "产品名称", required = false)
    private String productName;

    @ApiModelProperty(value = "设备id", required = true)
    private String deviceId;

    @ApiModelProperty(value = "设备名称", required = true)
    private String deviceName;

    @ApiModelProperty(value = "文档版本,直接返回得到的文档版本，若修改，则更新会失败,创建文档时不需要填写", required = false)
    private long version=0;
    
    public UploadFileVo() {
        
    }
    
    public UploadFileVo(String fileName,String deviceId,String deviceName) {
        this.fileName=fileName;
        this.deviceId=deviceId;
        this.deviceName=deviceName;
    }
    
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }



}
