package com.desay.cd.factory.rest;

import java.util.List;
import java.util.Set;

import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysGroup;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.SysGroupVo;
import com.desay.cd.factory.service.ISysGroupService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: SysGroupController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "SysGroupController", value = "NEW-组别管理")
@RestController
@Validated
public class SysGroupController {
    @Autowired
    private ISysGroupService sysGroupService;

    @RequestMapping(value = "/management/groups", method = RequestMethod.POST)
    @ApiOperation(value = "组别管理-新增", notes = "")
    @LogAnnotation(action = LogActionEnum.SYS_GROUP, message = "组别管理-新增")
    public ResponseEntity<?> add(@RequestBody @Validated SysGroupVo sysGroupVo) {
        try {
            String groupId = sysGroupService.add(sysGroupVo);
            return new ResponseEntity<Object>(CommonResponse.success(groupId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/groups/{groupId}", method = RequestMethod.DELETE)
    @ApiImplicitParams({ @ApiImplicitParam(name = "groupId", value = "组ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "组别管理-删除", notes = "")
    @LogAnnotation(action = LogActionEnum.SYS_GROUP, message = "组别管理-删除")
    public ResponseEntity<?> add(@PathVariable(value = "groupId", required = true) String groupId) {
        try {
            sysGroupService.delete(groupId);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @RequestMapping(value = "/management/groups/{groupId}", method = RequestMethod.PUT)
    @ApiImplicitParams({ @ApiImplicitParam(name = "groupId", value = "组ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "组别管理-更新-整体更新", notes = "用提供的对象数据，替换原始数据,必填字段必须填写")
    @LogAnnotation(action = LogActionEnum.SYS_GROUP, message = "组别管理-更新-整体更新")
    public ResponseEntity<?> put(@PathVariable(value = "groupId", required = true) String groupId, @Validated @RequestBody SysGroupVo sysGroupVo) {
        try {
            sysGroupService.update(groupId, sysGroupVo, true);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    @RequestMapping(value = "/management/groups/{groupId}", method = RequestMethod.PATCH)
    @ApiImplicitParams({ @ApiImplicitParam(name = "groupId", value = "组ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "组别管理-局部更新", notes = "用提供对象的指定字段，替换原始对象的指定字段。")
    @LogAnnotation(action = LogActionEnum.SYS_GROUP, message = "组别管理-局部更新")
    public ResponseEntity<?> update(@PathVariable(value = "groupId", required = true) String groupId, @RequestBody SysGroupVo sysGroupVo) {
        try {
            sysGroupService.update(groupId, sysGroupVo, false);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/groups", method = RequestMethod.GET)
    @ApiOperation(value = "组别管理-查询", notes = "当pageNo，pageSize为空时，默认返回第一页10条数据.")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "userId", value = "用户Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "策略Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupId", value = "策略Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupName", value = "策略名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "abilityIds", value = "能力Id列表", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "abilityIdsCondition", value = "能力Id的关系", required = false, dataType = "string", allowableValues = "and,or", paramType = "query"),
            @ApiImplicitParam(name = "abilityName", value = "能力名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "abilityNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.SYS_GROUP, message = "组别管理-查询")
    public ResponseEntity<?> search(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "userId", required = false) String userId,
            @RequestParam(value = "subsystemId", required = false) String subsystemId, @RequestParam(value = "groupId", required = false) String groupId,
            @RequestParam(value = "groupName", required = false) String groupName, @RequestParam(value = "groupNameLike", required = false) String groupNameLike,
            @RequestParam(value = "abilityIds", required = false) Set<String> abilityIds, @RequestParam(value = "abilityIdsCondition", required = false) String abilityIdsCondition,
            @RequestParam(value = "abilityName", required = false) String abilityName, @RequestParam(value = "abilityNameLike", required = false) String abilityNameLike,
            @RequestParam(value = "status", required = false) String status) {
        Page<SysGroup> rlt = sysGroupService.search(userId, groupId, subsystemId, groupName, groupNameLike, abilityIds, abilityIdsCondition, abilityName, abilityNameLike, status,
                pageNo, pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(rlt), HttpStatus.OK);
    }

}
