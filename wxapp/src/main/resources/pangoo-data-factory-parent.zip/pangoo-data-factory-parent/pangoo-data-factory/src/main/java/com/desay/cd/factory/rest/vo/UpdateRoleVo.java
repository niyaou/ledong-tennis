package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: UpdateRoleVo
 * @author: pengdengfu
 * @date: 2019年4月17日 下午1:44:36
 */
public class UpdateRoleVo {
    @ApiModelProperty(value = "角色名称(0<size<=30)", required = false)
    private String roleName;
    @ApiModelProperty(value = "角色描述", required = false)
    private String roleDesc;

    @ApiModelProperty(value = "权限Id列表,忽略不存在的Id", required = false)
    private Set<String> permissionIds;

    @ApiModelProperty(value = "该角色所属的子系统Id,如果更新为\"global\"，该角色为全局角色", required = false)
    private String subsystemId;

    public Set<String> getPermissionIds() {
        return permissionIds;
    }

    public void setPermissionIds(Set<String> permissionIds) {
        this.permissionIds = permissionIds;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public String getSubsystemId() {
        return subsystemId;
    }

    public void setSubsystemId(String subsystemId) {
        this.subsystemId = subsystemId;
    }

    @Override
    public String toString() {
        return " [roleName=" + roleName + ", roleDesc=" + roleDesc + ", permissionIds=" + permissionIds + ", subsystemId=" + subsystemId + "]";
    }

}
