package com.desay.cd.factory.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysTriggerEventDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysTriggerEvent;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.ISysTriggerEventService;

/**
 * SysTriggerEventServiceImpl
 * 
 * @author pengdengfu
 *
 */
@Service
public class SysTriggerEventServiceImpl implements ISysTriggerEventService {

    @Autowired
    ISysTriggerEventDao sysTriggerEventDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public SysTriggerEvent addNoticeEvent(String noticeEventName) {
        if (StringUtils.isEmpty(noticeEventName)) {
            throw new CustumException(ResultCodeEnum.EVENT_NAME_CANNOT_NULL.getCode(), ResultCodeEnum.EVENT_NAME_CANNOT_NULL.getMessage());
        }
        if (noticeEventName.length() > Constanst.NAME_LENGTH) {
            throw new CustumException(ResultCodeEnum.NOTICE_EVENT_NAME_TOO_LONG.getCode(), ResultCodeEnum.NOTICE_EVENT_NAME_TOO_LONG.getMessage());
        }
        SysTriggerEvent sysTriggerEvent = new SysTriggerEvent();
        sysTriggerEvent.setEventName(noticeEventName);
        try {
            SysTriggerEvent sysTriggerEvent2 = sysTriggerEventDao.saveAndFlush(sysTriggerEvent);
            return sysTriggerEvent2;
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.NOTICE_EVENT_NAME_EXISTED.getCode(), ResultCodeEnum.NOTICE_EVENT_NAME_EXISTED.getMessage());
        }
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public void deleteNoticeEvent(String noticeEventId) {
        if (StringUtils.isEmpty(noticeEventId)) {
            throw new CustumException(ResultCodeEnum.EVENT_ID_CANNOT_NULL.getCode(), ResultCodeEnum.EVENT_ID_CANNOT_NULL.getMessage());
        }
        SysTriggerEvent findOne = sysTriggerEventDao.findOne(noticeEventId);
        if (findOne == null) {
            throw new CustumException(ResultCodeEnum.NOTICE_EVENT_ID_NOT_EXISTED.getCode(), ResultCodeEnum.NOTICE_EVENT_ID_NOT_EXISTED.getMessage());
        }
        try {
            sysTriggerEventDao.delete(noticeEventId);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        }
    }

    @Override
    public List<SysTriggerEvent> getSysTriggerEvents() {
        return sysTriggerEventDao.findAll();
    }

}
