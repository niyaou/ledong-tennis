package com.desay.cd.factory.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.AddPermissionVo;
import com.desay.cd.factory.service.ISysPermissionService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/***
 * 权限管理
 * 
 * @author pengdengfu
 *
 */
@RestController
@Api(value = "用户管理-权限管理", tags = "SysPermissionController")
public class SysPermissionController {
    @Autowired
    private ISysPermissionService sysPermissionService;

    /**
     * 添加权限
     * 
     * @param permissionName
     * @param permissionDesc
     * @return
     */
    @RequestMapping(value = "/management/permissions", method = RequestMethod.POST)
    @ApiOperation(value = "权限管理-添加权限", notes = "")
    @LogAnnotation(action = LogActionEnum.SHIRO, message = "权限管理-添加权限")
    public ResponseEntity<?> addPermission(@RequestBody AddPermissionVo addPermission) {
        SysPermission sysPermission = sysPermissionService.addPermission(addPermission.getPermissionName(), addPermission.getMethod(), addPermission.getUrl(), addPermission.getPermissionDesc(),
                addPermission.getSubsystemId());
        return new ResponseEntity<Object>(CommonResponse.success(sysPermission.getPermissionId()), HttpStatus.OK);
    }

    /**
     * 删除权限
     * 
     * @param userId
     * @return
     */
    @RequestMapping(value = "/management/permissions/{permissionId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "权限管理-删除权限")
    @ApiImplicitParams({ @ApiImplicitParam(name = "permissionId", value = "权限ID", required = true, dataType = "String", paramType = "path") })
    @LogAnnotation(action = LogActionEnum.SHIRO, message = "权限管理-删除权限")
    public ResponseEntity<?> deletePermission(@PathVariable(value = "permissionId", required = true) String permissionId) {
        sysPermissionService.deletePermission(permissionId);
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 更新权限
     * 
     * @param permissionId
     * @param permissionName
     * @param permissionDesc
     * @return
     */
    @RequestMapping(value = "/management/permissions/{permissionId}", method = RequestMethod.PUT)
    @ApiOperation(value = "权限管理-更新权限", notes = "example:<br>" + "{<br>" + "  \"method\": \"post\",// 请求的方法，post,get,put,delete，<b>可选</b><br>" + "  \"permissionDesc\": \"string\",// 描述，<b>可选</b><br>"
            + "  \"permissionName\": \"string\", //权限名称，<b>可选</b><br>" + "  \"subsystemId\": \"string\", // 所属子系统Id，\"global\"为全局标志。<b>可选</b><br>" + "  \"url\": \"string\" // 该权限对应的url,<b>可选</b><br>"
            + "}")
    @LogAnnotation(action = LogActionEnum.SHIRO, message = "权限管理-更新权限")
    public ResponseEntity<?> updateRole(@PathVariable(value = "permissionId", required = true) String permissionId, @RequestBody AddPermissionVo apdatePermission) {
        sysPermissionService.updatePermission(permissionId, apdatePermission.getPermissionName(), apdatePermission.getMethod(), apdatePermission.getUrl(), apdatePermission.getPermissionDesc(),
                apdatePermission.getSubsystemId());
        return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
    }

    /**
     * 获取系统权限
     * 
     * @param pageNo
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/management/permissions", method = RequestMethod.GET)
    @ApiOperation(value = "权限管理-获取系统权限", notes = "")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "permissionId", value = "权限ID（精确查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "permissionName", value = "权限名称（模糊查询）", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "subsystemId", value = "属于该子系统的权限,通过关键词“global”查询全局权限", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "roleId", value = "属于角色的权限", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序的属性字段，默认按照创建时间降序排序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "sortDirection", value = "排序方向,默认降序", required = false, dataType = "string", allowableValues = "DESC,ASC", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态：0，不启用。1，启用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.SHIRO, message = "获取系统权限")
    public ResponseEntity<?> getRoles(@RequestParam(value = "pageNo", required = false) String pageNo, @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "permissionId", required = false) String permissionId, @RequestParam(value = "permissionName", required = false) String permissionName,
            @RequestParam(value = "subsystemId", required = false) String subsystemId, @RequestParam(value = "roleId", required = false) String roleId,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "sortDirection", required = false) String sortDirection,
            @RequestParam(value = "status", required = false) String status) {
        Page<SysPermission> syspermissions = sysPermissionService.getSyspermissions(pageNo, pageSize, permissionId, permissionName, subsystemId, roleId, sortProperties, sortDirection, status);
        return new ResponseEntity<Object>(CommonResponse.success(syspermissions), HttpStatus.OK);
    }
}
