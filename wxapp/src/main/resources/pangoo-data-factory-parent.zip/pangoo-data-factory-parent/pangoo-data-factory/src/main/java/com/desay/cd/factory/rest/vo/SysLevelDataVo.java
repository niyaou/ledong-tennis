package com.desay.cd.factory.rest.vo;

import java.util.Set;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: SysLevelDataVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午4:11:27
 */
@ApiModel(value = "层级数据")
@Data
public class SysLevelDataVo {

    @ApiModelProperty(value = "名称(0<size<=30)", required = true)
    @Length(min = 1, max = 30, message = "length长度在[1,30]之间")
    @NotEmpty
    private String name;

    @ApiModelProperty(value = "描述", required = false)
    private String desc;

    @ApiModelProperty(value = "Label样式,Tag不需要改字段", required = false)
    private String style;

    @ApiModelProperty(value = "父级ID", required = false)
    private String parentId;

    @ApiModelProperty(value = "子节点的名称列表", required = false)
    private Set<String> childrenNames;

    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", allowableValues = "1,0", example = "1", required = false)
    @Range(min = 0, max = 1, message = "状态必须在[0,1]")
    private Integer isActive = 1;

}
