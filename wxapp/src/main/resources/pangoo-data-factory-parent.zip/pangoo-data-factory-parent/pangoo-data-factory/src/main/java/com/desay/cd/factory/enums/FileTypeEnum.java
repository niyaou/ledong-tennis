package com.desay.cd.factory.enums;

/**
 * 文件状态枚举
 * 
 * @author uidq1343
 *
 */
public enum FileTypeEnum {
    /** 文件类型  0：视频，1：图片，2，文档，3：音频，       */

    VIDEO(0, "视频"),
    IMAGE(1, "图片"),
    DOCUMENT(2, "文档"),
    AUDIO(3, "音频"),
    RESERVED(4, "预留");

    private Integer code;

    private String message;
    
    

    FileTypeEnum(Integer code,String message) {
        this.code = code;
        this.message=message;
    }

    public Integer getCode() {
        return code;
    }


    public String getMessage() {
        return message;
    }

    public String[] getPrefix() {
        switch(code) {
        case 0:
            return new String[]{"mp4","avi"};
        case 1:
            return new String[]{"jpg","png","bmp","jpeg","gif","webp","ico"};
        case 2:
            return new String[]{"ppt","pptx","txt","xml","htm","html","xls","xlsx","docx","doc","csv"};
        case 3:
            return new String[]{"mp3","wav","wma","wmv"};
        default:
            return new String[]{""};
        }
    }
    
    public static FileTypeEnum getMIMEType(int type) {
        switch(type) {
        case 0:
            return FileTypeEnum.VIDEO;
        case 1:
            return FileTypeEnum.IMAGE;
        case 2:
            return FileTypeEnum.DOCUMENT;
        case 3:
            return FileTypeEnum.AUDIO;
        default:
            return FileTypeEnum.RESERVED;
        }
    }
    
    public static String getMessage(String name) {
        for (FileTypeEnum item : FileTypeEnum.values()) {
            if (item.name().equals(name)) {
                return item.message;
            }
        }
        return name;
    }

    public static Integer getCode(String name) {
        for (FileTypeEnum item : FileTypeEnum.values()) {
            if (item.name().equals(name)) {
                return item.code;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return this.name();
    }


}
