package com.desay.cd.factory.rest;

import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.TaskAssignStrategy;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.TaskAssignStrategyVo;
import com.desay.cd.factory.service.ITaskAssignStrategyService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: ClearAlgorithmController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "CleanStrategyController", value = "NEW-任务分配策略管理")
@RestController
@Validated
public class TaskAssignStrategyController {
    @Autowired
    private ITaskAssignStrategyService taskAssignStrategyService;

    @RequestMapping(value = "/management/taskAssignStrategy", method = RequestMethod.POST)
    @ApiOperation(value = "任务分配策略管理-添加策略", notes = "")
    @LogAnnotation(action = LogActionEnum.TASK_ASSIGN_STRATEGY, message = "任务分配策略管理-添加策略")
    public ResponseEntity<?> add(@RequestBody @Validated TaskAssignStrategyVo taskAssignStrategyVo) {
        try {
            String strgyId = taskAssignStrategyService.add(taskAssignStrategyVo);
            return new ResponseEntity<Object>(CommonResponse.success(strgyId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/taskAssignStrategy/{strgyId}", method = RequestMethod.DELETE)
    @ApiImplicitParams({ @ApiImplicitParam(name = "strgyId", value = "策略ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "任务分配策略管理-删除策略", notes = "")
    @LogAnnotation(action = LogActionEnum.TASK_ASSIGN_STRATEGY, message = "任务分配策略管理-删除策略")
    public ResponseEntity<?> add(@PathVariable(value = "strgyId", required = true) String strgyId) {
        try {
            taskAssignStrategyService.delete(strgyId);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @RequestMapping(value = "/management/taskAssignStrategy/{strgyId}", method = RequestMethod.PUT)
    @ApiImplicitParams({ @ApiImplicitParam(name = "strgyId", value = "策略ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "任务分配策略管理-更新策略-整体更新", notes = "用提供的对象数据，替换原始数据,必填字段必须填写")
    @LogAnnotation(action = LogActionEnum.TASK_ASSIGN_STRATEGY, message = "任务分配策略管理-更新策略-整体更新")
    public ResponseEntity<?> put(@PathVariable(value = "strgyId", required = true) String strgyId, @Validated @RequestBody TaskAssignStrategyVo taskAssignStrategyVo) {
        try {
            taskAssignStrategyService.update(strgyId, taskAssignStrategyVo, true);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/taskAssignStrategy/{strgyId}", method = RequestMethod.PATCH)
    @ApiImplicitParams({ @ApiImplicitParam(name = "strgyId", value = "策略ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "任务分配策略管理-更新策略-局部更新", notes = "用提供对象的指定字段，替换原始对象的指定字段。")
    @LogAnnotation(action = LogActionEnum.TASK_ASSIGN_STRATEGY, message = "任务分配策略管理-更新策略-局部更新")
    public ResponseEntity<?> update(@PathVariable(value = "strgyId", required = true) String strgyId, @RequestBody TaskAssignStrategyVo taskAssignStrategyVo) {
        try {
            taskAssignStrategyService.update(strgyId, taskAssignStrategyVo, false);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @RequestMapping(value = "/management/taskAssignStrategy", method = RequestMethod.GET)
    @ApiOperation(value = "任务分配策略管理-查询策略", notes = "当pageNo，pageSize为空时，默认返回第一页10条数据.")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "strgyId", value = "策略Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "strygName", value = "策略名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "strygNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "deviceId", value = "设备Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceName", value = "设备名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "deviceNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "groupId", value = "组Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupName", value = "组名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "groupNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "taskTypeId", value = "任务类型Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "taskTypeName", value = "任务类型名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "taskTypeNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "priorityId", value = "优先级Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "priorityName", value = "优先级名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "priorityNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query"),
            @ApiImplicitParam(name = "status", value = "状态，0，不可用，1，可用", required = false, dataType = "String", allowableValues = "0,1", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.TASK_ASSIGN_STRATEGY, message = "任务分配策略管理-查询策略")
    public ResponseEntity<?> search(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "strgyId", required = false) String strgyId,
            @RequestParam(value = "strygName", required = false) String strygName, @RequestParam(value = "strygNameLike", required = false) String strygNameLike,
            @RequestParam(value = "deviceId", required = false) String deviceId, @RequestParam(value = "deviceName", required = false) String deviceName,
            @RequestParam(value = "deviceNameLike", required = false) String deviceNameLike, @RequestParam(value = "groupId", required = false) String groupId,
            @RequestParam(value = "groupName", required = false) String groupName, @RequestParam(value = "groupNameLike", required = false) String groupNameLike,
            @RequestParam(value = "taskTypeId", required = false) String taskTypeId, @RequestParam(value = "taskTypeName", required = false) String taskTypeName,
            @RequestParam(value = "taskTypeNameLike", required = false) String taskTypeNameLike, @RequestParam(value = "priorityId", required = false) String priorityId,
            @RequestParam(value = "priorityName", required = false) String priorityName, @RequestParam(value = "priorityNameLike", required = false) String priorityNameLike,
            @RequestParam(value = "status", required = false) String status) {
        Page<TaskAssignStrategy> rlt = taskAssignStrategyService.search(strgyId, strygName, strygNameLike, deviceId, deviceName, deviceNameLike, groupId, groupName, groupNameLike,
                taskTypeId, taskTypeName, taskTypeNameLike, priorityId, priorityName, priorityNameLike, status, pageNo, pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(rlt), HttpStatus.OK);
    }

}
