package com.desay.cd.factory.service;

import java.io.IOException;
import java.io.InputStream;

/**
 * hdfs文件管理服务
 * 
 * @author pengdengfu
 *
 */
public interface IHdfsFileService {

    public static String HDFSDIR = "/pangoo_das/";

    public static final int DATA=0;
    public static final String DATA_PREFIX="data/";
    public static final int THUMBNAIL=1;
    public static final String THUMBNAIL_PREFIX="thumbnail/";
    public static final int CHUNKS=2;
    public static final String CHUNKS_PREFIX="chunks/";
    public static final int RESERVED=3;
    public static final String RESERVED_PREFIX="reserved/";
    
    /**
     * 向hdfs文件系统写入目录
     * 
     * @param path
     * @return
     */
    boolean mkdirs(String path);

    /**
     * 检查目录、文件是否存在于hdfs文件系统
     * 
     * @param path
     * @return
     */
    boolean fileExists(String path);

    /**
     * 删除指定文件夹
     * 
     * @param path
     * @return
     * @throws IOException
     */
    boolean deleteDirectory(String path) throws IOException;
    
    
    /**
     * 循环删除指定文件夹
     * 
     * @param path
     * @return
     * @throws IOException
     */
    boolean deleteDirectoryRecursively(String path) throws IOException;

    /**
     * 修改文件夹名称
     * 
     * @param originalPath
     * @param newPath
     * @return
     */
    boolean updateDirectoryName(String originalPath, String newPath);

    /**
     * 合并HDFS文件系统小文件
     * 
     * @param sourcePath
     * @param targetPath
     * @param file
     * @return
     */
    boolean mergeHdfsFile(String sourcePath,String targetPath, String file);

    /**
     * 将文件写入hdfs
     * 
     * @param stream
     * @param savePath
     * @param fileName
     * @return
     */
    boolean writeToHdfs(InputStream stream, String savePath, String fileName);
    
    
    /**
     * 将文件以正确的文件名写入文件系统
     * 1.若无相同文件，则直接将原名写入
     * 2.若有同名文件，则重命名后写入
     * @param path
     * @return FILENAME.PREFIX
     */
    String createFileName(String path);
    
    
    /**
     * 获取当日文件夹路径,包含末尾的/符号
     * @param type  数据类型  ，0 :数据   ,1:缩略图 , 2:断点续传临时文件    ,3:预留 
     * @return
     */
    String getCurrentFolderPath(int type);
    
    
    /**
     * 获取临时文件存放路径
     * @param fileName
     * @return
     */
    String getChunksFolderPath(String fileName);
    
    
    /**
     * 获取文件大小
     * @param path
     * @return
     */
    Long getFileSize(String path);
}
