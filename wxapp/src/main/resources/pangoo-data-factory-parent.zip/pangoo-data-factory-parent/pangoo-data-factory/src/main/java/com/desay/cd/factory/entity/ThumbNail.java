package com.desay.cd.factory.entity;

import org.springframework.context.ApplicationEvent;

/**
 * 异步消息
 * 
 * @author uidq1343
 *
 */
public class ThumbNail extends ApplicationEvent {
    
    public ThumbNail(Object source) {
        super(source);
    }
    private static final long serialVersionUID = -3423204956264545900L;

    
}
