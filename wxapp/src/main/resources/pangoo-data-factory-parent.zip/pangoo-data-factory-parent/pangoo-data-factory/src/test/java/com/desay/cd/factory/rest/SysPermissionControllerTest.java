package com.desay.cd.factory.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ISysPermissionDao;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.rest.vo.AddPermissionVo;

/**
 * SysPermissionControllerTest
 * 
 * @author pengdengfu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SysPermissionControllerTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    ISysPermissionDao sysPermissionDao;

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Test
    public void testPermission() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("permissionName", "testPermission");
        params.add("url", "http://www.baidu.com");
        params.add("permissionDesc", "testPermissionDesc");

        AddPermissionVo addPermissionVo = new AddPermissionVo();
        addPermissionVo.setPermissionName("testPermission");
        addPermissionVo.setUrl("http://www.baidu.com");
        addPermissionVo.setPermissionDesc("testPermissionDesc");
        String requestJson = JSONObject.toJSONString(addPermissionVo);
        // 添加
        mvc.perform(post("/management/permissions").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 重复添加
        mvc.perform(post("/management/permissions").contentType(MediaType.APPLICATION_JSON_UTF8).content(requestJson).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20032));
        // 查询
        params.clear();
        params.add("pageNo", "1");
        params.add("pageSize", "1");
        MvcResult mvcResult = mvc.perform(get("/management/permissions")).andExpect(status().is(200)).andDo(MockMvcResultHandlers.print()).andReturn();
        String result = mvcResult.getResponse().getContentAsString();
        JSONObject resultObj = JSON.parseObject(result);
        assertEquals(0, resultObj.get("code"));

        // 更新
        params.clear();
        SysPermission sysPermission = new SysPermission();
        sysPermission.setPermissionName("testPermission");
        Example<SysPermission> example = Example.of(sysPermission);
        SysPermission findOne = sysPermissionDao.findOne(example);

        AddPermissionVo apdatePermission = new AddPermissionVo();
        apdatePermission.setPermissionName("testPermissionXXX");
        apdatePermission.setUrl("https://oa.desaysv.com/sys/portal/page.jsp");
        apdatePermission.setPermissionDesc("testPermissionDescXXX");
        String updateRequestJson = JSONObject.toJSONString(apdatePermission);
        mvc.perform(put("/management/permissions/" + findOne.getPermissionId()).contentType(MediaType.APPLICATION_JSON_UTF8).content(updateRequestJson).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));

        // 更新不存在的数据
        mvc.perform(put("/management/permissions/testNotExistData").contentType(MediaType.APPLICATION_JSON_UTF8).content(updateRequestJson).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20033));

        // 删除
        params.clear();
        SysPermission sysPermission2 = new SysPermission();
        sysPermission2.setPermissionName("testPermissionXXX");
        Example<SysPermission> example2 = Example.of(sysPermission2);
        SysPermission findOne2 = sysPermissionDao.findOne(example2);
        mvc.perform(delete("/management/permissions/" + findOne2.getPermissionId()).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(0));
        // 删除不存在的数据
        mvc.perform(delete("/management/permissions/testNotExistData").contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$.code").value(20033));

    }

}
