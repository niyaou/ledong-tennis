package com.desay.cd.factory.utils;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Java2DFrameConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.desay.cd.hdfs.HdfsUtils;
import com.madgag.gif.fmsware.AnimatedGifEncoder;

/**
 * 创建缩略图和视频概要gif图的工具类
 * 
 * @author uidq1343
 *
 */
public final class ThumbNailUtil {

    private static Logger logger = LoggerFactory.getLogger(ThumbNailUtil.class);

    public static String createGif1(String displayName, String storedPath, InputStream ins) throws Exception {

        int startFrame = 20;
        int margin = 0;
        float frameRate = 2.5f;
        int totalTime = 10;

        // FileOutputStream targetFile = new FileOutputStream(displayName+".gif");
        String targetPath = storedPath + displayName + ".gif";

        FFmpegFrameGrabber ff = new FFmpegFrameGrabber(ins);
        Java2DFrameConverter converter = new Java2DFrameConverter();
        ff.start();

        try (OutputStream hdfsFile = HdfsUtils.createFileStream(targetPath)) {

            ff.setVideoFrameNumber(startFrame);
            margin = (int) (ff.getLengthInFrames() / (frameRate * totalTime));
            AnimatedGifEncoder en = new AnimatedGifEncoder();
            en.setFrameRate(frameRate);
            en.setRepeat(0);
            en.setQuality(20);
            en.start(hdfsFile);

            int i = startFrame;
            while (i < ff.getLengthInFrames()) {

                if (i % margin == 0) {
                    BufferedImage bI = converter.convert(ff.grab());
                    int w = bI.getWidth();
                    int h = bI.getHeight();
                    BufferedImage bufferedImage = new BufferedImage(w / 2, h / 2, BufferedImage.TYPE_INT_RGB);
                    Graphics graphics = bufferedImage.getGraphics();
                    graphics.drawImage(bI, 0, 0, w / 2, h / 2, null);
                    en.addFrame(bufferedImage);
                    ff.setVideoFrameNumber(i + margin);
                }
                i++;
            }
            en.finish();

        } finally {
            ff.stop();
            ff.close();
        }
        return targetPath;
    }

    public static String createGif(String displayName, String storedPath, InputStream ins) throws Exception {
        String[] rm = new String[] { "/bin/sh", "-c", "rm -rf temp" };
        logger.info(runShell(rm));

        // FileOutputStream targetFile = new FileOutputStream(displayName+".gif");
        String targetPath = storedPath + displayName + ".gif";
        logger.info(" targetPath:" + targetPath);

        String execResult = "";
        String[] mkdir = new String[] { "/bin/sh", "-c", "mkdir temp" };

        execResult = runShell(mkdir);
        if (StringUtil.isEmpty(execResult)) {
            logger.info(runShell(rm));
            return null;
        }
        execResult = downloadFile(displayName, ins);
        if (StringUtil.isEmpty(execResult)) {
            logger.info(runShell(rm));
            return null;
        }

        String[] cmdArray = new String[] { "/bin/sh", "-c", "ffmpeg -i \"temp/" + displayName + "\" 2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,//" };
        String[] thumbnail = new String[] { "/bin/sh", "-c", "ffmpeg -f image2 -framerate 2.5 -y -i \"temp/image_%05d.jpg\" \"temp/" + displayName + ".gif\"" };

        int i = 0;
        String[] createFrameTimes = createFrameTimes(runShell(cmdArray));
        if (createFrameTimes != null && createFrameTimes.length > 0) {
            for (String string : createFrameTimes) {
                execResult = runShell(new String[] { "/bin/sh", "-c", "ffmpeg -ss " + string + " -i \"temp/" + displayName
                        + "\" -s 480*300  -f image2 -vframes 1 -y -vsync 1   \"temp/image_" + String.format("%05d", i) + ".jpg\" " });
                i++;
                if (StringUtil.isEmpty(execResult)) {
                    logger.info(runShell(rm));
                    return null;
                }
            }
        }

        execResult = runShell(thumbnail);
        if (StringUtil.isEmpty(execResult)) {
            logger.info(runShell(rm));
            return null;
        }

        try (OutputStream hdfsFile = HdfsUtils.createFileStream(targetPath)) {
            if (hdfsFile == null) {
                return null;
            }
            execResult = writeToHdfs(displayName + ".gif", hdfsFile);
        }
        if (StringUtil.isEmpty(execResult)) {
            logger.info(runShell(rm));
            return null;
        }

        logger.info(runShell(rm));

        return targetPath;
    }

    /**
     * 将文件从hdfs下载到本地
     * 
     * @param displayName
     * @param is
     * @return
     */
    private static String downloadFile(String displayName, InputStream is) {
        File f = new File("temp/" + displayName);
        FileOutputStream outputStream = null;

        try {
            logger.info(" displayName:" + displayName);
            outputStream = new FileOutputStream(f);
            byte bytes[] = new byte[1024];
            int temp = 0;
            while ((temp = is.read(bytes)) != -1) {
                outputStream.write(bytes, 0, temp);
            }
            return "temp/" + displayName;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                if (outputStream != null) {
                    outputStream.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * 将文件写入hdfs
     * 
     * @param displayName
     * @param out
     * @return
     */
    private static String writeToHdfs(String displayName, OutputStream out) {
        File f = new File("temp/" + displayName);
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(f);

            byte bytes[] = new byte[1024];
            int temp = 0;
            while ((temp = fileInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, temp);
            }
            return "temp/" + displayName;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * 
     * @param cmds
     * @return
     */
    private static String runShell(String[] cmds) {
        String result = "";
        Process process = null;
        List<String> processList = new ArrayList<String>();
        try {
            process = Runtime.getRuntime().exec(cmds);
            int exitValue = process.waitFor();
            logger.info("runtime command : " + cmds[2] + "result :" + exitValue);
            if (0 != exitValue) {
                logger.error("call shell failed. error code is :" + exitValue);
                return result;
            }
            BufferedReader input = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = "";
            while ((line = input.readLine()) != null) {
                processList.add(line);
                logger.info(" command processList line add: " + line);
            }
            input.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (Exception f) {
            f.printStackTrace();
            return null;
        }

        for (String line : processList) {
            if (StringUtil.isNotEmpty(line)) {
                result = line;
            }
        }

        return StringUtil.isEmpty(result) ? "execute command  successed" : result;
    }

    /**
     * 
     * @param time
     * @return
     */
    private static String[] createFrameTimes(String time) {
        String[] arrs = new String[25];
        String[] defaultArr = new String[] { "00:00:02", "00:00:04", "00:00:06", "00:00:08", "00:00:10", "00:00:12", "00:00:14", "00:00:16", "00:00:18", "00:00:20", "00:00:22",
                "00:00:24", "00:00:26", "00:00:28", "00:00:30", "00:00:32", "00:00:34", "00:00:36", "00:00:38", "00:00:40", "00:00:42", "00:00:44", "00:00:46", "00:00:48",
                "00:00:50", };
        String[] times = time.split(":");
        if (times.length > 1) {
            if (Integer.valueOf(times[1]) > 1 || Integer.valueOf(times[1]) > 0) {
                return defaultArr;
            } else {
                arrs = createSeries(times);
            }
            ;

        } else {
            return defaultArr;
        }

        return arrs;

    }

    /**
     * 
     * @param times
     * @return
     */
    private static String[] createSeries(String[] times) {
        float seconds = Float.parseFloat(times[2]);
        int minutes = Integer.parseInt(times[1]);
        float total = (minutes * 60 + seconds);
        float interval = total / 25;
        String[] arrs = new String[25];
        float current = 0;
        int int25 = 25;
        for (int i = 0; i < int25; i++) {
            current += interval;
            arrs[i] = secToTime(current);
        }
        return arrs;

    }

    /**
     * 
     * @param time
     * @return
     */
    private static String secToTime(float time) {
        String timeStr = null;
        int hour = 0;
        int minute = 0;
        float second = 0;
        if (time <= 0)
            return "00:00:00";
        else {
            int int60 = 60;
            minute = (int) (time / int60);
            if (minute < int60) {
                second = time % int60;
                timeStr = "00:" + unitFormat(minute, true) + ":" + unitFormat(second, false);
            } else {
                hour = minute / int60;
                int int99 = 99;
                if (hour > int99) {
                    return "99:59:59";
                }
                minute = minute % int60;
                second = time - hour * 3600 - minute * int60;
                timeStr = unitFormat(hour, true) + ":" + unitFormat(minute, true) + ":" + unitFormat(second, false);
            }
        }
        return timeStr;
    }

    /**
     * 
     * @param i
     * @param isInt
     * @return
     */
    private static String unitFormat(float i, boolean isInt) {
        String retStr = null;
        int int10 = 10;
        if (i >= 0 && i < int10) {
            retStr = isInt ? ("0" + (int) i) : ("0" + Float.toString(i));
        } else {
            retStr = isInt ? ("" + (int) i) : ("" + i);
        }
        return retStr;
    }

}
