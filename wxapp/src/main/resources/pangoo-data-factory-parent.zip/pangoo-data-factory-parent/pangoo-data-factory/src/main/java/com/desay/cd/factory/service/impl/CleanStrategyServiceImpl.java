package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ICleanStrategyDao;
import com.desay.cd.factory.dao.IClearAlgorithmDao;
import com.desay.cd.factory.dao.IDataDictionaryDao;
import com.desay.cd.factory.dao.ISysDeviceDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.CleanAlgorithm;
import com.desay.cd.factory.entity.mysql.CleanStrategy;
import com.desay.cd.factory.entity.mysql.DataDictionary;
import com.desay.cd.factory.entity.mysql.SysDevice;
import com.desay.cd.factory.service.ICleanStrategyService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * 
 * @ClassName: CleanStrategyServiceImpl
 * @author: pengdengfu
 * @date: 2019年11月1日 下午12:01:07
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class CleanStrategyServiceImpl implements ICleanStrategyService {
    @Autowired
    private ICleanStrategyDao cleanStrategyDao;
    @Autowired
    private IClearAlgorithmDao clearAlgorithmDao;
    @Autowired
    private ISysDeviceDao sysDeviceDao;
    @Autowired
    private IDataDictionaryDao dataDictionaryDao;

    @Override
    public String add(CleanStrategy cleanStrategy) {
        // check id
        checkIds(cleanStrategy);
        try {
            cleanStrategyDao.saveAndFlush(cleanStrategy);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
        return cleanStrategy.getStrgyId();
    }

    private void checkIds(CleanStrategy cleanStrategy) {
        if (cleanStrategy.getCleanAlgorithm() != null && StringUtils.isNotEmpty(cleanStrategy.getCleanAlgorithm().getAlgId())) {
            CleanAlgorithm cleanAlgorithm = clearAlgorithmDao.findOne(cleanStrategy.getCleanAlgorithm().getAlgId());
            if (cleanAlgorithm == null) {
                throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
            } else {
                cleanStrategy.setCleanAlgorithm(cleanAlgorithm);
            }
        }
        if (cleanStrategy.getSysDevice() != null && StringUtils.isNotEmpty(cleanStrategy.getSysDevice().getDeviceId())) {
            SysDevice sysDevice = sysDeviceDao.findOne(cleanStrategy.getSysDevice().getDeviceId());
            if (sysDevice == null) {
                throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
            } else {
                cleanStrategy.setSysDevice(sysDevice);
            }
        }
        if (cleanStrategy.getPriority() != null && StringUtils.isNotEmpty(cleanStrategy.getPriority().getDataId())) {
            DataDictionary dataDictionary = dataDictionaryDao.findOne(cleanStrategy.getPriority().getDataId());
            if (dataDictionary == null) {
                throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
            } else {
                cleanStrategy.setPriority(dataDictionary);
            }
        }
    }

    @Override
    public void delete(String strgyId) {
        CleanStrategy findOne = cleanStrategyDao.findOne(strgyId);
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        try {
            cleanStrategyDao.delete(strgyId);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }

    }

    @Override
    public void update(CleanStrategy cleanStrategy, boolean isOverall) {
        CleanStrategy findOne = cleanStrategyDao.findOne(cleanStrategy.getStrgyId());
        if (findOne == null) {
            throw new BusinessException(ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED, null, ResultCodeEnum.SPECIFIED_DATA_NOT_EXISTED.getMessage());
        }
        checkIds(cleanStrategy);
        try {
            if (isOverall) {
                BeanUtils.copyProperties(cleanStrategy, findOne, "createTime");
            } else {
                BeanUtils.copyProperties(cleanStrategy, findOne, ControllerCommonUtils.getNullPropertyNames(cleanStrategy));
            }

            cleanStrategyDao.saveAndFlush(findOne);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }

    }

    @Override
    public Page<CleanStrategy> search(String strgyId, String strygName, String strygNameLike, String deviceId, String deviceName, String deviceNameLike, String algId,
            String algName, String algNameLike, String status, Integer pageNo, Integer pageSize, List<String> sortProperties) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, sortProperties, "createTime");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(strygName)) {
            strygName = strygName.replaceAll("%", "\\\\%");
            strygName = strygName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(deviceName)) {
            deviceName = deviceName.replaceAll("%", "\\\\%");
            deviceName = deviceName.replaceAll("_", "\\\\_");
        }
        if (StringUtils.isNotEmpty(algName)) {
            algName = algName.replaceAll("%", "\\\\%");
            algName = algName.replaceAll("_", "\\\\_");
        }

        final String strygNameTmp = strygName;
        final String deviceNameTmp = deviceName;
        final String algNameTmp = algName;
        Specification<CleanStrategy> specification = new Specification<CleanStrategy>() {
            @Override
            public Predicate toPredicate(Root<CleanStrategy> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(strgyId)) {
                    predicates.add(cb.equal(root.get("strgyId"), strgyId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                if (StringUtils.isNotEmpty(strygNameTmp)) {
                    if (StringUtils.equalsIgnoreCase(strygNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(root.get("strygName"), "%" + strygNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(root.get("strygName"), strygNameTmp));
                    }
                }
                if (StringUtils.isNotEmpty(deviceId)) {
                    Join<CleanStrategy, SysDevice> join = root.join("sysDevice", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("deviceId"), deviceId));
                }
                if (StringUtils.isNotEmpty(deviceNameTmp)) {
                    Join<CleanStrategy, SysDevice> join = root.join("sysDevice", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(deviceNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.like(join.get("deviceName"), "%" + deviceNameTmp + "%"));
                    } else {
                        predicates.add(cb.equal(join.get("deviceName"), deviceNameTmp));
                    }
                }
                if (StringUtils.isNotEmpty(algId)) {
                    Join<CleanStrategy, CleanAlgorithm> join = root.join("cleanAlgorithm", JoinType.LEFT);
                    predicates.add(cb.equal(join.get("algId"), algId));
                }
                if (StringUtils.isNotEmpty(algNameTmp)) {
                    Join<CleanStrategy, CleanAlgorithm> join = root.join("cleanAlgorithm", JoinType.LEFT);
                    if (StringUtils.equalsIgnoreCase(algNameLike, Constanst.SEARCH_LIKE)) {
                        predicates.add(cb.or(cb.like(join.get("algName"), "%" + algNameTmp + "%")));
                    } else {
                        predicates.add(cb.equal(join.get("algName"), algNameTmp));
                    }
                }

                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };

        return cleanStrategyDao.findAll(specification, pageable);
    }

}
