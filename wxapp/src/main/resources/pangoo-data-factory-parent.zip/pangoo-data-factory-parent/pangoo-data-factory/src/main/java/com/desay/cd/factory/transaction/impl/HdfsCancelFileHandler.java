package com.desay.cd.factory.transaction.impl;

import java.io.IOException;

import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.transaction.base.FileElement;
import com.desay.cd.factory.transaction.base.BaseHdfsServiceHandler;


/**
 * 取消文件上传任务事务处理类
 * @author uidq1343
 *
 */
public class HdfsCancelFileHandler extends  BaseHdfsServiceHandler {
    
   
    @Override
    public void doHandleReal(FileElement element) throws CustumException {
        
            String path=hdfsFileService.getChunksFolderPath(element.getChunk().getFileId());
            try {
                if(!hdfsFileService.deleteDirectoryRecursively(path)) {
                 throw   new CustumException(ResultCodeEnum.DELETE_FILE_FAILD.getCode(), ResultCodeEnum.DELETE_FILE_FAILD.getMessage());
                }
            } catch (IOException e) {
                throw  new CustumException(ResultCodeEnum.DELETE_FILE_FAILD.getCode(), ResultCodeEnum.DELETE_FILE_FAILD.getMessage());
            }
    }

    
    @Override
    public void rollBackReal(FileElement element) {
        
    }

}
