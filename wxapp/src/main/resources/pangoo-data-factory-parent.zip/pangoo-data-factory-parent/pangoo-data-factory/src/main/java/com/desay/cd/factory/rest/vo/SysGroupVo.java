package com.desay.cd.factory.rest.vo;

import java.io.Serializable;
import java.util.Set;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: SysGroupVo
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:37:13
 */
@Data
public class SysGroupVo implements Serializable {

    private static final long serialVersionUID = -4614160335978798032L;

    @NotEmpty
    @ApiModelProperty(value = "组名称")
    private String groupName;

    @ApiModelProperty(value = "组描述")
    private String groupDesc;

    @ApiModelProperty(value = "组成员userId")
    private Set<String> memberIds;

    @ApiModelProperty(value = "管理员userId")
    private Set<String> masterIds;

    @ApiModelProperty(value = "组能力Id")
    private Set<String> abilityIds;

    @ApiModelProperty(value = "所属子系统Id")
    private String subsystemId;

    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", allowableValues = "1,0", example = "1", required = false)
    @Range(min = 0, max = 1, message = "状态必须在[0,1]")
    private Integer isActive = 1;

}
