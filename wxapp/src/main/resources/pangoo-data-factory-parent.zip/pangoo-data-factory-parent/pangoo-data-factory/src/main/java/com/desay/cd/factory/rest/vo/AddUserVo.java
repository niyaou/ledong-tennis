package com.desay.cd.factory.rest.vo;

import java.util.Set;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: UserVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午3:30:21
 */
@ApiModel(value = "添加用户")
@Data
public class AddUserVo {
    /** 用户Id */
    @ApiModelProperty(value = "userId(0<size<=20)", required = true)
    @NotEmpty
    @Length(min = 1, max = 20, message = "length长度在[1,20]之间")
    private String userId;

    /** 用户角色Id */
    @ApiModelProperty(value = "用户角色Id列表", required = false)
    private Set<String> roleIds;

    @ApiModelProperty(value = "用户状态：1：启用，0：不启用", required = false, allowableValues = "0,1", example = "1")
    private String status = "1";

    @ApiModelProperty(value = "用户所属子系统Id列表（忽略不存在的id）", required = false)
    private Set<String> subsystemId;

    @ApiModelProperty(value = "组能力Id")
    private Set<String> abilityIds;

    @ApiModelProperty(value = "用户所属组")
    private Set<GroupVO> groups;

}