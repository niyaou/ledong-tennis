package com.desay.cd.factory.utils.validate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author
 * @date 2018-04-25
 * @description：校验注解类
 */

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD, ElementType.PARAMETER })
public @interface Validate {
	/** 是否可以为空 */
	boolean nullable() default false;

	/** 最大长度 */
	int maxLength() default 0;

	/** 最小长度 */
	int minLength() default 0;

	/** 最大值 */
	int max() default 0;

	/** 最小值 */
	int min() default 0;

	/** 表示这个字段是否为int类型 */
	boolean isInt() default false;

	/** 提供几种常用的正则验证 */
	RegexType regexType() default RegexType.NONE;

	/** 自定义正则验证 */
	String regexExpression() default "";

	/** 参数或者字段描述,这样能够显示友好的异常信息 */
	String description() default "";

	/** 时间格式验证 */
	String dateformat() default "";

	/** 字符串数字取值范围：不区分大小写 */
	String[] rangeS() default {};

	/** 字符串数字取值范围：严格模式 */
	String[] rangeStrict() default {};
}
