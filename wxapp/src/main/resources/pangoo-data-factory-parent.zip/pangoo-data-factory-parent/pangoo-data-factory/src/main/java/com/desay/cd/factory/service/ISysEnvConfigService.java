package com.desay.cd.factory.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.desay.cd.factory.entity.mysql.SysEnvConfig;

/**
 * 
 * @ClassName: ISysEnvConfigService
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:22:23
 */
public interface ISysEnvConfigService {
    /**
     * 添加
     * 
     * @param sysEnvConfig
     * @return
     */
    String addOrUpdate(SysEnvConfig sysEnvConfig);

    /**
     * 删除
     * 
     * @param envId
     */
    void delete(String envId);

    /**
     * 查询
     * 
     * @param envId
     * @param type
     * @param ip
     * @param hostName
     * @param hostNameLike
     * @param pageNo
     * @param pageSize
     * @param sortProperties
     * @return
     */
    Page<SysEnvConfig> search(String envId, String type, String ip, String hostName, String hostNameLike, Integer pageNo, Integer pageSize, List<String> sortProperties);
}
