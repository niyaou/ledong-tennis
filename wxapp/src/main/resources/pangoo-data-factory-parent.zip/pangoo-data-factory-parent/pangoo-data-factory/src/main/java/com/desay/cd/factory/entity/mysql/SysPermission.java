package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 系统权限
 * 
 * @author pengdengfu
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_permission", uniqueConstraints = { @UniqueConstraint(columnNames = { "permission_name" }) })
public class SysPermission implements Serializable {

    private static final long serialVersionUID = -462282051234984338L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "permission_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String permissionId;

    /** 权限名称 */
    @Column(name = "permission_name", unique = true, nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '权限名称'")
    private String permissionName;

    /** url的方法 */
    @Column(name = "method", nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT 'url的方法'")
    private String method;

    /** 权限对应的url */
    @Column(name = "url", nullable = false, length = 500, columnDefinition = "varchar(500) COMMENT '权限对应的url'")
    private String url;

    /** 权限描述 */
    @Column(name = "permission_desc", columnDefinition = "text COMMENT '权限描述'")
    private String permissionDesc;

    /** 权限角色关系 */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "sys_role_permission", joinColumns = { @JoinColumn(name = "permission_id") }, inverseJoinColumns = { @JoinColumn(name = "role_id") })
    @JsonIgnore
    private Set<SysRole> roles;

    /** 所属子系统 */
    @ManyToOne
    @JoinColumn(name = "sub_system_id")
    private SysSubSystem sysSubsystem;

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private String isActive = "1";

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    public SysPermission() {
    }

    public SysPermission(String permissionId) {
        this.permissionId = permissionId;
    }

    public SysPermission(String permissionName, String url, String permissionDesc) {
        this.permissionName = permissionName;
        this.url = url;
        this.permissionDesc = permissionDesc;
    }

    public SysPermission(String permissionId, String permissionName, String url, String permissionDesc) {
        this.permissionId = permissionId;
        this.permissionName = permissionName;
        this.url = url;
        this.permissionDesc = permissionDesc;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((permissionId == null) ? 0 : permissionId.hashCode());
        result = prime * result + ((permissionName == null) ? 0 : permissionName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysPermission other = (SysPermission) obj;
        if (permissionId == null) {
            if (other.permissionId != null) {
                return false;
            }
        } else if (!permissionId.equals(other.permissionId)) {
            return false;
        }
        if (permissionName == null) {
            if (other.permissionName != null) {
                return false;
            }
        } else if (!permissionName.equals(other.permissionName)) {
            return false;
        }
        return true;
    }

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPermissionDesc() {
        return permissionDesc;
    }

    public void setPermissionDesc(String permissionDesc) {
        this.permissionDesc = permissionDesc;
    }

    public Set<SysRole> getRoles() {
        return roles;
    }

    public void setRoles(Set<SysRole> roles) {
        this.roles = roles;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public SysSubSystem getSysSubsystem() {
        return sysSubsystem;
    }

    public void setSysSubsystem(SysSubSystem sysSubsystem) {
        this.sysSubsystem = sysSubsystem;
    }

}
