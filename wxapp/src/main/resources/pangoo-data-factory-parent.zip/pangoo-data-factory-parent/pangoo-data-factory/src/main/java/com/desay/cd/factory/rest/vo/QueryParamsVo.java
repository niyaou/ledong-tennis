package com.desay.cd.factory.rest.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: QueryParamsVo
 * @author: nixuchun
 * @date: 2019年4月17日 下午4:11:27
 */
@ApiModel(value = "文件审核")
public class QueryParamsVo {
    @ApiModelProperty(value = "开始时间  YYYY-MM-DD", required = false)
    private String startTime;
    @ApiModelProperty(value = "结束时间 YYYY-MM-DD", required = false)
    private String endTime;
    @ApiModelProperty(value = "文件状态 { 0：未完成，1：待审核，2，待清洗，3：入库，4：拒绝，5：已删除，6：已取消 ，7：预留}", required = false)
    private String status;
    @ApiModelProperty(value = "用户id", required = false)
    private String userId;
    @ApiModelProperty(value = "产品名", required = false)
    private String productName;
    @ApiModelProperty(value = "设备名", required = false)
    private String deviceName;
    @ApiModelProperty(value = "文件类型 {0：视频，1：图片，2，文档，3：音频}", required = false)
    private String fileType;
    @ApiModelProperty(value = "文件大小最小值 Kb", required = false)
    private String minSize;
    @ApiModelProperty(value = "文件大小最大值 Kb", required = false)
    private String maxSize;
    @ApiModelProperty(value = "页码", required = false)
    private String pageNo;
    @ApiModelProperty(value = "每页数据条数", required = false)
    private String pageSize;
    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getDeviceName() {
        return deviceName;
    }
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }
    public String getFileType() {
        return fileType;
    }
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
    public String getMinSize() {
        return minSize;
    }
    public void setMinSize(String minSize) {
        this.minSize = minSize;
    }
    public String getMaxSize() {
        return maxSize;
    }
    public void setMaxSize(String maxSize) {
        this.maxSize = maxSize;
    }
    public String getPageNo() {
        return pageNo;
    }
    public void setPageNo(String pageNo) {
        this.pageNo = pageNo;
    }
    public String getPageSize() {
        return pageSize;
    }
    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }
    
   

}
