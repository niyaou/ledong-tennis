package com.desay.cd.factory.entity;

import com.fasterxml.jackson.databind.ser.std.SerializableSerializer;

/**
 * 
 * @author uidq1343
 *
 */
public class Progress extends SerializableSerializer {
    private static final long serialVersionUID = -7842275939711475314L;
    public static String PROGRESS_STATUS = "progress_status";
    /** 已读取文件的比特数 */
    private long bytesRead;
    /** 文件总比特数 */
    private long contentLength;
    /** 正读的第几个文件 */
    private long items;

    public long getBytesRead() {
        return bytesRead;
    }

    public void setBytesRead(long bytesRead) {
        this.bytesRead = bytesRead;
    }

    public long getContentLength() {
        return contentLength;
    }

    public void setContentLength(long contentLength) {
        this.contentLength = contentLength;
    }

    public long getItems() {
        return items;
    }

    public void setItems(long items) {
        this.items = items;
    }

}