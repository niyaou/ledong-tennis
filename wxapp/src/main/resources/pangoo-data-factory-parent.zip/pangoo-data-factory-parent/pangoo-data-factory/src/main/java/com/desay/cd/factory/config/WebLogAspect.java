package com.desay.cd.factory.config;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.factory.service.ISysUserService;

/**
 * 
 * @ClassName: WebLogAspect
 * @author: pengdengfu
 * @date: 2019年5月10日 下午6:13:21
 */
@Aspect
@Component
@ConditionalOnProperty(prefix = "pangoo-data-factory.web.log", name = "switch", havingValue = "true")
public class WebLogAspect {
    private Logger logger = LoggerFactory.getLogger(WebLogAspect.class);
    @Autowired
    private ISysUserService userService;

    @Value("${pangoo-data-factory.web.log.response}")
    private boolean isShowResp;

    @Pointcut("execution(* com.desay.cd.factory.rest.*.*(..))")
    public void pointLog() {
    }

    @Around("pointLog()")
    public Object timeAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime;
        long endTime;
        Object obj;

        // 获取开始时间
        startTime = System.currentTimeMillis();
        // 接收到请求，记录请求内容
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();

        Map<String, String> logMap = new LinkedHashMap<>(6);
        logMap.put("userId", getUserId(request));
        logMap.put("url", request.getRequestURL().toString());
        logMap.put("ip", request.getRemoteAddr());
        logMap.put("class_method", joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName());
        logMap.put("args", Arrays.toString(joinPoint.getArgs()));

        logger.info(logMap.toString());
        // 获取返回结果集
        obj = joinPoint.proceed(joinPoint.getArgs());
        // 获取方法执行时间
        endTime = System.currentTimeMillis() - startTime;
        if (isShowResp) {
            logger.info("reponse : " + obj.toString());
        }
        String classAndMethod = joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName();
        logger.info("Execute " + classAndMethod + " Time-consuming : " + endTime + "ms");

        return obj;
    }

    /**
     * 获取userId
     * 
     * @param request
     * @return
     */
    private String getUserId(HttpServletRequest request) {
        Object token = request.getHeader("access_token");
        TokenDto tokenDto = null;
        if (null != token) {
            tokenDto = (TokenDto) userService.tokenAuthorize((String) token);
            if (null != tokenDto) {
                return tokenDto.cid;
            }
        }
        return null;
    }
}