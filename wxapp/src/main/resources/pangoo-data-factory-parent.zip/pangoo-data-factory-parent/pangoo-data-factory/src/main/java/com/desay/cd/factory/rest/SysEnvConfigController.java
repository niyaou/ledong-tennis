package com.desay.cd.factory.rest;

import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.storage.engine.common.exception.BusinessException;

import com.desay.cd.factory.annotation.LogAnnotation;
import com.desay.cd.factory.entity.CommonResponse;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysEnvConfig;
import com.desay.cd.factory.enums.LogActionEnum;
import com.desay.cd.factory.rest.vo.SysEnvConfigVo;
import com.desay.cd.factory.service.ISysEnvConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @ClassName: SysEnvConfigController
 * @author: pengdengfu
 * @date: 2019年11月1日 上午10:34:45
 */
@Api(tags = "SysEnvConfigController", value = "NEW-运行环境配置")
@RestController
@Validated
public class SysEnvConfigController {
    @Autowired
    private ISysEnvConfigService sysEnvConfigService;

    @RequestMapping(value = "/management/envConfig", method = RequestMethod.POST)
    @ApiOperation(value = "运行环境配置-添加", notes = "")
    @LogAnnotation(action = LogActionEnum.ENV_CONFIG, message = "运行环境配置-添加")
    public ResponseEntity<?> add(@RequestBody @Validated SysEnvConfigVo sysEnvConfigVo) {
        SysEnvConfig sysEnvConfig = new SysEnvConfig();
        BeanUtils.copyProperties(sysEnvConfigVo, sysEnvConfig);
        try {
            String envId = sysEnvConfigService.addOrUpdate(sysEnvConfig);
            return new ResponseEntity<Object>(CommonResponse.success(envId), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    @RequestMapping(value = "/management/envConfig/{envId}", method = RequestMethod.DELETE)
    @ApiImplicitParams({ @ApiImplicitParam(name = "envId", value = "ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "运行环境配置-删除", notes = "")
    @LogAnnotation(action = LogActionEnum.ENV_CONFIG, message = "运行环境配置-删除")
    public ResponseEntity<?> add(@PathVariable(value = "envId", required = true) String envId) {
        try {
            sysEnvConfigService.delete(envId);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA, null, ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage());
        }
    }

    @RequestMapping(value = "/management/envConfig/{envId}", method = RequestMethod.PUT)
    @ApiImplicitParams({ @ApiImplicitParam(name = "envId", value = "ID", required = true, dataType = "String", paramType = "path") })
    @ApiOperation(value = "运行环境配置-更新-整体更新", notes = "用提供的对象数据，替换原始数据,必填字段必须填写")
    @LogAnnotation(action = LogActionEnum.ENV_CONFIG, message = "运行环境配置-更新-整体更新")
    public ResponseEntity<?> put(@PathVariable(value = "envId", required = true) String envId, @Validated @RequestBody SysEnvConfigVo sysEnvConfigVo) {
        SysEnvConfig sysEnvConfig = new SysEnvConfig();
        BeanUtils.copyProperties(sysEnvConfigVo, sysEnvConfig);
        try {
            sysEnvConfigService.addOrUpdate(sysEnvConfig);
            return new ResponseEntity<Object>(CommonResponse.success(), HttpStatus.OK);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new BusinessException(ResultCodeEnum.OTHER_USER_UPDATED, null, ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException(ResultCodeEnum.SAME_NAME_EXISTED, null, ResultCodeEnum.SAME_NAME_EXISTED.getMessage());
        }
    }

    @RequestMapping(value = "/management/envConfig", method = RequestMethod.GET)
    @ApiOperation(value = "运行环境配置-查询", notes = "当pageNo，pageSize为空时，默认返回第一页10条数据.")
    @ApiImplicitParams({ @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "sortProperties", value = "排序字段列表,[+col1,-col2],按照 col1升序， col2降序", required = false, dataType = "string", allowMultiple = true, paramType = "query"),
            @ApiImplicitParam(name = "envId", value = "Id", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "type", value = "数据类型：1，算法机器；2：镜像仓库；3：hdfs client", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "ip", value = "ip", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "hostName", value = "主机名称", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "hostNameLike", value = "为like时，模糊匹配，其他为精确查询", required = false, dataType = "string", allowableValues = "like,equal", paramType = "query") })
    @LogAnnotation(action = LogActionEnum.ENV_CONFIG, message = "运行环境配置-查询")
    public ResponseEntity<?> search(@RequestParam(value = "pageSize", required = false) @Min(value = 1, message = "pageSize必须大于1") Integer pageSize,
            @RequestParam(value = "pageNo", required = false) @Min(value = 1, message = "pageNo必须大于1") Integer pageNo,
            @RequestParam(value = "sortProperties", required = false) List<String> sortProperties, @RequestParam(value = "envId", required = false) String envId,
            @RequestParam(value = "type", required = false) String type, @RequestParam(value = "ip", required = false) String ip,
            @RequestParam(value = "hostName", required = false) String hostName, @RequestParam(value = "hostNameLike", required = false) String hostNameLike) {
        Page<SysEnvConfig> rlt = sysEnvConfigService.search(envId, type, ip, hostName, hostNameLike, pageNo, pageSize, sortProperties);
        return new ResponseEntity<Object>(CommonResponse.success(rlt), HttpStatus.OK);
    }

}
