package com.desay.cd.factory.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.cd.factory.entity.mysql.SysEnvConfig;

/**
 * 
 * @ClassName: ISysEnvConfigDao
 * @author: pengdengfu
 * @date: 2019年11月1日 上午11:08:31
 */
public interface ISysEnvConfigDao extends JpaRepository<SysEnvConfig, Serializable>, JpaSpecificationExecutor<SysEnvConfig> {

}
