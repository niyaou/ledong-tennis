package com.desay.cd.factory.service.impl;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.dao.ISysPermissionDao;
import com.desay.cd.factory.dao.ISysRoleDao;
import com.desay.cd.factory.dao.ISysSubSystemDao;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.entity.mysql.SysUser;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.enums.UserRoleEnum;
import com.desay.cd.factory.service.IIndexService;
import com.desay.cd.factory.service.ISysPermissionService;
import com.desay.cd.factory.service.MailSenderService;
import com.desay.cd.factory.utils.StringUtil;

/**
 * 服务开始启动执行一次
 * 
 * @author uidq1163
 *
 */
@Component
@Order(1)
public class StartUpRunner implements CommandLineRunner {

    @Autowired
    private ISysPermissionService iSysPermissionService;

    @Value("${server.port}")
    private String port;
    @Autowired
    private ISysPermissionDao iSysPermissionDao;
    @Autowired
    private IIndexService indexService;
    @Autowired
    private MailSenderService mailSenderService;
    @Autowired
    private ISysRoleDao iSysRoleDao;
    @Autowired
    private ISysSubSystemDao sysSubSystemDao;

    @Override
    public void run(String... arg0) throws Exception {
        // initSystemData();
    }

    public void initSystemData() {
        String subsystemName = "Pangoo Das";
        SysSubSystem findBySubSystemName = sysSubSystemDao.findBySubsystemName(subsystemName);
        if (findBySubSystemName == null) {
            // 添加子系统
            List<SysSubSystem> findAllSysSub = sysSubSystemDao.findAll();
            if (findAllSysSub == null || findAllSysSub.size() <= 0) {
                SysSubSystem sysSubSystem = new SysSubSystem();
                sysSubSystem.setSubsystemName(subsystemName);
                sysSubSystemDao.saveAndFlush(sysSubSystem);
            }
        }
        findBySubSystemName = sysSubSystemDao.findBySubsystemName(subsystemName);
        // 添加权限数据
        initPermissions(findBySubSystemName);
        // 添加角色
        initRoles(findBySubSystemName);

    }

    /**
     * 添加角色
     */
    public void initRoles(SysSubSystem findBySubSystemName) {
        List<SysRole> findAllRoles = iSysRoleDao.findAll();
        if (findAllRoles == null || findAllRoles.size() <= 0) {
            // 管理员
            SysRole sysRoleMng = new SysRole();
            sysRoleMng.setRoleName("superManagement");
            sysRoleMng.setRoleDesc("超级管理员");
            Set<SysPermission> permissionsMng = new HashSet<>(iSysPermissionDao.findAll());
            sysRoleMng.setPermissions(permissionsMng);
            iSysRoleDao.saveAndFlush(sysRoleMng);

            // 文件管理-删除文件
            SysPermission findByMethordAndUrl2 = iSysPermissionDao.findByMethodAndUrl("delete", "/fileSystem/files/**");
            // 文件管理-根据参数查询文档
            SysPermission findByMethordAndUrl3 = iSysPermissionDao.findByMethodAndUrl("get", "/fileSystem/files");
            // 文件管理-文件断点续传 将文件按照50MB的大小分割成小文件，依次上传
            SysPermission findByMethordAndUrl4 = iSysPermissionDao.findByMethodAndUrl("post", "/fileSystem/files");
            // 文件管理-查看未完成的断点续传任务
            SysPermission findByMethordAndUrl5 = iSysPermissionDao.findByMethodAndUrl("get", "/fileSystem/files/chunks");
            // 文件预览-图片预览
            SysPermission findByMethordAndUrl6 = iSysPermissionDao.findByMethodAndUrl("get", "/preview/image");
            // 文件预览-图片预览-缩略图
            SysPermission findByMethordAndUrl1 = iSysPermissionDao.findByMethodAndUrl("get", "/preview/image/thumbnail");
            // 文件预览-小型文本查看
            SysPermission findByMethordAndUrl7 = iSysPermissionDao.findByMethodAndUrl("get", "/preview/text");
            // 文件管理-审核文件
            SysPermission findByMethordAndUrl8 = iSysPermissionDao.findByMethodAndUrl("post", "/fileSystem/files/audit/**");
            // 文件管理-审核文件
            SysPermission findByMethordAndUrl9 = iSysPermissionDao.findByMethodAndUrl("post", "/fileSystem/files/info/**");
            // 文件管理-审核文件
            SysPermission findByMethordAndUrl10 = iSysPermissionDao.findByMethodAndUrl("post", "/fileSystem/files/info");

            // 添加上传员和审核员
            addRoleUploaderAndAuth(findByMethordAndUrl1, findByMethordAndUrl2, findByMethordAndUrl3, findByMethordAndUrl4, findByMethordAndUrl5, findByMethordAndUrl6,
                    findByMethordAndUrl7, findByMethordAndUrl8, findByMethordAndUrl9, findByMethordAndUrl10, findBySubSystemName);
            // 添加其他角色
            addOtherRoles(findBySubSystemName);
        }
    }

    /**
     * 添加其他角色
     */
    private void addOtherRoles(SysSubSystem findBySubSystemName) {
        // 设备类型管理 deviceTypeManagement
        SysRole sysRoleDeviceType = new SysRole();
        sysRoleDeviceType.setRoleName("deviceTypeManagement");
        sysRoleDeviceType.setRoleDesc("设备类型管理");
        sysRoleDeviceType.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("设备类型管理")));
        sysRoleDeviceType.setSysSubsystem(findBySubSystemName);
        iSysRoleDao.saveAndFlush(sysRoleDeviceType);
        // 设备管理 deviceManagement
        SysRole sysRoleDevice = new SysRole();
        sysRoleDevice.setRoleName("deviceManagement");
        sysRoleDevice.setRoleDesc("设备管理 ");
        sysRoleDevice.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("设备管理 ")));
        sysRoleDevice.setSysSubsystem(findBySubSystemName);
        iSysRoleDao.saveAndFlush(sysRoleDevice);
        // 角色管理 roleManagement
        SysRole sysRoleRole = new SysRole();
        sysRoleRole.setRoleName("roleManagement");
        sysRoleRole.setRoleDesc("角色管理");
        sysRoleRole.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("角色管理")));
        iSysRoleDao.saveAndFlush(sysRoleRole);
        // 产品管理 productManagement
        SysRole sysRoleProduct = new SysRole();
        sysRoleProduct.setRoleName("productManagement");
        sysRoleProduct.setRoleDesc("产品管理");
        sysRoleProduct.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("产品管理")));
        sysRoleProduct.setSysSubsystem(findBySubSystemName);
        iSysRoleDao.saveAndFlush(sysRoleProduct);
        // 子系统管理 subsystemManagement
        SysRole sysRoleSubsys = new SysRole();
        sysRoleSubsys.setRoleName("subsystemManagement");
        sysRoleSubsys.setRoleDesc("子系统管理");
        sysRoleSubsys.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("子系统管理")));
        iSysRoleDao.saveAndFlush(sysRoleSubsys);
        // 文件预览 filePreview
        SysRole sysRolePreview = new SysRole();
        sysRolePreview.setRoleName("filePreview");
        sysRolePreview.setRoleDesc("文件预览");
        sysRolePreview.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("文件预览")));
        sysRolePreview.setSysSubsystem(findBySubSystemName);
        iSysRoleDao.saveAndFlush(sysRolePreview);
        // 用户管理 userManagement
        SysRole sysRoleUser = new SysRole();
        sysRoleUser.setRoleName("userManagement");
        sysRoleUser.setRoleDesc("用户管理");
        sysRoleUser.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("用户管理")));
        iSysRoleDao.saveAndFlush(sysRoleUser);

        // 认证管理
        SysRole sysRoleAuth = new SysRole();
        sysRoleAuth.setRoleName("authManagement");
        sysRoleAuth.setRoleDesc("认证管理");
        sysRoleAuth.setPermissions(new HashSet<>(iSysPermissionDao.findbyPermissionNameLike("认证管理")));
        iSysRoleDao.saveAndFlush(sysRoleAuth);

    }

    /**
     * 添加上传员和审核员
     * 
     * @param findByMethordAndUrl1
     * @param findByMethordAndUrl2
     * @param findByMethordAndUrl3
     * @param findByMethordAndUrl4
     * @param findByMethordAndUrl5
     * @param findByMethordAndUrl6
     * @param findByMethordAndUrl7
     * @param findByMethordAndUrl8
     * @param findByMethordAndUrl9
     * @param findByMethordAndUrl10
     */
    private void addRoleUploaderAndAuth(SysPermission findByMethordAndUrl1, SysPermission findByMethordAndUrl2, SysPermission findByMethordAndUrl3,
            SysPermission findByMethordAndUrl4, SysPermission findByMethordAndUrl5, SysPermission findByMethordAndUrl6, SysPermission findByMethordAndUrl7,
            SysPermission findByMethordAndUrl8, SysPermission findByMethordAndUrl9, SysPermission findByMethordAndUrl10, SysSubSystem findBySubSystemName) {
        // 上传员
        SysRole sysRoleUploader = new SysRole();
        sysRoleUploader.setRoleName("fileUploader");
        sysRoleUploader.setRoleDesc("上传员");
        Set<SysPermission> permissionsUp = new HashSet<>();
        permissionsUp.add(findByMethordAndUrl1);
        permissionsUp.add(findByMethordAndUrl2);
        permissionsUp.add(findByMethordAndUrl3);
        permissionsUp.add(findByMethordAndUrl4);
        permissionsUp.add(findByMethordAndUrl5);
        permissionsUp.add(findByMethordAndUrl6);
        permissionsUp.add(findByMethordAndUrl7);
        permissionsUp.add(findByMethordAndUrl9);
        permissionsUp.add(findByMethordAndUrl10);
        sysRoleUploader.setPermissions(permissionsUp);
        sysRoleUploader.setSysSubsystem(findBySubSystemName);
        iSysRoleDao.saveAndFlush(sysRoleUploader);

        // 审核员
        SysRole sysRoleAuditor = new SysRole();
        sysRoleAuditor.setRoleName("fileAuditor");
        sysRoleAuditor.setRoleDesc("审核员");
        Set<SysPermission> permissionsAuditor = new HashSet<>();
        permissionsAuditor.add(findByMethordAndUrl1);
        permissionsAuditor.add(findByMethordAndUrl3);
        permissionsAuditor.add(findByMethordAndUrl6);
        permissionsAuditor.add(findByMethordAndUrl7);
        permissionsAuditor.add(findByMethordAndUrl8);
        sysRoleAuditor.setPermissions(permissionsAuditor);
        sysRoleAuditor.setSysSubsystem(findBySubSystemName);
        iSysRoleDao.saveAndFlush(sysRoleAuditor);
    }

    /**
     * 添加权限数据
     * 
     * @param subsystemName
     */
    public void initPermissions(SysSubSystem findBySubSystemName) {
        List<SysPermission> findAllPermissions = iSysPermissionDao.findAll();
        if (findAllPermissions == null || findAllPermissions.size() <= 0) {
            String response = doGet("http://127.0.0.1:" + port + "/v2/api-docs");
            if (StringUtil.isNotEmpty(response)) {
                JSONObject success = (JSONObject) JSONArray.parse(response);
                JSONObject jsonObject = success.getJSONObject("paths");
                Iterator<String> iterator = jsonObject.keySet().iterator();
                while (iterator.hasNext()) {
                    // URL
                    String key = iterator.next();
                    JSONObject data = jsonObject.getJSONObject(key);
                    Iterator<String> datas = data.keySet().iterator();
                    while (datas.hasNext()) {
                        // 请求类型
                        String methord = datas.next();
                        JSONObject data2 = data.getJSONObject(methord);
                        // 描述
                        String permissionName = data2.getString("summary");
                        try {
                            String url = key.replaceAll("\\{(.*?)\\}", "**");
                            if (permissionName.contains("设备类型管理") || permissionName.contains("设备管理") || permissionName.contains("产品管理") || permissionName.contains("文件预览")
                                    || permissionName.contains("文件管理")) {
                                iSysPermissionService.addPermission(permissionName, methord, url, null, findBySubSystemName.getSubsystemId());
                            } else {
                                iSysPermissionService.addPermission(permissionName, methord, url, null, null);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

        }
    }

    /**
     * get请求
     * 
     * @return
     */
    public static String doGet(String url) {
        CloseableHttpResponse response = null;
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            // 发送get请求
            HttpGet request = new HttpGet(url);
            response = client.execute(request);
            /** 请求发送成功，并得到响应 **/
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                /** 读取服务器返回过来的json字符串数据 **/
                String strResult = EntityUtils.toString(response.getEntity());
                return strResult;
            }
        } catch (IOException e) {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }

        }
        return null;
    }

    /**
     * 定时推送邮件通知信息：早上9点
     */
    @Scheduled(cron = "0 0 9 * * ?")
    public void morningPush() {
        pushMailMessage();
    }

    /**
     * 定时推送邮件通知信息：0 0 18 * * 每天下午6点触发
     */
    @Scheduled(cron = "0 0 18 * * ?")
    public void afternoonPush() {
        pushMailMessage();
    }

    /**
     * 推送任务
     */
    public void pushMailMessage() {
        // status pageNo size
        Long total = indexService.exploreFilesByParamsWithoutSize(null, FileStatusEnum.PENDING_TO_AUDITED.getCode().toString(), null, null, null, null, null, null, null, null,
                null, null);
        // 有需要审核的文件
        if (total > 0) {
            String title = "您有待处理的审核任务";
            String message = "您有" + total + "个文件待审核";
            SysRole sysRole = iSysRoleDao.findByRoleName(UserRoleEnum.FileAuditor.getEnName());
            if (null != sysRole) {
                Set<SysUser> sysUsers = sysRole.getUsers();
                if (CollectionUtils.isNotEmpty(sysUsers)) {
                    String[] mails = new String[sysUsers.size()];
                    int i = 0;
                    for (SysUser sysUser : sysUsers) {
                        mails[i] = sysUser.getEmail();
                        i++;
                    }
                    try {
                        mailSenderService.sendMail(title, message, mails);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
