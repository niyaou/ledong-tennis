package com.desay.cd.factory.rest.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @ClassName: DataDictionaryVo
 * @author: pengdengfu
 * @date: 2019年11月5日 上午9:18:30
 */
@Data
public class DataDictionaryVo implements Serializable {

    private static final long serialVersionUID = 2140387170267363219L;

    @NotNull
    @ApiModelProperty(value = "数据类别Id，清洗优先级：0，\n" + "标注优先级：1\n" + "标注能力：2\n" + "")
    private Integer classId;

    @NotEmpty
    @Length(min = 1, max = 50, message = "length长度在[1,50]之间")
    @ApiModelProperty(value = "数据字段名称")
    private String name;

    @ApiModelProperty(value = "数据字段值")
    private String value;

    @ApiModelProperty(value = "状态：0，不启用。1，启用,默认为1", allowableValues = "1,0", example = "1", required = false)
    @Range(min = 0, max = 1, message = "状态必须在[0,1]")
    private Integer isActive = 1;
}
