package com.desay.cd.factory.transaction.base;

import com.desay.cd.factory.service.impl.SysChunksLogServiceImpl;


/**
 * es文件操作事务基类
 * @author uidq1343
 *
 */
public abstract class BaseChunksServiceHandler  extends AbstractFileHandler{
    protected SysChunksLogServiceImpl chunksLogService;
    
    @Override
    protected void clean() {
        if(chunksLogService!=null) {
            chunksLogService=null;
        }
        
    }

    @Override
    public <T> void setResource(T resouce) {
        if( resouce instanceof SysChunksLogServiceImpl) {
            chunksLogService=(SysChunksLogServiceImpl)resouce;
        }
    }
}
