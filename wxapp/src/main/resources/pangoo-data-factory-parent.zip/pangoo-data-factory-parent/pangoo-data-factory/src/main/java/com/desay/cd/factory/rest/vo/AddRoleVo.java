package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddRoleVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午4:11:27
 */
@ApiModel(value = "角色")
public class AddRoleVo {
    @ApiModelProperty(value = "角色名称(0<size<=30)", required = true)
    private String roleName;
    @ApiModelProperty(value = "角色描述", required = false)
    private String roleDesc;
    @ApiModelProperty(value = "该角色所有的权限ID，忽略不存储在的权限ID", required = false)
    private Set<String> permissions;

    @ApiModelProperty(value = "该角色所属的子系统Id,如果为空，该角色为全局角色", required = false)
    private String subsystemId;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public Set<String> getPermissions() {
        return permissions;
    }

    public void setPermissions(Set<String> permissions) {
        this.permissions = permissions;
    }

    public String getSubsystemId() {
        return subsystemId;
    }

    public void setSubsystemId(String subsystemId) {
        this.subsystemId = subsystemId;
    }

    @Override
    public String toString() {
        return " [roleName=" + roleName + ", roleDesc=" + roleDesc + ", permissions=" + permissions + ", subsystemId=" + subsystemId + "]";
    }

}
