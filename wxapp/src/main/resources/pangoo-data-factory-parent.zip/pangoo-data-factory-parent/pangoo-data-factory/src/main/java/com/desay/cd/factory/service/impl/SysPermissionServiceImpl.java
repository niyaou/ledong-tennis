package com.desay.cd.factory.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.dao.ISysPermissionDao;
import com.desay.cd.factory.dao.ISysSubSystemDao;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.entity.mysql.SysPermission;
import com.desay.cd.factory.entity.mysql.SysRole;
import com.desay.cd.factory.entity.mysql.SysSubSystem;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.ISysPermissionService;
import com.desay.cd.factory.utils.ControllerCommonUtils;

/**
 * SysPermissionServiceImpl
 * 
 * @author pengdengfu
 *
 */
@Service
public class SysPermissionServiceImpl implements ISysPermissionService {
    @Autowired
    private ISysPermissionDao sysPermissionDao;
    @Autowired
    private ISysSubSystemDao sysSubSystemDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public SysPermission addPermission(String permissionName, String methord, String url, String permissionDesc, String subSystemId) {
        // 检查permissionName
        checkPermissionName(permissionName, url, true, null);
        SysPermission sysPermission = new SysPermission();
        if (StringUtils.isNotEmpty(permissionName)) {
            sysPermission.setPermissionName(permissionName);
        }
        // 添加其他属性
        addOther(permissionName, methord, url, permissionDesc, subSystemId, sysPermission, false);
        SysPermission permission = null;
        try {
            permission = sysPermissionDao.saveAndFlush(sysPermission);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.PERMISSION_NAME_EXISTED.getCode(), ResultCodeEnum.PERMISSION_NAME_EXISTED.getMessage());
        }
        return permission;
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public void deletePermission(String permissionId) {
        // 检查permissionId
        checkPermissionId(permissionId);
        // 检查是否被使用
        Integer countPermissionUsedBy = sysPermissionDao.countPermissionUsedBy(permissionId);
        if (countPermissionUsedBy > 0) {
            Map<String, Integer> referencedCount = new HashMap<>(1);
            referencedCount.put("referencedCount", countPermissionUsedBy);
            throw new CustumException(ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getCode(), ResultCodeEnum.CAN_NOT_DELETE_USING_DATA.getMessage(), referencedCount);
        }
        try {
            sysPermissionDao.delete(permissionId);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.PERMISSION_NAME_EXISTED.getCode(), ResultCodeEnum.PERMISSION_NAME_EXISTED.getMessage());
        }

    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public void updatePermission(String permissionId, String permissionName, String methord, String url, String permissionDesc, String subSystemId) {
        // 检查permissionId
        SysPermission sysPermission = checkPermissionId(permissionId);
        // 检查permissionName
        checkPermissionName(permissionName, url, false, permissionId);
        // 添加其他属性
        addOther(permissionName, methord, url, permissionDesc, subSystemId, sysPermission, true);
        try {
            sysPermissionDao.saveAndFlush(sysPermission);
        } catch (ObjectOptimisticLockingFailureException e) {
            throw new CustumException(ResultCodeEnum.OTHER_USER_UPDATED.getCode(), ResultCodeEnum.OTHER_USER_UPDATED.getMessage());
        } catch (DataIntegrityViolationException e) {
            throw new CustumException(ResultCodeEnum.PERMISSION_NAME_EXISTED.getCode(), ResultCodeEnum.PERMISSION_NAME_EXISTED.getMessage());
        }

    }

    /**
     * 检查permissionId
     * 
     * @param permissionId
     * @return
     */
    private SysPermission checkPermissionId(String permissionId) {
        if (StringUtils.isEmpty(permissionId)) {
            throw new CustumException(ResultCodeEnum.PERMISSION_ID_CANNOT_NULL.getCode(), ResultCodeEnum.PERMISSION_ID_CANNOT_NULL.getMessage());
        }
        SysPermission sysPermission = sysPermissionDao.findOne(permissionId);
        if (sysPermission == null) {
            throw new CustumException(ResultCodeEnum.PERMISSION_ID_NOT_EXISTED.getCode(), ResultCodeEnum.PERMISSION_ID_NOT_EXISTED.getMessage());
        }
        return sysPermission;
    }

    @Override
    public Page<SysPermission> getSyspermissions(String pageNo, String pageSize, String permissionId, String permissionName, String subSystemId, String roleId, List<String> properties,
            String sortDirection, String status) {
        Pageable pageable = ControllerCommonUtils.getPager(pageNo, pageSize, properties, sortDirection, "permissionName");
        // 特殊字符转义
        if (StringUtils.isNotEmpty(permissionName)) {
            permissionName = permissionName.replaceAll("%", "\\\\%");
            permissionName = permissionName.replaceAll("_", "\\\\_");
        }
        final String permissionNameTmp = permissionName;

        Specification<SysPermission> specification = new Specification<SysPermission>() {
            @Override
            public Predicate toPredicate(Root<SysPermission> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();
                if (StringUtils.isNotEmpty(permissionId)) {
                    predicates.add(cb.equal(root.get("permissionId"), permissionId));
                }
                if (StringUtils.isNotEmpty(permissionNameTmp)) {
                    predicates.add(cb.or(cb.like(root.get("permissionName"), "%" + permissionNameTmp + "%"), cb.like(root.get("permissionDesc"), "%" + permissionNameTmp + "%")));
                }
                if (StringUtils.isNotEmpty(subSystemId)) {
                    if (Constanst.GLOABLE_FLG.equalsIgnoreCase(subSystemId)) {
                        predicates.add(cb.isNull(root.get("sysSubsystem")));
                    } else {
                        Join<SysPermission, SysSubSystem> join = root.join("sysSubsystem", JoinType.INNER);
                        predicates.add(cb.equal(join.get("subsystemId"), subSystemId));
                    }
                }
                if (StringUtils.isNotEmpty(roleId)) {
                    Join<SysPermission, SysRole> join = root.join("roles", JoinType.INNER);
                    predicates.add(cb.equal(join.get("roleId"), roleId));
                }
                if (StringUtils.isNotEmpty(status)) {
                    ControllerCommonUtils.checkStatus(status);
                    predicates.add(cb.equal(root.get("isActive"), status));
                }
                return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        return sysPermissionDao.findAll(specification, pageable);
    }

    /**
     * 检查permissionName
     * 
     * @param permissionName
     * @param url
     * @param checkEmpty
     * @param permissionId
     * @return
     */
    private void checkPermissionName(String permissionName, String url, boolean checkEmpty, String permissionId) {
        if (checkEmpty) {
            if (StringUtils.isEmpty(permissionName)) {
                throw new CustumException(ResultCodeEnum.PERMISSION_NAME_CANNOT_NULL.getCode(), ResultCodeEnum.PERMISSION_NAME_CANNOT_NULL.getMessage());
            }
            if (permissionName.length() > Constanst.NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.PERMISSION_NAME_TOO_LONG.getCode(), ResultCodeEnum.PERMISSION_NAME_TOO_LONG.getMessage());
            }
        } else {
            if (StringUtils.isNotEmpty(permissionName) && permissionName.length() > Constanst.PERMISSION_NAME_LENGTH) {
                throw new CustumException(ResultCodeEnum.PERMISSION_NAME_TOO_LONG.getCode(), ResultCodeEnum.PERMISSION_NAME_TOO_LONG.getMessage());
            }
        }
        if (StringUtils.isEmpty(permissionName)) {
            return;
        }
    }

    /**
     * 添加其他属性
     * 
     * @param permissionName
     * @param methord
     * @param url
     * @param permissionDesc
     * @param subSystemId
     * @param sysPermission
     */
    private void addOther(String permissionName, String methord, String url, String permissionDesc, String subSystemId, SysPermission sysPermission, boolean isUpdate) {
        if (StringUtils.isNotEmpty(permissionName)) {
            sysPermission.setPermissionName(permissionName);
        }
        if (StringUtils.isNotEmpty(methord)) {
            sysPermission.setMethod(methord);
        } else {
            if (!isUpdate) {
                throw new CustumException(ResultCodeEnum.PERMISSION_METHORD_CANNOT_NULL.getCode(), ResultCodeEnum.PERMISSION_METHORD_CANNOT_NULL.getMessage());
            }
        }

        if (StringUtils.isNotEmpty(url)) {
            sysPermission.setUrl(url);
        } else {
            if (!isUpdate) {
                throw new CustumException(ResultCodeEnum.PERMISSION_URL_CANNOT_NULL.getCode(), ResultCodeEnum.PERMISSION_URL_CANNOT_NULL.getMessage());
            }
        }
        if (StringUtils.isNotEmpty(permissionDesc)) {
            sysPermission.setPermissionDesc(permissionDesc);
        }
        if (StringUtils.isNotEmpty(subSystemId)) {
            // 切换为全局权限
            if (Constanst.GLOABLE_FLG.equalsIgnoreCase(subSystemId)) {
                sysPermission.setSysSubsystem(null);
            } else {
                SysSubSystem subSystem = sysSubSystemDao.findOne(subSystemId);
                if (subSystem != null) {
                    sysPermission.setSysSubsystem(subSystem);
                }
            }

        }
    }

}
