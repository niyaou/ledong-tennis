package com.desay.cd.factory.utils;

import java.beans.PropertyDescriptor;
import java.io.BufferedInputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.desay.common.es.search.SearchApi;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;

import com.desay.cd.factory.constance.Constanst;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.exception.CustumException;

/**
 * 
 * @author uidq1070
 *
 */
public class ControllerCommonUtils {
    /**
     * 检查status是否符合
     * 
     * @param status
     */
    public static void checkStatus(String status) {
        Set<String> statusSet = new HashSet<>();
        statusSet.add(Constanst.ACTIVE_STATUS_0);
        statusSet.add(Constanst.ACTIVE_STATUS_1);
        if (!statusSet.contains(status)) {
            throw new CustumException(ResultCodeEnum.STATUS_JUST_ONLY_ONE_TWO.getCode(), ResultCodeEnum.STATUS_JUST_ONLY_ONE_TWO.getMessage());
        }
    }

    /**
     * 获取分页对象
     * 
     * @param pageNo
     * @param pageSize
     * @param properties
     * @param sortDirection
     * @param defaultProperty
     * @return
     */
    public static Pageable getPager(String pageNo, String pageSize, List<String> properties, String sortDirection, String defaultProperty) {
        Integer pageNo2 = 0;
        Integer pageSize2 = 0;
        try {
            pageNo2 = Integer.parseInt(pageNo);
        } catch (NumberFormatException e) {
            pageNo2 = Constanst.FIRST_PAGE_NO;
        }
        try {
            pageSize2 = Integer.parseInt(pageSize);
        } catch (NumberFormatException e) {
            pageSize2 = Constanst.PAGE_SIZE;
        }
        if (pageNo2 <= 0) {
            pageNo2 = Constanst.FIRST_PAGE_NO;
        }
        if (pageSize2 <= 0) {
            pageSize2 = Constanst.PAGE_SIZE;
        }
        // JPA的page参数从0开始
        pageNo2--;
        Sort sort = null;
        if (properties == null || properties.size() <= 0) {
            properties = new ArrayList<>(1);
            properties.add("createTime");
            if (StringUtils.isNotEmpty(defaultProperty)) {
                properties.add(defaultProperty);
            }
        }
        if (StringUtils.isEmpty(sortDirection)) {
            sortDirection = Constanst.SORT_DIRECTION_DESC;
        }
        if (Constanst.SORT_DIRECTION_ASC.equalsIgnoreCase(sortDirection)) {
            sort = new Sort(Sort.Direction.ASC, properties);
        } else {
            sort = new Sort(Sort.Direction.DESC, properties);
        }
        Pageable pageable = new PageRequest(pageNo2, pageSize2, sort);
        return pageable;
    }

    /**
     * 组合排序分页对象
     * 
     * @param pageNo
     * @param pageSize
     * @param properties
     * @param defaultProperty
     * @return
     */
    public static Pageable getPager(Integer pageNo, Integer pageSize, List<String> properties, String defaultProperty) {
        Integer pageNo2 = pageNo;
        Integer pageSize2 = pageSize;

        if (pageNo == null || pageNo == 0) {
            pageNo2 = Constanst.FIRST_PAGE_NO;
        }
        if (pageSize == null || pageSize == 0) {
            pageSize2 = Constanst.PAGE_SIZE;
        }

        // JPA的page参数从0开始
        pageNo2--;

        List<Order> orders = new ArrayList<Order>();
        if (properties == null || properties.size() <= 0) {
            if (StringUtils.isEmpty(defaultProperty)) {
                orders.add(new Order(Sort.Direction.DESC, "createTime"));
            } else {
                orders.add(new Order(Sort.Direction.DESC, defaultProperty));
            }
        } else {
            for (String property : properties) {
                String prefix = property.charAt(0) + "";
                String field = property.substring(1);
                if (StringUtils.equals(prefix, "+")) {
                    orders.add(new Order(Sort.Direction.ASC, field));
                } else {
                    orders.add(new Order(Sort.Direction.DESC, field));
                }

            }
        }

        Pageable pageable = new PageRequest(pageNo2, pageSize2, new Sort(orders));
        return pageable;
    }

    /**
     * 获取需要忽略的属性
     * 
     * @param source
     * @return
     */
    public static String[] getNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> emptyNames = new HashSet<>();
        for (PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());
            // 此处判断可根据需求修改
            if (srcValue == null) {
                emptyNames.add(pd.getName());
            }
        }
        emptyNames.add("createTime");
        String[] result = new String[emptyNames.size()];
        return emptyNames.toArray(result);
    }

    /**
     * 获取文件编码
     * 
     * @param bin
     * @return
     * @throws Exception
     */
    public static String codeString(BufferedInputStream bin) throws Exception {
        bin.mark(0);
        int p = (bin.read() << 8) + bin.read();
        String code = null;

        switch (p) {
        case 0xefbb:
            code = "UTF-8";
            break;
        case 0xfffe:
            code = "Unicode";
            break;
        case 0xfeff:
            code = "UTF-16BE";
            break;
        default:
            code = "GBK";
        }
        return code;
    }

    /**
     * 检查组,或者用户是否有未完成任务
     * 
     * @param groupId
     * @param userId
     * @return
     */
    public static boolean checkTask(String groupId, String userId) {
        boolean isOk = false;
        ArrayList<QueryBuilder> params = new ArrayList<QueryBuilder>();
        if (StringUtils.isNotEmpty(groupId)) {
            params.add(SearchApi.createSearchByFieldSource("groupId", groupId));
        }
        if (StringUtils.isNotEmpty(userId)) {
            params.add(SearchApi.createSearchByFieldSource("labeler", userId));
        }
        // 状态0：待领取；1：已领取；2：已提交；3：已通过；4：未通过
        params.add(SearchApi.createSearchByMultiSource("status", "1", "2", "4"));
        SearchResponse searchResponse = SearchApi.searchByMultiQueriesAndOrders("pangoo_dls_task_information", "_doc", null, 1, 10,
                params.toArray(new QueryBuilder[params.size()]));

        if (searchResponse == null || searchResponse.getHits() == null) {
            return true;
        }
        long totalHits = searchResponse.getHits().totalHits;
        if (totalHits <= 0) {
            return true;
        }
        return isOk;
    }
}
