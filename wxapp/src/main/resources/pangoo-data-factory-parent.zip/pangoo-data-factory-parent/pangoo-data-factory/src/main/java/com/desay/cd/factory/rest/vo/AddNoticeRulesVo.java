package com.desay.cd.factory.rest.vo;

import java.util.Set;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: AddNoticeRulesVo
 * @author: pengdengfu
 * @date: 2019年3月4日 下午4:37:23
 */
@ApiModel(value = "通知规则")
public class AddNoticeRulesVo {
    @ApiModelProperty(value = "userId(0<size<=20)", required = true)
    private String userId;
    @ApiModelProperty(value = "通知频率ID", required = false)
    private String noticeFreqId;
    @ApiModelProperty(value = "触发事件Id，忽略不存储在的权限ID(不传该参数哦，则不更新；传递空数组，则是清空触发事件)", required = false)
    private Set<String> triggerEventIds;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNoticeFreqId() {
        return noticeFreqId;
    }

    public void setNoticeFreqId(String noticeFreqId) {
        this.noticeFreqId = noticeFreqId;
    }

    public Set<String> getTriggerEventIds() {
        return triggerEventIds;
    }

    public void setTriggerEventIds(Set<String> triggerEventIds) {
        this.triggerEventIds = triggerEventIds;
    }

}
