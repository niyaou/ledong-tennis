package com.desay.cd.factory.entity.mysql;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @ClassName: Device
 * @author: pengdengfu
 * @date: 2019年4月8日 上午9:26:29
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "sys_device", uniqueConstraints = { @UniqueConstraint(columnNames = { "device_name" }) })
@Getter
@Setter
public class SysDevice implements Serializable {

    private static final long serialVersionUID = -2928695175442867843L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-uuid")
    @GenericGenerator(name = "custom-uuid", strategy = "com.desay.cd.factory.utils.CustomUUIDGenerator")
    @Column(name = "device_id", columnDefinition = "varchar(32) COMMENT '主键'")
    private String deviceId;

    /** 设备名称 */
    @Column(name = "device_name", nullable = false, length = 60, columnDefinition = "varchar(60) COMMENT '设备名称'")
    private String deviceName;

    @OneToOne
    @JoinColumn(name = "device_type_id")
    private SysDeviceType deviceType;

    /** 包含的产品 */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "sys_product_devices", joinColumns = @JoinColumn(name = "device_id"), inverseJoinColumns = @JoinColumn(name = "product_id"))
    @JsonIgnore
    private Set<SysProduct> sysProducts;

    /** 设备所拥有的属性 */
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id")
    @OrderBy("attribute_name DESC")
    private Set<SysDeviceAttribute> deviceAttributes;

    /** 是否可用，0，不可用，1，可用 */
    @Column(name = "is_active", nullable = false, columnDefinition = " char(1) default '1' COMMENT '是否可用'")
    private String isActive = "1";

    @OneToOne(mappedBy = "sysDevice")
    @JsonIgnoreProperties({ "sysDevice" })
    private CleanStrategy cleanStrategy;

    @OneToOne(mappedBy = "sysDevice")
    @JsonIgnoreProperties({ "sysDevice" })
    private TaskAssignStrategy taskAssignStrategy;

    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time")
    private Date createTime;

    /** 修改时间 */
    @LastModifiedDate
    @Column(name = "modify_time")
    @JsonIgnore
    private Date modifyTime;

    @Version
    @JsonIgnore
    private Long version;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((deviceId == null) ? 0 : deviceId.hashCode());
        result = prime * result + ((deviceName == null) ? 0 : deviceName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SysDevice other = (SysDevice) obj;
        if (deviceId == null) {
            if (other.deviceId != null) {
                return false;
            }
        } else if (!deviceId.equals(other.deviceId)) {
            return false;
        }
        if (deviceName == null) {
            if (other.deviceName != null) {
                return false;
            }
        } else if (!deviceName.equals(other.deviceName)) {
            return false;
        }
        return true;
    }

}
