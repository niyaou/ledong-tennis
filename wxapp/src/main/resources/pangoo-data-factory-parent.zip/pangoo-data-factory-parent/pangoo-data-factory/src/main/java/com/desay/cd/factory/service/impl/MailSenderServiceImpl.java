package com.desay.cd.factory.service.impl;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.desay.cd.factory.service.MailSenderService;

/**
 * 发送邮件服务
 * 
 * @author uidq1163
 *
 */
@Service
public class MailSenderServiceImpl implements MailSenderService {
    @Autowired
    private JavaMailSender mailSender;
    @Value("${mail.fromMail.addr}")
    private String from;

    @Override
    public void sendMail(String title, String message, String mail) throws Exception {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
        helper.setFrom(from);
        helper.setTo(mail);
        helper.setSubject(title);
        helper.setText(message);
        mailSender.send(mimeMessage);
    }

    @Override
    public void sendMail(String title, String message, String[] mails) throws Exception {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
        helper.setFrom(from);
        helper.setTo(mails);
        helper.setSubject(title);
        helper.setText(message);
        mailSender.send(mimeMessage);
    }
}
