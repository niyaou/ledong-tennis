package com.desay.cd.factory.transaction.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.util.TextUtils;
import org.elasticsearch.action.DocWriteResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.factory.entity.ResultCodeEnum;
import com.desay.cd.factory.enums.FileStatusEnum;
import com.desay.cd.factory.enums.LogFileOptEnum;
import com.desay.cd.factory.exception.CustumException;
import com.desay.cd.factory.service.impl.FileServiceImpl;
import com.desay.cd.factory.service.impl.IndexServiceImpl;
import com.desay.cd.factory.transaction.base.BaseIndexServiceHandler;
import com.desay.cd.factory.transaction.base.FileElement;
import com.desay.cd.factory.utils.DateUtil;



/**
 * es文档事务处理基类
 * @author uidq1343
 *
 */
public class IndexDeleteHandler extends  BaseIndexServiceHandler {



    @SuppressWarnings("unchecked")
    @Override
    public void doHandleReal(FileElement element) throws CustumException {
        
        HashMap<String, Object> doc = indexService.queryFileInfomation(element.getChunk().getFileId());
        if (doc == null) {
            throw new CustumException(ResultCodeEnum.FILE_NOT_EXISTED.getCode(), ResultCodeEnum.FILE_NOT_EXISTED.getMessage());
        }
        element.setDoc(new JSONObject((Map<String, Object>) doc.clone()));
        doc.put(IndexServiceImpl.STATUS, FileStatusEnum.DELETED.getCode());
        doc.put(IndexServiceImpl.DELETETIME, DateUtil.getTimeStamp(element.getOperationTime()));
        element.setFilePath((String) doc.get(IndexServiceImpl.FILEPATH));
        DocWriteResponse result=null;
        result=  indexService.updateFileInfomation(JSON.toJSONString(doc), element.getChunk().getFileId());
        if(result==null) {
            throw new CustumException(ResultCodeEnum.DELETE_DATA_FAILD.getCode(), ResultCodeEnum.DELETE_DATA_FAILD.getMessage());
        }
        /**  写入操作日志*/
        FileServiceImpl.createOperationLog(element,LogFileOptEnum.DELETE);
    }


    @Override
    public void rollBackReal(FileElement element) {
        String fileId=element.getChunk().getFileId();
        if(!TextUtils.isEmpty(fileId) && element.getDoc()!=null) {
            System.out.println(element.getDoc().toJSONString());
            indexService.updateFileInfomation(element.getDoc().toJSONString(), fileId);
        }
    }


}
