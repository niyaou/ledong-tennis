package com.desay.cd.auth;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.serializer.SerializationException;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.auth.dto.DepartmentDto;
import com.desay.cd.auth.dto.PersonDto;
import com.desay.cd.auth.uitls.StringUtil;
import com.google.common.base.CharMatcher;
import com.google.common.collect.Lists;

/**
 * 
 * @author 倪旭春
 *
 */
@Service
public class LdapAuthorize {
    public static Logger log = Logger.getLogger(LdapAuthorize.class);
    private static String SEARCHBASES = "OU=LDA,DC=v01,DC=net";
    private static String[] SEARCHSEQUENSE = null;
    private static String URL = "";
    private static String FACTORY = "";
    private static String ADMIN = "";
    private static String SEARCHDN = "v01\\";
    private static String BASE64PREFIX = "data:image/jpeg;base64,";
    private LdapContext ctx = null;
    private Hashtable<String, String> env = null;
    private Control[] connCtls = null;
    /** 字母表 */
    private static final String ALPHABETA = "abcdefghijklmnopqrstuvwxyz";

    /**
     * 加载ldap用户组信息
     */
    static {
        InputStream inputStream = LdapAuthorize.class.getClassLoader().getResourceAsStream("ldapgroup.properties");
        Properties properties = new Properties();
        try {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        URL = properties.getProperty("URL");
        FACTORY = properties.getProperty("FACTORY");
        ADMIN = properties.getProperty("ADMIN");

        // 惠州1
        String hzh1Ou = properties.getProperty("HZH1_OU");
        String[] hzh1Ous = hzh1Ou.split(",");
        StringBuilder sb = null;
        for (int i = 0; i < hzh1Ous.length; i++) {
            sb = new StringBuilder();
            sb.append("OU=Users");
            sb.append(hzh1Ous[i]);
            sb.append(",OU=Users,OU=HZH1,");
            sb.append(SEARCHBASES);
            hzh1Ous[i] = sb.toString();
        }
        String fra1Ou = properties.getProperty("FRA1_OU");
        fra1Ou = fra1Ou + SEARCHBASES;
        String hij1Ou = properties.getProperty("HIJ1_OU");
        hij1Ou = hij1Ou + SEARCHBASES;
        // 惠州2
        String hzh2Ou = properties.getProperty("HZH2_OU");
        String[] hzh2Ous = hzh2Ou.split(",");
        for (int i = 0; i < hzh2Ous.length; i++) {
            sb = new StringBuilder();
            sb.append("OU=Users");
            sb.append(hzh2Ous[i]);
            sb.append(",OU=Users,OU=HZH2,");
            sb.append(SEARCHBASES);
            hzh2Ous[i] = sb.toString();
        }
        // 新加坡
        String sgp1Ou = properties.getProperty("SGP1_OU");
        String[] sgp1Ous = sgp1Ou.split(",");
        for (int i = 0; i < sgp1Ous.length; i++) {
            sb = new StringBuilder();
            sb.append("OU=Users");
            sb.append(sgp1Ous[i]);
            sb.append(",OU=Users,OU=SGP1,");
            sb.append(SEARCHBASES);
            sgp1Ous[i] = sb.toString();
        }
        // 台北
        String tpe1Ou = properties.getProperty("TPE1_OU");
        tpe1Ou = tpe1Ou + SEARCHBASES;
        //南京
        String nkg1ou = properties.getProperty("NKG1_OU");
        nkg1ou = nkg1ou + SEARCHBASES;
        String nkg5ou = properties.getProperty("NKG5_OU");
        nkg5ou = nkg5ou + SEARCHBASES;

        String[] others = new String[5];
        others[0] = fra1Ou;
        others[1] = hij1Ou;
        others[2] = tpe1Ou;
        others[3] = nkg1ou;
        others[4] = nkg5ou;
       
        SEARCHSEQUENSE = unitStringArray(hzh1Ous, hzh2Ous, sgp1Ous, others);
    }

    /**
     * 合并数组
     */
    public static String[] unitStringArray(String[]... bytes) {
        String[] byte1 = null;
        for (String[] byte2 : bytes) {
            if (byte1 == null) {
                byte1 = byte2;
            } else {
                String[] unitByte = new String[byte1.length + byte2.length];
                System.arraycopy(byte1, 0, unitByte, 0, byte1.length);
                System.arraycopy(byte2, 0, unitByte, byte1.length, byte2.length);
                byte1 = unitByte;
            }
        }
        return byte1;
    }

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public void delete(String key) {
        redisTemplate.delete(key);
    }

    /**
     * 获取用户信息
     * 
     * @param key
     * @return
     */
    public Object get(String key) {
        try {
            ValueOperations<String, Object> vo = redisTemplate.opsForValue();
            Object p = vo.get(key);
            return p;
        } catch (SerializationException e) {
            e.printStackTrace();
            delete(key);
        } catch (Exception es) {
            es.printStackTrace();
            delete(key);
        }
        return null;
    }

    /**
     * 缓存用户信息
     * 
     * @param key
     * @param value
     */
    public void set(String key, PersonDto value) {
        ValueOperations<String, Object> vo = redisTemplate.opsForValue();
        vo.set(key, value);
    }

    public void reset() {
    }

    /**
     * 认证
     * 
     * @param name
     * @param password
     * @return
     */
    private boolean ldapConnect(String name, String password) {

        env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY);
        // LDAP server
        env.put(Context.PROVIDER_URL, URL);
        env.put(Context.SECURITY_PRINCIPAL, SEARCHDN + name);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_CREDENTIALS, password);
        // 此处若不指定用户名和密码,则自动转换为匿名登录
        try {
            ctx = new InitialLdapContext(env, connCtls);
        } catch (NamingException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 自动装载信息
     * 
     * @return
     */
    public int autoCacheDI() {
        return cachePerson(SEARCHSEQUENSE);
    }

    private int cachePerson(String[] searchBases) {
        int count = 0;
        if (searchBases != null) {
            for (String seachbase : searchBases) {
                count += cachePersonImp(seachbase);
            }
        } else {
            count += cachePersonImp(SEARCHBASES);
        }
        return count;
    }

    /**
     * 根据用户id快速搜索用户信息
     * 
     * @param id
     * @param pageNo
     * @param pageSize
     * @return
     */
    public List<Object> autoCompletedSearch(String id, String pageNo, String pageSize) {
        String key = id;
        if (StringUtils.isEmpty(id)) {
            return null;
        }
        int pageNoInt = 1;
        int pageSizeInt = 20;
        try {
            pageNoInt = Integer.parseInt(pageNo);
            pageSizeInt = Integer.parseInt(pageSize);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        pageNoInt = pageNoInt < 1 ? 1 : pageNoInt;
        pageSizeInt = pageSizeInt < 1 ? 1 : pageSizeInt;
        ValueOperations<String, Object> vo = redisTemplate.opsForValue();
        List<Object> groups = new ArrayList<Object>();
        List<List<Object>> partition = new ArrayList<>();
        try {
            key = StringUtils.rightPad(id, 8, "?");
            Set<String> keys = redisTemplate.keys(key);
            TreeSet<String> queue = new TreeSet<String>(new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    o1 = CharMatcher.anyOf(ALPHABETA).collapseFrom(o1, '0');
                    o2 = CharMatcher.anyOf(ALPHABETA).collapseFrom(o2, '0');
                    return Integer.parseInt(o2) < Integer.parseInt(o1) ? 1 : -1;
                }
            });
            queue.addAll(keys);
            if (queue != null && queue.size() != 0) {
                for (String string : queue) {
                    PersonDto p = (PersonDto) vo.get(string);
                    JSONObject brief = new JSONObject();
                    if (p != null) {
                        brief.put("userName", p.getName() != null ? p.getName().get(0) : null);
                        brief.put("userId", p.getMailnickname() != null ? p.getMailnickname().get(0) : null);
                        groups.add(brief);
                    }

                }
                if (groups.size() != 0) {
                    partition = Lists.partition(groups, pageSizeInt);
                }
            } else {
                key = StringUtils.join(new String[] { id, "*" });
                JSONArray array = searchUsersByVagueId(key);
                if (array != null) {
                    partition = Lists.partition(array, pageSizeInt);
                }
            }

            if (pageNoInt > partition.size()) {
                pageNoInt = partition.size();
            }
            return partition.get(--pageNoInt);
        } catch (SerializationException e) {
            e.printStackTrace();
        } catch (Exception es) {
            es.printStackTrace();
        }
        return groups;
    }

    /**
     * 根据用户id返回lpad信息
     * 
     * @param id
     * @return
     * @throws NamingException
     * @throws IllegalAccessException
     */
    public Map<String, ArrayList<String>> searchUserById(String id) throws NamingException {
        if (!TextUtils.isEmpty(id)) {
            id = id.replaceAll("%", "\\\\%");
            id = id.replaceAll("_", "\\\\_");
            id = id.replaceAll("[*]", "\\\\*");
            id = id.replaceAll("[?]", "\\\\?");
            id = id.replaceAll("[+]", "\\\\+");
        }
        ctx.reconnect(connCtls);
        String filters = String.format("(&(objectClass=person)(mailNickname=%s))", id);
        String[] returnedAtts = { "name", "distinguishedName", "l", "memberOf", "mail", "mailnickname", "mobile", "cn", "extensionattribute2", "thumbnailPhoto" };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(60000);
        if (returnedAtts != null && returnedAtts.length > 0) {
            constraints.setReturningAttributes(returnedAtts);
        }
        for (String base : SEARCHSEQUENSE) {
            ctx.reconnect(connCtls);
            NamingEnumeration<SearchResult> answer = ctx.search(base, filters, constraints);
            String company = "";
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                // 得到符合条件的属性集
                Attributes attrs = sr.getAttributes();
                Map<String, ArrayList<String>> user = new HashMap<String, ArrayList<String>>(16);
                if (attrs != null) {
                    for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                        // 得到下一个属性
                        Attribute attr = (Attribute) ne.next();
                        String key = attr.getID().toString();
                        ArrayList<String> params = new ArrayList<String>();
                        for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                            Object o = e.next();
                            if ("thumbnailPhoto".equals(key)) {
                                byte[] bytes = (byte[]) o;
                                params.add(new StringBuffer(BASE64PREFIX).append(Base64.encodeBase64String(bytes)).toString());
                            } else {
                                company = o.toString();
                                params.add(company);
                            }
                        }
                        user.put(key, params);
                    }
                    PersonDto p = JSON.parseObject(JSON.toJSONString(user), PersonDto.class);
                    if (p == null) {
                        return null;
                    }
                    set(p.getMailnickname().get(0), p);
                    return user;
                }
            }

        }
        return null;
    }

    /**
     * 根据id模糊查询用户
     * 
     * @param id
     * @return
     * @throws NamingException
     */
    public JSONArray searchUsersByVagueId(String id) throws NamingException {
        ctx.reconnect(connCtls);
        String filters = String.format("(&(objectClass=person)(mailNickname=%s))", id);
        String[] returnedAtts = { "name", "mailnickname" };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(60000);
        if (returnedAtts != null && returnedAtts.length > 0) {
            constraints.setReturningAttributes(returnedAtts);
        }
        ArrayList<Object> group = new ArrayList<Object>();
        for (String base : SEARCHSEQUENSE) {
            ctx.reconnect(connCtls);
            NamingEnumeration<SearchResult> answer = ctx.search(base, filters, constraints);
            String company = "";
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                // 得到符合条件的属性集
                Attributes attrs = sr.getAttributes();
                Map<String, ArrayList<String>> user = new HashMap<String, ArrayList<String>>(16);
                if (attrs != null) {
                    for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                        // 得到下一个属性
                        Attribute attr = (Attribute) ne.next();
                        String key = attr.getID().toString();
                        ArrayList<String> params = new ArrayList<String>();
                        for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                            Object o = e.next();
                            company = o.toString();
                            params.add(company);
                        }
                        user.put(key, params);
                    }
                    group.add(user);
                }
            }
        }
        return group.size() > 0 ? JSONArray.parseArray(JSON.toJSONString(group)) : null;
    }

    /**
     * 缓存用户信息
     * 
     * @param base
     * @return
     */
    private int cachePersonImp(String base) {
        String filters = "(&(objectClass=person)(l=*))";
        String[] returnedAtts = { "name", "distinguishedName", "l", "memberOf", "mail", "mailnickname", "mobile", "cn", "extensionattribute2", "thumbnailPhoto" };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(60000);
        int count = 0;
        if (returnedAtts != null && returnedAtts.length > 0) {
            constraints.setReturningAttributes(returnedAtts);
        }
        try {
            NamingEnumeration<SearchResult> answer = ctx.search(base, filters, constraints);
            String company = "";
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                // 得到符合条件的属性集
                Attributes attrs = sr.getAttributes();
                Map<String, ArrayList<String>> user = new HashMap<String, ArrayList<String>>(16);
                if (attrs != null) {
                    count++;
                    try {
                        for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                            // 得到下一个属性
                            Attribute attr = (Attribute) ne.next();
                            String key = attr.getID().toString();
                            ArrayList<String> params = new ArrayList<String>();
                            for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                                Object o = e.next();
                                if ("thumbnailPhoto".equals(key)) {
                                    byte[] bytes = (byte[]) o;
                                    params.add(new StringBuffer(BASE64PREFIX).append(Base64.encodeBase64String(bytes)).toString());
                                } else {
                                    company = o.toString();
                                    params.add(company);
                                }
                            }
                            user.put(key, params);
                        }
                    } catch (NamingException e) {
                        System.err.println("Throw Exception : " + e);
                    }

                    PersonDto p = JSON.parseObject(JSON.toJSONString(user), PersonDto.class);
                    if (p == null || p.getMailnickname() == null) {
                        continue;
                    }
                    set(p.getMailnickname().get(0), p);
                }
            }
        } catch (NamingException e1) {
            e1.printStackTrace();
            return 0;
        }
        return count;
    }

    /**
     * 
     * @param type
     *            organizationalUnit:组织架构 group：用户组 user|person：用户
     * @param name
     * @return
     */
    public PersonDto getADInfo(String filter, String name, String searchBase) {
        String userName = name;
        if (userName == null) {
            userName = "";
        }
        String company = "";
        try {
            // ldapConnect(hexStr2Str(uid), hexStr2Str(passwd));
            if (searchBase == null || searchBase.isEmpty()) {
                searchBase = "ou=LDA,DC=v01,DC=net";
            }
            String searchFilter = "(&(objectClass=user)(" + filter + "=*" + name + "*))";
            SearchControls searchCtls = new SearchControls();
            searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String[] returnedAtts = { "name", "distinguishedName", "l", "memberOf", "mail", "mailnickname", "mobile", "cn" };
            searchCtls.setReturningAttributes(returnedAtts);
            NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
            // 遍历结果集
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                Attributes attrs = sr.getAttributes();
                Map<String, ArrayList<String>> user = new HashMap<String, ArrayList<String>>(16);
                if (attrs != null) {
                    try {
                        for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                            Attribute attr = (Attribute) ne.next();
                            String key = attr.getID().toString();
                            ArrayList<String> params = new ArrayList<String>();
                            for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                                company = e.next().toString();
                                params.add(company);
                            }
                            user.put(key, params);
                        }
                    } catch (NamingException e) {
                        System.err.println("Throw Exception : " + e);
                    }
                    return JSON.parseObject(JSON.toJSONString(user), PersonDto.class);
                }
            }
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Map<String, String> getCurrentUser() {

        Map<String, String> map = new HashMap<String, String>(16);
        try {
            if (ctx != null) {
                NamingEnumeration<NameClassPair> list = ctx.list("dc=v01,dc=net");
                while (list.hasMore()) {
                    NameClassPair ncp = list.next();
                    String cn = ncp.getName();
                    if (cn.indexOf("=") != -1) {
                        int index = cn.indexOf("=");
                        cn = cn.substring(index + 1, cn.length());
                        map.put(cn, ncp.getNameInNamespace());
                    }
                }
            }
        } catch (NamingException e) {
            e.printStackTrace();
            return null;
        }

        try {
            if (ctx != null) {
                ctx.close();
            }
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 获取部门和成员信息
     * 
     * @return
     */
    public List<DepartmentDto> getDepartmentInfo() {
        String[] SEARCHSEQUENSE = { "OU=Mail,OU=Groups,OU=HZH1," + SEARCHBASES, "OU=Groups,OU=CTU1," + SEARCHBASES, "OU=Mail,OU=Groups,OU=SGP1," + SEARCHBASES };
        String filters = "(&(objectClass=group))";
        String[] returnedAtts = { "cn", "member" };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(6000);
        constraints.setReturningAttributes(returnedAtts);
        String pattern = "(?<=\\()(\\S+)(?=\\))";
        Pattern r = Pattern.compile(pattern);
        ArrayList<DepartmentDto> departs = new ArrayList<DepartmentDto>();
        for (String search : SEARCHSEQUENSE) {
            NamingEnumeration<SearchResult> answer;
            try {
                answer = ctx.search(search, filters, constraints);
                while (answer.hasMoreElements()) {
                    SearchResult sr = (SearchResult) answer.next();
                    DepartmentDto depart = new DepartmentDto();
                    Attributes attrs = sr.getAttributes();
                    if (attrs != null) {
                        Attribute member = attrs.get(returnedAtts[1]);
                        Attribute cn = attrs.get(returnedAtts[0]);
                        depart.setCn((String) cn.get());
                        if (member == null) {
                            continue;
                        }
                        ArrayList<String> params = new ArrayList<String>();
                        for (NamingEnumeration<?> ne = member.getAll(); ne.hasMore();) {
                            String id = ne.next().toString();
                            Matcher match = r.matcher(id);
                            while (match.find()) {
                                params.add(match.group());
                            }
                        }
                        depart.setMember(params);
                        departs.add(depart);
                    }
                }
            } catch (NamingException e1) {
                e1.printStackTrace();
            }
        }
        return departs.size() == 0 ? null : departs;
    }

    /**
     * 用户登录认证
     * 
     * @param id
     * @param password
     * @return
     */
    public boolean authenricate(String id, String password) {
        boolean valide = false;
        if (StringUtils.isEmpty(id) || StringUtils.isEmpty(password)) {
            return false;
        }
        if (!ldapConnect(id, password)) {
            return false;
        }
        // 装载所有用户信息
        if (StringUtil.isNotEmpty(ADMIN) && ADMIN.equals(id)) {
            autoCacheDI();
        }
        if (get(id) == null) {
            PersonDto p = getADInfo("cn", id, null);
            if (p != null) {
                String a = p.getDistinguishedName().get(0);
                String b = "";
                String[] sp = a.split(",");
                for (int i = 1; i < sp.length; i++) {
                    b += sp[i] + ",";
                }
                b = b.substring(0, b.length() - 1);
                cachePerson(new String[] { b });
            }
        }
        valide = true;
        return valide;
    }
}