package com.desay.cd.auth.uitls;

/**
 * 通用的状态返回,暂时用于用户中心与注册中心。有序如果需要统一处理，再做继承扩展
 * @author uidq1163
 *
 */
public enum ResponseCode {
	/**正常*/
    OK(200,""),
    /**通用错误*/
    ERROR(201,"通用错误"),
    /**参数错误*/
    PARAMETER_ERROR(202,"参数错误"),
    /**权限不足*/
    PERMISSION_ERROR(203,"权限不足"),
    /**用户名或密码错误*/
    AUTH_LOGIN_OR_PWD_ERROR(303,"用户名或密码错误"),
    /**登录时间戳错误*/
    AUTH_TIME_ERROR(304,"登录时间戳错误"),
    /**token认证失败*/
    AUTH_TOKEN_ERROR(305,"token认证失败"),
    /**登录次数过多*/
    AUTH_TOO_MANY(3056,"登录次数过多"),
    /**秘钥不能为空*/
    AES_EMPTY_ERROR(402,"秘钥不能为空"),
    /**未找到该用户*/
    USER_NOT_FIND(310,"未找到该用户");

    int code;
    String message;
    private ResponseCode(int code,String message){
        this.code=code;
        this.message=message;
    }
    public int getCode() {
        return code;
    }
    public String getMessage() {
        return message;
    }

    public static ResponseCode valueOf(int statusCode) {
        ResponseCode[] var1 = values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            ResponseCode status = var1[var3];
            if (status.code == statusCode) {
                return status;
            }
        }
        throw new IllegalArgumentException("No matching constant for [" + statusCode + "]");
    }
}
