package com.desay.cd.auth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 认证成功返回登录信息
 * 
 * @author uidq1163
 *
 */
public class TokenDto implements Serializable {
    private static final long serialVersionUID = 850620854461729445L;
    public String cid;
    public String token;
    public String client;
    public String roleId;
    public String orgId;
    @JsonIgnore
    public Object personDto;
    public Object userInfo;
    @JsonIgnore
    public Object sysUserInfo;

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public Object getPersonDto() {
        return personDto;
    }

    public void setPersonDto(Object object) {
        this.personDto = object;
    }

    public Object getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(Object userInfo) {
        this.userInfo = userInfo;
    }

    public Object getSysUserInfo() {
        return sysUserInfo;
    }

    public void setSysUserInfo(Object sysUserInfo) {
        this.sysUserInfo = sysUserInfo;
    }

    @Override
    public String toString() {
        return super.toString() + "ToStringTokenDTO{" + "cid='" + cid + '\'' + '}';
    }
}
