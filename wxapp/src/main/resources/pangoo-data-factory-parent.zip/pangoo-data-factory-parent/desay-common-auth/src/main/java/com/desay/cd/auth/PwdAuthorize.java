package com.desay.cd.auth;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.session.ExpiringSession;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.stereotype.Component;

import com.desay.cd.auth.dto.DepartmentDto;
import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.auth.security.SecurityChecker;
import com.desay.cd.auth.uitls.ConstantUtils;
import com.desay.cd.auth.uitls.StringUtil;

/**
 * 密码认证实现类
 * 
 * @author uidq1163
 *
 */
@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class PwdAuthorize {
    @Autowired
    LdapAuthorize ldapImp;
    @Autowired
    FindByIndexNameSessionRepository findByIndexNameSessionRepository;

    /**
     * 登出删除session
     * 
     * @param token
     * @return
     */
    public boolean logout(String token) {
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        if (session == null) {
            return false;
        } else {
            findByIndexNameSessionRepository.delete(token);
            return true;
        }
    }

    /**
     * LDAP登录认证
     * 
     * @param name
     * @param pwd
     * @param clientId
     * @param org
     * @param verifyCode
     * @param session
     * @return
     */
    public Object loginToLdap(String userId, String pwd, String clientId, HttpSession session) {
        // 验证密码
        boolean authResult = false;
        SecurityChecker checker = checkerEffectiveness(pwd);
        if (!checker.isSafty()) {
            // 密码解密异常
            return null;
        }
        // 测试专用账号
        if ("uidq8888".equals(userId) && "123456".equals(checker.getPass())) {
            authResult = Boolean.TRUE;
        } else {
            authResult = ldapImp.authenricate(userId, checker.getPass());
        }
        if (authResult) {
            invalidMultiLogin(userId, clientId);
            TokenDto token = createLdapSession(session, clientId, userId);
            token.setPersonDto(ldapImp.get(userId));
            return token;
        }
        return null;
    }

    /**
     * 判断加密密码是否合法
     *
     * @param passwd
     * @param clientId
     * @return
     */
    SecurityChecker checkerEffectiveness(String passwd) {
        SecurityChecker checker = new SecurityChecker();
        return checker.decodeDES(passwd);
    }

    /**
     * 创建LDAP会话
     * 
     * @param session
     * @param client
     * @param userId
     * @return
     */
    TokenDto createLdapSession(HttpSession session, String client, String userId) {
        // 后期用于账户多平台同时登录管理
        session.setAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, userId);
        TokenDto token = new TokenDto();
        if (StringUtil.isNotEmpty(client)) {
            token.client = client;
        }
        token.cid = userId;
        token.token = session.getId();
        session.setAttribute(ConstantUtils.SESSION_TOKEN, token);
        return token;
    }

    /**
     * 处理重复登录，无效化操作
     *
     * @param userId
     * @param client
     */
    void invalidMultiLogin(String userId, String client) {
        TokenDto token = findTokenDTO(userId, client);
        if (token != null) {
            findByIndexNameSessionRepository.delete(token.token);
        }
    }

    /**
     * 判断用户在当前终端是否登录
     *
     * @param cid
     * @param client
     * @return
     */
    private TokenDto findTokenDTO(String userId, String client) {
        Map<String, Session> sessions = findByIndexNameSessionRepository
                .findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, userId);
        TokenDto tokenDTO = null;
        for (Map.Entry<String, Session> entry : sessions.entrySet()) {
            Session s = entry.getValue();
            try {
                tokenDTO = s.getAttribute(ConstantUtils.SESSION_TOKEN);
                if (tokenDTO != null) {
                    if (tokenDTO.cid.equals(userId) && tokenDTO.client.equals(client)) {
                        return tokenDTO;
                    }
                }
            } catch (Exception e) {
                return null;
            }
        }
        return tokenDTO;
    }

    /**
     * 获取部门及其成员信息
     * 
     * @return
     */
    public List<DepartmentDto> getDepartmentInfo() {
        return ldapImp.getDepartmentInfo();
    }
}
