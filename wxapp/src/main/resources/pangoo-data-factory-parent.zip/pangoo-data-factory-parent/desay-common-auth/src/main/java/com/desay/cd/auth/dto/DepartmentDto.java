package com.desay.cd.auth.dto;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * 部门数据实体
 * @author uidq1343
 *
 */
public class DepartmentDto implements Serializable{
    private static final long serialVersionUID = 8193710881057643663L;
    /**部门名称*/
    String cn;
    
    /**部门成员uid*/
    ArrayList<String> member;

    public String getCn() {
        return cn;
    }

    public void setCn(String cn) {
        this.cn = cn;
    }

    public  ArrayList<String> getMember() {
        return member;
    }

    public void setMember( ArrayList<String> member) {
        this.member = member;
    }
    
    
}
