package com.desay.cd.auth.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.desay.cd.auth.uitls.StringUtil;

/**
 * 安全验证
 * 
 * @author uidq1163
 *
 */
public class SecurityChecker {
    private static Logger logger = LoggerFactory.getLogger(SecurityChecker.class);
    private String pass;
    private boolean safty = false;

    public SecurityChecker decodeDES(String text) {
        try {
            RsaKeyManager rsaKeyManager = new RsaKeyManager();
            String str = rsaKeyManager.decode(text);
            if (StringUtil.isNotEmpty(str)) {
                this.pass = str;
                safty = Boolean.TRUE;
            } else {
                this.safty = this.safty && Boolean.FALSE;
            }
        } catch (Exception e) {
            this.safty = this.safty && Boolean.FALSE;
            logger.error(e.getMessage(), e);
        }
        return this;
    }

    public String getPass() {
        return pass;
    }

    public boolean isSafty() {
        return safty;
    }
}
