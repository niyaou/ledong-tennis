package com.desay.cd.auth.uitls;

/**
 * 字符串工具类
 * @author uidq1163
 *
 */
public final class StringUtil {

	/**
	 * 判断字符串是否为null
	 * 
	 * @param s
	 *            需要非空判断的字符串
	 * @return 为空返回true,否则返回false
	 */
	public static boolean isEmpty(String s) {
		return s == null ? true : "".equals(s.trim());
	}

	/**
	 * 判断不为null
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isNotEmpty(String s) {
		return !isEmpty(s);
	}
}
