package com.desay.cd.auth.security;

import java.security.PrivateKey;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;

import com.desay.cd.auth.uitls.RsaUtils;
import com.desay.cd.auth.uitls.StringUtil;
import com.google.common.util.concurrent.ThreadFactoryBuilder;


/**
 * 获取RSA秘钥
 * 
 * @author uidq1163
 *
 */
public class RsaKeyManager {
	public static Logger log = Logger.getLogger(RsaKeyManager.class);
	/** 1024位加密后密文长度为172 */
	static final int RSA_SIZE = 172;
	/** 秘钥保存 */
	static Map<String, byte[]> keyMap = RsaUtils.generateKeyBytes();

	ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("lastPrivateKey-%d").build();
	ScheduledExecutorService singleThreadPool = new ScheduledThreadPoolExecutor(1, namedThreadFactory);

	public static byte[] getPublicKey() {
		return keyMap.get(RsaUtils.PUBLIC_KEY);
	}

	static byte[] lastPrivateKey;

	public static byte[] getLastPrivateKey() {
		return lastPrivateKey;
	}

	/**
	 * 每6个小时更新一次RSA秘钥
	 */
	@Scheduled(cron = "0 0 0/6 * * ?")
	void upDateKeys() {
		lastPrivateKey = getPrivateKey();
		keyMap = RsaUtils.generateKeyBytes();
		// 虽然抛出了运行异常,当被拦截了,next周期继续运行
		singleThreadPool.schedule(new Runnable() {
			@Override
			public void run() {
				try {
					lastPrivateKey = null;
					log.info("无效化旧的key");
				} catch (Exception e) {
					log.warn("RuntimeException catched,can run next");
				}
			}
			// 初始化延时
			// 计时单位
			// 表示延迟60秒执行
		}, 60, TimeUnit.SECONDS);
	}

	public static byte[] getPrivateKey() {
		return keyMap.get(RsaUtils.PRIVATE_KEY);
	}

	/**
	 * 单机解密
	 * 
	 * @param content
	 * @return
	 */
	public String decode(String content) {
		if (StringUtil.isEmpty(content)) {
			return null;
		}

		PrivateKey privateKey = null;
		try {
			privateKey = RsaUtils.restorePrivateKey(getPrivateKey());
			// 长度超过后，进行拼接
			if (content.length() > RSA_SIZE) {
				String content2 = content.substring(RSA_SIZE, RSA_SIZE * 2);
				content = content.substring(0, RSA_SIZE);
				content = RsaUtils.rsaDecode(privateKey, content);
				if (StringUtil.isNotEmpty(content)) {
					content += RsaUtils.rsaDecode(privateKey, content2);
				} else {
					content = RsaUtils.rsaDecode(privateKey, content2);
				}
			} else {
				content = RsaUtils.rsaDecode(privateKey, content);
			}

		} catch (Exception e) {
			// 解密失败，尝试使用前一次的秘钥进行解密，解决秘钥更新后的同步异常
			if (lastPrivateKey != null) {
				privateKey = RsaUtils.restorePrivateKey(getLastPrivateKey());
				// 长度超过后，进行拼接
				if (content.length() > RSA_SIZE) {
					String content2 = content.substring(RSA_SIZE, RSA_SIZE * 2);
					content = content.substring(0, RSA_SIZE);
					content = RsaUtils.rsaDecode(privateKey, content);
					content += RsaUtils.rsaDecode(privateKey, content2);
				} else {
					content = RsaUtils.rsaDecode(privateKey, content);
				}
				log.info("使用旧的key解密");
			} else {
				return null;
			}
		}
		return content;
	}
}
