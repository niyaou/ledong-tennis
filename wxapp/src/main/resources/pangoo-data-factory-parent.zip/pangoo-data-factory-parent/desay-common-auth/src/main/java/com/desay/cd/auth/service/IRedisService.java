package com.desay.cd.auth.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import com.desay.cd.auth.config.ClusterConfig;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPoolConfig;

/**
 * 缓存服务
 * 
 * @author uidq1163
 *
 */
@Component
public class IRedisService {

    @Autowired
    ClusterConfig clusterProperties;

    String[] clusters;
    JedisCluster jedisCluster;

    public IRedisService(@Value("${spring.redis.cluster.nodes}") String nodes) {
        this.clusters = nodes.split(",");
        initialShardedPool();
    }

    /**
     * 初始化切片池
     */
    private void initialShardedPool() {
        JedisPoolConfig config = new JedisPoolConfig();
        // 设置最大空闲数
        config.setMaxIdle(1000);
        // 设置超时时间
        config.setMaxWaitMillis(10001);
        // 设置最大连接数
        config.setMaxTotal(60000);
        // 链接
        Set<HostAndPort> jedisClusterNode = new HashSet<HostAndPort>();
        // 配置集群
        for (String string : clusters) {
            String[] strs = string.split(":");
            jedisClusterNode.add(new HostAndPort(strs[0], Integer.parseInt(strs[1])));
        }
        // 构造池
        jedisCluster = new JedisCluster(jedisClusterNode, config);
    }

    public void put(String key, String doamin, int expire) {
        jedisCluster.setex(key, expire, doamin);
    }

    public void put(String key, String doamin) {
        put(key, doamin, 60 * 30);
    }

    public String get(String key) {
        return jedisCluster.get(key);
    }

    /**
     * 删除
     *
     * @param key
     *            传入key的名称
     */
    public void remove(String key) {
        jedisCluster.del(key);
    }

    @Bean
    public JedisConnectionFactory connectionFactory() {
        JedisPoolConfig config = new JedisPoolConfig();
        // 设置最大空闲数
        config.setMaxIdle(1000);
        // 设置超时时间
        config.setMaxWaitMillis(10001);
        // 设置最大连接数
        config.setMaxTotal(60000);
        JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(
                new RedisClusterConfiguration(clusterProperties.getNodes()));
        jedisConnectionFactory.setUsePool(true);
        jedisConnectionFactory.setPoolConfig(config);
        jedisConnectionFactory.afterPropertiesSet();
        return jedisConnectionFactory;
    }

    /**
     * RedisTemplate配置
     * 
     * @param redisCF
     * @return
     */
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory redisCF) {
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
        RedisSerializer<?> stringSerializer = new StringRedisSerializer();
        redisTemplate.setKeySerializer(stringSerializer);
        redisTemplate.setHashKeySerializer(stringSerializer);
        redisTemplate.setConnectionFactory(redisCF);
        redisTemplate.afterPropertiesSet();
        return redisTemplate;
    }

}
