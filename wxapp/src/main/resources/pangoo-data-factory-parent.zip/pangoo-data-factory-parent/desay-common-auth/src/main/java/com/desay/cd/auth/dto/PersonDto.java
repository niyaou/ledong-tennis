package com.desay.cd.auth.dto;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * LDAP用户信息
 * @author uidq1163
 *
 */
public class PersonDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8193710881057643463L;
	ArrayList<String> name;
	ArrayList<String> distinguishedName;
	ArrayList<String> l;
	ArrayList<String> memberOf;
	ArrayList<String> mail;
	ArrayList<String> mailnickname;
	ArrayList<String> mobile;
	ArrayList<String> cn;
	ArrayList<String> extensionattribute2;
	ArrayList<String> thumbnailPhoto;

	public ArrayList<String> getExtensionattribute2() {
		return extensionattribute2;
	}

	public void setExtensionattribute2(ArrayList<String> extensionattribute2) {
		this.extensionattribute2 = extensionattribute2;
	}

	public ArrayList<String> getName() {
		return name;
	}

	public void setName(ArrayList<String> name) {
		this.name = name;
	}

	public ArrayList<String> getDistinguishedName() {
		return distinguishedName;
	}

	public void setDistinguishedName(ArrayList<String> distinguishedName) {
		this.distinguishedName = distinguishedName;
	}

	public ArrayList<String> getL() {
		return l;
	}

	public void setL(ArrayList<String> l) {
		this.l = l;
	}

	public ArrayList<String> getMemberOf() {
		return memberOf;
	}

	public void setMemberOf(ArrayList<String> memberOf) {
		this.memberOf = memberOf;
	}

	public ArrayList<String> getMail() {
		return mail;
	}

	public void setMail(ArrayList<String> mail) {
		this.mail = mail;
	}

	public ArrayList<String> getMailnickname() {
		return mailnickname;
	}

	public void setMailnickname(ArrayList<String> mailnickname) {
		this.mailnickname = mailnickname;
	}

	public ArrayList<String> getMobile() {
		return mobile;
	}

	public void setMobile(ArrayList<String> mobile) {
		this.mobile = mobile;
	}

	public ArrayList<String> getCn() {
		return cn;
	}

	public void setCn(ArrayList<String> cn) {
		this.cn = cn;
	}
	public ArrayList<String> getThumbnailPhoto() {
        return thumbnailPhoto;
    }

    public void setThumbnailPhoto(ArrayList<String> thumbnailPhoto) {
        this.thumbnailPhoto = thumbnailPhoto;
    }

    @Override
	public String toString() {
        return super.toString() + "ToStringPersonDTO{" + "name='" + name + '\'' + '}';
    }
}
