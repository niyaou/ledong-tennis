package com.desay.cd.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.session.ExpiringSession;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.stereotype.Component;

import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.auth.uitls.ConstantUtils;

/**
 * token认证实现方法
 * 
 * @author uidq1163
 *
 */
@SuppressWarnings("rawtypes")
@Component
public class TokenAuthorize {
    @Autowired
    private FindByIndexNameSessionRepository findByIndexNameSessionRepository;

    /***
     * 用户token有效认证
     * 
     * @param token
     * @return
     */
    public TokenDto tokenAuthorize(String token) {
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        TokenDto tokenDTO = null;
        if (session != null) {
            tokenDTO = session.getAttribute(ConstantUtils.SESSION_TOKEN);
            session.setLastAccessedTime(System.currentTimeMillis());
            findByIndexNameSessionRepository.save(session);
        }
        return tokenDTO;
    }
}
