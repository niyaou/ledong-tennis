package com.desay.cd.auth.service;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.stereotype.Service;

import com.desay.cd.auth.PwdAuthorize;
import com.desay.cd.auth.TokenAuthorize;
import com.desay.cd.auth.dto.TokenDto;
import com.desay.cd.auth.security.RsaKeyManager;

/**
 * 用户认证接口
 * 
 * @author uidq1163
 *
 */
@Service
@SuppressWarnings("rawtypes")
public class LdapAuthorizeService {
    public static Logger log = Logger.getLogger(LdapAuthorizeService.class);
    @Autowired
    PwdAuthorize pwdAuthorizeImp;
    @Autowired
    TokenAuthorize tokenAuthorizeImp;
    @Autowired
    FindByIndexNameSessionRepository findByIndexNameSessionRepository;

    /**
     * 获取公共秘钥,用于密码加密
     * 
     * @param request
     * @param response
     * @return
     */
    public Object getPublicKey() {
        String key = Base64.encodeBase64String(RsaKeyManager.getPublicKey());
        return key;
    }

    /**
     * 公司账户登录认证
     * 
     * @param request
     * @param username
     * @param password
     * @param clientId
     * @param response
     * @return
     */
    public Object pwdAuthorizeldap(String username, String password, String clientId, HttpServletRequest request) {
        return pwdAuthorizeImp.loginToLdap(username, password, clientId, request.getSession());
    }

    /**
     * 服务为用户登出登出，无效化相关session
     * 
     * @param request
     * @param token
     * @return
     */
    public Object logOutBytoken(String token) {
        return pwdAuthorizeImp.logout(token);
    }

    /**
     * token认证
     * 
     * @param token
     * @return true:认证成功 false:认证失败
     */
    public Object tokenAuthorize(String token) {
        TokenDto tokenDTO = tokenAuthorizeImp.tokenAuthorize(token);
        return tokenDTO;
    }

    /**
     * 获取部门及其成员信息
     * 
     * @return
     */
    public Object getDepartmentInfo() {
        return pwdAuthorizeImp.getDepartmentInfo();
    }
}
