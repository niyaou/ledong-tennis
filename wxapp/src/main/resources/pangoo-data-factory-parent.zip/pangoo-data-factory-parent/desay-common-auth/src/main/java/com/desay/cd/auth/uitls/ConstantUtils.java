package com.desay.cd.auth.uitls;

/**
 * 系統常量
 * @author uidq1163
 *
 */
public class ConstantUtils {
	/**tokenDTO*/
	public static final String SESSION_TOKEN = "tokenDTO";
	/**yyyyMMddHHmmss*/
	public static final String DATA_FORMAT = "yyyyMMddHHmmss";
	/** 服务票据 */
	public static final String SERVICE_TICKET = "ST-";
	/** 用户身份认证凭证 */
	public static final String TICKET_GRANT = "TG-";
	/** 刷新 */
	public static final String REFRESH_TICKET = "RT-";
	/** client_id格式: 端（1位，P:PC,M:移动,W:WEB,C:车机,S:服务）应用类型（1位，）日期（8）序列号（4） */
	public static final int CLIENT_ID_LENGTH = 12;
	/** 30天:秒 */
	public static final int TOKEN_EXPIRES_IN = 2592000;
	/** 30天:秒 */
	public static final int CODE_EXPIRES_IN = 2592000;
	/** 毫秒 */
	public static final int TIME_1000 = 1000;
	/** 5分钟 */
	public static final int TIME_5 = 5;
	/** 分钟 */
	public static final int TIME_60 = 60;
}
