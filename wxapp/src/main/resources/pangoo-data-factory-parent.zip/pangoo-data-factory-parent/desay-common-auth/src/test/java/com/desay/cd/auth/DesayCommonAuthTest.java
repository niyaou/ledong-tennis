package com.desay.cd.auth;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.auth.dto.DepartmentDto;
import com.desay.cd.auth.dto.PersonDto;
import com.google.common.base.CharMatcher;


/**
 * 
 * @author uidq1163
 *
 */

public class DesayCommonAuthTest {

    private static String SEARCHDN = "v01\\";
    private LdapContext ctx = null;
    private Hashtable<String, String> env = null;
    private Control[] connCtls = null;

    private String SEARCHBASES = "OU=LDA,DC=v01,DC=net";
    
    @Before()
    public  void prepared() {
        env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        // LDAP server
        env.put(Context.PROVIDER_URL, "ldap://10.219.68.188:389");
        env.put(Context.SECURITY_PRINCIPAL, SEARCHDN + "uidq1343");
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_CREDENTIALS, "fiorile1F");
        // 此处若不指定用户名和密码,则自动转换为匿名登录
        try {
            ctx = new InitialLdapContext(env, connCtls);
        } catch (NamingException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void insert() {
        String[] SEARCHSEQUENSE = { "OU=Mail,OU=Groups,OU=HZH1,"+SEARCHBASES,"OU=Groups,OU=CTU1,"+SEARCHBASES,"OU=Mail,OU=Groups,OU=SGP1,"+SEARCHBASES};
        
        String filters = "(&(objectClass=group))";
        String[] returnedAtts = {  "cn",  "member"     };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(6000);
        int count = 0;
        if (returnedAtts != null && returnedAtts.length > 0) {
            constraints.setReturningAttributes(returnedAtts);
        }
        try {
            for(String search:SEARCHSEQUENSE) {
                NamingEnumeration<SearchResult> answer = ctx.search(search, filters, constraints);
                String company = "";
                while (answer.hasMoreElements()) {
                    SearchResult sr = (SearchResult) answer.next();
                    DepartmentDto depart=new DepartmentDto();
                    Attributes attrs = sr.getAttributes();
                    if (attrs != null) {
                        try {
                            Attribute member =    attrs.get("member");
                            Attribute cn =    attrs.get("cn");
                            depart.setCn((String) cn.get());
                            if(member==null) {
                                continue;
                            }
                            ArrayList<String> params = new ArrayList<String>();
                            for (NamingEnumeration<?> ne = member.getAll(); ne.hasMore();) {
                                String id=ne.next().toString();
                                String pattern = "(?<=\\()(\\S+)(?=\\))";
                                Pattern r = Pattern.compile(pattern);
                                Matcher c = r.matcher(id);
                                while(c.find()) {
                                    params.add(c.group());
                                }
                            }
                            depart.setMember(params);
                        } catch (NamingException e) {
                            System.err.println("Throw Exception : " + e);
                        }
                    }
                } 
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    
    @Test
    public void test1() {
         String[] SEARCHSEQUENSE = { "OU=Users05,OU=Users,OU=HZH1,"+SEARCHBASES};
        
        String filters = "(&(objectClass=person))";
        String[] returnedAtts = {  "cn",  "thumbnailPhoto"    };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(6000);
        if (returnedAtts != null && returnedAtts.length > 0) {
            constraints.setReturningAttributes(returnedAtts);
        }
        try {
            for(String search:SEARCHSEQUENSE) {
                NamingEnumeration<SearchResult> answer = ctx.search(search, filters, constraints);
                while (answer.hasMoreElements()) {
                    SearchResult sr = (SearchResult) answer.next();
                    Attributes attrs = sr.getAttributes();
                    if (attrs != null) {
                        for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                            // 得到下一个属性
                            Attribute attr = (Attribute) ne.next();
                            String key = attr.getID().toString();
                                
                            for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                                if("thumbnailPhoto".equals(key)) {
                                    System.out.println(key);
                                    Object o=e.next();
                                    byte[] a=(byte[])o;
                                    System.out.println(Base64.encodeBase64String(a));
                                    String thumbnailPhoto = o.toString();
                                }
                               
                            }
                        }
                    }
                } 
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }
    
    
    @Test
    public void findUserTest() {
     
        String[] SEARCHSEQUENSE = { "OU=Users05,OU=Users,OU=HZH1,"+SEARCHBASES};
        String filters = String.format("(&(objectClass=person)(mailNickname=%s))", "uidq134~");
        String[] returnedAtts = { "name", "distinguishedName", "l", "memberOf", "mail", "mailnickname", "mobile", "cn", "extensionattribute2", "thumbnailPhoto" };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(60000);
        if (returnedAtts != null && returnedAtts.length > 0) {
            constraints.setReturningAttributes(returnedAtts);
        }
        try {
        for (String base : SEARCHSEQUENSE) {
            NamingEnumeration<SearchResult> answer = ctx.search(base, filters, constraints);
            String company = "";
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                // 得到符合条件的属性集
                Attributes attrs = sr.getAttributes();
                Map<String, ArrayList<String>> user = new HashMap<String, ArrayList<String>>(16);
                if (attrs != null) {
                    for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                        // 得到下一个属性
                        Attribute attr = (Attribute) ne.next();
                        String key = attr.getID().toString();
                        ArrayList<String> params = new ArrayList<String>();
                        for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                            Object o = e.next();
                                company = o.toString();
                                params.add(company);
                        }
                        user.put(key, params);
                    }
                    PersonDto p = JSON.parseObject(JSON.toJSONString(user), PersonDto.class);
                    System.out.println(JSON.toJSONString(p));
                }
            }
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void test3() {
        String key = "id";
        List<JSONObject> groups=new ArrayList<JSONObject>();
//            key=StringUtils.rightPad(id, 8, "?");
            Set<String> keys = new HashSet<String>();
            keys.add("uidq1340");
            keys.add("uidq1341");
            keys.add("uidq1342");
            keys.add("uidq1343");
            keys.add("uidq1344");
            
            TreeSet<String> queue=new  TreeSet<String>(new Comparator<String>() {

                @Override
                public int compare(String o1, String o2) {
                     o1= CharMatcher.anyOf("abcdefghijklmnopqrstuvwxyz").collapseFrom(o1, '0');
                     o2= CharMatcher.anyOf("abcdefghijklmnopqrstuvwxyz").collapseFrom(o2, '0');
                    return Integer.parseInt(o2)<Integer.parseInt(o1)?1:-1;
                }
            });
            queue.addAll(keys);
            System.out.println(keys.size());
            System.out.println(queue.size());
            Iterator<String> i = queue.iterator();
            while (i.hasNext()) {
                System.out.println("----------");
                System.out.println(i.next());
            }
    }
    
    @Test
    public void test4() {
        List<HashMap<String, Object>> dic=new ArrayList<HashMap<String, Object>>();
        HashMap<String, Object> a=new HashMap<String, Object>();
        HashMap<String, Object> b=new HashMap<String, Object>();
        HashMap<String, Object> c=new HashMap<String, Object>();
        a.put("fff", 1);
        b.put("fff", 11);
        c.put("fff", 13);
        dic.add(a);
        dic.add(b);
        dic.add(c);
        Pageable page1=new PageRequest(0, 1);
        Page<HashMap<String, Object>> page=new PageImpl<HashMap<String, Object>>(dic,page1 ,3);
        System.out.println(page.toString());
        System.out.println(JSON.toJSONString(page));
    }
}
