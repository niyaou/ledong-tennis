package com.desay.cd.auth.dto;

import com.desay.cd.auth.uitls.ResponseCode;

/**
 * 
 * @author uidq1163
 *
 * @param <T>
 */
public class ResponseDto<T> {
    Integer code;
    String msg;
    T data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    /**
     * 异常数据返回，默认返回#ResponseCode内异常信息
     * @param code 错误代码
     * @return
     */
	public static ResponseDto<?> newErrorResponseDto(ResponseCode code) {
        ResponseDto<?> responseDTO = new ResponseDto<Object>();
        responseDTO.msg = code.getMessage();
        responseDTO.code=code.getCode();
        return responseDTO;
    }

    /**
     * 异常数据返回
     * @param msg  自定义错误信息
     * @param code 错误代码
     * @return
     */
    public static ResponseDto<?> newErrorResponseDto(String msg, ResponseCode code) {
        ResponseDto<?> responseDTO = new ResponseDto<Object>();
        responseDTO.msg = msg;
        responseDTO.code=code.getCode();
        return responseDTO;
    }

    public static ResponseDto<?> responseDto(Object data) {
        ResponseDto<Object> responseDTO = new ResponseDto<Object>();
        responseDTO.code = ResponseCode.OK.getCode();
        responseDTO.data=data;
        return responseDTO;
    }
    
    @Override
	public String toString() {
        return super.toString() + "ToStringResponseDTO{" + "code='" + code + '\'' + '}';
    }
}
