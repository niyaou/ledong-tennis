#! /bin/bash

find /home/alg/alg_test/ -name dcs_task_running*.log -mtime +7 -exec rm {} \;
