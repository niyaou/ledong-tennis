#! /bin/bash

ip=$1
sshPort=$2
imageName=$3
imageVer=$4
fileId=$5
task=$6
imageParams=$7
env=$8

export  bashpath=$(cd `dirname $0`;pwd)
work_dir=`echo $bashpath`
LOG_FILE="$work_dir/dcs_task_running.log"
exec 2>>${LOG_FILE}
##拉取镜像
docker pull $ip:$sshPort/$imageName:$imageVer

#-pt=P 生产环境 ； -r 运行自动标注; -s 保存日志和标注结果到ES; -l 上传图片到hdfs;-c "PHash"/"AHash"/"DHash" 默认是"PHash"
cmd="nvidia-docker run -tid --rm $ip:$sshPort/$imageName:$imageVer $task $imageParams  $env -r -s  -l"
echo "`date "+%Y-%m-%d %H:%M:%S"` | $cmd" >> ${LOG_FILE}

result=`$cmd`
