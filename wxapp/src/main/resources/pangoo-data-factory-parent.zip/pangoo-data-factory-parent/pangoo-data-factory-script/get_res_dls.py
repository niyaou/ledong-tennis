#!/usr/bin/env python
# -*- coding: utf-8 -*-

## 获取服务器资源状态（cpu、mem、disk、gpu）

import sys
import ast
import json
import paramiko

def usage():
    print("Usage: python " + sys.argv[0] + " '[{\"ip\": \"xx\", \"port\": \"xx\", \"userName\": \"xx\", \"password\": \"xx\"}, {\"ip\": \"xx\", \"port\": \"xx\", \"userName\": \"xx\", \"password\": \"xx\"}]'")

# 执行远程命令（包括本机命令）
def rcmd(hostname, port, username, password, cmd):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=hostname, port=port, username=username, password=password)
    stdin,stdout,stderr = client.exec_command(cmd)
    cmd_res = stdout.read().decode('utf-8')
    return cmd_res

def get_cpu_status(host, port, username, password):
    cmd_cpu = "top -b -n 1 | awk '{if($1 ~ /^%Cpu/) {print 100 - $8}}'"
    return rcmd(host, port, username, password, cmd_cpu).strip() + '%'

def get_mem_status(host, port, username, password):
    cmd_mem = "free -m | awk '{if($1 ~ /^Mem:/) {printf \"%.1f\", $3 / $2 * 100}}'"
    return rcmd(host, port, username, password, cmd_mem).strip() + '%'

def get_disk_status(host, port, username, password):
    disk_status = {}
    cmd_disk = "df -h | awk '{if($6 !~ /Mounted|\/(run|boot|sys|dev)/) {print $6,$5}}'"
    res = rcmd(host, port, username, password, cmd_disk).strip().split('\n')
    
    for mount in res:
        disk_status[mount.split()[0]] = mount.split()[1]
    return disk_status

def get_gpu_status(host, port, username, password):
    cmd_gpu_status = "nvidia-smi | awk '{if($14 ~ /Default/) {print $9,$11,$13}}'"
    cmd_gpu_process = "nvidia-smi | awk '{if($4 ~ /G/) {print $2,$5,$6}}'"
    res_gpu_status = rcmd(host, port, username, password, cmd_gpu_status).strip().split('\n')
    res_gpu_process = rcmd(host, port, username, password, cmd_gpu_process).strip().split('\n')

    gpu_status = {}
    for gpu in res_gpu_status:
        if gpu:
            gpu_seq = str(res_gpu_status.index(gpu))
            util_list=gpu.split()
            gpu_status[gpu_seq] = {}
            gpu_status[gpu_seq]['gpu_util'] = {}
            gpu_status[gpu_seq]['gpu_process'] = {}
            gpu_status[gpu_seq]['gpu_util']['mem_used'] = util_list[0]
            gpu_status[gpu_seq]['gpu_util']['mem_total'] = util_list[1]
            gpu_status[gpu_seq]['gpu_util']['util'] = util_list[2]

    for process in res_gpu_process:
        if process:
            process_list=process.split()
            gpu_status[process_list[0]]['gpu_process'][process_list[1]] = process_list[2]

    return gpu_status

if __name__ == '__main__':
    if len(sys.argv) < 2:
        usage()
        sys.exit(1)

    host_list = ast.literal_eval(sys.argv[1])
    host_status = {}
    for host_info in host_list:
        host = host_info['ip']
        port = host_info['port']
        username = host_info['userName']
        password = host_info['password']

        host_res = {}
        host_res['cpu_usage'] = get_cpu_status(host, port, username, password)
        host_res['mem_usage'] = get_mem_status(host, port, username, password)
        host_res['disk_usage'] = get_disk_status(host, port, username, password)
        host_res['gpu_usage'] = get_gpu_status(host, port, username, password)
        host_status[host] = host_res

    print(json.dumps(host_status))