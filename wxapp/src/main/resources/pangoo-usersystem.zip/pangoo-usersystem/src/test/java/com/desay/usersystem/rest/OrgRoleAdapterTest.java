package com.desay.usersystem.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.UserInfoDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.DateUtil;
import com.desay.usersystem.adapter.bean.RoleBean;
import com.desay.usersystem.dao.PermissionRoleDao;
import com.desay.usersystem.dao.RoleDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.entity.PermissionRole;
import com.desay.usersystem.entity.Role;
import com.desay.usersystem.entity.UserRole;
import com.desay.usersystem.security.RsaKeyManager;
import com.desay.usersystem.service.PwdAuthorizeService;
import com.desay.usersystem.utils.Cst;

/**
 * 用于企业工厂等机构角色管理
 * 
 * @author uidq1163
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class OrgRoleAdapterTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    PwdAuthorizeService authRequest;
    String token = "";
    final static Type type = new TypeReference<ResponseDTO<UserInfoDTO>>() {
    }.getType();

    /**
     * 将Base64编码后的公钥转换成PublicKey对象
     * 
     * @param pubStr
     * @return
     * @throws Exception
     */
    public PublicKey string2PublicKey(String pubStr) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(pubStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        // 获取公钥
        String publicKey = Base64.encodeBase64String(RsaKeyManager.getPublicKey());
        // 用户名
        String pwd = "123456";
        // 终端号
        // 本地系统时间yyyyMMddHHmmss+明文密码后用接口getPublicKey所得公钥进行RSA加密，本地时间不能与服务器时间相差2分钟以上
        try {
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);
            String result = mvc
                    .perform(post("/pwdAuthorize").header(Cst.HEADER_TOKEN, token).param("username", "huangshouyi")
                            .param("password", decodepwd).param("clientId", "C0201806130001")
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

            ResponseDTO<UserInfoDTO> userInfoDTO = JSON.parseObject(result, type);
            token = userInfoDTO.getData().getToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取企业角色
     * 
     * @param request
     * @return
     */
    @Test
    public void getOrgRole() {
        try {
            String result = mvc
                    .perform(get("/orgRole/getOrgRole").header(Cst.HEADER_TOKEN, token)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(200, responseResult.getCode());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取机构权限列表
     * 
     * @param request
     * @return
     */
    @Test
    public void getPermissionList() {
        try {
            String result = mvc
                    .perform(get("/orgRole/getPermissionList").header(Cst.HEADER_TOKEN, token)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(200, responseResult.getCode());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Autowired
    PermissionRoleDao permissionRoleDao;

    /**
     * 添加角色权限：正常添加
     * 
     * @param request
     * @return
     */
    @Test
    public void addRolePermission() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1);
            permission.setRoleId("1000");
            // 如果存在该角色权限，先删除
            permissionRoleDao.delete(permission);
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(post("/orgRole/addRolePermission").header(Cst.HEADER_TOKEN, token).content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 200);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加角色权限：角色不存在
     * 
     * @param request
     * @return
     */
    @Test
    public void addRolePermission1() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1);
            permission.setRoleId("error1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(post("/orgRole/addRolePermission").header(Cst.HEADER_TOKEN, token).content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 201);
            assertEquals(responseResult.getMsg(), "没有该角色");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加角色权限：没有该权限
     * 
     * @param request
     * @return
     */
    @Test
    public void addRolePermission2() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1000000001);
            permission.setRoleId("1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(post("/orgRole/addRolePermission").header(Cst.HEADER_TOKEN, token).content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 201);
            assertEquals(responseResult.getMsg(), "没有该权限");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加角色权限：权限必须是自己所在机构或者通用权限，角色必须是自己所在机构特有角色
     * 
     * @return
     */
    @Test
    public void addRolePermission3() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1005);
            permission.setRoleId("1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(post("/orgRole/addRolePermission").header(Cst.HEADER_TOKEN, token).content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 203);
            assertEquals(responseResult.getMsg(), "权限不足");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加角色权限：PermissionId位null
     * 
     * @return
     */
    @Test
    public void addRolePermission4() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId(null);
            permission.setRoleId("1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(post("/orgRole/addRolePermission").header(Cst.HEADER_TOKEN, token).content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(202, responseResult.getCode());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加角色权限：RoleId为空
     * 
     * @return
     */
    @Test
    public void addRolePermission5() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1000);
            permission.setRoleId("");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(post("/orgRole/addRolePermission").header(Cst.HEADER_TOKEN, token).content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(202, responseResult.getCode());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限
     * 
     * @return
     */
    @Test
    public void delRolePermission() {
        try {
            // 先插入数据
            PermissionRole permissionRole = new PermissionRole();
            permissionRole.setPermissionId("" + 1000);
            permissionRole.setRoleId("1000");
            permissionRoleDao.save(permissionRole);
            // 执行删除动作
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1000);
            permission.setRoleId("1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").header(Cst.HEADER_TOKEN, token).content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 200);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限
     * 
     * @return
     */
    @Test
    public void delRolePermission1() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1000);
            permission.setRoleId("error1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 201);
            assertEquals(responseResult.getMsg(), "没有该角色");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限
     * 
     * @return
     */
    @Test
    public void delRolePermission2() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1000000001);
            permission.setRoleId("1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 201);
            assertEquals(responseResult.getMsg(), "没有该权限");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限
     * 
     * @return
     */
    @Test
    public void delRolePermission3() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1005);
            permission.setRoleId("1000");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 203);
            assertEquals(responseResult.getMsg(), "权限不足");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限
     * 
     * @return
     */
    @Test
    public void delRolePermission4() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1004);
            permission.setRoleId("3");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 201);
            assertEquals(responseResult.getMsg(), "权限不存在");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限:权限必须是自己所在机构或者通用权限，角色必须是自己所在机构特有角色
     * 
     * @return
     */
    @Test
    public void delRolePermission5() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1004);
            permission.setRoleId("22");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(203, responseResult.getCode());
            assertEquals(responseResult.getMsg(), "权限不足");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限:PermissionId为null
     * 
     * @return
     */
    @Test
    public void delRolePermission6() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId(null);
            permission.setRoleId("6");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(202, responseResult.getCode());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色权限:RoleId为空
     * 
     * @return
     */
    @Test
    public void delRolePermission7() {
        try {
            PermissionRole permission = new PermissionRole();
            permission.setPermissionId("" + 1004);
            permission.setRoleId("");
            String content = JSON.toJSONString(permission);
            String result = mvc
                    .perform(delete("/orgRole/delRolePermission").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(202, responseResult.getCode());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Autowired
    UserRoleDao userRoleDao;

    /**
     * 设置用户角色：正常设置
     * 
     * @return
     */
    @Test
    public void setUserRole() {
        try {

            UserRole orgRole = new UserRole();
            orgRole.setRoleId("1000");
            orgRole.setUserCid("f31cbd10-dedb-4b61-8e3b-666ae451d64a");
            // 先删除用户角色
            userRoleDao.delete(orgRole);
            String content = JSON.toJSONString(orgRole);
            String result = mvc
                    .perform(post("/orgRole/setUserRole").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                            .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 200);
            // 测试完成删除数据
            userRoleDao.delete(orgRole);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 设置用户角色
     * 
     * @return
     */
    @Test
    public void setUserRole1() {
        try {
            UserRole orgRole = new UserRole();
            orgRole.setRoleId("1000");
            orgRole.setUserCid("1111");
            String content = JSON.toJSONString(orgRole);
            String result = mvc
                    .perform(post("/orgRole/setUserRole").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                            .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 203);
            assertEquals(responseResult.getMsg(), "不能操控非本机构");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 设置用户角色
     * 
     * @return
     */
    @Test
    public void setUserRole2() {
        try {
            UserRole orgRole = new UserRole();
            orgRole.setRoleId("1000");
            orgRole.setUserCid("1111");
            String content = JSON.toJSONString(orgRole);
            String result = mvc
                    .perform(post("/orgRole/setUserRole").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                            .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(203, responseResult.getCode());
            assertEquals(responseResult.getMsg(), "不能操控非本机构");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 设置用户角色
     * 
     * @return
     */
    @Test
    public void setUserRole3() {
        try {
            UserRole orgRole = new UserRole();
            orgRole.setRoleId("1000");
            orgRole.setUserCid("111100000000001");
            String content = JSON.toJSONString(orgRole);
            String result = mvc
                    .perform(post("/orgRole/setUserRole").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                            .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 201);
            assertEquals(responseResult.getMsg(), "角色不存在");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Autowired
    RoleDao roleDao;

    /**
     * 创建角色
     * 
     * @return
     */
    @Test
    public void creatRole() throws Exception {
        RoleBean role = new RoleBean();
        // role.setCreatorId("单元测试");
        role.setRoleName("单元测试");
        role.setRemark("单元测试");
        List<String> permissionList = new ArrayList<>();
        permissionList.add("" + 1000);
        permissionList.add("" + 1001);
        role.setPermissionList(permissionList);
        String content = JSON.toJSONString(role);
        String result = mvc
                .perform(post("/orgRole/creatRole").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 200);
        // case: delRole3()
        // 测试之后删除对应的测试数据
        PermissionRole permissionRole = new PermissionRole();
        permissionRole.setPermissionId("" + 1000);
        permissionRole.setRoleId("单元测试normal");
        PermissionRole permissionRole2 = new PermissionRole();
        permissionRole2.setPermissionId("" + 1001);
        permissionRole2.setRoleId("单元测试normal");
        permissionRoleDao.delete(permissionRole);
        permissionRoleDao.delete(permissionRole2);

        roleDao.delete("单元测试normal");
    }

    /**
     * 创建角色:角色已存在
     * 
     * @return
     */
    @Test
    public void creatRole1() throws Exception {
        RoleBean role = new RoleBean();
        // role.setCreatorId("test");
        role.setRoleName("test");
        role.setRemark("test");
        List<String> permissionList = new ArrayList<>();
        permissionList.add("" + 1000);
        permissionList.add("" + 1001);
        role.setPermissionList(permissionList);
        String content = JSON.toJSONString(role);
        String result = mvc
                .perform(post("/orgRole/creatRole").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 201);
        assertEquals(responseResult.getMsg(), "角色已存在");
    }

    /**
     * 创建角色:角色已存在
     * 
     * @return
     */
    @Test
    public void creatRole2() throws Exception {
        RoleBean role = new RoleBean();
        // role.setCreatorId("单元测试2");
        role.setRoleName("单元测试2");
        role.setRemark("单元测试2");
        List<String> permissionList = new ArrayList<>();
        permissionList.add("" + 100000000);
        role.setPermissionList(permissionList);
        String content = JSON.toJSONString(role);
        String result = mvc
                .perform(post("/orgRole/creatRole").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 201);
        assertEquals(responseResult.getMsg(), "当前权限不存在");
    }

    /**
     * 删除角色
     * 
     * @return
     * @throws Throwable
     * @throws UnsupportedEncodingException
     */
    @Test
    public void delRole() throws UnsupportedEncodingException, Throwable {
        String result = mvc
                .perform(delete("/orgRole/delRole").param("roleId", "1000000")
                        .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(310, responseResult.getCode());
        assertEquals(responseResult.getMsg(), "未找到该用户");
    }

    /**
     * 删除角色 只能操作自己机构的：删除其他机构的角色
     * 
     * @return
     */
    @Test
    public void delRole1() {
        try {
            String result = mvc
                    .perform(delete("/orgRole/delRole").param("roleId", "22")
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 203);
            assertEquals(responseResult.getMsg(), "权限不足");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除角色:正常删除
     * 
     * @return
     */
    @Test
    public void delRole3() throws Exception {
        Role role = new Role();
        role.setId("单元测试normal");
        role.setOrgId("normal");
        role.setRoleName("单元测试normal");
        roleDao.save(role);
        UserRole userRole = new UserRole();
        userRole.setRoleId(role.getId());
        userRole.setUserCid("2643290c-5aa2-4aa1-93f0-93060f7412f5");
        userRoleDao.save(userRole);
        PermissionRole permissionRole = new PermissionRole();
        permissionRole.setPermissionId("" + 1000);
        permissionRole.setRoleId(role.getId());
        permissionRoleDao.save(permissionRole);

        String result = mvc
                .perform(delete("/orgRole/delRole").param("roleId", "单元测试normal")
                        .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
    }

    /**
     * 获取角色权限
     * 
     * @return
     */
    @Test
    public void getRolePermission() throws Exception {
        String result = mvc
                .perform(get("/orgRole/getRolePermission").param("roleId", "1000")
                        .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 200);
    }

    /**
     * 获取角色权限:只能获取当前机构的用户角色
     * 
     * @return
     */
    @Test
    public void getRolePermission1() throws Exception {
        String result = mvc
                .perform(get("/orgRole/getRolePermission").param("roleId", "22")
                        .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 203);
        assertEquals(responseResult.getMsg(), "权限不足");
    }

    /**
     * 获取角色权限:只能获取当前机构的用户角色
     * 
     * @return
     */
    @Test
    public void getUserRole() throws Exception {
        String result = mvc
                .perform(get("/orgRole/getUserRole").param("cid", "1111").header(Cst.HEADER_TOKEN, token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 203);
        assertEquals(responseResult.getMsg(), "权限不足");
    }

    /**
     * 获取角色权限:只能获取当前机构的用户角色
     * 
     * @return
     */
    @Test
    public void getUserRole1() {
        try {
            String result = mvc
                    .perform(get("/orgRole/getUserRole").param("cid", "23a75b23-1766-4460-9089-04c7869b5a66")
                            .header(Cst.HEADER_TOKEN, token).accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 200);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
