package com.desay.usersystem.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.UserInfoDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.DateUtil;
import com.desay.usersystem.utils.Cst;

/**
 * 用户token认证
 * 
 * @author uidq1887
 * @date 2018年12月14日
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TokenAuthAdapterTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    String token = "";
    final static Type type = new TypeReference<ResponseDTO<UserInfoDTO>>() {
    }.getType();

    /**
     * 将Base64编码后的公钥转换成PublicKey对象
     * 
     * @param pubStr
     * @return
     * @throws Exception
     */
    public PublicKey string2PublicKey(String pubStr) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(pubStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        // 本地系统时间yyyyMMddHHmmss+明文密码后用接口getPublicKey所得公钥进行RSA加密，本地时间不能与服务器时间相差2分钟以上
        String pwd = "123456";
        try {
            String res = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> resResult = JSON.parseObject(res, ResponseDTO.class);
            String publicKey = (String) resResult.getData();
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);
            String result = mvc
                    .perform(post("/pwdAuthorize").param("username", "huangshouyi").param("password", decodepwd)
                            .param("clientId", "NH00000000001").accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<UserInfoDTO> userInfoDTO = JSON.parseObject(result, type);
            token = userInfoDTO.getData().getToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 用户token身份认证接口
     * 
     * @param request
     * @return
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    @Test
    public void tokenAuthorize() throws UnsupportedEncodingException, Exception {
        String result = mvc
                .perform(get("/tokenAuthorize").header(Cst.HEADER_TOKEN, token).param("token", token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(305, responseResult.getCode());
        result = mvc.perform(get("/tokenAuthorize").param("token", "123").accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(305, responseResult.getCode());
    }

    /**
     * 用户token身份认证接口，同时会返回角色权限
     * 
     * @param request
     * @return
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    @Test
    public void tokenPermission() throws UnsupportedEncodingException, Exception {
        String result = mvc
                .perform(get("/tokenPermission").header(Cst.HEADER_TOKEN, token).param("token", token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(305, responseResult.getCode());
        result = mvc
                .perform(get("/tokenPermission").header(Cst.HEADER_TOKEN, token).param("token", "123456")
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(305, responseResult.getCode());
    }
}
