package com.desay.usersystem.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.lang.reflect.Type;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.UserInfoDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.DateUtil;
import com.desay.cd.utils.MD5Util;
import com.desay.usersystem.adapter.bean.Password;
import com.desay.usersystem.adapter.bean.UpdateUserInfo;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.security.RsaKeyManager;
import com.desay.usersystem.service.PwdAuthorizeService;

/**
 * 用户基础信息测试工具类
 * 
 * @author uidq1163
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserInfoAdapterTest {
    final static Type type = new TypeReference<ResponseDTO<UserInfoDTO>>() {
    }.getType();
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    PwdAuthorizeService authRequest;
    String token = "";

    /**
     * 将Base64编码后的公钥转换成PublicKey对象
     * 
     * @param pubStr
     * @return
     * @throws Exception
     */
    public PublicKey string2PublicKey(String pubStr) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(pubStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        // 获取公钥
        String publicKey = Base64.encodeBase64String(RsaKeyManager.getPublicKey());
        // 用户名
        String pwd = "123456";
        // 终端号
        // 本地系统时间yyyyMMddHHmmss+明文密码后用接口getPublicKey所得公钥进行RSA加密，本地时间不能与服务器时间相差2分钟以上
        try {
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);
            String result = mvc
                    .perform(post("/pwdAuthorize").param("username", "huangshouyi").param("password", decodepwd)
                            .param("clientId", "C0201806130001").accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

            ResponseDTO<UserInfoDTO> userInfoDTO = JSON.parseObject(result, type);
            token = userInfoDTO.getData().getToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 普通用户用户注册接口
     * 
     * @param request
     * @return
     */
    @Test
    public void getUser() throws Exception {
        String result = mvc
                .perform(get("/userInfo/getUser").param("username", "huangshouyi").header("accept_token", token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 200);
    }

    /**
     * 获取用户基础信息接口（用戶名为空）
     * 
     * @param request
     * @return
     */
    @Test
    public void getUser1() throws Exception {
        String result = mvc
                .perform(get("/userInfo/getUser").param("username", "").header("accept_token", token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(202, responseResult.getCode());
    }

    /**
     * 获取用户基础信息接口（用戶名不存在）
     * 
     * @param request
     * @return
     */
    @Test
    public void getUser2() throws Exception {
        String result = mvc
                .perform(get("/userInfo/getUser").param("username", "huangshouyitest").header("accept_token", token)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(310, responseResult.getCode());
    }

    @Autowired
    PangooUserDao pangooUserDao;

    /**
     * 修改用户密码
     * 
     * @param request
     * @return
     */
    @Test
    public void changePassword() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("");
        pangooUser.setLogin("huangshouyichangePassword");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("12345678"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        Password password = new Password();
        String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
        // password.setCid("11111111111111111111111111");
        password.setNewPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + "87654321"));
        password.setOldPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + "12345678"));
        String content = JSON.toJSONString(password);
        String result = mvc
                .perform(post("/userInfo/changePassword").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header("accept_token", token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
        // 删除
        pangooUserDao.delete(pangooUser);
    }

    /**
     * 修改用户密码(账户信息不对)
     * 
     * @param request
     * @return
     */
    @Test
    public void changePassword1() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("");
        pangooUser.setLogin("huangshouyichangePassword");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("12345678"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        Password password = new Password();
        // password.setCid("11111111111111111111111111test");
        String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
        password.setNewPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + "87654321"));
        password.setOldPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + "12345678"));
        String content = JSON.toJSONString(password);
        String result = mvc
                .perform(post("/userInfo/changePassword").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header("accept_token", token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(301, responseResult.getCode());
        // 删除
        pangooUserDao.delete(pangooUser);
    }

    /**
     * 修改用户密码(密码时间戳不对不对)
     * 
     * @param request
     * @return
     */
    @Test
    public void changePassword2() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("");
        pangooUser.setLogin("huangshouyichangePassword");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("12345678"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        Password password = new Password();
        String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
        // password.setCid("11111111111111111111111111");
        password.setNewPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "20161205121212") + "87654321"));
        password.setOldPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "20161205121212") + "12345678"));
        String content = JSON.toJSONString(password);
        String result = mvc
                .perform(post("/userInfo/changePassword").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header("accept_token", token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(314, responseResult.getCode());
        // 删除
        pangooUserDao.delete(pangooUser);
    }

    /**
     * 修改用户密码(密码不对)
     * 
     * @param request
     * @return
     */
    @Test
    public void changePassword3() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("testShouyi.Huang@desay-svautomotive.com");
        pangooUser.setLogin("huangshouyichangePassword");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("87654321"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        Password password = new Password();
        String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
        // password.setCid("11111111111111111111111111");
        password.setNewPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + "123456789"));
        password.setOldPassword(RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()),
                DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + "87654321error"));
        String content = JSON.toJSONString(password);
        String result = mvc
                .perform(post("/userInfo/changePassword").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header("accept_token", token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(302, responseResult.getCode());
        // 删除
        pangooUserDao.delete(pangooUser);
    }

    /**
     * 修改用户信息
     * 
     * @param request
     * @return
     */
    @Test
    public void upUserInfo() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("testShouyi.Huang@desay-svautomotive.com");
        pangooUser.setLogin("huangshouyiupUserInfo");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("12345678"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        UpdateUserInfo updateUserInfo = new UpdateUserInfo();
        // updateUserInfo.setCid("11111111111111111111111111");
        updateUserInfo.setEmail("Shouyi.Huang@desay-svautomotive.com");
        // updateUserInfo.setLogin("huangshouyiupUserInfo2");
        updateUserInfo.setTelPhone("1245788885511");
        String content = JSON.toJSONString(updateUserInfo);
        String result = mvc
                .perform(post("/userInfo/upUserInfo").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header("accept_token", token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
        PangooUser uppangooUser = pangooUserDao.findOne("11111111111111111111111111");
        assertEquals("huangshouyiupUserInfo2", uppangooUser.getLogin());
        // 删除
        pangooUserDao.delete(uppangooUser);
    }

    /**
     * 修改用户信息（用户不存在）
     * 
     * @param request
     * @return
     */
    @Test
    public void upUserInfo2() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("testShouyi.Huang@desay-svautomotive.com");
        pangooUser.setLogin("huangshouyiupUserInfo");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("12345678"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        UpdateUserInfo updateUserInfo = new UpdateUserInfo();
        // updateUserInfo.setCid("11111111111111111111111111test");
        updateUserInfo.setEmail("Shouyi.Huang@desay-svautomotive.com");
        // updateUserInfo.setLogin("huangshouyiupUserInfo");
        updateUserInfo.setTelPhone("12457888855");
        String content = JSON.toJSONString(updateUserInfo);
        String result = mvc
                .perform(post("/userInfo/upUserInfo").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header("accept_token", token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(310, responseResult.getCode());
        // 删除
        pangooUserDao.delete(pangooUser);
    }

    /**
     * 修改用户信息(用户主键ID为空)
     * 
     * @param request
     * @return
     */
    @Test
    public void upUserInfo3() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("testShouyi.Huang@desay-svautomotive.com");
        pangooUser.setLogin("huangshouyiupUserInfo");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("12345678"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        UpdateUserInfo updateUserInfo = new UpdateUserInfo();
        // updateUserInfo.setCid("");
        updateUserInfo.setEmail("Shouyi.Huang@desay-svautomotive.com");
        // updateUserInfo.setLogin("huangshouyiupUserInfo");
        updateUserInfo.setTelPhone("12457888855");
        String content = JSON.toJSONString(updateUserInfo);
        String result = mvc
                .perform(post("/userInfo/upUserInfo").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .header("accept_token", token).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(202, responseResult.getCode());
        // 删除
        pangooUserDao.delete(pangooUser);
    }
}
