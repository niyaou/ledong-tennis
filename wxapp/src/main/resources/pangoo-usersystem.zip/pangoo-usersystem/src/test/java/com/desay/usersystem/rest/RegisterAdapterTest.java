package com.desay.usersystem.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.DateUtil;
import com.desay.cd.utils.MD5Util;
import com.desay.usersystem.adapter.bean.User;
import com.desay.usersystem.adapter.bean.WxUser;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.dao.WeixinCodeDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.entity.UserRole;
import com.desay.usersystem.entity.WeixinCode;

/**
 * 普通用户注册入口测试工具类
 * 
 * @author uidq1163
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class RegisterAdapterTest {
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    private PangooUserDao pangooUserDao;
    @Autowired
    private UserRoleDao userRoleDao;
    private String publicKey = "";

    /**
     * 将Base64编码后的公钥转换成PublicKey对象
     * 
     * @param pubStr
     * @return
     * @throws Exception
     */
    public PublicKey string2PublicKey(String pubStr) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(pubStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    @Before()
    public void setup() {
        try {
            mvc = MockMvcBuilders.webAppContextSetup(wac).build();
            String Key = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResultpublicKey = JSON.parseObject(Key, ResponseDTO.class);
            publicKey = responseResultpublicKey.getData().toString();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 普通用户用户注册接口
     * 
     * @param request
     * @return
     */
    @Test
    public void registration() throws Exception {
        PangooUser pangooUser = pangooUserDao.findByUserName("uidq1163");
        if (null != pangooUser) {
            UserRole userRole = userRoleDao.getOne(pangooUser.getCid());
            if (null != userRole) {
                userRoleDao.delete(userRole);
            }
            pangooUserDao.delete(pangooUser.getCid());
        }
        User user = new User();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("uidq1163");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密

        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);
        user.setTelPhone("18100000000");
        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/Registration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 200);
        // 删除插入用户
        pangooUser = pangooUserDao.findByUserName("uidq1163");
        pangooUserDao.delete(pangooUser.getCid());
    }

    /**
     * 普通用户注册入口:用戶名和电话号码不能为空
     * 
     * @param request
     * @return
     */
    @Test
    public void registration1() throws Exception {
        PangooUser pangooUser = pangooUserDao.findByUserName("uidq1163");
        if (null != pangooUser) {
            userRoleDao.delete(pangooUser.getCid());
            pangooUserDao.delete(pangooUser);
        }
        User user = new User();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("");
        String pwd = "123456";
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);
        user.setTelPhone("");
        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/Registration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 202);
    }

    /**
     * 普通用户注册入口:用戶名重复
     * 
     * @param request
     * @return
     */
    @Test
    public void registration2() throws Exception {
        User user = new User();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("huangshouyi");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);
        user.setTelPhone("122222222");
        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/Registration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(312, responseResult.getCode());
    }

    @Autowired
    WeixinCodeDao weixinCodeDao;

    /**
     * 普通用户:微信用户注册接口
     * 
     * @param request
     * @return
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    @Test
    public void wxRegistration() throws Exception {
        PangooUser pangooUser = pangooUserDao.findByUserName("wxuidq1163Shouyi.Huang");
        if (null != pangooUser) {
            WeixinCode weixinCode = weixinCodeDao.getOne("Openidwxuidq1163");
            if (null != weixinCode) {
                weixinCodeDao.delete(weixinCode);
            }
            UserRole userRole = userRoleDao.getOne(pangooUser.getCid());
            if (null != userRole) {
                userRoleDao.delete(userRole);
            }
            pangooUserDao.delete(pangooUser);
        }
        WxUser user = new WxUser();
        user.setEmail("wxShouyi.Huang@desay-svautomotive.com");
        user.setLogin("wxuidq1163Shouyi.Huang");
        user.setOpenid("Openidwxuidq1163");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);
        user.setTelPhone("18100000000");
        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/wxRegistration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
        // 删除插入用户
        pangooUser = pangooUserDao.findByUserName("wxuidq1163Shouyi.Huang");
        weixinCodeDao.delete(user.getOpenid());
        pangooUserDao.delete(pangooUser.getCid());
    }

    /**
     * 普通用户:微信用户注册接口（用户名和电话号码不能为空）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void wxRegistration1() throws UnsupportedEncodingException, Exception {
        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("");
        user.setTelPhone("");
        user.setOpenid("Openidwxuidq1163");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/wxRegistration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 202);
    }

    /**
     * 普通用户:微信用户注册接口（密码长度小于7）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void wxRegistration2() throws Exception {
        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("wxuidq1163");
        user.setTelPhone("1380000001");
        user.setOpenid("Openidwxuidq1163");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "123456";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/wxRegistration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(responseResult.getCode(), 314);
    }

    /**
     * 普通用户:微信用户注册接口（微信已经绑定账户）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void wxRegistration3() throws Exception {
        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("wxuidq1163");
        user.setTelPhone("1380000001");
        // 数据已经存在的微信ID
        user.setOpenid("033Oxatn123sNbun1iXYtn1OxHtT");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "123456";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/wxRegistration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(312, responseResult.getCode());
        assertEquals("微信已经绑定账户", responseResult.getMsg());
    }

    /**
     * 普通用户:微信用户注册接口（用户已经存在直接绑定微信账户）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void wxRegistration4() throws Exception {
        PangooUser pangooUser = new PangooUser();
        pangooUser.setCid("11111111111111111111111111");
        pangooUser.setEmail("Shouyi.Huang@desay-svautomotive.com");
        pangooUser.setLogin("huangshouyiwxRegistration");
        pangooUser.setOrgId("normal");
        pangooUser.setPassword(MD5Util.md5("12345678"));
        pangooUser.setTelPhone("12457888855");
        pangooUserDao.save(pangooUser);

        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("huangshouyiwxRegistration");
        user.setTelPhone("12457888855");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/wxRegistration").content(content)
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        // 删除绑定信息
        weixinCodeDao.delete("huangshouyi13399999990");
        pangooUserDao.delete(pangooUser);
        assertEquals(200, responseResult.getCode());
    }

    /**
     * 普通用户:微信扫码，绑定已有用户
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void bindwx() throws Exception {
        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("huangshouyi");
        user.setTelPhone("13399999990");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "123456";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/bindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
        // 删除绑定信息
        weixinCodeDao.delete("huangshouyi13399999990");
    }

    /**
     * 普通用户:微信扫码，绑定已有用户
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void bindwx1() throws Exception {
        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("");
        user.setTelPhone("");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/bindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(202, responseResult.getCode());
    }

    /**
     * 普通用户:微信解绑定已有用户
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void unBindwx() throws Exception {
        WeixinCode weixinCode = new WeixinCode();
        weixinCode.setCid("23a75b23-1766-4460-9089-04c7869b5a66");
        weixinCode.setOpenid("huangshouyi13399999990");
        weixinCode.setUnionid("Unionidwxuidq1163");
        weixinCodeDao.save(weixinCode);

        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("huangshouyi");
        user.setTelPhone("13399999990");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "123456";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/unBindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
    }

    /**
     * 普通用户:微信解绑定已有用户（微信账户不存在）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void unBindwx1() throws Exception {
        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("huangshouyi");
        user.setTelPhone("13399999990");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/unBindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(310, responseResult.getCode());
    }

    /**
     * 普通用户:微信解绑定已有用户（账户不存在）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void unBindwx2() throws Exception {
        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("testhuangshouyi");
        user.setTelPhone("121212121212");
        user.setOpenid("test");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);

        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/unBindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(310, responseResult.getCode());
    }

    /**
     * 普通用户:微信解绑定已有用户（密码不合法时间戳错误）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void unBindwx3() throws Exception {
        WeixinCode weixinCode = new WeixinCode();
        weixinCode.setCid("23a75b23-1766-4460-9089-04c7869b5a66");
        weixinCode.setOpenid("huangshouyi13399999990");
        weixinCode.setUnionid("Unionidwxuidq1163");
        weixinCodeDao.save(weixinCode);

        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("huangshouyi");
        user.setTelPhone("13399999990");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        user.setPassword(pwd);
        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/unBindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(304, responseResult.getCode());
    }

    /**
     * 普通用户:微信解绑定已有用户（密码错误）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void unBindwx4() throws Exception {
        WeixinCode weixinCode = new WeixinCode();
        weixinCode.setCid("23a75b23-1766-4460-9089-04c7869b5a66");
        weixinCode.setOpenid("huangshouyi13399999990");
        weixinCode.setUnionid("Unionidwxuidq1163");
        weixinCodeDao.save(weixinCode);

        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("huangshouyi");
        user.setTelPhone("13399999990");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);
        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/unBindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        weixinCodeDao.delete("huangshouyi13399999990");
        assertEquals(302, responseResult.getCode());
    }

    /**
     * 普通用户:微信解绑定已有用户（登录用户和电话号码为空）
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void unBindwx5() throws Exception {

        WxUser user = new WxUser();
        user.setEmail("Shouyi.Huang@desay-svautomotive.com");
        user.setLogin("");
        user.setTelPhone("");
        user.setOpenid("huangshouyi13399999990");
        user.setUnionid("Unionidwxuidq1163");
        String pwd = "12345678";
        // 获取公钥，对密码进行加密
        String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
        decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);

        user.setPassword(decodepwd);
        String content = JSON.toJSONString(user);
        String result = mvc
                .perform(post("/registration/unBindwx").content(content).contentType(MediaType.APPLICATION_JSON_UTF8)
                        .accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(202, responseResult.getCode());
    }

    /**
     * 获取手机验证码
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void getVerificationCode() throws Exception {

        String result = mvc
                .perform(get("/registration/getVerificationCode").param("phone", "18180827300")
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
    }

    /**
     * 单独验证手机验证码
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @Test
    public void verifyCode() throws Exception {

        String result = mvc
                .perform(get("/registration/verifyCode").param("phone", "18180827300").param("code", "123456")
                        .contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
        assertEquals(200, responseResult.getCode());
    }
}
