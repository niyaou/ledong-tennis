package com.desay.usersystem.rest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.UserInfoDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.DateUtil;
import com.desay.usersystem.adapter.bean.User;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.security.RsaKeyManager;
import com.desay.usersystem.service.PwdAuthorizeService;
import com.desay.usersystem.utils.Cst;

/**
 * 企业用户注册入口测试工具类
 * 
 * @author uidq1163
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class OrgUserRegisterAdapterTest {
    final static Type type = new TypeReference<ResponseDTO<UserInfoDTO>>() {
    }.getType();
    private MockMvc mvc;
    @Autowired
    protected WebApplicationContext wac;
    @Autowired
    PwdAuthorizeService authRequest;
    String token = "";

    /**
     * 将Base64编码后的公钥转换成PublicKey对象
     * 
     * @param pubStr
     * @return
     * @throws Exception
     */
    public PublicKey string2PublicKey(String pubStr) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(pubStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    @Before()
    public void setup() {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
        // 获取公钥
        String publicKey = Base64.encodeBase64String(RsaKeyManager.getPublicKey());
        // 用户名
        String pwd = "123456";
        // 终端号
        // 本地系统时间yyyyMMddHHmmss+明文密码后用接口getPublicKey所得公钥进行RSA加密，本地时间不能与服务器时间相差2分钟以上
        try {
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(publicKey), decodepwd);
            String result = mvc
                    .perform(post("/pwdAuthorize").header(Cst.HEADER_TOKEN, token).param("username", "huangshouyi")
                            .param("password", decodepwd).param("clientId", "C0201806130001")
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

            ResponseDTO<UserInfoDTO> userInfoDTO = JSON.parseObject(result, type);
            token = userInfoDTO.getData().getToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Autowired
    PangooUserDao pangooUserDao;

    /**
     * 企业用户用户注册接口
     * 
     * @param request
     * @return
     */
    @Test
    public void registration() {
        try {
            PangooUser pangooUser = pangooUserDao.findByUserName("uidq1163");
            if (null != pangooUser) {
                pangooUserDao.delete(pangooUser);
            }
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("uidq1163");
            String pwd = "123456";
            // 获取公钥，对密码进行加密
            String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()), decodepwd);

            user.setPassword(decodepwd);
            user.setTelPhone("18100000000");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/Registration").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 200);
            // 删除插入用户
            pangooUser = pangooUserDao.findByUserName("uidq1163");
            pangooUserDao.delete(pangooUser);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 企业用户用户注册接口:用户已存在
     * 
     * @param request
     * @return
     */
    @Test
    public void registration1() {
        try {
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("huangshouyi");
            String pwd = "123456";
            // 获取公钥，对密码进行加密
            String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()), decodepwd);

            user.setPassword(decodepwd);
            user.setTelPhone("18180827300");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/Registration").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 312);
            assertEquals(responseResult.getMsg(), "用户已存在");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 企业用户用户注册接口:用户密码格式不合法
     * 
     * @param request
     * @return
     */
    @Test
    public void registration2() {
        try {
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("huangshouyi");
            String pwd = "1234561111111111111111";
            user.setPassword(pwd);
            user.setTelPhone("18180827300");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/Registration").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 314);
            assertEquals(responseResult.getMsg(), "用户密码格式不合法");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 企业用户用户注册接口:用户密码格式不合法
     * 
     * @param request
     * @return
     */
    @Test
    public void registration3() {
        try {
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("");
            String pwd = "1234561111111111111111";
            user.setPassword(pwd);
            user.setTelPhone("");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/Registration").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 202);
            assertEquals(responseResult.getMsg(), "参数错误");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加企业管理员入口
     * 
     * @param request
     * @return
     */
    @Test
    public void creatRoot() {
        try {
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("");
            String pwd = "1234561111111111111111";
            user.setPassword(pwd);
            user.setTelPhone("");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/creatRoot").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 202);
            assertEquals(responseResult.getMsg(), "参数错误");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加企业管理员:用户密码格式不合法
     * 
     * @param request
     * @return
     */
    @Test
    public void creatRoot1() {
        try {
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("huangshouyi");
            String pwd = "1234561111111111111111";
            user.setPassword(pwd);
            user.setTelPhone("18180827300");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/creatRoot").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 314);
            assertEquals(responseResult.getMsg(), "用户密码格式不合法");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 企业用户用户注册接口:用户已存在
     * 
     * @param request
     * @return
     */
    @Test
    public void creatRoot2() {
        try {
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("huangshouyi");
            String pwd = "123456";
            // 获取公钥，对密码进行加密
            String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()), decodepwd);

            user.setPassword(decodepwd);
            user.setTelPhone("18180827300");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/creatRoot").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 312);
            assertEquals(responseResult.getMsg(), "用户已存在");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Autowired
    UserRoleDao userRoleDao;

    /**
     * 企业用户用户注册接口
     * 
     * @param request
     * @return
     */
    @Test
    public void creatRoot3() {
        try {
            PangooUser pangooUser = pangooUserDao.findByUserName("uidq1163");
            if (null != pangooUser) {
                pangooUserDao.delete(pangooUser);
            }
            User user = new User();
            user.setEmail("Shouyi.Huang@desay-svautomotive.com");
            user.setLogin("uidq1163");
            String pwd = "123456";
            // 获取公钥，对密码进行加密
            String publicKey = mvc.perform(get("/getPublicKey").accept(MediaType.APPLICATION_OCTET_STREAM))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResultpublicKey = JSON.parseObject(publicKey, ResponseDTO.class);
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + pwd;
            decodepwd = RSAUtils.RSAEncode(string2PublicKey(responseResultpublicKey.getData().toString()), decodepwd);

            user.setPassword(decodepwd);
            user.setTelPhone("18100000000");
            String content = JSON.toJSONString(user);
            String result = mvc
                    .perform(post("/orgRegistration/creatRoot").content(content)
                            .contentType(MediaType.APPLICATION_JSON_UTF8).header(Cst.HEADER_TOKEN, token)
                            .accept(MediaType.APPLICATION_JSON_UTF8))
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
            ResponseDTO<?> responseResult = JSON.parseObject(result, ResponseDTO.class);
            assertEquals(responseResult.getCode(), 200);
            // 删除插入用户
            pangooUser = pangooUserDao.findByUserName("uidq1163");
            userRoleDao.deleteByUserCidAndRoleId(pangooUser.getCid(), "1000");
            pangooUserDao.delete(pangooUser);
            // 删除角色
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
