package com.desay.usersystem.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.MD5Util;
import com.desay.usersystem.dao.OrganizationDao;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.Organization;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.security.SecurityChecker;
import com.desay.usersystem.service.OrgUserRegisterService;

/**
 * 用戶注册实现类
 * 
 * @author uidq1163
 *
 */
@Service
public class OrgUserRegisterServiceImpl extends BaseRegisterServiceImpl implements OrgUserRegisterService {
    @Autowired
    private PangooUserDao pangooUserDao;
    @Autowired
    private OrganizationDao organizationDao;

    public Logger log = Logger.getLogger(OrgUserRegisterServiceImpl.class);

    /**
     * 用戶注册
     * 
     * @param password
     * @param phone
     * @param username
     * @param org
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> registration(String password, String phone, String email, String username, String org) {
        Organization organization = organizationDao.findOne(org);
        if (null == organization) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_ORG_ERROR);
        }
        if (organization.getAuth()) {
            return ResponseDTO.NewErrorResponseDTO("企业自主鉴权不需要注册用户！", ResponseCode.AUTH_ORG_ERROR);
        }
        // 解密
        SecurityChecker securityChecker = checkerEffectiveness(password);
        ResponseDTO<?> responseDTO = checkPreRegister(securityChecker.getPass(), phone, email, username, org);
        if (responseDTO != null) {
            return responseDTO;
        } else {
            PangooUser newUser = new PangooUser();
            // MD5后存入数据库
            newUser.setPassword(MD5Util.md5(password));
            newUser.setLogin(username);
            newUser.setTelPhone(phone);
            newUser.setOrgId(org);
            newUser.setStatus(Boolean.TRUE);
            newUser.setIsManager(Boolean.FALSE);
            newUser.setSourceId("PLATFORM");
            newUser.setUserStatus(Boolean.FALSE);
            newUser.setEmail(email);
            pangooUserDao.save(newUser);
            return ResponseDTO.ResponseDTO("");
        }
    }

    /**
     * 创建管理员
     * 
     * @param password
     * @param phone
     * @param username
     * @param org
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> creatRoot(String password, String phone, String email, String username, String org) {
        SecurityChecker securityChecker = checkerEffectiveness(password);
        if (securityChecker.isSafty()) {
            password = securityChecker.getPass();
        } else {
            return ResponseDTO.NewErrorResponseDTO("密码不合法或者时间戳错误！", ResponseCode.USER_PWD_LEGAL_ERROR);
        }
        ResponseDTO<?> responseDTO = checkPreRegister(password, phone, email, username, org);
        if (responseDTO != null) {
            return responseDTO;
        } else {
            PangooUser newUser = new PangooUser();
            // MD5后存入数据库
            newUser.setPassword(MD5Util.md5(password));
            newUser.setLogin(username);
            newUser.setTelPhone(phone);
            newUser.setOrgId(org);
            newUser.setUserStatus(Boolean.TRUE);
            newUser.setStatus(Boolean.TRUE);
            newUser.setIsManager(Boolean.FALSE);
            newUser.setSourceId("PLATFORM");
            newUser.setEmail(email);
            pangooUserDao.save(newUser);
            return ResponseDTO.ResponseDTO("");
        }
    }
}
