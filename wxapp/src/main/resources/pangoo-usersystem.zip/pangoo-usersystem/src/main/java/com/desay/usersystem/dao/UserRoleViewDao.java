package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.UserRoleView;

/**
 * 用户角色视图
 * 
 * @author uidq1163
 *
 */
public interface UserRoleViewDao extends JpaRepository<UserRoleView, String>, JpaSpecificationExecutor<UserRoleView> {
    /**
     * 根据登录名和组织机构查询用户角色信息
     * 
     * @param login
     * @param org
     * @return
     */
    @Query("select t from UserRoleView t where (t.login = :login or t.telPhone=:login) and t.orgId=:org")
    List<UserRoleView> findByUserName(@Param("login") String login, @Param("org") String org);

    /**
     * 根据登录名和普通组织机构（normal）查询用户角色信息
     * 
     * @param login
     * @return
     */
    @Query("select t from UserRoleView t where (t.login = :login or t.telPhone=:login) and t.orgId = 'normal'")
    List<UserRoleView> findByUserName(@Param("login") String login);
}
