package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.UserRole;

/**
 * 用户角色关系表
 * 
 * @author uidq1163
 *
 */
public interface UserRoleDao extends JpaRepository<UserRole, String>, JpaSpecificationExecutor<UserRole> {

    /**
     * 根据用户ID和角色ID删除用户对应权限
     * 
     * @param userCid
     * @param roleId
     */
    @Modifying
    @Query("delete from UserRole t where t.userCid = :user_cid and  t.roleId=:role_id")
    void deleteByUserCidAndRoleId(@Param("user_cid") String userCid, @Param("role_id") String roleId);

    /**
     * 根据用户，角色ID查询该用户是否设置角色信息
     * 
     * @param userCid
     * @param roleId
     * @return
     */
    UserRole findByUserCidAndRoleId(String userCid, String roleId);

    /**
     * 删除用户角色信息
     * 
     * @param userCid
     */
    @Modifying
    @Query("delete from UserRole t where t.userCid = :user_cid")
    void deleteByUserCid(@Param("user_cid") String userCid);

    /**
     * 根据角色ID删除用户对应权限
     * 
     * @param roleId
     */
    @Modifying
    @Query("delete from UserRole t where t.roleId=:roleId")
    void deleteByRoleId(@Param("roleId") String roleId);

    /**
     * 根据登录名和组织机构查询用户角色信息
     * 
     * @param userCid
     * @return
     */
    @Query("select t from UserRole t where t.userCid=:userCid")
    List<UserRole> findByUserCid(@Param("userCid") String userCid);

    /**
     * 根据角色ID查询用户角色信息
     * 
     * @param userCid
     * @return
     */
    @Query("select t from UserRole t where t.roleId=:roleId")
    List<UserRole> findByRoleId(@Param("roleId") String roleId);
}
