package com.desay.usersystem.adapter.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 用户对象
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = "user对象", description = "用户对象user")
public class User {
    @ApiModelProperty(value = "用户名", name = "login", example = "xingguo", required = true)
    String login;
    @ApiModelProperty(value = "电话", name = "telPhone", example = "xingguo@163.com", required = true)
    String telPhone;
    @ApiModelProperty(value = "邮箱", name = "email", example = "xingguo@163.com")
    String email;
    @ApiModelProperty(value = "用户名", name = "password", example = "xingguo", required = true)
    String password;
    @ApiModelProperty(value = "短信验证码,企业用户注册无需填写", name = "org", example = "951741")
    String verifyCode;
    @ApiModelProperty(value = "", name = "平台类型标识", example = "NV5087")
    String sourceId;
    @ApiModelProperty(value = "", name = "企业域名", example = "V01")
    String org;

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getTelPhone() {
        return telPhone;
    }

    public void setTelPhone(String telPhone) {
        this.telPhone = telPhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }
}
