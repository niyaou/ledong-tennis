package com.desay.usersystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.usersystem.entity.ClientInfo;

/**
 * 客户端配置信息dao
 * @author uidq1163
 *
 */
public interface ClientDao extends JpaRepository<ClientInfo, String>, JpaSpecificationExecutor<ClientInfo> {

}
