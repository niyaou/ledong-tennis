package com.desay.usersystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.usersystem.entity.AccountTag;

/**
 * 账户标识
 * 
 * @author uidq1163
 *
 */
public interface AccountTagDao extends JpaRepository<AccountTag, String>, JpaSpecificationExecutor<AccountTag> {

}
