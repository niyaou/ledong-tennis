package com.desay.usersystem.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.MD5Util;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.security.SecurityChecker;
import com.desay.usersystem.service.UserInfoService;

/**
 * 用戶信息
 * 
 * @author uidq1163
 *
 */
@Service
public class UserInfoServiceImpl extends BaseRegisterServiceImpl implements UserInfoService {
    @Autowired
    PangooUserDao pangooUserDao;

    /**
     * 修改用户密码
     * 
     * @param cid
     *            用户cid
     * @param npwd
     *            新密码
     * @param opwd
     *            老密码
     * @return
     */
    @Override
    public ResponseDTO<?> changePassword(String cid, String npwd, String opwd) {
        PangooUser user = pangooUserDao.findOne(cid);
        if (user == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_USER_ERROR);
        }
        SecurityChecker nChecker = checkerEffectiveness(npwd);
        SecurityChecker oChecker = checkerEffectiveness(opwd);
        if (nChecker.isSafty() && oChecker.isSafty()) {
            if (oChecker.checkPass(user.getPassword())) {
                String t = nChecker.getPass();
                user.setPassword(MD5Util.md5(t));
                pangooUserDao.save(user);
                return ResponseDTO.ResponseDTO("");
            } else {
                return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_PWD_ERROR);
            }
        } else {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_PWD_LEGAL_ERROR);
        }
    }
}
