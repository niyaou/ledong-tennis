package com.desay.usersystem.rest;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.PermissionDTO;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.DTO.TokenPermission;
import com.desay.cd.utils.DateUtil;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.dao.SecretKeyDao;
import com.desay.usersystem.entity.Permission;
import com.desay.usersystem.entity.SecretKey;
import com.desay.usersystem.service.TokenAuthorizeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/***
 * 用户token认证
 * 
 * @author uidq1163
 *
 */
@RestController
@Api(tags = "用户token认证")
public class TokenAuthController {
    @Autowired
    TokenAuthorizeService tokenAuthorizeImp;
    @Autowired
    SecretKeyDao secretKeyDao;
    @Resource
    RedisTemplate<String, Object> redisTemplate;

    @ApiOperation(value = "用户token身份认证接口", notes = "认证用户token。返回用户token信息。用户CID，角色，机构代码，登录的 端", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "token", value = "登录后获取到的token", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/tokenAuthorize", method = RequestMethod.GET)
    public Object tokenAuthorize(HttpServletRequest request,
            @RequestParam(value = "token", required = true) String token) {
        TokenDTO tokenDTO = tokenAuthorizeImp.tokenAuthorize(token);
        if (tokenDTO == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR));
        }
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(tokenDTO));
    }

    @ApiOperation(value = "用户token身份认证接口，同时会返回角色权限", notes = "认证用户token。返回用户token信息。用户CID，角色，机构代码，登录的 端，权限列表", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "token", value = "登录后获取到的token", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/tokenPermission", method = RequestMethod.GET)
    public Object tokenPermission(HttpServletRequest request,
            @RequestParam(value = "token", required = true) String token) {
        TokenPermission tokenDTO = tokenAuthorizeImp.tokenPermission(token);
        if (tokenDTO == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR));
        }
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(tokenDTO));
    }

    @ApiOperation(value = "三方接口认证", notes = "认证secret_key。获取权限列表", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "secret_key", value = "三方认证秘钥", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/tokenSecret", method = RequestMethod.GET)
    public Object secretKeyPermission(HttpServletRequest request,
            @RequestParam(value = "secret_key", required = true) String key) {
        List<PermissionDTO> permissionDTOlist = new ArrayList<>();
        SecretKey logIn = (SecretKey) redisTemplate.opsForValue().get(key);
        if (null == logIn) {
            SecretKey secretKey = secretKeyDao.findOne(key);
            if (null == secretKey) {
                return JsonResponseEntity
                        .instatnce(ResponseDTO.NewErrorResponseDTO("secret_key无效", ResponseCode.ERROR));
            }
            try {
                Long day = DateUtil.daysBetween(new Date(), secretKey.getExpireTime());
                if (day < 0) {
                    return JsonResponseEntity
                            .instatnce(ResponseDTO.NewErrorResponseDTO("secret_key已经过期", ResponseCode.ERROR));
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if (CollectionUtils.isEmpty(secretKey.getPermissionlist())) {
                return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PERMISSION_ERROR));
            }

            PermissionDTO permissionDTO = null;
            List<Permission> list = new ArrayList<>(secretKey.getPermissionlist());
            for (Permission rolePermissionView : list) {
                permissionDTO = new PermissionDTO();
                BeanUtils.copyProperties(rolePermissionView, permissionDTO);
                permissionDTOlist.add(permissionDTO);
            }
            // 设置有效时间为24
            secretKey.setAccess(1);
            redisTemplate.opsForValue().set(key, secretKey, 24, TimeUnit.HOURS);
        } else {
            PermissionDTO permissionDTO = null;
            // List<Permission> list = new ArrayList<>(logIn.getPermissionlist());
            Set<Permission> list = logIn.getPermissionlist();
            for (Permission rolePermissionView : list) {
                permissionDTO = new PermissionDTO();
                BeanUtils.copyProperties(rolePermissionView, permissionDTO);
                permissionDTOlist.add(permissionDTO);
            }
            logIn.setAccess(logIn.getAccess() + 1);
            if (null != logIn.getAccessCountDay()) {
                if (logIn.getAccess() > logIn.getAccessCountDay()) {
                    return JsonResponseEntity
                            .instatnce(ResponseDTO.NewErrorResponseDTO("当日访问次数超过最大限制", ResponseCode.ERROR));
                }
            }
            redisTemplate.opsForValue().setIfAbsent(key, logIn);
        }

        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(permissionDTOlist));
    }
}
