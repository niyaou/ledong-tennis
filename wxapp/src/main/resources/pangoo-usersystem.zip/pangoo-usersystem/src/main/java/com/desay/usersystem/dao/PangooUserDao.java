package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.PangooUser;

/**
 * 用户dao
 * 
 * @author uidq1163
 *
 */
public interface PangooUserDao extends JpaRepository<PangooUser, String>, JpaSpecificationExecutor<PangooUser> {
    /**
     * 通过用户名称：默认平台用户
     * 
     * @param login
     * @return
     */
    @Query("select t from PangooUser t where (t.login = :login or t.email=:login or t.telPhone=:login) and t.orgId='normal'")
    PangooUser findByUserName(@Param("login") String login);

    /**
     * 默认西威域名
     * 
     * @param login
     * @return
     */
    @Query("select t from PangooUser t where (t.login = :login or t.email=:login or t.telPhone=:login) and t.orgId='v01'")
    PangooUser findByUserNameOther(@Param("login") String login);

    /**
     * 通过用户名称和组织机构ID
     * 
     * @param login
     * @return
     */
    @Query("select t from PangooUser t where (t.login = :login or t.email=:login or t.telPhone=:login) and t.orgId =:orgId")
    PangooUser findByUserNameAndOrg(@Param("login") String login, @Param("orgId") String orgId);

    /**
     * 判断用户是否存在
     * 
     * @param phone
     * @param login
     * @return
     */
    @Query("select t from PangooUser t where (t.login = :login or t.email=:login or t.telPhone=:phone) and t.orgId = 'normal'")
    PangooUser exist(@Param("phone") String phone, @Param("login") String login);

    /**
     * 获取机构管理员
     * 
     * @param orgId
     * @return
     */
    @Query("select t from PangooUser t where t.isManager =true and t.orgId =:orgId")
    List<PangooUser> getOrgManager(@Param("orgId") String orgId);

    /**
     * 判断用户是否存在
     * 
     * @param phone
     * @param login
     * @param email
     * @param orgId
     * @return
     */
    @Query("select t from PangooUser t where (t.login = :login or t.email=:email or t.telPhone=:phone) and t.orgId =:orgId")
    PangooUser exist(@Param("phone") String phone, @Param("login") String login, @Param("email") String email,
            @Param("orgId") String orgId);

    /**
     * 判断用户是否存在
     * 
     * @param phone
     * @param login
     * @param orgId
     * @return
     */
    @Query("select t from PangooUser t where (t.login = :login or t.telPhone=:phone) and t.orgId =:orgId")
    PangooUser exist(@Param("phone") String phone, @Param("login") String login, @Param("orgId") String orgId);
}
