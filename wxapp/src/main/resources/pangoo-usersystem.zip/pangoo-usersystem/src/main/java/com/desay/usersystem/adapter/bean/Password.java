package com.desay.usersystem.adapter.bean;

import io.swagger.annotations.ApiModel;

/**
 * 密码实体
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = "修改密码对象", description = "用于密码修改")
public class Password {
    String newPassword;
    String oldPassword;

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }
}
