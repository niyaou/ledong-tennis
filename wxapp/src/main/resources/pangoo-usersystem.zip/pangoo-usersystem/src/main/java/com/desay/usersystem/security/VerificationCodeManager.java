package com.desay.usersystem.security;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.utils.Cst;

/**
 * 验证码管理器
 * 
 * @author uidq1163
 *
 */
@Component
public class VerificationCodeManager {
    @Resource
    RedisTemplate<String, String> redisTemplate;

    /**
     * 获取并发送验证码
     * 
     * @param phone
     * @return
     */
    public String getVerificationCode(String phone) {
        String text = RandomStringUtils.random(5, "1234567890");
        // 设置验证有效时间为一分钟
        redisTemplate.opsForValue().set(phone, text, Cst.SECONDS, TimeUnit.SECONDS);
        return text;
    }

    /**
     * 检验验证码
     * 
     * @param phone
     * @return
     */
    public boolean checkVerificationCode(String code, String phone) {
        String text = redisTemplate.opsForValue().get(phone);
        // 手机验证码没有失效
        if (StringUtil.isNotEmpty(text)) {
            if (text.equals(code)) {
                return true;
            }
        }
        return true;
    }
}
