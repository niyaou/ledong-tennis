package com.desay.usersystem.service.impl;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.session.ExpiringSession;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.stereotype.Service;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.usersystem.security.RsaKeyManager;
import com.desay.usersystem.service.SecurityAdapterService;

/**
 * 密码认证实现类
 * 
 * @author uidq1163
 *
 */
@Service
public class SecurityAdapterServiceImpl implements SecurityAdapterService {
    @SuppressWarnings("rawtypes")
    @Autowired
    private FindByIndexNameSessionRepository findByIndexNameSessionRepository;
    @Autowired
    RsaKeyManager rsaKeyManager;
    @Resource
    RedisTemplate<String, ExpiringSession> redisTemplate;

    @SuppressWarnings("unchecked")
    @Override
    public ResponseDTO<?> uploadAESKey(String token, String key) {
        if (TextUtils.isEmpty(key)) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AES_EMPTY_ERROR);
        }
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        if (session == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR);
        } else {
            key = rsaKeyManager.clusterDecode(key);
            if (!TextUtils.isEmpty(key)) {
                session.setAttribute(AuthorizeBase.AES_KEY, key);
                findByIndexNameSessionRepository.save(session);
                return ResponseDTO.ResponseDTO("");
            } else {
                return ResponseDTO.NewErrorResponseDTO(ResponseCode.AES_PWD_ERROR);
            }
        }
    }

    /**
     * 单独针对集群并发的
     * 
     * @param token
     * @param key
     * @return
     */
    @Override
    public ResponseDTO<?> uploadAESKeyNetty(String token, String key) {
        if (TextUtils.isEmpty(key)) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AES_EMPTY_ERROR);
        }
        ExpiringSession session = redisTemplate.opsForValue().get(token);
        if (session == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR);
        } else {
            key = rsaKeyManager.clusterDecode(key);
            if (!TextUtils.isEmpty(key)) {
                session.setAttribute(AuthorizeBase.AES_KEY, key);
                try {
                    redisTemplate.opsForValue().set(session.getId(), session, 60 * 30, TimeUnit.SECONDS);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return ResponseDTO.ResponseDTO("");
            } else {
                return ResponseDTO.NewErrorResponseDTO(ResponseCode.AES_PWD_ERROR);
            }
        }
    }
}
