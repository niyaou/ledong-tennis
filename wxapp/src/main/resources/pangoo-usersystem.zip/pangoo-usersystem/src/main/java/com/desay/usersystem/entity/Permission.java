package com.desay.usersystem.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * 权限表
 * 
 * @author uidq1163
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "permission_info")
public class Permission implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 4266644157679477105L;
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    @Column(name = "permission_id")
    private String permissionId;
    /** 上级主键ID */
    @Column(name = "parent_id")
    private String parentId;
    @Column(name = "permission_name")
    private String name;
    @Column(name = "org_id")
    private String orgId;
    @Column(name = "method")
    private String method;
    @Column(name = "descs")
    private String descs;
    /** 权限类型：1接口 2页面 */
    @Column(name = "type", columnDefinition = "varchar COMMENT '权限类型：1接口 2页面'")
    private String type;
    @CreatedDate
    @Column(name = "create_time", nullable = false, insertable = true, updatable = false, columnDefinition = "datetime COMMENT '创建时间'")
    private Date createTime;
    @LastModifiedDate
    @Column(name = "update_time", insertable = true, updatable = true, columnDefinition = "datetime COMMENT '更新时间'")
    private Date updateTime;

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getDescs() {
        return descs;
    }

    public void setDescs(String descs) {
        this.descs = descs;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
