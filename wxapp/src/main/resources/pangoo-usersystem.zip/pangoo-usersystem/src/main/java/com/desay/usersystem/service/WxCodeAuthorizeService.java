package com.desay.usersystem.service;

import javax.servlet.http.HttpSession;

import com.desay.cd.DTO.ResponseDTO;

/**
 * 微信认证
 * 
 * @author uidq1163
 *
 */
public interface WxCodeAuthorizeService {

    /**
     * 微信认证
     * 
     * @param code
     * @param session
     * @return
     */
    public ResponseDTO<?> codeAuthorize(String code, HttpSession session);

}
