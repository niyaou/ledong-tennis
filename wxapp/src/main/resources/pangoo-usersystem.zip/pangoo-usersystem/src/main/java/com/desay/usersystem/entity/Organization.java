package com.desay.usersystem.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * 组织机构
 * 
 * @author uidq1163
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "organization_info")
public class Organization {
    @Id
    @Column(name = "org_id")
    private String orgId;
    @Column(name = "org_name", nullable = false)
    private String name;
    @Column(name = "parent_id", nullable = true)
    private String parentId;
    /** 否用当前认证系统：true 是 false 否 */
    @Column(name = "auth", nullable = false)
    private Boolean auth;
    /** 发起认证请求类型 */
    @Column(name = "auth_type", nullable = true)
    private String authType;
    @Column(name = "auth_url")
    private String authUrl;
    @Column(name = "auth_params")
    private String authParams;
    @Column(name = "remake")
    private String remake;
    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time", nullable = false, insertable = true, updatable = false, columnDefinition = "datetime COMMENT '创建时间'")
    private Date createTime;
    /** 更新时间 */
    @LastModifiedDate
    @Column(name = "update_time", nullable = false, insertable = true, updatable = true, columnDefinition = "datetime COMMENT '更新时间'")
    private Date updateTime;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Boolean getAuth() {
        return auth;
    }

    public void setAuth(Boolean auth) {
        this.auth = auth;
    }

    public String getAuthUrl() {
        return authUrl;
    }

    public void setAuthUrl(String authUrl) {
        this.authUrl = authUrl;
    }

    public String getAuthParams() {
        return authParams;
    }

    public void setAuthParams(String authParams) {
        this.authParams = authParams;
    }

    public String getRemake() {
        return remake;
    }

    public void setRemake(String remake) {
        this.remake = remake;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
