package com.desay.usersystem.rest;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.OrgBean;
import com.desay.usersystem.dao.OrgUserViewDao;
import com.desay.usersystem.dao.RoleDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.entity.OrgUserView;
import com.desay.usersystem.entity.Role;
import com.desay.usersystem.entity.UserRole;
import com.desay.usersystem.service.OrgService;
import com.desay.usersystem.utils.Cst;
import com.desay.usersystem.utils.PageUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 用于企业工厂等机构角色管理
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/org")
@Api(tags = "用于企业工厂等机构管理")
public class OrgController {
    @Autowired
    private OrgService orgImpl;
    @Autowired
    private OrgUserViewDao orgUserViewDao;
    @Autowired
    private UserRoleDao userRoleDao;
    @Autowired
    private RoleDao roleDao;

    /**
     * 获取企业角色
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "增加企业", notes = "超级管理创建企业信息", httpMethod = "POST")
    @RequestMapping(value = "/addOrg", method = RequestMethod.POST)
    public ResponseDTO<?> addOrg(HttpServletRequest request, @RequestBody OrgBean orgBean) {
        ResponseDTO<?> response = orgImpl.creatOrg(orgBean, request.getAttribute(Cst.ATTRIBUTE_ORG).toString());
        return response;
    }

    @ApiOperation(value = "企业浏览", notes = "超级管理浏览企业信息", httpMethod = "GET")
    @RequestMapping(value = "/orgExplore", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public ResponseDTO<?> orgExplore(HttpServletRequest request,
            @RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize) {
        String org = (String) request.getAttribute(Cst.ATTRIBUTE_ORG);
        return orgImpl.exploreOrg(org, pageNo, pageSize);
    }

    @ApiOperation(value = "企业用户浏览", notes = "超级管理浏览企业用户信息", httpMethod = "GET")
    @RequestMapping(value = "/orgUserExplore", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "orgId", value = "企业id", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "isManager", value = "成员权限，管理员为1，普通用户为0，若不输入，则查询所有成员", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public ResponseDTO<?> orgUserExplore(HttpServletRequest request,
            @RequestParam(value = "orgId", required = true) String orgId,
            @RequestParam(value = "isManager", required = false) String isManager,
            @RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize) {
        return orgImpl.exploreOrgUser(orgId, isManager, pageNo, pageSize);
    }

    @ApiOperation(value = "企业管理员浏览", notes = "管理员浏览下属企业管理员", httpMethod = "GET")
    @RequestMapping(value = "/orgMangerExplore", method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    public ResponseDTO<?> orgMangerExplore(HttpServletRequest request,
            @RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize) {
        Object org = request.getAttribute(Cst.ATTRIBUTE_ORG);
        int[] pageParams = PageUtil.creagePageAbleParams(pageNo, pageSize);
        Pageable pageable = new PageRequest(pageParams[0], pageParams[1]);
        Page<OrgUserView> result = orgUserViewDao.findByParentIdAndIsManager(String.valueOf(org), "1", pageable);
        for (OrgUserView orgUserView : result.getContent()) {
            List<UserRole> list = userRoleDao.findByUserCid(orgUserView.getCid());
            List<String> roleIds = new ArrayList<>();
            for (UserRole userRole : list) {
                Role Role = roleDao.findOne(userRole.getRoleId());
                if (StringUtil.isNotEmpty(Role.getParentId())) {
                    roleIds.add(Role.getParentId());
                }
            }
            orgUserView.setRoleList(roleIds);
        }
        return ResponseDTO.ResponseDTO(result);
    }

}
