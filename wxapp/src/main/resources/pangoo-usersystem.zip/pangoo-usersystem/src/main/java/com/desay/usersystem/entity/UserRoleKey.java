package com.desay.usersystem.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * 用户角色联合主键类
 * 
 * @author uidq1163
 *
 */
@Embeddable
public class UserRoleKey implements Serializable {

    private static final long serialVersionUID = 4608711704289320213L;
    private String userCid;
    private String roleId;

    public String getUserCid() {
        return userCid;
    }

    public void setUserCid(String userCid) {
        this.userCid = userCid;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

}