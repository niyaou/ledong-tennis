package com.desay.usersystem.adapter.httpentity;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.google.gson.Gson;

/**
 * 
 * @author uidq1163
 *
 */
public class JsonResponseEntity {
	static Gson gs = new Gson();

	/**
	 * 生成返回http json p数据包
	 * 
	 * @param obj
	 * @return
	 */
	public static ResponseEntity<?> instatnce(Object obj) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		String body = gs.toJson(obj);
		return new ResponseEntity<Object>(body, headers, HttpStatus.OK);
	}

	/**
	 * @param status
	 * @return
	 */
	public static ResponseEntity<?> instatnce(HttpStatus status) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_PLAIN);
		return new ResponseEntity<Object>("", headers, status);
	}
}
