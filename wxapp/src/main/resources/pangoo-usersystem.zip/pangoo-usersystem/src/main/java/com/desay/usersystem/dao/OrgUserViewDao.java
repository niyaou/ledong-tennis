package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.OrgUserView;

/**
 * 用户角色权限
 * 
 * @author uidq1163
 *
 */
public interface OrgUserViewDao extends JpaRepository<OrgUserView, String>, JpaSpecificationExecutor<OrgUserView> {

    /**
     * 根据企业查询对应用户
     * 
     * @param orgId
     * @return
     */
    @Query("select t from OrgUserView t where t.orgId = :orgId")
    List<OrgUserView> getOrgUserView(@Param("orgId") String orgId);

    /**
     * 根据企业id查询成员
     * 
     * @param orgId
     * @param pageable
     * @return
     */
    Page<OrgUserView> findByOrgId(String orgId, Pageable pageable);

    /**
     * 根据企业id和成员权限查询成员
     * 
     * @param orgId
     * @param isManager
     * @param pageable
     * @return
     */
    Page<OrgUserView> findByOrgIdAndIsManager(String orgId, String isManager, Pageable pageable);

    /**
     * 
     * @param orgId
     * @param parentId
     * @param isManager
     * @param pageable
     * @return
     */
    Page<OrgUserView> findByParentIdAndIsManager(String parentId, String isManager, Pageable pageable);
}
