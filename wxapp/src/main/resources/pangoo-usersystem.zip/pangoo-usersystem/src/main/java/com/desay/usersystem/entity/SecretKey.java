package com.desay.usersystem.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * 项目管理
 * 
 * @author uidq1163
 *
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "secret_key", uniqueConstraints = { @UniqueConstraint(columnNames = { "name" }) })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "key")
public class SecretKey implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1663488244405455108L;
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    @Column(name = "secret_key", nullable = false, length = 36, columnDefinition = "varchar(36) COMMENT 'key'")
    private String key;
    @Column(name = "name", nullable = false, columnDefinition = "varchar(100) COMMENT '对应外部服务名称'")
    private String name;
    @Column(name = "expire_time", nullable = false, columnDefinition = "date COMMENT '有效截止时间'")
    private Date expireTime;
    @Column(name = "access", nullable = false, columnDefinition = "int COMMENT '访问次数'")
    private Integer access = 0;
    @Column(name = "access_count_day", nullable = true, columnDefinition = "int COMMENT '访问次数限制（每天）'")
    private Integer accessCountDay;
    @Column(name = "access_count", nullable = true, columnDefinition = "int COMMENT '访问次数限制总共'")
    private Integer accessCount;
    /** 权限 */
    @ManyToMany
    @JoinTable(name = "secret_permission", joinColumns = { @JoinColumn(name = "secret_key") }, inverseJoinColumns = {
            @JoinColumn(name = "permission_id") })
    private Set<Permission> permissionlist;
    /** 创建时间 */
    @CreatedDate
    @Column(name = "create_time", nullable = false, insertable = true, updatable = false, columnDefinition = "datetime COMMENT '创建时间'")
    private Date createTime;
    /** 更新时间 */
    @LastModifiedDate
    @Column(name = "update_time", insertable = false, updatable = true, columnDefinition = "datetime COMMENT '更新时间'")
    private Date updateTime;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }

    public Set<Permission> getPermissionlist() {
        return permissionlist;
    }

    public void setPermissionlist(Set<Permission> permissionlist) {
        this.permissionlist = permissionlist;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getAccess() {
        return access;
    }

    public void setAccess(Integer access) {
        this.access = access;
    }

    public Integer getAccessCountDay() {
        return accessCountDay;
    }

    public void setAccessCountDay(Integer accessCountDay) {
        this.accessCountDay = accessCountDay;
    }

    public Integer getAccessCount() {
        return accessCount;
    }

    public void setAccessCount(Integer accessCount) {
        this.accessCount = accessCount;
    }
}
