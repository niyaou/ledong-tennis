package com.desay.usersystem.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * 
 * @author uidq1163
 *
 */
@Embeddable
public class PermRoleKey implements Serializable {

    private static final long serialVersionUID = -3304319243957837925L;
    private String permissionId;
    private String roleId;

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof PermRoleKey) {
            PermRoleKey key = (PermRoleKey) o;
            if (this.roleId.equals(key.getPermissionId()) && this.permissionId.equals(key.permissionId)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (roleId + permissionId).hashCode();
    }

}