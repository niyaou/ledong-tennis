package com.desay.usersystem.service;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.usersystem.adapter.bean.OrgBean;

/**
 * 组织结构角色权限管理实现
 * 
 * @author uidq1163
 *
 */
public interface OrgService {

    /**
     * 创建机构
     * 
     * @param orgBean
     * @param parentId
     * @return
     */
    public ResponseDTO<?> creatOrg(OrgBean orgBean, String parentId);

    /**
     * 刪除机构
     * 
     * @param org
     * @return
     */
    public ResponseDTO<?> delOrg(String org);

    /**
     * 分页浏览机构
     * 
     * @param pageNo
     * @param pageSize
     * @return
     */
    public ResponseDTO<?> exploreOrg(String org, String pageNo, String pageSize);

    /**
     * 分页浏览机构成员
     * 
     * @param orgId
     * @param isManager
     * @param pageNo
     * @param pageSize
     * @return
     */
    public ResponseDTO<?> exploreOrgUser(String orgId, String isManager, String pageNo, String pageSize);

    /**
     * 添加企业成员
     * 
     * @param orgId
     * @param isManager
     * @param userName
     * @return
     */
    public ResponseDTO<?> addOrgMember(String orgId, Boolean isManager, String userName);

}
