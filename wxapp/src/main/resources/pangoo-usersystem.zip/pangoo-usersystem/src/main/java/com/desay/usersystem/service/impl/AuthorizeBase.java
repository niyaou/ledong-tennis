package com.desay.usersystem.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.http.util.TextUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.session.ExpiringSession;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;

import com.desay.cd.DTO.PermissionDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.utils.CollectionUtil;
import com.desay.usersystem.adapter.bean.LogInError;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.dao.RolePermissionViewDao;
import com.desay.usersystem.dao.SecretDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.dao.UserRoleViewDao;
import com.desay.usersystem.entity.ClientInfo;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.entity.RolePermissionView;
import com.desay.usersystem.entity.UserRole;
import com.desay.usersystem.entity.UserRoleView;
import com.desay.usersystem.security.AesKeyManager;
import com.desay.usersystem.security.SecurityChecker;
import com.desay.usersystem.security.VerificationCodeManager;
import com.desay.usersystem.utils.Cst;

/**
 * 用户认证实现基类
 * 
 * @author uidq1163
 *
 */
public class AuthorizeBase {
    public static final String AES_KEY = "AES_KEY";
    @Value("${authorize.max}")
    int maxLogTimes;
    @Autowired
    SecretDao secretDao;
    @Autowired
    VerificationCodeManager verificationCodeManager;
    @Autowired
    UserRoleViewDao userRoleViewDao;
    @Autowired
    PangooUserDao pangooUserDao;
    @Autowired
    RolePermissionViewDao permissionDao;
    @SuppressWarnings("rawtypes")
    @Autowired
    FindByIndexNameSessionRepository findByIndexNameSessionRepository;
    @Resource
    RedisTemplate<String, ExpiringSession> redisTemplate;
    @Resource
    RedisTemplate<String, Object> redisTemplateLogIn;
    @Resource
    RedisTemplate<String, String> redisTemplateNetty;
    @Autowired
    UserRoleDao userRoleDao;

    /**
     * 处理重复登录，无效化操作
     *
     * @param cid
     * @param client
     */
    public void invalidMultiLogin(String cid, String client) {
        TokenDTO token = findTokenDTO(cid, client);
        if (token != null) {
            findByIndexNameSessionRepository.delete(token.token);
        }
    }

    /**
     * 判断用户在当前终端是否登录
     *
     * @param cid
     * @param client
     * @return
     */
    @SuppressWarnings("unchecked")
    public TokenDTO findTokenDTO(String cid, String client) {
        Map<String, Session> sessions = findByIndexNameSessionRepository
                .findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, cid);
        TokenDTO tokenDTO = null;
        for (Map.Entry<String, Session> entry : sessions.entrySet()) {
            Session s = entry.getValue();
            tokenDTO = (TokenDTO) s.getAttribute(ConstantUtils.SESSION_TOKEN);
            if (tokenDTO != null) {
                if (tokenDTO.cid.equals(cid) && tokenDTO.client.equals(client)) {
                    return tokenDTO;
                }
            }
        }
        return tokenDTO;
    }

    /**
     * 创建回话
     *
     * @param session
     * @param client
     * @param info
     * @return
     */
    public HttpSession createSession(HttpSession session, ClientInfo client, PangooUser info) {
        // 后期用于账户多平台同时登录管理
        session.setAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, info.getCid());
        if (!TextUtils.isBlank(client.getClientId())) {
            TokenDTO token = new TokenDTO();
            token.client = client.getClientId();
            token.cid = info.getCid();
            token.token = session.getId();
            token.orgId = info.getOrgId();
            token.login = info.getLogin();
            session.setAttribute(ConstantUtils.SESSION_TOKEN, token);
            session.setAttribute(AES_KEY, AesKeyManager.creatKey());
            info.setToken(token.token);
            // 用户权限
            List<UserRole> usrRoles = userRoleDao.findByUserCid(info.getCid());
            if (CollectionUtil.isNotEmpty(usrRoles)) {
                List<PermissionDTO> permissionDTOlist = new ArrayList<>();
                for (UserRole userRole : usrRoles) {
                    List<RolePermissionView> list = permissionDao.getRolePermission(userRole.getRoleId());
                    PermissionDTO permissionDTO = null;
                    for (RolePermissionView rolePermissionView : list) {
                        permissionDTO = new PermissionDTO();
                        BeanUtils.copyProperties(rolePermissionView, permissionDTO);
                        permissionDTOlist.add(permissionDTO);
                    }
                }
                if (CollectionUtil.isNotEmpty(permissionDTOlist)) {
                    session.setAttribute(Cst.SESSION_PERMISSIOM, permissionDTOlist);
                }
            }
        }
        session.setMaxInactiveInterval(client.getSessionTime());
        return session;
    }

    /**
     * 创建回话
     *
     * @param session
     * @param client
     * @param info
     * @return
     * @throws Exception
     * @throws IllegalAccessException
     */
    public void createSession(ExpiringSession session, String clientId, PangooUser info)
            throws IllegalAccessException, Exception {
        // 后期用于账户多平台同时登录管理
        TokenDTO token = new TokenDTO();
        token.cid = info.getCid();
        token.token = session.getId();
        token.orgId = info.getOrgId();
        token.login = info.getLogin();
        token.client = clientId;
        session.setAttribute(ConstantUtils.SESSION_TOKEN, token);
        session.setAttribute(AES_KEY, AesKeyManager.creatKey());
        info.setToken(token.token);
        // 向redis里存入数据和设置缓存时间
        redisTemplate.opsForValue().set(session.getId(), session, 60 * 30, TimeUnit.SECONDS);
        redisTemplateNetty.opsForValue().set(info.getCid() + clientId, session.getId(), 60 * 30, TimeUnit.SECONDS);
    }

    /**
     * 创建LDAP回话
     *
     * @param session
     * @param client
     * @param info
     * @return
     */
    public HttpSession createLdapSession(HttpSession session, ClientInfo client, UserRoleView info) {
        // 后期用于账户多平台同时登录管理
        session.setAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, info.getCid());
        if (!TextUtils.isBlank(client.getClientId())) {
            TokenDTO token = new TokenDTO();
            token.client = client.getClientId();
            token.login = info.getLogin();
            token.cid = info.getCid();
            token.token = session.getId();
            token.orgId = info.getOrgId();
            session.setAttribute(ConstantUtils.SESSION_TOKEN, token);
            session.setAttribute(AES_KEY, AesKeyManager.creatKey());
            info.setToken(token.token);
            // 用户权限
            List<UserRole> usrRoles = userRoleDao.findByUserCid(info.getCid());
            if (CollectionUtil.isNotEmpty(usrRoles)) {
                List<PermissionDTO> permissionDTOlist = new ArrayList<>();
                for (UserRole userRole : usrRoles) {
                    List<RolePermissionView> list = permissionDao.getRolePermission(userRole.getRoleId());
                    PermissionDTO permissionDTO = null;
                    for (RolePermissionView rolePermissionView : list) {
                        permissionDTO = new PermissionDTO();
                        BeanUtils.copyProperties(rolePermissionView, permissionDTO);
                        permissionDTOlist.add(permissionDTO);
                    }
                }
                if (CollectionUtil.isNotEmpty(permissionDTOlist)) {
                    session.setAttribute(Cst.SESSION_PERMISSIOM, permissionDTOlist);
                }
            }
        }
        session.setMaxInactiveInterval(client.getSessionTime());
        return session;
    }

    /**
     * 判断加密密码是否合法
     *
     * @param passwd
     * @param clientId
     * @return
     */
    public SecurityChecker checkerEffectiveness(String passwd, String clientId) {
        SecurityChecker checker = new SecurityChecker();
        return checker.decodeDES(passwd).checkTime();
    }

    /**
     * 判断加密密码是否合法
     * 
     * @param passwd
     * @return
     */
    public SecurityChecker checkerEffectiveness(String passwd) {
        SecurityChecker checker = new SecurityChecker();
        return checker.decodeDES(passwd).checkTime();
    }

    /**
     * 检测密码尝试是否超过限制
     *
     * @param info
     * @return
     */
    public boolean checkLogCount(PangooUser info, String verification) {
        LogInError logInError = (LogInError) redisTemplateLogIn.opsForValue().get(info.getCid());
        boolean result = false;
        if (logInError == null) {
            result = true;
        } else {
            // 小于最大次数：可以继续验证
            if (logInError.getLoginErrCounts() < maxLogTimes) {
                result = true;
            } else {
                // 验证码验证
                verificationCodeManager.checkVerificationCode(verification, info.getTelPhone());
            }
        }
        return result;
    }

    /**
     * 检测密码尝试是否超过限制
     *
     * @param info
     * @return
     */
    public boolean checkLogCount(String key) {
        LogInError logInError = (LogInError) redisTemplateLogIn.opsForValue().get(key);
        boolean result = false;
        if (logInError == null) {
            result = true;
        } else {
            // 小于最大次数：可以继续验证
            if (logInError.getLoginErrCounts() < maxLogTimes) {
                result = true;
            }
        }
        return result;
    }

    /**
     * 更新登录信息记录
     *
     * @param vInfo
     * @param status
     */
    public void upLogCountStatus(PangooUser vInfo, boolean status) {
        // 密码校验错误
        if (!status) {
            LogInError logInError = (LogInError) redisTemplateLogIn.opsForValue().get(vInfo.getCid());
            if (null != logInError) {
                logInError.setLoginErrCounts(logInError.getLoginErrCounts() + 1);
                logInError.setLoginErrTime(Calendar.getInstance().getTimeInMillis());
            } else {
                logInError = new LogInError();
                logInError.setLoginErrCounts(1);
                logInError.setLoginErrTime(Calendar.getInstance().getTimeInMillis());
            }
            // 存入缓存
            // 5分钟自动清除登录异常信息
            redisTemplateLogIn.opsForValue().set(vInfo.getCid(), logInError, Cst.OVER_MINUTE, TimeUnit.MINUTES);
        }
    }

    /**
     * 更新登录信息记录
     *
     * @param vInfo
     * @param status
     */
    public void upLogCountStatus(String key, boolean status) {
        // 密码校验错误
        if (!status) {
            LogInError logInError = (LogInError) redisTemplateLogIn.opsForValue().get(key);
            if (null != logInError) {
                logInError.setLoginErrCounts(logInError.getLoginErrCounts() + 1);
                logInError.setLoginErrTime(Calendar.getInstance().getTimeInMillis());
            } else {
                logInError = new LogInError();
                logInError.setLoginErrCounts(1);
                logInError.setLoginErrTime(Calendar.getInstance().getTimeInMillis());
            }
            // 存入缓存
            // 5分钟自动清除登录异常信息
            redisTemplateLogIn.opsForValue().set(key, logInError, Cst.OVER_MINUTE, TimeUnit.MINUTES);
        }
    }
}
