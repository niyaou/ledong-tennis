package com.desay.usersystem.service;

import java.util.Map;

import com.desay.cd.DTO.PersonDTO;

/**
 * 
 * @author 倪旭春
 *
 */
public interface LdapAuthorizeService {

    /**
     * 获取用户信息
     * 
     * @param key
     * @return
     */
    public PersonDTO get(String key);

    public static String SEARCHDN = "v01\\";

    /**
     * 获取当前用户信息
     * 
     * @return
     */
    public Map<String, String> getCurrentUser();

    /**
     * 用户认证
     * 
     * @param id
     * @param password
     * @return
     */
    public boolean authenricate(String id, String password);
}