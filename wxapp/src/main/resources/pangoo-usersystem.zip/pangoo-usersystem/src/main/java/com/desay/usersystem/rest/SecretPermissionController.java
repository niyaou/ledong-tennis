package com.desay.usersystem.rest;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.SecretKeyBean;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.dao.SecretKeyDao;
import com.desay.usersystem.entity.SecretKey;
import com.desay.usersystem.exception.BizException;
import com.desay.usersystem.service.SecretKeyService;
import com.desay.usersystem.utils.PageUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 用于三方key权限管理
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/secret")
@Api(tags = "用于三方key权限管理")
public class SecretPermissionController {

    @Autowired
    private SecretKeyDao secretKeyDao;
    @Autowired
    private SecretKeyService secretKeyService;

    @ApiOperation(value = "添加三方key", notes = "添加三方key", httpMethod = "POST")
    @RequestMapping(value = "/creatSecretKey", method = RequestMethod.POST)
    public Object creatSecretKey(
            @ApiParam(required = true, name = "secretKey", value = "三方key信息json数据") @RequestBody(required = true) SecretKeyBean secretKey,
            HttpServletRequest request) {
        ResponseDTO<?> dto = null;
        try {
            dto = secretKeyService.creatSecretKey(secretKey);
        } catch (Exception e) {
            if (e instanceof BizException) {
                // 业务异常数据回滚
                return JsonResponseEntity.instatnce(
                        ResponseDTO.NewErrorResponseDTO(e.getMessage(), ((BizException) e).getResponseCode()));
            } else {
                // 通用异常
                return JsonResponseEntity
                        .instatnce(ResponseDTO.NewErrorResponseDTO(e.getMessage(), ResponseCode.ERROR));
            }
        }
        if (dto == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(""));
        } else {
            return JsonResponseEntity.instatnce(dto);
        }
    }

    @ApiOperation(value = "删除三方key", notes = "删除三方key", httpMethod = "DELETE")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "key", value = "三方key", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/delSecretKey", method = RequestMethod.DELETE)
    public Object delSecretKey(@RequestParam(name = "roleId", required = true) String key, HttpServletRequest request) {
        ResponseDTO<?> responseDTO = null;
        try {
            responseDTO = secretKeyService.delSecretKey(key);
        } catch (Exception e) {
            // 通用异常
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(e.getMessage(), ResponseCode.ERROR));
        }
        return JsonResponseEntity.instatnce(responseDTO);
    }

    /**
     * 获取三方key列表
     * 
     * @param name
     * @param request
     * @return
     */
    @ApiOperation(value = "获取三方key列表", notes = "获取三方key列表", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "对应外部服务名称", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    @RequestMapping(value = "/getKeyList", method = RequestMethod.GET)
    public Object getKeyList(@RequestParam(name = "name", required = false) String name,
            @RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize, HttpServletRequest request) {
        Page<SecretKey> result = null;
        int[] pageParams = PageUtil.creagePageAbleParams(pageNo, pageSize);
        Pageable pageable = new PageRequest(pageParams[0], pageParams[1]);
        if (StringUtil.isNotEmpty(name)) {
            result = secretKeyDao.findByName(name, pageable);
        } else {
            result = secretKeyDao.findAll(pageable);
        }
        return ResponseDTO.ResponseDTO(result);
    }

    @ApiOperation(value = "修改三方key", notes = "修改三方key", httpMethod = "POST")

    @RequestMapping(value = "/updateSecretKey", method = RequestMethod.POST)
    public Object updateSecretKey(
            @ApiParam(required = true, name = "orgRole", value = "role角色信息json数据") @RequestBody(required = true) SecretKeyBean secretKey,
            HttpServletRequest request) {
        ResponseDTO<?> dto = null;
        try {
            dto = secretKeyService.updateSecretKey(secretKey);
        } catch (Exception e) {
            if (e instanceof BizException) {
                // 业务异常数据回滚
                return JsonResponseEntity.instatnce(
                        ResponseDTO.NewErrorResponseDTO(e.getMessage(), ((BizException) e).getResponseCode()));
            } else {
                // 通用异常
                return JsonResponseEntity
                        .instatnce(ResponseDTO.NewErrorResponseDTO(e.getMessage(), ResponseCode.ERROR));
            }
        }
        if (dto == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(""));
        } else {
            return JsonResponseEntity.instatnce(dto);
        }
    }
}
