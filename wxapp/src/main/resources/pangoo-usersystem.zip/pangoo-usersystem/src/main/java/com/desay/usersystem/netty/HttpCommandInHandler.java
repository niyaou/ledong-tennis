package com.desay.usersystem.netty;

import static io.netty.handler.codec.http.HttpResponseStatus.OK;
import static io.netty.handler.codec.http.HttpVersion.HTTP_1_1;

import java.io.IOException;
import java.util.Calendar;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpHeaders;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.security.RsaKeyManager;
import com.desay.usersystem.service.impl.PwdAuthorizeServiceImpl;
import com.desay.usersystem.service.impl.SecurityAdapterServiceImpl;
import com.desay.usersystem.service.impl.TokenAuthorizeServiceImpl;
import com.desay.usersystem.utils.Cst;
import com.google.gson.Gson;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.util.ReferenceCountUtil;
import io.netty.util.internal.logging.InternalLogger;
import io.netty.util.internal.logging.InternalLoggerFactory;

/***
 * * netty 的token认证接口。以便处理更大并发的访问。/
 * http://localhost:8082/tokenAuthorize?token=78098aa4-10ef-43be-9c8b-74cc9d253139
 * 
 * @author uidq1163
 *
 */
@ChannelHandler.Sharable
public class HttpCommandInHandler extends SimpleChannelInboundHandler<FullHttpRequest> {
    public static InternalLogger logger = InternalLoggerFactory.getInstance(HttpCommandInHandler.class);
    Gson gson = new Gson();
    TokenAuthorizeServiceImpl tokenAuthorizeImp = NettyContext.getBean(TokenAuthorizeServiceImpl.class);
    SecurityAdapterServiceImpl securityAdapterImp = NettyContext.getBean(SecurityAdapterServiceImpl.class);
    PwdAuthorizeServiceImpl pwdAuthorizeImp = NettyContext.getBean(PwdAuthorizeServiceImpl.class);

    @Override
    public void channelRead0(ChannelHandlerContext ctx, FullHttpRequest msg) {
        ReferenceCountUtil.retain(msg);
        String uri = msg.getUri();
        DefaultFullHttpResponse response = new DefaultFullHttpResponse(HTTP_1_1, OK);
        response.headers().set(HttpHeaders.CONTENT_TYPE, "text/json; charset=UTF-8");
        ResponseDTO<?> responseDTO = null;
        if (uri.startsWith(Cst.TOKEN_AUTHORIZE)) {
            // 认证接口
            TokenDTO token = null;
            Map<String, String> parmMap = null;
            String tokenStr = "";
            try {
                parmMap = new RequestParser(msg).parse();
                tokenStr = parmMap.get("token");
            } catch (IOException e) {
                logger.error(e.getMessage());
            }
            if (StringUtil.isNotEmpty(tokenStr)) {
                token = tokenAuthorizeImp.tokenNettyAuthorize(tokenStr);
            }
            if (token == null) {
                responseDTO = ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR);
            } else {
                responseDTO = ResponseDTO.ResponseDTO(token);
            }
        } else if (uri.startsWith(Cst.GET_PUBLICKEY)) {
            // 修正http头的时间
            response.headers().add("date", Calendar.getInstance().getTime().toString());
            String key = Base64.encodeBase64String(RsaKeyManager.getPublicKey());
            responseDTO = ResponseDTO.ResponseDTO(key);
        } else if (uri.startsWith(Cst.UPLOAD_AESKEY)) {
            // 上传AES秘钥
            responseDTO = uploadAESKey(msg);
        } else if (uri.startsWith(Cst.PWDAUTHORIZE)) {
            Map<String, String> parmMap = null;
            String name = "";
            String pwd = "";
            String clientId = "";
            try {
                parmMap = new RequestParser(msg).parse();
                name = parmMap.get("name");
                pwd = parmMap.get("pwd");
                clientId = parmMap.get("clientId");
            } catch (IOException e) {
                logger.error(e.getMessage());
            }
            responseDTO = pwdAuthorizeImp.login(name, pwd, clientId, "", "");
        } else if (uri.startsWith(Cst.LOGOUTBYTOKEN)) {
            // 退出登录
            Map<String, String> parmMap = null;
            String tokenStr = "";
            try {
                parmMap = new RequestParser(msg).parse();
                tokenStr = parmMap.get("token");
            } catch (IOException e) {
                logger.error(e.getMessage());
            }
            if (pwdAuthorizeImp.logoutNetty(tokenStr)) {
                responseDTO = ResponseDTO.NewErrorResponseDTO(ResponseCode.OK);
            } else {
                responseDTO = ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR);
            }
        } else {
            return;
        }
        response.setStatus(HttpResponseStatus.OK);
        ByteBuf b = response.content();
        String abc = gson.toJson(responseDTO);
        b.writeBytes(abc.getBytes());
        ctx.writeAndFlush(response);
        ctx.fireChannelRead(msg);
        ctx.close();
        ReferenceCountUtil.release(msg);
    }

    /**
     * 上传AES秘钥
     * 
     * @param msg
     * @return
     */
    private ResponseDTO<?> uploadAESKey(FullHttpRequest msg) {
        String token = "";
        String key = "";
        Map<String, String> parmMap = null;
        try {
            parmMap = new RequestParser(msg).parse();
            token = parmMap.get("token");
            key = parmMap.get("key");
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
        return securityAdapterImp.uploadAESKeyNetty(token, key);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        ctx.close();
    }

    /**
     * 
     * channelReadComplete 在通道读取完成后会在这个方法里通知
     */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        ctx.flush();
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("inactive1");
        ctx.fireChannelInactive();
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        super.channelActive(ctx);
    }
}
