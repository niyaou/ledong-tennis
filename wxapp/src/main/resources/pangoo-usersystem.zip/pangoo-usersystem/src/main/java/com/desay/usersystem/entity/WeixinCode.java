package com.desay.usersystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 微信账户实体类
 * 
 * @author uidq1163
 *
 */
@Entity
@Table(name = "weixin_code")
public class WeixinCode {
    @Id
    @Column(name = "open_id")
    String openid;
    @Column(name = "cid")
    String cid;
    @Column(name = "union_id")
    String unionid;
    @Column(name = "session_key")
    String sessionKey;

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getUnionid() {
        return unionid;
    }

    public void setUnionid(String unionid) {
        this.unionid = unionid;
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }
}
