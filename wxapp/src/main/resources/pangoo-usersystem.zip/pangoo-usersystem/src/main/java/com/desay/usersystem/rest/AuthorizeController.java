package com.desay.usersystem.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.Login;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.service.PwdAuthorizeService;
import com.desay.usersystem.service.WxCodeAuthorizeService;
import com.desay.usersystem.utils.Cst;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 用户认证接口
 * 
 * @author uidq1163
 *
 */
@RestController
@Api(tags = "用户认证接口")
public class AuthorizeController {
    public static Logger log = Logger.getLogger(AuthorizeController.class);
    @Autowired
    PwdAuthorizeService pwdAuthorizeImp;
    @Autowired
    WxCodeAuthorizeService wxCodeAuthorizeImp;

    @ApiOperation(value = "用户密码认证接口", notes = "根据用户名密码，进行身份认证，验证通过创建会话，并将会话id作为token或者code返回", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "clientId", value = "应用ID，（区分车机，web，Android手机，ios手机）", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "username", value = "用户名", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "verifyCode", value = "验证码", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "org", value = "机构代码", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "password", value = "本地系统时间yyyyMMddHHmmss+明文密码后用接口getPublicKey所得公钥进行RSA加密，本地时间不能与服务器时间相差2分钟以上", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/pwdAuthorize", method = RequestMethod.POST)
    public Object pwdAuthorize(HttpServletRequest request,
            @RequestParam(value = "username", required = true) String username,
            @RequestParam(value = "password", required = true) String password,
            @RequestParam(value = "clientId", required = true) String clientId, HttpServletResponse response) {
        ResponseDTO<?> responseDTO = new ResponseDTO<Object>();
        if (StringUtil.isEmpty(username)) {
            responseDTO.setMsg("用户名不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        if (StringUtil.isEmpty(password)) {
            responseDTO.setMsg("密码不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        if (StringUtil.isEmpty(clientId)) {
            responseDTO.setMsg("应用ID不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        String verifyCode = request.getParameter("verifyCode");
        String org = request.getParameter("org");
        return JsonResponseEntity
                .instatnce(doPwdAuthorize(username, password, clientId, org, verifyCode, request, response));
    }

    @ApiOperation(value = "用户密码认证接口", notes = "根据用户名密码，进行身份认证，验证通过创建会话，并将会话id作为token或者code返回", httpMethod = "POST")
    @RequestMapping(value = "/pwdAuthorize2", method = RequestMethod.POST)
    public Object pwdAuthorize2(
            @ApiParam(required = true, name = "user", value = "user用户信息json数据") @RequestBody Login login,
            HttpServletRequest request, HttpServletResponse response) {
        String username = login.getUserName();
        String password = login.getPassword();
        String clientId = login.getClientId();
        String org = login.getOrg();
        String verifyCode = login.getVerifyCode();
        ResponseDTO<?> responseDTO = new ResponseDTO<Object>();
        if (StringUtil.isEmpty(username)) {
            responseDTO.setMsg("用户名不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        if (StringUtil.isEmpty(password)) {
            responseDTO.setMsg("密码不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        if (StringUtil.isEmpty(clientId)) {
            responseDTO.setMsg("应用ID不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        return JsonResponseEntity
                .instatnce(doPwdAuthorize(username, password, clientId, org, verifyCode, request, response));
    }

    @ApiOperation(value = "LDAP用户密码认证接口", notes = "根据用户名密码，进行身份认证，验证通过创建会话，使用德賽uid系統驗證", httpMethod = "POST")
    @RequestMapping(value = "/pwdAuthorizeldap", method = RequestMethod.POST)
    public Object pwdAuthorizeldap(HttpServletRequest request,
            @RequestParam(value = "username", required = true) String username,
            @RequestParam(value = "password", required = true) String password,
            @RequestParam(value = "clientId", required = true) String clientId, HttpServletResponse response) {
        ResponseDTO<?> responseDTO = new ResponseDTO<Object>();
        if (StringUtil.isEmpty(username)) {
            responseDTO.setMsg("用户名不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        if (StringUtil.isEmpty(password)) {
            responseDTO.setMsg("密码不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        if (StringUtil.isEmpty(clientId)) {
            responseDTO.setMsg("应用ID不能为空");
            responseDTO.setCode(ResponseCode.PARAMETER_ERROR.getCode());
            return JsonResponseEntity.instatnce(responseDTO);
        }
        String verifyCode = request.getParameter("verifyCode");
        String org = request.getParameter("org");
        return JsonResponseEntity
                .instatnce(doPwdAuthorizeByLdap(username, password, clientId, org, verifyCode, request, response));

    }

    private ResponseDTO<?> doPwdAuthorize(String username, String password, String clientId, String org,
            String verifyCode, HttpServletRequest request, HttpServletResponse response) {
        ResponseDTO<?> result = pwdAuthorizeImp.login(username, password, clientId, org, verifyCode,
                request.getSession());
        if (result != null) {
            return result;
        } else {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_LOGIN_OR_PWD_ERROR);
        }
    }

    private ResponseDTO<?> doPwdAuthorizeByLdap(String username, String password, String clientId, String org,
            String verifyCode, HttpServletRequest request, HttpServletResponse response) {
        // 允许跨域请求
        ResponseDTO<?> result = pwdAuthorizeImp.loginToLdap(username, password, clientId, org, verifyCode,
                request.getSession());
        if (result != null) {
            return result;
        } else {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_LOGIN_OR_PWD_ERROR);
        }
    }

    @ApiOperation(value = "微信code登录", notes = "用户通过微信进行第三方登录", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "code", value = "微信服务提供的登录code", required = true, dataType = "String", paramType = "query") })

    @RequestMapping(value = "/wxCodeAuthorize", method = RequestMethod.POST)
    public Object wxCodeAuthorize(@RequestParam(name = "code") String code, HttpServletRequest request,
            HttpServletResponse response) {
        ResponseDTO<?> dto = wxCodeAuthorizeImp.codeAuthorize(code, request.getSession());
        return JsonResponseEntity.instatnce(dto);

    }

    @ApiOperation(value = "登出接口", notes = "用户登出，无效化相关session", httpMethod = "POST")
    @ApiImplicitParams({})
    @RequestMapping(value = "/logOut", method = RequestMethod.POST)
    public Object logOut(HttpServletRequest request) {
        String tokenId = request.getHeader(Cst.HEADER_TOKEN);
        if (pwdAuthorizeImp.logout(tokenId)) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.OK));
        } else {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR));
        }
    }

    @ApiOperation(value = "登出接口", notes = "服务为用户登出登出，无效化相关session", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "token", value = "token", required = false, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/logOutBytoken", method = RequestMethod.POST)
    public Object logOutBytoken(HttpServletRequest request,
            @RequestParam(value = "token", required = true) String token) {
        if (pwdAuthorizeImp.logout(token)) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.OK));
        } else {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR));
        }
    }
}
