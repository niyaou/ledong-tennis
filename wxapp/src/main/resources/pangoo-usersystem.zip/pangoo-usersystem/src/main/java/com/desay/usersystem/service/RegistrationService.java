package com.desay.usersystem.service;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.usersystem.adapter.bean.User;
import com.desay.usersystem.adapter.bean.WxUser;

/**
 * 注册实现类
 * 
 * @author uidq1163
 *
 */
public interface RegistrationService {

    /**
     * 用户注册
     * 
     * @param user
     * @return
     */
    public ResponseDTO<?> registration(User user);

    /**
     * 创建微信普通用户
     *
     * @param user
     * @return
     */
    public ResponseDTO<?> wxRegistration(WxUser user);

    /**
     * 解密密码，并开始绑定
     * 
     * @param user
     * @return
     */
    public ResponseDTO<?> bindWx(WxUser user);

    /**
     * 解绑微信
     * 
     * @param user
     * @return
     */
    public ResponseDTO<?> unBindWx(WxUser user);

}
