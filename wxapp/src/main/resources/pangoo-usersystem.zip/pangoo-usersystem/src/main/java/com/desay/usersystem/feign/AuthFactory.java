package com.desay.usersystem.feign;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import feign.Feign;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;

/**
 * 微信认证服务
 * 
 * @author uidq1163
 *
 */
@Component
public class AuthFactory {
    /** 微信认证服务地址。 */
    @Value("${wx.service}")
    String wxService;

    ThreadLocal<WxAuth> threadLocal = new ThreadLocal<WxAuth>();

    public WxAuth getGsonInterFace() {
        WxAuth service = threadLocal.get();
        if (service == null) {
            service = Feign.builder().decoder(new GsonDecoder()).encoder(new GsonEncoder()).target(WxAuth.class,
                    wxService);
            threadLocal.set(service);
        }
        return service;
    }

    public void remove() {
        threadLocal.remove();
    }
}
