package com.desay.usersystem.service.impl;

import java.text.ParseException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.CollectionUtil;
import com.desay.cd.utils.DateUtil;
import com.desay.usersystem.adapter.bean.SecretKeyBean;
import com.desay.usersystem.dao.PermissionDao;
import com.desay.usersystem.dao.SecretKeyDao;
import com.desay.usersystem.entity.Permission;
import com.desay.usersystem.entity.SecretKey;
import com.desay.usersystem.exception.BizException;
import com.desay.usersystem.service.SecretKeyService;

/**
 * 三方key管理实现
 * 
 * @author uidq1887
 *
 */
@Service
public class SecretKeyServiceImpl implements SecretKeyService {
    Logger log = Logger.getLogger(SecretKeyServiceImpl.class);
    @Autowired
    PermissionDao permissionDao;
    @Autowired
    SecretKeyDao secretKeyDao;

    /**
     * 添加三方key
     * 
     * @param secretKeyBean
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> creatSecretKey(SecretKeyBean secretKeyBean) {
        String name = secretKeyBean.getName();
        SecretKey exist = secretKeyDao.findByName(name);
        if (exist != null) {
            return ResponseDTO.NewErrorResponseDTO("三方key已存在", ResponseCode.ERROR);
        }
        SecretKey secretKey = new SecretKey();
        List<String> permissions = secretKeyBean.getPermissionList();
        Set<Permission> permissionlist = new HashSet<>();
        BeanUtils.copyProperties(secretKeyBean, secretKey);
        try {
            secretKey.setExpireTime(DateUtil.getDate(secretKeyBean.getExpireTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (CollectionUtil.isNotEmpty(permissions)) {
            for (String id : permissions) {
                Permission permissionold = permissionDao.findOne(id);
                if (null == permissionold) {
                    throw new BizException(ResponseCode.ERROR, "当前权限不存在");
                }
                permissionlist.add(permissionold);
            }
            secretKey.setPermissionlist(permissionlist);
        }
        secretKeyDao.saveAndFlush(secretKey);
        log.info("创建三方key:" + secretKey.getName());
        return null;
    }

    /**
     * 修改三方key
     * 
     * @param secretKeyBean
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> updateSecretKey(SecretKeyBean secretKeyBean) {
        String key = secretKeyBean.getKey();
        SecretKey secretKey = secretKeyDao.findOne(key);
        secretKey.setName(secretKeyBean.getName());
        try {
            secretKey.setExpireTime(DateUtil.getDate(secretKeyBean.getExpireTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        secretKey.setAccessCount(secretKeyBean.getAccessCount());
        secretKey.setAccessCountDay(secretKeyBean.getAccessCountDay());
        secretKey.setPermissionlist(null);
        List<String> permissions = secretKeyBean.getPermissionList();
        Set<Permission> permissionlist = new HashSet<>();
        if (CollectionUtil.isNotEmpty(permissions)) {
            for (String id : permissions) {
                Permission permissionold = permissionDao.findOne(id);
                if (null == permissionold) {
                    throw new BizException(ResponseCode.ERROR, "当前权限不存在");
                }
                permissionlist.add(permissionold);
            }
            secretKey.setPermissionlist(permissionlist);
        }
        secretKeyDao.saveAndFlush(secretKey);
        log.info("修改三方key:" + secretKey.getName());
        return null;
    }

    /**
     * 删除三方key
     * 
     * @param key
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> delSecretKey(String key) {
        SecretKey secretKey = secretKeyDao.findOne(key);
        if (secretKey == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.SECRET_KEY_NOT_FIND);
        }
        if (secretKey.getAccess() > 0) {
            return ResponseDTO.NewErrorResponseDTO("该三方key正在使用不能删除！", ResponseCode.ERROR);
        }
        secretKeyDao.delete(key);
        return ResponseDTO.ResponseDTO("");
    }

}
