package com.desay.usersystem.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 企业成员视图
 * 
 * @author uidq1343
 *
 */
@Entity
@Table(name = "organization_master_info")
public class OrgUserView {

    @Id
    @Column(name = "cid")
    private String cid;
    @Column(name = "org_id")
    private String orgId;
    @Column(name = "org_name")
    private String orgName;
    @Column(name = "parent_id")
    private String parentId;
    @Column(name = "login_name")
    private String loginName;
    @Column(name = "is_manager")
    private String isManager;
    @Column(name = "status")
    private String status;
    @Column(name = "user_status")
    private String userStatus;
    @Transient
    private List<String> roleList;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getIsManager() {
        return isManager;
    }

    public void setIsManager(String isManager) {
        this.isManager = isManager;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public List<String> getRoleList() {
        return roleList;
    }

    public void setRoleList(List<String> roleList) {
        this.roleList = roleList;
    }
}
