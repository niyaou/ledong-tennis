package com.desay.usersystem.service;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.usersystem.adapter.bean.SecretKeyBean;

/**
 * 三方key管理实现
 * 
 * @author uidq1887
 *
 */
public interface SecretKeyService {

    /**
     * 添加三方key
     * 
     * @param orgRole
     * @param org
     * @return
     */
    public ResponseDTO<?> creatSecretKey(SecretKeyBean secretKeyBean);

    /**
     * 修改三方key
     * 
     * @param secretKeyBean
     * @return
     */
    public ResponseDTO<?> updateSecretKey(SecretKeyBean secretKeyBean);

    /**
     * 删除三方key
     * 
     * @param key
     * @return
     */
    public ResponseDTO<?> delSecretKey(String key);
}
