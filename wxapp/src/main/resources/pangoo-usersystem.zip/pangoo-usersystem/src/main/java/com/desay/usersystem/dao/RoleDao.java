package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.Role;

/**
 * 
 * @author uidq1163
 *
 */
public interface RoleDao extends JpaRepository<Role, String>, JpaSpecificationExecutor<Role> {
    /**
     * 定义normal 或 orgid 为空的角色，为通用角色
     * 
     * @param org
     * @return
     */
    @Query("select t from Role t where t.orgId = :org or t.orgId='normal'")
    List<Role> getOrgRole(@Param("org") String org);

    /**
     * 
     * @param parentId
     * @return
     */
    @Query("select t from Role t where t.parentId = :parentId")
    List<Role> getOrgRoleByParentId(@Param("parentId") String parentId);

    /**
     * 查看当前企业的原始角色
     * 
     * @param org
     * @param parentId
     * @return
     */
    @Query("select t from Role t where t.orgId = :org and t.parentId=:parentId")
    Role findOrgRole(@Param("org") String org, @Param("parentId") String parentId);

    /**
     * 查看当前企业角色是否存在
     * 
     * @param org
     * @param parentId
     * @return
     */
    @Query("select t from Role t where t.orgId = :org and t.roleName=:roleName")
    Role findOrgRoleByName(@Param("org") String org, @Param("roleName") String roleName);

    /**
     * 同机构名称和角色名称查询角色
     * 
     * @param orgId
     * @param roleName
     * @return
     */
    Page<Role> findByOrgIdAndRoleName(String orgId, String roleName, Pageable pageable);

    /**
     * 角色名称查询角色
     * 
     * @param roleName
     * @return
     */

    Page<Role> findByRoleName(String roleName, Pageable pageable);

    /**
     * 机构名称查询角色
     * 
     * @param orgId
     * @return
     */
    Page<Role> findByOrgId(String orgId, Pageable pageable);
}
