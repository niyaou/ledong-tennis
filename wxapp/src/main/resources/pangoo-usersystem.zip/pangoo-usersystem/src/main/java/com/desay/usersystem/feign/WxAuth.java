package com.desay.usersystem.feign;

import com.desay.usersystem.adapter.bean.WxAuthBean;

import feign.Param;
import feign.RequestLine;

/**
 * 微信认证
 * 
 * @author uidq1163
 *
 */
public interface WxAuth {

    /**
     * 微信code登录认证接口。grant_type为固定authorization_code
     * 
     * @param appid
     *            小程序唯一标识
     * @param secret
     *            小程序秘钥
     * @param js_code
     *            登录的code
     * @return //正常返回的JSON数据包 { "openid": "OPENID", "session_key": "SESSIONKEY", }
     *
     *         //满足UnionID返回条件时，返回的JSON数据包 { "openid": "OPENID", "session_key":
     *         "SESSIONKEY", "unionid": "UNIONID" } //错误时返回JSON数据包(示例为Code无效) {
     *         "errcode": 40029, "errmsg": "invalid code" }
     * @param appid
     * @param secret
     * @param jsCode
     * @return
     */
    @RequestLine("GET /sns/jscode2session?appid={appid}&secret={secret}&js_code={js_code}&grant_type=authorization_code")
    WxAuthBean auth(@Param(value = "appid") Object appid, @Param(value = "secret") Object secret,
            @Param(value = "js_code") Object jsCode);
}
