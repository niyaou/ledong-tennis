package com.desay.usersystem.security;

import java.security.PrivateKey;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.serviceregistry.Registration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.ClusterRsaCheck;
import com.desay.usersystem.feign.ClusterInterface;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

import feign.Feign;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;

/**
 * 获取RSA秘钥
 * 
 * @author uidq1163
 *
 */
@Service
public class RsaKeyManager {
    public static Logger log = Logger.getLogger(RsaKeyManager.class);
    /** 1024位加密后密文长度为172 */
    public static final int RSA_SIZE = 172;
    /** 秘钥保存 */
    public static Map<String, byte[]> keyMap = RSAUtils.generateKeyBytes();

    ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("lastPrivateKey-%d").build();
    ScheduledExecutorService singleThreadPool = new ScheduledThreadPoolExecutor(1, namedThreadFactory);
    @Autowired
    DiscoveryClient discoveryClient;
    @Autowired
    Registration registration;

    public static byte[] getPublicKey() {
        return keyMap.get(RSAUtils.PUBLIC_KEY);
    }

    static byte[] lastPrivateKey;

    public static byte[] getLastPrivateKey() {
        return lastPrivateKey;
    }

    /**
     * 每6个小时更新一次RSA秘钥
     */
    @Scheduled(cron = "0 0 0/6 * * ?")
    void upDateKeys() {
        lastPrivateKey = getPrivateKey();
        keyMap = RSAUtils.generateKeyBytes();
        // 虽然抛出了运行异常,当被拦截了,next周期继续运行
        singleThreadPool.schedule(new Runnable() {
            @Override
            public void run() {
                try {
                    lastPrivateKey = null;
                    log.info("无效化旧的key");
                } catch (Exception e) {
                    log.warn("RuntimeException catched,can run next");
                }
            }
            // 初始化延时
            // 计时单位
            // 表示延迟60秒执行
        }, 60, TimeUnit.SECONDS);
    }

    public static byte[] getPrivateKey() {
        return keyMap.get(RSAUtils.PRIVATE_KEY);
    }

    /**
     * 单机解密
     * 
     * @param content
     * @return
     */
    public static String decode(String content) {
        if (TextUtils.isEmpty(content)) {
            return null;
        }

        PrivateKey privateKey = null;
        try {
            privateKey = RSAUtils.restorePrivateKey(RsaKeyManager.getPrivateKey());
            // 长度超过后，进行拼接
            if (content.length() > RSA_SIZE) {
                String content2 = content.substring(RSA_SIZE, RSA_SIZE * 2);
                content = content.substring(0, RSA_SIZE);
                content = RSAUtils.RSADecode(privateKey, content);
                if (StringUtil.isNotEmpty(content)) {
                    content += RSAUtils.RSADecode(privateKey, content2);
                } else {
                    content = RSAUtils.RSADecode(privateKey, content2);
                }
            } else {
                content = RSAUtils.RSADecode(privateKey, content);
            }

        } catch (Exception e) {
            // 解密失败，尝试使用前一次的秘钥进行解密，解决秘钥更新后的同步异常
            if (lastPrivateKey != null) {
                privateKey = RSAUtils.restorePrivateKey(RsaKeyManager.getLastPrivateKey());
                // 长度超过后，进行拼接
                if (content.length() > RSA_SIZE) {
                    String content2 = content.substring(RSA_SIZE, RSA_SIZE * 2);
                    content = content.substring(0, RSA_SIZE);
                    content = RSAUtils.RSADecode(privateKey, content);
                    content += RSAUtils.RSADecode(privateKey, content2);
                } else {
                    content = RSAUtils.RSADecode(privateKey, content);
                }
                log.info("使用旧的key解密");
            } else {
                return null;
            }
        }
        return content;
    }

    /**
     * 集群解密
     * 
     * @param content
     * @return
     */
    public String clusterDecode(String content) {
        try {
            // 时间(14)+
            String decodeContent = decode(content);
            if (StringUtil.isNotEmpty(decodeContent)) {
                return decodeContent;
            } else {
                return clusterService(content);
            }
        } catch (Exception e) {
            return clusterService(content);
        }
    }

    /**
     * 集群服务解码
     * 
     * @param content
     * @return
     */
    private String clusterService(String content) {
        List<ServiceInstance> list = discoveryClient.getInstances("PANGOO-USERSYSTEM");
        String localservice = "http://" + registration.getHost() + ":" + registration.getPort();
        for (ServiceInstance si : list) {
            String nextService = "http://" + si.getHost() + ":" + si.getPort();
            if (localservice.equals(nextService)) {
                continue;
            }
            ResponseDTO<ClusterRsaCheck> result = null;
            try {
                result = getGsonInterFace(nextService).clusterRsaDecode(content);
                if (Boolean.TRUE == result.getData().getFlg()) {
                    return result.getData().getContent();
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        return null;
    }

    /**
     * @param host
     * @return
     */
    public ClusterInterface getGsonInterFace(String host) {
        ClusterInterface service = Feign.builder().decoder(new GsonDecoder()).encoder(new GsonEncoder())
                .target(ClusterInterface.class, host);
        return service;
    }
}
