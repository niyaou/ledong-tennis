package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.RolePermissionView;

/**
 * 用户角色权限
 * 
 * @author uidq1163
 *
 */
public interface RolePermissionViewDao
        extends JpaRepository<RolePermissionView, String>, JpaSpecificationExecutor<RolePermissionView> {

    /**
     * 根据用户角色查询对应权限
     * 
     * @param role
     * @return
     */
    @Query("select t from RolePermissionView t where t.roleId = :role")
    List<RolePermissionView> getRolePermission(@Param("role") String role);
}
