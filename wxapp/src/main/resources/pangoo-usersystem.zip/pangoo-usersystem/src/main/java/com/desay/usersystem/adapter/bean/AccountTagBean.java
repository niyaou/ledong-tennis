package com.desay.usersystem.adapter.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 数据类型分类
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = " 数据类型分类", description = " 数据类型分类")
public class AccountTagBean {
    @ApiModelProperty(value = "企业ID(不设置默认为当前登录用户企业)", name = "orgId", example = "IOV", required = false)
    private String orgId;
    @ApiModelProperty(value = "项目ID", name = "sourceId", example = "NV5087", required = true)
    private String sourceId;
    @ApiModelProperty(value = "需要添加的用户ID，VIN、设备ID", name = "name", example = "111111111111", required = true)
    private String name;
    @ApiModelProperty(value = "目标名称", name = "tag", example = "xingguo", required = true)
    private String tag;
    /** 权限类型：userid:1、vin:2、device:3 */
    @ApiModelProperty(value = "权限类型", name = "type", example = "userid:1、vin:2、device:3", required = true)
    private Integer type;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
