package com.desay.usersystem.interceptor;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.util.AntPathMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.PermissionDTO;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.service.TokenAuthorizeService;
import com.desay.usersystem.utils.Cst;
import com.google.gson.Gson;

/**
 * 请求拦截器
 * 
 * @author uidq1163
 *
 */
@Component
public class AllIntercepter extends HandlerInterceptorAdapter {
    private Gson gson = new Gson();
    @Autowired
    private TokenAuthorizeService tokenAuthorizeService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        response.setHeader("date", Calendar.getInstance().getTime().toString());
        return allowVisit(request, response);
    }

    /**
     * 是否允许访问
     * 
     * @param request
     * @param response
     * @return
     */
    private boolean allowVisit(HttpServletRequest request, HttpServletResponse response) {
        boolean flag = false;
        // 拦截未登录的url
        String rex = "(\\.html)|(\\.css)|(\\.js)|(\\.woff)|(v2/api-docs)|(swagger-resources)|(/metrics)|(/error)|(/health)";
        Pattern sinaPatten = Pattern.compile(rex, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
        // 获取此请求的地址
        // 非法路径处理
        String uri = request.getRequestURI();
        Matcher matcher = sinaPatten.matcher(uri);
        if (matcher.find()) {
            return true;
        } else {
            String tokenId = request.getHeader(Cst.HEADER_TOKEN);
            TokenDTO token = null;
            if (tokenId != null) {
                token = tokenAuth(tokenId);
            }
            // 权限检测
            if (token != null) {
                request.setAttribute(Cst.ATTRIBUTE_ORG, token.orgId);
                request.setAttribute(ConstantUtils.SESSION_TOKEN, token);
                flag = checkPermission(uri, token);
            }
            // 无权限返回
            if (!flag) {
                try {
                    response.setHeader("content-type", "application/json");
                    String error = gson.toJson(ResponseDTO.NewErrorResponseDTO(ResponseCode.PERMISSION_ERROR));
                    response.setContentType("text/html;charset=UTF-8");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(error);
                    response.getWriter().flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return flag;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
    }

    /**
     * token认证
     * 
     * @param
     * @return
     */
    private TokenDTO tokenAuth(Object tokenId) {
        TokenDTO token = tokenAuthorizeService.tokenAuthorize((String) tokenId);
        return token;
    }

    /**
     * 角色权限判断
     *
     * @param url
     * @param token
     * @return
     */
    private boolean checkPermission(String url, TokenDTO token) {
        List<PermissionDTO> list = tokenAuthorizeService.tokenPermissionList(token.token);
        for (PermissionDTO permission : list) {
            String method = permission.getMethod();
            if (StringUtil.isNotEmpty(method)) {
                AntPathMatcher methodmatcher = new AntPathMatcher();
                String methodpattern = method;
                if (methodmatcher.match(methodpattern, url)) {
                    return true;
                }
            }
        }
        return false;
    }
}
