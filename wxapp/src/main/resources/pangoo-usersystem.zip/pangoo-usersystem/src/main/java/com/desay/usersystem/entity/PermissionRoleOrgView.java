package com.desay.usersystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * 角色权限机构关系视图
 * @author uidq1163
 *
 */
@Entity
@Table(name = "permission_role_org_view")
public class PermissionRoleOrgView {

	String roleId;
	@Id
	@Column(name = "permission_id")
	int permissionId;
	@Column(name = "org_id")
	String orgId;
	@Column(name = "method")
	String method;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public int getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(int permissionId) {
		this.permissionId = permissionId;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
}
