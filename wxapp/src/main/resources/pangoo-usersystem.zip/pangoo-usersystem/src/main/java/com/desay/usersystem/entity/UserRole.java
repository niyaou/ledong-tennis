package com.desay.usersystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * 用户所在机构角色,一个用户只能有一个角色
 * 
 * @author uidq1163
 *
 */
@IdClass(UserRoleKey.class)
@Entity
@Table(name = "user_role")
public class UserRole {
    @Id
    @Column(name = "user_cid")
    private String userCid;
    @Id
    @Column(name = "role_id")
    private String roleId;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getUserCid() {
        return userCid;
    }

    public void setUserCid(String userCid) {
        this.userCid = userCid;
    }

}
