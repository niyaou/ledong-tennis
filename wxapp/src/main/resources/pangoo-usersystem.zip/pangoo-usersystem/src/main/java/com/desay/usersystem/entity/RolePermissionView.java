package com.desay.usersystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.desay.cd.DTO.PermissionDTO;

/**
 * 角色权限视图实体类
 * 
 * @author uidq1163
 *
 */
@Entity
@IdClass(PermRoleKey.class)
@Table(name = "role_permission_view")
public class RolePermissionView extends PermissionDTO {

    private static final long serialVersionUID = -2392190542800992180L;
    @Id
    @Column(name = "permission_id")
    private String permissionId;
    @Id
    @Column(name = "role_id")
    private String roleId;
    @Column(name = "parent_id")
    private String parentId;

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }
}
