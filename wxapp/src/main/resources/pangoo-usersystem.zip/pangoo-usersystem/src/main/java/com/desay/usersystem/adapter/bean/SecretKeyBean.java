package com.desay.usersystem.adapter.bean;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 三方key
 * 
 * @author uidq1887
 *
 */
@ApiModel(value = "三方key类", description = "三方key")
public class SecretKeyBean {
    @ApiModelProperty(value = "三方key", name = "key", example = "a190b738-4a2f-4a62-8b66-31d72298eea6", required = true)
    private String key;
    @ApiModelProperty(value = "对应外部服务名称", name = "name", example = "平台大屏", required = true)
    private String name;
    @ApiModelProperty(value = "有效截止时间", name = "expireTime", example = "2019-12-31", required = true)
    private String expireTime;
    @ApiModelProperty(value = "访问次数限制（每天）", name = "accessCountDay", required = false)
    private Integer accessCountDay;
    @ApiModelProperty(value = "访问次数限制总共", name = "accessCount", required = false)
    private Integer accessCount;
    @ApiModelProperty(value = "权限列表", name = "permissionList")
    private List<String> permissionList;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }

    public Integer getAccessCountDay() {
        return accessCountDay;
    }

    public void setAccessCountDay(Integer accessCountDay) {
        this.accessCountDay = accessCountDay;
    }

    public Integer getAccessCount() {
        return accessCount;
    }

    public void setAccessCount(Integer accessCount) {
        this.accessCount = accessCount;
    }

    public List<String> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List<String> permissionList) {
        this.permissionList = permissionList;
    }

}
