package com.desay.usersystem.config;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.desay.cd.DTO.ResponseDTO;

/**
 * 统一异常处理
 * 
 * @author uidq1163
 *
 */
@SuppressWarnings("rawtypes")
@ControllerAdvice
@ResponseBody
public class CommonExceptionAdvice {

	/**
	 * 400 - Bad Request
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ResponseDTO handleMissingServletRequestParameterException(MissingServletRequestParameterException e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg(e.getParameterName() + "必选参数未传");
		return responseDTO;
	}

	/**
	 * 400 - Bad Request
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseDTO handleMissingServletRequestParameterException(MethodArgumentTypeMismatchException e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg(e.getName() + "参数类型错误");
		return responseDTO;
	}

	/**
	 * 400 - Bad Request
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseDTO handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("参数解析失败:" + e.getMessage());
		return responseDTO;
	}

	/**
	 * 400 - Bad Request
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseDTO handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
		BindingResult result = e.getBindingResult();
		FieldError error = result.getFieldError();
		String field = error.getField();
		String code = error.getDefaultMessage();
		String message = String.format("%s:%s", field, code);
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("参数验证失败:" + message);
		return responseDTO;
	}

	/**
	 * 400 - Bad Request
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(BindException.class)
	public ResponseDTO handleBindException(BindException e) {
		BindingResult result = e.getBindingResult();
		FieldError error = result.getFieldError();
		String field = error.getField();
		String code = error.getDefaultMessage();
		String message = String.format("%s:%s", field, code);
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("参数绑定失败:" + message);
		return responseDTO;
	}

	/**
	 * 400 - Bad Request
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseDTO handleServiceException(ConstraintViolationException e) {
		Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
		ConstraintViolation<?> violation = violations.iterator().next();
		String message = violation.getMessage();
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("参数验证失败:" + message);
		return responseDTO;
	}

	/**
	 * 400 - Bad Request
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(ValidationException.class)
	public ResponseDTO handleValidationException(ValidationException e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("参数验证失败:" + e.getMessage());
		return responseDTO;
	}

	/**
	 * 405 - Method Not Allowed
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseDTO handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("不支持当前请求方法");
		return responseDTO;
	}

	/**
	 * 415 - Unsupported Media Type
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(HttpMediaTypeNotSupportedException.class)
	public ResponseDTO handleHttpMediaTypeNotSupportedException(Exception e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("不支持当前媒体类型:" + e.getMessage());
		return responseDTO;
	}

	/**
	 * 500 - Internal Server Error
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(Exception.class)
	public ResponseDTO handleException(Exception e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("通用异常：" + e.getMessage());
		return responseDTO;
	}

	/**
	 * 操作数据库出现异常:名称重复，外键关联
	 */
	@ResponseStatus(HttpStatus.OK)
	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseDTO handleException(DataIntegrityViolationException e) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setCode(-1);
		responseDTO.setMsg("操作数据库出现异常：字段重复、有外键关联等");
		return responseDTO;
	}
}
