package com.desay.usersystem.rest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.util.TextUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.utils.CollectionUtil;
import com.desay.cd.utils.StringUtil;
import com.desay.cd.utils.tree.IRelation;
import com.desay.cd.utils.tree.TreeNode;
import com.desay.cd.utils.tree.TreeTool;
import com.desay.usersystem.adapter.bean.RoleBean;
import com.desay.usersystem.adapter.bean.UserRoleBean;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.dao.PermissionDao;
import com.desay.usersystem.dao.PermissionRoleDao;
import com.desay.usersystem.dao.RoleDao;
import com.desay.usersystem.dao.RolePermissionViewDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.entity.Permission;
import com.desay.usersystem.entity.PermissionRole;
import com.desay.usersystem.entity.Role;
import com.desay.usersystem.entity.RolePermissionView;
import com.desay.usersystem.entity.UserRole;
import com.desay.usersystem.exception.BizException;
import com.desay.usersystem.service.OrgRoleService;
import com.desay.usersystem.service.TokenAuthorizeService;
import com.desay.usersystem.utils.Cst;
import com.desay.usersystem.utils.PageUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 用于企业工厂等机构角色管理
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/orgRole")
@Api(tags = "用于企业工厂等机构角色管理")
public class OrgRoleController {
    @Autowired
    private RoleDao roleDao;
    @Autowired
    private PermissionDao permissionDao;
    @Autowired
    private PermissionRoleDao permissionRoleDao;
    @Autowired
    private OrgRoleService orgRoleImp;
    @Autowired
    private TokenAuthorizeService authRequest;
    @Autowired
    private PangooUserDao pangooUserDao;
    @Autowired
    private UserRoleDao userRoleDao;
    @Autowired
    private RolePermissionViewDao rolepermissionDao;

    /**
     * 获取企业角色
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "获取企业角色", notes = "通过认证后的信息，token自身组织机构的企业角色和通用角色", httpMethod = "GET")
    @RequestMapping(value = "/getOrgRole", method = RequestMethod.GET)
    public Object getOrgRole(HttpServletRequest request) {
        String org = (String) request.getAttribute(Cst.ATTRIBUTE_ORG);
        List<com.desay.usersystem.entity.Role> list = roleDao.getOrgRole(org);
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(list));
    }

    /**
     * 获取机构权限列表
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "获取机构权限列表", notes = "通过登录认证后的token，获取自己机构相关权限列表", httpMethod = "GET")
    @RequestMapping(value = "/getPermissionList", method = RequestMethod.GET)
    public Object getPermissionList(HttpServletRequest request) {
        String org = (String) request.getAttribute(Cst.ATTRIBUTE_ORG);
        String tokenId = request.getHeader(Cst.HEADER_TOKEN);
        TokenDTO tokenDTO = authRequest.tokenAuthorize(tokenId);
        PangooUser pangooUser = pangooUserDao.findOne(tokenDTO.cid);
        List<Permission> list = new ArrayList<>();
        if (org.equals(Cst.NORMAL_ORG) && pangooUser.getIsManager()) {
            // 平台系统管理员
            list = permissionDao.getOrgPermissionList(org);
        } else if (!org.equals(Cst.NORMAL_ORG) && pangooUser.getIsManager()) {
            // 获取当前企业所有管理员
            List<PangooUser> listUser = pangooUserDao.getOrgManager(pangooUser.getOrgId());
            if (CollectionUtil.isNotEmpty(listUser)) {
                for (PangooUser manager : listUser) {
                    // 企业管理员：根据角色查询对应角色权限
                    List<UserRole> usrRoles = userRoleDao.findByUserCid(manager.getCid());
                    if (CollectionUtil.isNotEmpty(usrRoles)) {
                        for (UserRole userRole : usrRoles) {
                            List<RolePermissionView> listView = rolepermissionDao
                                    .getRolePermission(userRole.getRoleId());
                            Permission permission = null;
                            for (RolePermissionView rolePermissionView : listView) {
                                permission = new Permission();
                                BeanUtils.copyProperties(rolePermissionView, permission);
                                list.add(permission);
                            }
                        }
                    }
                }
            }
        }
        // 去重
        Set<Permission> sets = new HashSet<>(list);
        return ResponseDTO.ResponseDTO(sets);
    }

    /**
     * 获取机构权限列表
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "获取机构权限列表", notes = "通过登录认证后的token，获取自己机构相关权限列表", httpMethod = "GET")
    @RequestMapping(value = "/getPermissionTree", method = RequestMethod.GET)
    public Object getPermissionTree(HttpServletRequest request) {
        String org = (String) request.getAttribute(Cst.ATTRIBUTE_ORG);
        String tokenId = request.getHeader(Cst.HEADER_TOKEN);
        TokenDTO tokenDTO = authRequest.tokenAuthorize(tokenId);
        PangooUser pangooUser = pangooUserDao.findOne(tokenDTO.cid);
        List<Permission> list = new ArrayList<>();
        if (org.equals(Cst.NORMAL_ORG) && pangooUser.getIsManager()) {
            // 平台系统管理员
            list = permissionDao.getOrgPermissionList(org);

        } else if (!org.equals(Cst.NORMAL_ORG) && pangooUser.getIsManager()) {
            // 获取当前企业所有管理员
            List<PangooUser> listUser = pangooUserDao.getOrgManager(pangooUser.getOrgId());
            if (CollectionUtil.isNotEmpty(listUser)) {
                for (PangooUser manager : listUser) {
                    // 企业管理员：根据角色查询对应角色权限
                    List<UserRole> usrRoles = userRoleDao.findByUserCid(manager.getCid());
                    if (CollectionUtil.isNotEmpty(usrRoles)) {
                        for (UserRole userRole : usrRoles) {
                            List<RolePermissionView> listView = rolepermissionDao
                                    .getRolePermission(userRole.getRoleId());
                            Permission permission = null;
                            for (RolePermissionView rolePermissionView : listView) {
                                permission = new Permission();
                                BeanUtils.copyProperties(rolePermissionView, permission);
                                list.add(permission);
                            }
                        }
                    }
                }
            }
        }
        // 去重
        Set<Permission> sets = new HashSet<>(list);
        List<Permission> newList = new ArrayList<>(sets);
        return ResponseDTO.ResponseDTO(permissionTree(newList));
    }

    private JSONArray permissionTree(List<Permission> listBean) {
        // 父子关系处理
        IRelation<Permission> relation = new IRelation<Permission>() {
            @Override
            public boolean isFatherAndSon(Permission father, Permission son) {
                return father.getPermissionId().equals(son.getParentId());
            }
        };
        List<TreeNode<Permission>> treeNodes = new TreeTool<Permission>(listBean, relation).getNodeList();
        return getGroupInfoJsonObj(treeNodes);
    }

    private JSONArray getGroupInfoJsonObj(List<TreeNode<Permission>> treeNodes) {
        JSONArray jsonArray = new JSONArray();
        for (TreeNode<Permission> treeNode : treeNodes) {
            JSONObject jsonObj = new JSONObject();
            Permission permission = treeNode.getSelf();
            jsonObj.put("value", permission.getPermissionId());
            jsonObj.put("key", permission.getPermissionId());
            jsonObj.put("title", permission.getName());
            if (CollectionUtil.isNotEmpty(treeNode.getChildren())) {
                jsonObj.put("children", getGroupInfoJsonObj(treeNode.getChildren()));
            }
            jsonArray.add(jsonObj);
        }
        return jsonArray;
    }

    /**
     * 添加角色权限
     * 
     * @param permission
     * @param request
     * @return
     */
    @ApiOperation(value = "添加角色权限", notes = "添加角色权限", httpMethod = "POST")
    @RequestMapping(value = "/addRolePermission", method = RequestMethod.POST)
    public Object addRolePermission(
            @ApiParam(required = true, name = "permission", value = "权限json数据") @RequestBody(required = true) PermissionRole permission,
            HttpServletRequest request) {
        Object s = request.getAttribute(Cst.ATTRIBUTE_ORG);
        if (TextUtils.isEmpty(permission.getRoleId()) || permission.getPermissionId() == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        ResponseDTO<?> dto = orgRoleImp.addRolePermission(permission, s);
        if (dto == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        } else {
            return JsonResponseEntity.instatnce(dto);
        }
    }

    /**
     * 删除角色权限
     * 
     * @param permission
     * @param request
     * @return
     */
    @ApiOperation(value = "删除角色权限", notes = "删除角色权限", httpMethod = "DELETE")
    @RequestMapping(value = "/delRolePermission", method = RequestMethod.DELETE)
    public Object delRolePermission(
            @ApiParam(required = true, name = "permission", value = "权限json数据") @RequestBody(required = true) PermissionRole permission,
            HttpServletRequest request) {
        Object s = request.getAttribute(Cst.ATTRIBUTE_ORG);
        if (TextUtils.isEmpty(permission.getRoleId()) || permission.getPermissionId() == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        ResponseDTO<?> dto = orgRoleImp.delRolePermission(permission, s);
        if (dto == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        } else {
            return JsonResponseEntity.instatnce(dto);
        }
    }

    @ApiOperation(value = "设置用户角色", notes = "设置用户角色", httpMethod = "POST")

    @RequestMapping(value = "/setUserRole", method = RequestMethod.POST)
    public Object setUserRole(
            @ApiParam(required = true, name = "orgRole", value = "user用户信息json数据") @RequestBody(required = true) UserRoleBean orgRole,
            HttpServletRequest request) {
        Object s = request.getAttribute(Cst.ATTRIBUTE_ORG);
        ResponseDTO<?> responseDTO = orgRoleImp.setUserRole(orgRole, s);
        if (responseDTO != null) {
            return JsonResponseEntity.instatnce(responseDTO);
        }
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(""));
    }

    @ApiOperation(value = "创建角色", notes = "创建角色", httpMethod = "POST")

    @RequestMapping(value = "/creatRole", method = RequestMethod.POST)
    public Object creatRole(
            @ApiParam(required = true, name = "orgRole", value = "user用户信息json数据") @RequestBody(required = true) RoleBean orgRole,
            HttpServletRequest request) {
        TokenDTO tokenDTO = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        ResponseDTO<?> dto = null;
        try {
            dto = orgRoleImp.creatRole(orgRole, tokenDTO);
        } catch (Exception e) {
            if (e instanceof BizException) {
                // 业务异常数据回滚
                return JsonResponseEntity.instatnce(
                        ResponseDTO.NewErrorResponseDTO(e.getMessage(), ((BizException) e).getResponseCode()));
            } else {
                // 通用异常
                return JsonResponseEntity
                        .instatnce(ResponseDTO.NewErrorResponseDTO(e.getMessage(), ResponseCode.ERROR));
            }
        }
        if (dto == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(""));
        } else {
            return JsonResponseEntity.instatnce(dto);
        }
    }

    @ApiOperation(value = "删除角色", notes = "删除角色", httpMethod = "DELETE")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/delRole", method = RequestMethod.DELETE)
    public Object delRole(@RequestParam(name = "roleId", required = true) String roleId, HttpServletRequest request) {
        String org = (String) request.getAttribute(Cst.ATTRIBUTE_ORG);
        ResponseDTO<?> responseDTO = null;
        try {
            responseDTO = orgRoleImp.delRole(roleId, org);
        } catch (Exception e) {
            // 通用异常
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(e.getMessage(), ResponseCode.ERROR));
        }
        return JsonResponseEntity.instatnce(responseDTO);
    }

    @ApiOperation(value = "获取角色权限", notes = "获取角色权限", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/getRolePermission", method = RequestMethod.GET)
    public Object getRolePermission(@RequestParam(name = "roleId", required = true) String roleId,
            HttpServletRequest request) {
        Object org = request.getAttribute(Cst.ATTRIBUTE_ORG);
        Role role = roleDao.findOne(roleId);
        if (!Cst.checkOrg(org, role.getOrgId())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PERMISSION_ERROR));
        }
        List<RolePermissionView> list = rolepermissionDao.getRolePermission(roleId);
        // List<PermissionRole> list = permissionRoleDao.getRolePermission(roleId);
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(list));
    }

    @ApiOperation(value = "查询用户角色", notes = "查询用户角色", httpMethod = "GET")
    @RequestMapping(value = "/getUserRole", method = RequestMethod.GET)
    public Object getUserRole(HttpServletRequest request, @RequestParam(name = "cid", required = false) String cid) {
        TokenDTO tokenDTO = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        if (StringUtil.isNotEmpty(cid)) {
            return JsonResponseEntity.instatnce(orgRoleImp.getUserRole(cid, tokenDTO.getOrgId()));
        }
        return JsonResponseEntity.instatnce(orgRoleImp.getUserRole(tokenDTO.getCid(), tokenDTO.getOrgId()));
    }

    /**
     * 获取角色列表
     * 
     * @param roleName
     * @param request
     * @return
     */
    @ApiOperation(value = "获取角色列表", notes = "获取角色列表", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleName", value = "角色名称", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    @RequestMapping(value = "/getRoleList", method = RequestMethod.GET)
    public Object getRoleList(@RequestParam(name = "roleName", required = false) String roleName,
            @RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize, HttpServletRequest request) {
        Page<Role> result = null;
        int[] pageParams = PageUtil.creagePageAbleParams(pageNo, pageSize);
        Pageable pageable = new PageRequest(pageParams[0], pageParams[1]);
        Object org = request.getAttribute(Cst.ATTRIBUTE_ORG);
        if (StringUtil.isNotEmpty(roleName)) {
            result = roleDao.findByOrgIdAndRoleName((String) org, roleName, pageable);
        } else {
            result = roleDao.findByOrgId((String) org, pageable);
        }
        return ResponseDTO.ResponseDTO(result);
    }

    @ApiOperation(value = "修改角色", notes = "修改角色", httpMethod = "POST")

    @RequestMapping(value = "/updateRole", method = RequestMethod.POST)
    public Object updateRole(
            @ApiParam(required = true, name = "orgRole", value = "role角色信息json数据") @RequestBody(required = true) RoleBean orgRole,
            HttpServletRequest request) {
        TokenDTO tokenDTO = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        ResponseDTO<?> dto = null;
        try {
            dto = orgRoleImp.updateRole(orgRole, tokenDTO);
        } catch (Exception e) {
            if (e instanceof BizException) {
                // 业务异常数据回滚
                return JsonResponseEntity.instatnce(
                        ResponseDTO.NewErrorResponseDTO(e.getMessage(), ((BizException) e).getResponseCode()));
            } else {
                // 通用异常
                return JsonResponseEntity
                        .instatnce(ResponseDTO.NewErrorResponseDTO(e.getMessage(), ResponseCode.ERROR));
            }
        }
        if (dto == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(""));
        } else {
            return JsonResponseEntity.instatnce(dto);
        }
    }
}
