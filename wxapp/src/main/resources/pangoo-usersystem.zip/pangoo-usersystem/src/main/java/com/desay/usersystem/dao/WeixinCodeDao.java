package com.desay.usersystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.usersystem.entity.WeixinCode;

/**
 * 微信认证
 * @author uidq1163
 *
 */
public interface WeixinCodeDao extends JpaRepository<WeixinCode, String>, JpaSpecificationExecutor<WeixinCode>{

}
