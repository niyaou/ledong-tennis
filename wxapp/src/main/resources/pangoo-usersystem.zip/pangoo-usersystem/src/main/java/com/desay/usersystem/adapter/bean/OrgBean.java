package com.desay.usersystem.adapter.bean;

import com.alibaba.fastjson.JSONObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 组织机构类
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = "组织机构", description = "角色")
public class OrgBean {
    @ApiModelProperty(value = "组织机构域名", name = "orgId", example = "vo2", required = true)
    private String orgId;
    @ApiModelProperty(value = "组织机构名称", name = "name", example = "德赛西威", required = true)
    private String name;
    /** 否用当前认证系统：true 是 false 否 */
    @ApiModelProperty(value = "否用当前认证系统", name = "auth", example = "false", required = true)
    private Boolean auth;
    @ApiModelProperty(value = "认证地址", name = "authUrl", example = "http:localhost:8080/")
    private String authUrl;
    @ApiModelProperty(value = "发起认证请求类型", name = "authType", example = "POST")
    private String authType;
    @ApiModelProperty(value = "认证参数", name = "authParams", example = "{name:'',value:'',sercet_key:''}")
    private JSONObject authParams;
    @ApiModelProperty(value = "备注信息", name = "remake", example = "vo1")
    private String remark;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getAuth() {
        return auth;
    }

    public void setAuth(Boolean auth) {
        this.auth = auth;
    }

    public String getAuthUrl() {
        return authUrl;
    }

    public void setAuthUrl(String authUrl) {
        this.authUrl = authUrl;
    }

    public JSONObject getAuthParams() {
        return authParams;
    }

    public void setAuthParams(JSONObject authParams) {
        this.authParams = authParams;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }
}
