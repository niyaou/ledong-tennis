package com.desay.usersystem.feign;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.usersystem.adapter.bean.ClusterRsaCheck;

import feign.Headers;
import feign.Param;
import feign.RequestLine;

/**
 * 集群下RSA解密
 * 
 * @author uidq1163
 *
 */
public interface ClusterInterface {
    /**
     * 集群下RSA解密
     * 
     * @param content
     * @return
     */
    @Headers({ "Content-Type: application/json", "Accept: application/json" })
    @RequestLine("GET /clusterRsaDecode?content={content}")
    ResponseDTO<ClusterRsaCheck> clusterRsaDecode(@Param(value = "content") String content);
}
