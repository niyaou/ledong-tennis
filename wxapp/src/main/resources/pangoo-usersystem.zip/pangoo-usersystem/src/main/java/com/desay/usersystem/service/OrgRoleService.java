package com.desay.usersystem.service;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.usersystem.adapter.bean.RoleBean;
import com.desay.usersystem.adapter.bean.UserRoleBean;
import com.desay.usersystem.entity.PermissionRole;

/**
 * 组织结构角色权限管理实现
 * 
 * @author uidq1163
 *
 */
public interface OrgRoleService {

    /**
     * 创建角色
     * 
     * @param orgRole
     * @param org
     * @return
     */
    public ResponseDTO<?> creatRole(RoleBean orgRole, TokenDTO tokenDTO);

    /**
     * 修改角色
     * 
     * @param orgRole
     * @param org
     * @return
     */
    public ResponseDTO<?> updateRole(RoleBean orgRole, TokenDTO tokenDTO);

    /**
     * 删除角色
     * 
     * @param roleid
     * @param org
     * @return
     */
    public ResponseDTO<?> delRole(String roleid, String org);

    /**
     * 设置用户角色，只有本机构的人才可以设置自己机构
     *
     * @param orgRole
     * @param org
     *            操作者认证的机构id
     * @return
     */
    public ResponseDTO<?> setUserRole(UserRoleBean orgRole, Object org);

    /**
     * 增加角色权限
     * 
     * @param permission
     * @param org
     * @return
     */
    public ResponseDTO<?> addRolePermission(PermissionRole permission, Object org);

    /**
     * 删除角色权限
     * 
     * @param permission
     * @param org
     * @return
     */
    public ResponseDTO<?> delRolePermission(PermissionRole permission, Object org);

    /**
     * 查询用户角色信息
     * 
     * @param cid
     * @param org
     * @return
     */
    public ResponseDTO<?> getUserRole(String cid, Object org);
}
