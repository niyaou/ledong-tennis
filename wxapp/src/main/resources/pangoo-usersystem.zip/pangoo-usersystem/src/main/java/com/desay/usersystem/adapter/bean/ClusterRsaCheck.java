package com.desay.usersystem.adapter.bean;

/**
 * 集群RAS解密
 * 
 * @author uidq1163
 *
 */
public class ClusterRsaCheck {
    /** 时间 */
    private String time;
    /** 解密之后的密码 */
    private String pass;
    /** 原始密码 */
    private String content;
    /** 解密状态：true 为正确解密 false： 解密失败 */
    private Boolean flg;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Boolean getFlg() {
        return flg;
    }

    public void setFlg(Boolean flg) {
        this.flg = flg;
    }
}
