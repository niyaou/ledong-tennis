package com.desay.usersystem.adapter.bean;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 角色信息类
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = "角色信息类", description = "角色")
public class RoleBean {
    @ApiModelProperty(value = "角色id", name = "roleId", example = "111", required = false)
    String roleId;
    @ApiModelProperty(value = "角色名称", name = "roleName", example = "root", required = true)
    String roleName;
    @ApiModelProperty(value = "描述", name = "remark", example = "干啥吃")
    String remark;
    @ApiModelProperty(value = "权限列表", name = "permissionList")
    List<String> permissionList;

    public List<String> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List<String> permissionList) {
        this.permissionList = permissionList;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }
}
