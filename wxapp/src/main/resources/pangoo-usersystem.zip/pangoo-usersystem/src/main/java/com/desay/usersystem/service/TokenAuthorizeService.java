package com.desay.usersystem.service;

import java.util.List;

import com.desay.cd.DTO.PermissionDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.DTO.TokenPermission;

/**
 * token认证实现方法
 * 
 * @author uidq1163
 *
 */
public interface TokenAuthorizeService {
    /***
     * 用户token有效认证
     * 
     * @param token
     * @return
     */
    public TokenDTO tokenAuthorize(String token);

    /**
     * 用户token有效认证:单独针对集群并发的
     * 
     * @param token
     * @return
     */
    public TokenDTO tokenNettyAuthorize(String token);

    /**
     * 用户访问权限设置
     * 
     * @param token
     * @return
     */
    public TokenPermission tokenPermission(String token);

    /**
     * 获取token对应的用户权限列表
     * 
     * @param token
     * @return
     */
    public List<PermissionDTO> tokenPermissionList(String token);
}
