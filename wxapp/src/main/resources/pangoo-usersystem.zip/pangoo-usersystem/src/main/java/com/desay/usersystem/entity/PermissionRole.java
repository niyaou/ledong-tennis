package com.desay.usersystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 角色权限对应关系
 * 
 * @author uidq1163
 *
 */
@Entity
@IdClass(PermRoleKey.class)
@Table(name = "permission_role")
@ApiModel(value = "角色权限对应关系", description = "角色权限对应关系")
public class PermissionRole {
    @Id
    @ApiModelProperty(value = "权限ID", name = "permission_id", example = "权限ID")
    @Column(name = "permission_id")
    private String permissionId;
    @Id
    @ApiModelProperty(value = "角色ID", name = "role_id", example = "角色ID")
    @Column(name = "role_id")
    private String roleId;

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }
}
