package com.desay.usersystem.service;

import com.desay.cd.DTO.ResponseDTO;

/**
 * 密码认证实现类
 * 
 * @author uidq1163
 *
 */
public interface SecurityAdapterService {
    /**
     * 上次AES秘钥
     * 
     * @param token
     * @param key
     * @return
     */
    public ResponseDTO<?> uploadAESKey(String token, String key);

    /**
     * 单独针对集群并发的
     * 
     * @param token
     * @param key
     * @return
     */
    public ResponseDTO<?> uploadAESKeyNetty(String token, String key);
}
