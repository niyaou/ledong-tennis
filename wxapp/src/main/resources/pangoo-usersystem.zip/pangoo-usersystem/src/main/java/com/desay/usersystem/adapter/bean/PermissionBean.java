package com.desay.usersystem.adapter.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 权限表
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = "权限类", description = "权限")
public class PermissionBean {
    @ApiModelProperty(value = "权限名称", name = "name", example = "root", required = true)
    private String name;
    @ApiModelProperty(value = "方法、地址", name = "method", example = "/restful/**", required = true)
    private String method;
    @ApiModelProperty(value = "方法描述", name = "descs", example = "root", required = true)
    private String descs;
    /** 权限类型：1接口 2页面 */
    @ApiModelProperty(value = "权限类型", name = "type", example = "1", allowableValues = "1,2", required = true)
    private String type;
    /** 上级（父级主键ID） */
    @ApiModelProperty(value = "父级主键ID", name = "parentId", example = "1", required = false)
    private String parentId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getDescs() {
        return descs;
    }

    public void setDescs(String descs) {
        this.descs = descs;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }
}
