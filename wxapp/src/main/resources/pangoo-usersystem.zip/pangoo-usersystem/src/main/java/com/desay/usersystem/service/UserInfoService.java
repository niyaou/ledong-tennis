package com.desay.usersystem.service;

import com.desay.cd.DTO.ResponseDTO;

/**
 * 用戶信息
 * 
 * @author uidq1163
 *
 */
public interface UserInfoService {
    /**
     * 修改用户密码
     * 
     * @param cid
     *            用户cid
     * @param npwd
     *            新密码
     * @param opwd
     *            老密码
     * @return
     */
    public ResponseDTO<?> changePassword(String cid, String npwd, String opwd);
}
