package com.desay.usersystem.rest;

import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.usersystem.adapter.bean.User;
import com.desay.usersystem.adapter.bean.WxUser;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.security.VerificationCodeManager;
import com.desay.usersystem.service.RegistrationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 普通用户注册入口
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/registration")
@Api(tags = "普通用户注册入口")
public class RegisterController {
    public static Logger log = Logger.getLogger(RegisterController.class);
    @Autowired
    RegistrationService registrationImp;
    @Autowired
    VerificationCodeManager vrificationCodeManager;

    @ApiOperation(value = "普通用户注册接口", notes = "普通用户注册接口，只用于外部普通用户注册。注册后用户身份为普通用户,密码采用RSA非对称加密。手机号    必须填写", httpMethod = "POST")
    @RequestMapping(value = "/Registration", method = RequestMethod.POST)
    public Object registration(
            @ApiParam(required = true, name = "user", value = "user用户信息json数据") @RequestBody User user) {
        if (TextUtils.isBlank(user.getTelPhone()) && TextUtils.isBlank(user.getLogin())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        if (!vrificationCodeManager.checkVerificationCode(user.getVerifyCode(), user.getTelPhone())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        }
        ResponseDTO<?> response = registrationImp.registration(user);
        return JsonResponseEntity.instatnce(response);
    }

    @ApiOperation(value = "微信用户注册接口", notes = "如用户已注册，则绑定，如用户未注册则创建一个新的账户，并与微信ID绑定", httpMethod = "POST")
    @RequestMapping(value = "/wxRegistration", method = RequestMethod.POST)
    public Object wxRegistration(
            @ApiParam(required = true, name = "user", value = "user用户信息json数据") @RequestBody WxUser user) {
        if (TextUtils.isBlank(user.getTelPhone()) && TextUtils.isBlank(user.getLogin())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        if (!vrificationCodeManager.checkVerificationCode(user.getVerifyCode(), user.getTelPhone())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        }
        ResponseDTO<?> response = registrationImp.wxRegistration(user);
        return JsonResponseEntity.instatnce(response);
    }

    @ApiOperation(value = "微信扫码，绑定已有用户", notes = "微信扫码登录，与已注册用户进行绑定", httpMethod = "POST")
    @RequestMapping(value = "/bindwx", method = RequestMethod.POST)
    public Object bindwx(@ApiParam(required = true, name = "user", value = "user用户信息json数据") @RequestBody WxUser user) {
        if (TextUtils.isBlank(user.getTelPhone()) && TextUtils.isBlank(user.getLogin())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        if (!vrificationCodeManager.checkVerificationCode(user.getVerifyCode(), user.getTelPhone())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        }
        ResponseDTO<?> response = registrationImp.bindWx(user);
        return JsonResponseEntity.instatnce(response);
    }

    @ApiOperation(value = "微信解绑定已有用户", notes = "解除微信和某注册用户的绑定关系", httpMethod = "POST")
    @RequestMapping(value = "/unBindwx", method = RequestMethod.POST)
    public Object unBindwx(
            @ApiParam(required = true, name = "user", value = "user用户信息json数据") @RequestBody WxUser user) {
        if (TextUtils.isBlank(user.getTelPhone()) && TextUtils.isBlank(user.getLogin())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        if (!vrificationCodeManager.checkVerificationCode(user.getVerifyCode(), user.getTelPhone())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        }
        ResponseDTO<?> response = registrationImp.unBindWx(user);
        return JsonResponseEntity.instatnce(response);
    }

    @ApiOperation(value = "获取手机验证码", notes = "获取注册用手机验证码", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "phone", value = "用户手机号", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/getVerificationCode", method = RequestMethod.GET)
    public Object getVerificationCode(@RequestParam(name = "phone", required = true) String phone) {
        String code = vrificationCodeManager.getVerificationCode(phone);
        ResponseDTO<String> response = new ResponseDTO<>();
        response.setData(code);
        response.setCode(ResponseCode.OK.getCode());
        return JsonResponseEntity.instatnce(response);
    }

    @ApiOperation(value = "单独验证手机验证码", notes = "验证手机验证码", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "phone", value = "用户手机号", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "code", value = "验证码", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/verifyCode", method = RequestMethod.GET)
    public Object verifyCode(@RequestParam(name = "phone", required = true) String phone,
            @RequestParam(name = "code", required = true) String code) {
        if (vrificationCodeManager.checkVerificationCode(code, phone)) {
            return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(null));
        } else {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        }
    }

}
