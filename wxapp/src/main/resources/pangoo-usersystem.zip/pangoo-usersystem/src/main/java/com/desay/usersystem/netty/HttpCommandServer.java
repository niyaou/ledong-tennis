package com.desay.usersystem.netty;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.AdaptiveRecvByteBufAllocator;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.stream.ChunkedWriteHandler;
import io.netty.util.internal.logging.InternalLogger;
import io.netty.util.internal.logging.InternalLoggerFactory;

/**
 * netty 大并发处理认证接口
 * 
 * @author uidq1163
 *
 */
@Component
public class HttpCommandServer implements CommandLineRunner {
    @Value("${netty.server.port}")
    private Integer port;
    public static InternalLogger logger = InternalLoggerFactory.getInstance(HttpCommandServer.class);

    public void bindHttp(int port) throws Exception {
        // 连接处理group
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        // 事件处理group
        EventLoopGroup workerGroup = new NioEventLoopGroup(16);
        try {
            ServerBootstrap serverBootstrap = new ServerBootstrap();
            // 绑定处理group
            serverBootstrap.group(bossGroup, workerGroup);
            serverBootstrap.channel(NioServerSocketChannel.class);
            // 保持连接数
            serverBootstrap.option(ChannelOption.SO_BACKLOG, 1024 * 1024);
            // 有数据立即发送
            serverBootstrap.option(ChannelOption.TCP_NODELAY, true);
            // 日志
            serverBootstrap.handler(new LoggingHandler(LogLevel.ERROR));
            // 保持连接
            serverBootstrap.childOption(ChannelOption.SO_KEEPALIVE, true);
            // 接收缓冲区
            serverBootstrap.option(ChannelOption.SO_RCVBUF, 32 * 1024);
            // 发送缓冲区
            serverBootstrap.option(ChannelOption.SO_SNDBUF, 32 * 1024);
            // 最大接收、发送的长度
            serverBootstrap.option(ChannelOption.RCVBUF_ALLOCATOR, AdaptiveRecvByteBufAllocator.DEFAULT);
            // Boss线程内存池配置
            serverBootstrap.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);
            // Work线程内存池配置.
            serverBootstrap.childOption(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);
            // 处理新连接
            serverBootstrap.childHandler(new ChannelInitializer<SocketChannel>() {
                @Override
                protected void initChannel(SocketChannel ch) throws Exception {
                    // 请求消息解码器
                    ch.pipeline().addLast("http-decoder", new HttpRequestDecoder());
                    // 目的是将多个消息转换为单一的request或者response对象
                    ch.pipeline().addLast("http-aggregator", new HttpObjectAggregator(65536));
                    // 响应解码器
                    ch.pipeline().addLast("http-encoder", new HttpResponseEncoder());
                    // 目的是支持异步大文件传输（）
                    ch.pipeline().addLast("http-chunked", new ChunkedWriteHandler());
                    // 业务逻辑
                    ch.pipeline().addLast("CommandInHandler", new HttpCommandInHandler());
                }
            });
            ChannelFuture channelFuture = serverBootstrap.bind(port).sync();
            channelFuture.channel().closeFuture().sync();
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }

    @Override
    public void run(String... args) throws Exception {
        bindHttp(port);
    }
}
