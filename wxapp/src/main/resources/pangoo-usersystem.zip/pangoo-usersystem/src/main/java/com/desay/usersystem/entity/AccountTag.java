package com.desay.usersystem.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * 数据类型分类
 * 
 * @author uidq1163
 *
 */
@Entity
@IdClass(AccountTagKey.class)
@EntityListeners(AuditingEntityListener.class)
@Table(name = "account_tag")
public class AccountTag implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 2546116149241047251L;
    @Id
    @Column(name = "org_id", columnDefinition = "varchar(25) COMMENT '企业ID'")
    private String orgId;
    @Id
    @Column(name = "source_id", columnDefinition = "varchar(25) COMMENT '项目ID'")
    private String sourceId;
    @Id
    @Column(name = "name", columnDefinition = "varchar(50) COMMENT '用户ID，VIN、设备ID'")
    private String name;
    @Id
    @Column(name = "tag", columnDefinition = "varchar(25) COMMENT '目标名称'")
    private String tag;
    /** 权限类型：userid:1、vin:2、device:3 */
    @Id
    @Column(name = "type", length = 1, columnDefinition = "int COMMENT 'userid:1、vin:2、device:3'")
    private Integer type;
    @CreatedDate
    @Column(name = "create_time", nullable = false, insertable = true, updatable = false, columnDefinition = "datetime COMMENT '创建时间'")
    private Date createTime;
    @LastModifiedDate
    @Column(name = "update_time", insertable = true, updatable = true, columnDefinition = "datetime COMMENT '更新时间'")
    private Date updateTime;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
