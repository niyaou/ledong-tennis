package com.desay.usersystem.adapter.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
/**
 * 微信user对象
 * @author uidq1163
 *
 */
@ApiModel(value="微信user对象",description="用户对象user")
public class WxUser extends User{
    @ApiModelProperty(value="微信登录后获取的unionid",name="unionid",example="033Oxatn123sNbun1iXYtn1OxHtT",required=true)
    String unionid;
    @ApiModelProperty(value="openid",name="openid",example="033Oxatn123sNbun1iXYtn1OxHtT")
    String openid;

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getUnionid() {
        return unionid;
    }

    public void setUnionid(String unionid) {
        this.unionid = unionid;
    }
}
