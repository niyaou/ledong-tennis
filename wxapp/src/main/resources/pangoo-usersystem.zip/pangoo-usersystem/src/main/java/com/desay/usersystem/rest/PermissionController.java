package com.desay.usersystem.rest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.CollectionUtil;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.PermissionBean;
import com.desay.usersystem.dao.PermissionDao;
import com.desay.usersystem.dao.PermissionRoleDao;
import com.desay.usersystem.entity.Permission;
import com.desay.usersystem.entity.PermissionRole;
import com.desay.usersystem.utils.Cst;
import com.desay.usersystem.utils.PageUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 权限管理
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/permission")
@Api(tags = "系统权限管理")
public class PermissionController {
    @Autowired
    private PermissionDao permissionDao;
    @Autowired
    private PermissionRoleDao permissionRoleDao;

    /**
     * 增加权限
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "增加权限", notes = "增加权限", httpMethod = "POST")
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseDTO<?> add(HttpServletRequest request, @RequestBody PermissionBean permissionBean) {
        Permission permission = new Permission();
        List<Permission> list = permissionDao.findByMethodAndType(permissionBean.getMethod(), permissionBean.getType());
        if (CollectionUtil.isNotEmpty(list)) {
            return ResponseDTO.NewErrorResponseDTO("权限已经存在", ResponseCode.ERROR);
        }
        if (StringUtil.isNotEmpty(permissionBean.getParentId())) {
            Permission parentPermission = permissionDao.findOne(permissionBean.getParentId());
            if (null == parentPermission) {
                return ResponseDTO.NewErrorResponseDTO("父级权限不存在", ResponseCode.ERROR);
            }
        }
        BeanUtils.copyProperties(permissionBean, permission);
        permission.setOrgId(Cst.NORMAL_ORG);
        permissionDao.save(permission);
        return ResponseDTO.ResponseDTO("");
    }

    /**
     * 删除权限
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "删除权限", notes = "删除权限", httpMethod = "DELETE")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseDTO<?> add(HttpServletRequest request, @PathVariable("id") String permissionId) {
        List<PermissionRole> list = permissionRoleDao.getRolePermission(permissionId);
        if (CollectionUtil.isNotEmpty(list)) {
            return ResponseDTO.NewErrorResponseDTO("权限已经被占用不能删除", ResponseCode.ERROR);
        }
        Permission permission = permissionDao.findOne(permissionId);
        List<Permission> parentPermissions = permissionDao.findByParentId(permission.getPermissionId());
        if (CollectionUtil.isNotEmpty(parentPermissions)) {
            return ResponseDTO.NewErrorResponseDTO("当前权限有子节点不能删除", ResponseCode.ERROR);
        }
        permissionDao.delete(permission);
        return ResponseDTO.ResponseDTO("");
    }

    /**
     * 获取权限列表
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "获取权限列表", notes = "获取权限列表", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNo", value = "页码", required = false, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页数据条数", required = false, dataType = "string", paramType = "query") })
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public Object getRoleList(@RequestParam(value = "pageNo", required = false) String pageNo,
            @RequestParam(value = "pageSize", required = false) String pageSize, HttpServletRequest request) {
        Page<Permission> result = null;
        int[] pageParams = PageUtil.creagePageAbleParams(pageNo, pageSize);
        Pageable pageable = new PageRequest(pageParams[0], pageParams[1]);
        result = permissionDao.findAll(pageable);
        return ResponseDTO.ResponseDTO(result);
    }
}
