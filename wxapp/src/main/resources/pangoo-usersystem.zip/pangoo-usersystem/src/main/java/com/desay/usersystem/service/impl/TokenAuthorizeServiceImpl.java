package com.desay.usersystem.service.impl;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.session.ExpiringSession;
import org.springframework.stereotype.Service;

import com.desay.cd.DTO.PermissionDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.DTO.TokenPermission;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.usersystem.dao.PermissionDao;
import com.desay.usersystem.service.TokenAuthorizeService;
import com.desay.usersystem.utils.Cst;

/**
 * token认证实现方法
 * 
 * @author uidq1163
 *
 */
@Service
public class TokenAuthorizeServiceImpl extends AuthorizeBase implements TokenAuthorizeService {
    @Autowired
    PermissionDao permissionDao;

    /***
     * 用户token有效认证
     * 
     * @param token
     * @return
     */
    @Override
    public TokenDTO tokenAuthorize(String token) {
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        TokenDTO tokenDTO = null;
        if (session != null) {
            tokenDTO = session.getAttribute(ConstantUtils.SESSION_TOKEN);
            tokenDTO.AESKey = session.getAttribute(Cst.AES_KEY);
            session.setLastAccessedTime(System.currentTimeMillis());
            findByIndexNameSessionRepository.save(session);
        }
        return tokenDTO;
    }

    /**
     * 用户token有效认证:单独针对集群并发的
     * 
     * @param token
     * @return
     */
    @Override
    public TokenDTO tokenNettyAuthorize(String token) {
        ExpiringSession session = redisTemplate.opsForValue().get(token);
        TokenDTO tokenDTO = null;
        if (session != null) {
            try {
                tokenDTO = session.getAttribute(ConstantUtils.SESSION_TOKEN);
                tokenDTO.AESKey = session.getAttribute(Cst.AES_KEY);
                session.setLastAccessedTime(System.currentTimeMillis());
                redisTemplate.opsForValue().set(session.getId(), session, 60 * 30, TimeUnit.SECONDS);
                redisTemplateNetty.opsForValue().set(tokenDTO.getCid() + tokenDTO.getClient(), session.getId(), 60 * 30,
                        TimeUnit.SECONDS);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return tokenDTO;
    }

    /**
     * 用户访问权限设置
     * 
     * @param token
     * @return
     */
    @Override
    public TokenPermission tokenPermission(String token) {
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        TokenPermission permissionDTO = null;
        TokenDTO tokenDTO = null;
        if (session != null) {
            permissionDTO = new TokenPermission();
            tokenDTO = session.getAttribute(ConstantUtils.SESSION_TOKEN);
            session.setLastAccessedTime(System.currentTimeMillis());
            permissionDTO.cid = tokenDTO.cid;
            permissionDTO.token = tokenDTO.token;
            permissionDTO.client = tokenDTO.client;
            permissionDTO.orgId = tokenDTO.orgId;
            permissionDTO.AESKey = session.getAttribute(Cst.AES_KEY);
            if (null != session.getAttribute(Cst.SESSION_PERMISSIOM)) {
                List<PermissionDTO> list = session.getAttribute(Cst.SESSION_PERMISSIOM);
                permissionDTO.permissionList = list;
            }
        }
        return permissionDTO;
    }

    /**
     * 用户访问权限设置
     * 
     * @param token
     * @return
     */
    @Override
    public List<PermissionDTO> tokenPermissionList(String token) {
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        if (session != null) {
            List<PermissionDTO> list = session.getAttribute(Cst.SESSION_PERMISSIOM);
            return list;
        }
        return null;
    }
}
