package com.desay.usersystem.rest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.AccountTagBean;
import com.desay.usersystem.dao.AccountTagDao;
import com.desay.usersystem.entity.AccountTag;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 账户TAG管理
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/accounttag")
@Api(tags = "账户TAG管理")
public class AccountTagController {

    @Autowired
    private AccountTagDao accountTagDao;
    @Resource
    RedisTemplate<String, Object> redisTemplateTag;

    /**
     * 获取企业角色
     * 
     * @param request
     * @return
     */
    @ApiOperation(value = "增加需要处理的设备or用户or车机", notes = "增加需要处理的设备or用户or车机", httpMethod = "POST")
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseDTO<?> addOrg(HttpServletRequest request, @RequestBody AccountTagBean accountTagBean) {
        TokenDTO token = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        AccountTag accountTag = new AccountTag();
        BeanUtils.copyProperties(accountTagBean, accountTag);
        if (StringUtil.isEmpty(accountTagBean.getOrgId())) {
            accountTagBean.setOrgId(token.getOrgId());
        }
        accountTagDao.save(accountTag);
        com.desay.cd.beans.AccountTag accountTagbean = new com.desay.cd.beans.AccountTag();
        BeanUtils.copyProperties(accountTag, accountTagbean);
        // 写入缓存
        redisTemplateTag.opsForValue().set("tag:" + accountTag.getName(), accountTagbean);

        return ResponseDTO.ResponseDTO("");
    }
}
