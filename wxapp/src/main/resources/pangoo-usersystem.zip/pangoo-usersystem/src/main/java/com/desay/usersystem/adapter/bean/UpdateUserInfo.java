package com.desay.usersystem.adapter.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 用户对象
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = "user更新对象", description = "用户更新对象")
public class UpdateUserInfo {
    @ApiModelProperty(value = "电话", name = "telPhone", example = "13988888888", required = true)
    String telPhone;
    @ApiModelProperty(value = "邮箱", name = "email", example = "xingguo@163.com")
    String email;
    @ApiModelProperty(value = "血型", name = "bloodType", example = "A,B,AB,O")
    String bloodType;
    @ApiModelProperty(value = "头像", name = "avatar", example = "base64")
    String avatar;
    @ApiModelProperty(value = "昵称", name = "nickName", example = "你大爷")
    String nickName;

    public String getTelPhone() {
        return telPhone;
    }

    public void setTelPhone(String telPhone) {
        this.telPhone = telPhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

}
