package com.desay.usersystem.rest;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.User;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.dao.OrganizationDao;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.service.OrgUserRegisterService;
import com.desay.usersystem.service.impl.OrgServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 企业用户注册入口
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/orgRegistration")
@Api(tags = "企业用户注册入口")
public class OrgUserRegisterController {
    Logger log = Logger.getLogger(OrgUserRegisterController.class);
    @Autowired
    private OrgUserRegisterService registrationImp;
    @Autowired
    private OrganizationDao organizationDao;
    @Autowired
    private OrgServiceImpl orgServiceImpl;
    @Autowired
    private PangooUserDao pangooUserDao;

    /**
     * 企业用户用户注册
     * 
     * @param user
     * @param request
     * @return
     */
    @ApiOperation(value = "企业用户注册接口", notes = "企业用户注册接口，只用于内部企业用户注册（并且在平台鉴权）。", httpMethod = "POST")
    @RequestMapping(value = "/Registration", method = RequestMethod.POST)
    public Object registration(
            @ApiParam(required = true, name = "postData", value = "user用户信息json数据") @RequestBody(required = true) User user,
            HttpServletRequest request) {
        String org = user.getOrg();
        if (StringUtil.isEmpty(org)) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        if (null == organizationDao.findOne(org)) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_ORG_ERROR));
        }
        if (TextUtils.isBlank(user.getTelPhone()) && TextUtils.isBlank(user.getLogin())) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR));
        }
        ResponseDTO<?> response = registrationImp.registration(user.getPassword(), user.getTelPhone(), user.getEmail(),
                user.getLogin(), org);
        return JsonResponseEntity.instatnce(response);
    }

    /**
     * 添加企业管理员
     * 
     * @param user
     * @param request
     * @return
     */
    @ApiOperation(value = "添加企业管理员入口", notes = "添加企业管理员接口，只允许超级管理员调用", httpMethod = "POST")
    @RequestMapping(value = "/creatRoot", method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userName", value = "管理员用户名", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "orgId", value = "企业id", required = true, dataType = "string", paramType = "query"), })
    public Object creatRoot(
            @ApiParam(required = true, name = "userName", value = "用户名") @RequestParam(required = true) String userName,
            @ApiParam(required = true, name = "orgId", value = "企业域名") @RequestParam(required = true) String orgId,
            HttpServletRequest request) {
        return orgServiceImpl.addOrgMember(orgId, Boolean.TRUE, userName);
    }

    @ApiOperation(value = "添加企业成员入口", notes = "添加企业成员入口，用于企业自主鉴权的企业", httpMethod = "POST")
    @RequestMapping(value = "/addOrgMember", method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userName", value = "管理员用户名", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "orgId", value = "企业id", required = true, dataType = "string", paramType = "query"), })
    public Object addLDAPUser(
            @ApiParam(required = true, name = "userName", value = "用户名") @RequestParam(required = true) String userName,
            @ApiParam(required = true, name = "orgId", value = "企业域名") @RequestParam(required = true) String orgId,
            HttpServletRequest request) {

        return orgServiceImpl.addOrgMember(orgId, Boolean.FALSE, userName);
    }

    @ApiOperation(value = "冻结用户", notes = "冻结用户", httpMethod = "PUT")
    @RequestMapping(value = "/{cid}/frozen", method = RequestMethod.PUT)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cid", value = "用户主键id", required = true, dataType = "string", paramType = "path") })
    public Object frozen(@PathVariable(value = "cid", required = true) String cid, HttpServletRequest request) {
        PangooUser pangooUser = pangooUserDao.findOne(cid);
        // 账户状态:1有效,0:无效
        pangooUser.setStatus(Boolean.FALSE);
        pangooUserDao.save(pangooUser);
        return ResponseDTO.ResponseDTO("");
    }

    @ApiOperation(value = "解冻用户", notes = "解冻用户", httpMethod = "PUT")
    @RequestMapping(value = "/{cid}/unfrozen", method = RequestMethod.PUT)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cid", value = "用户主键id", required = true, dataType = "string", paramType = "path") })
    public Object unfrozen(@PathVariable(value = "cid", required = true) String cid, HttpServletRequest request) {
        PangooUser pangooUser = pangooUserDao.findOne(cid);
        // 账户状态:1有效,0:无效
        pangooUser.setStatus(Boolean.TRUE);
        pangooUserDao.save(pangooUser);
        return ResponseDTO.ResponseDTO("");
    }

    @ApiOperation(value = "用户审核", notes = "用户审核", httpMethod = "PUT")
    @RequestMapping(value = "/{cid}/verify", method = RequestMethod.PUT)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cid", value = "用户主键id", required = true, dataType = "string", paramType = "path") })
    public Object verify(@PathVariable(value = "cid", required = true) String cid, HttpServletRequest request) {
        PangooUser pangooUser = pangooUserDao.findOne(cid);
        // 用户审核状态:1审核成功 0待审核
        pangooUser.setUserStatus(Boolean.TRUE);
        pangooUserDao.save(pangooUser);
        return ResponseDTO.ResponseDTO("");
    }
}
