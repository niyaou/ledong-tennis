package com.desay.usersystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.desay.cd.DTO.UserInfoDTO;

/**
 * 用户角色视图实体类
 * 
 * @author uidq1163
 *
 */
@Entity
@Table(name = "user_role_view")
public class UserRoleView extends UserInfoDTO {
    @Column(name = "update_date_time")
    String updateDateTime;
    @Column(name = "avatar")
    String avatar;
    @Column(name = "nick_name")
    String nickName;
    @Column(name = "user_status")
    Boolean userStatus;

    public UserInfoDTO toUserInfoDTO() {
        setPassword(null);
        updateDateTime = null;
        return this;
    }

    public String getUpdateDateTime() {
        return updateDateTime;
    }

    public void setUpdateDateTime(String updateDateTime) {
        this.updateDateTime = updateDateTime;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public Boolean getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(Boolean userStatus) {
        this.userStatus = userStatus;
    }
}
