package com.desay.usersystem.security;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

/**
 * AES秘钥生产器
 * @author uidq1163
 *
 */
@Service
public class AesKeyManager {
    public static Logger log = Logger.getLogger(AesKeyManager.class);
    /**
     * 创建秘钥：16位
     * @return
     */
    public static String creatKey(){
        return RandomStringUtils.random(16,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456");
    }
}
