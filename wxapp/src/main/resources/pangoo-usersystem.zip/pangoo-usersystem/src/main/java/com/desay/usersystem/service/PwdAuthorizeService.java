package com.desay.usersystem.service;

import javax.servlet.http.HttpSession;

import com.desay.cd.DTO.ResponseDTO;

/**
 * 密码认证实现类
 * 
 * @author uidq1163
 *
 */
public interface PwdAuthorizeService {

    /**
     * 登出删除session
     * 
     * @param token
     * @return
     */
    public boolean logout(String token);;

    /**
     * 删除认证信息
     * 
     * @param token
     * @return
     */
    public boolean logoutNetty(String token);

    /**
     * 用户登录验证
     * 
     * @param name
     * @param pwd
     * @param clientId
     * @param org
     * @param verifyCode
     * @param session
     * @return
     */
    public ResponseDTO<?> login(String name, String pwd, String clientId, String org, String verifyCode,
            HttpSession session);

    /**
     * 用户登录验证:针对集群并发
     * 
     * @param name
     * @param pwd
     * @param clientId
     * @param org
     * @param verifyCode
     * @return
     */
    public ResponseDTO<?> login(String name, String pwd, String clientId, String org, String verifyCode);

    /**
     * loginToLdap
     * 
     * @param name
     * @param pwd
     * @param clientId
     * @param org
     * @param verifyCode
     * @param session
     * @return
     */
    public ResponseDTO<?> loginToLdap(String name, String pwd, String clientId, String org, String verifyCode,
            HttpSession session);
}
