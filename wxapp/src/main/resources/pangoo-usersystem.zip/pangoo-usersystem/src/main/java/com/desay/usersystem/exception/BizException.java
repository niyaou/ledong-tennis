package com.desay.usersystem.exception;

import com.desay.cd.ResponseCode;

/**
 * 业务异常
 * 
 * @author uidq1163
 *
 */
@SuppressWarnings("serial")
public class BizException extends RuntimeException {

	private String message;
	private ResponseCode responseCode;
	private Exception exception;

	public BizException(String message) {
		this.message = message;
	}

	public BizException(Exception exception) {
		super();
		this.exception = exception;
	}

	public Exception getException() {
		return this.exception;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

	public ResponseCode getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(ResponseCode responseCode) {
		this.responseCode = responseCode;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setException(Exception exception) {
		this.exception = exception;
	}

	public BizException(ResponseCode responseCode, String message) {
		super(message);
		this.message = message;
		this.responseCode = responseCode;
	}
}
