package com.desay.usersystem.security;

import org.apache.http.util.TextUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.common.auth.DateUtils;
import com.desay.cd.utils.MD5Util;
import com.desay.usersystem.config.GetApplicationContext;
import com.desay.usersystem.utils.Cst;

/**
 * 安全验证
 * 
 * @author uidq1163
 *
 */
public class SecurityChecker {
    private static Logger logger = LoggerFactory.getLogger(SecurityChecker.class);
    private String time;
    private String pass;
    private boolean safty = false;
    RsaKeyManager rsaKeyManager = GetApplicationContext.getBean(RsaKeyManager.class);

    public SecurityChecker decodeDES(String text) {
        try {
            // 时间(14)+
            String str = rsaKeyManager.clusterDecode(text);
            this.time = str.substring(0, 14);
            this.pass = str.substring(14, str.length());
        } catch (Exception e) {
            this.safty = this.safty && Boolean.FALSE;
            logger.error(e.getMessage(), e);
        }
        return this;
    }

    public String getTime() {
        return time;
    }

    public String getPass() {
        return pass;
    }

    public boolean checkPass(String srcPwd) {
        return MD5Util.md5(getPass()).equals(srcPwd);
    }

    public SecurityChecker checkTime() {
        if (TextUtils.isEmpty(this.time)) {
            this.safty = false;
        } else {
            try {
                // 对比时间差异，不得超过2分钟
                long timeOff = DateUtils.contrastDateTime(time, ConstantUtils.DATA_FORMAT);
                if (Math.abs(timeOff) < Cst.MILLISECOND * Cst.SECONDS * Cst.TWO) {
                    this.safty = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
                this.safty = false;
            }
        }
        return this;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("pass:").append(this.pass).append(",");
        sb.append("time:").append(this.time).append(",");
        sb.append("safty:").append(this.safty).append(",");
        return sb.toString();
    }

    public boolean isSafty() {
        return safty;
    }
}
