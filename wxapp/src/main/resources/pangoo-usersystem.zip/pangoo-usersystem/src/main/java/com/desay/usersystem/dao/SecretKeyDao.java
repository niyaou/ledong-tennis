package com.desay.usersystem.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.usersystem.entity.SecretKey;

/**
 * 三方接口授权
 * 
 * @author uidq1163
 *
 */
public interface SecretKeyDao extends JpaRepository<SecretKey, String>, JpaSpecificationExecutor<SecretKey> {

    /**
     * 根据三方key名称获取key列表
     * 
     * @param name
     * @param pageable
     * @return
     */
    Page<SecretKey> findByName(String name, Pageable pageable);

    /**
     * 根据三方key名称获取key列表
     * 
     * @param name
     * @param pageable
     * @return
     */
    SecretKey findByName(String name);

}
