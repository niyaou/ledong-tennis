package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.PermissionRoleOrgView;

/**
 * 
 * @author uidq1163
 *
 */
public interface PermissionRoleOrgViewDao extends JpaRepository<PermissionRoleOrgView, String>, JpaSpecificationExecutor<PermissionRoleOrgView> {
    /**
     * 获取角色权限
     * @param role
     * @return
     */
	@Query("select t from PermissionRoleOrgView t where t.roleId = :role")
    List<PermissionRoleOrgView> getRolePermission(@Param("role") String role);
}
