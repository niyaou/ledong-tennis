package com.desay.usersystem.config;

import org.apache.tomcat.util.threads.ThreadPoolExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.desay.usersystem.interceptor.AllIntercepter;

/**
 * 
 * @author uidq1343
 * 
 */
@Configuration
@EnableAsync
public class WebConfig extends WebMvcConfigurerAdapter {
    @Autowired
    AllIntercepter allIntercepter;

    /**
     * 配置拦截器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(allIntercepter).addPathPatterns("/**").excludePathPatterns("/getPublicKey",
                "/getPassWordRSA", "/pwdAuthorize", "/pwdAuthorize2", "/pwdAuthorizeldap", "/wxCodeAuthorize",
                "/clusterRsaDecode", "/registration/**", "/orgRegistration/Registration", "/token**");
    }

    @Bean
    public ThreadPoolTaskExecutor defaultThreadPool() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        // 核心线程数目
        executor.setCorePoolSize(16);
        // 指定最大线程数
        executor.setMaxPoolSize(64);
        // 队列中最大的数目
        executor.setQueueCapacity(16);
        // 线程名称前缀
        executor.setThreadNamePrefix("defaultThreadPool_");
        // rejection-policy：当pool已经达到max size的时候，如何处理新任务
        // CALLER_RUNS：不在新线程中执行任务，而是由调用者所在的线程来执行
        // 对拒绝task的处理策略
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        // 线程空闲后的最大存活时间
        executor.setKeepAliveSeconds(60);
        // 加载
        executor.initialize();
        return executor;
    }

    // 过滤器
    //    @Bean
    //    public FilterRegistrationBean filterRegist() {
    //        FilterRegistrationBean frBean = new FilterRegistrationBean();
    //        frBean.setFilter(new MyFilter());
    //        frBean.addUrlPatterns("/*");
    //        return frBean;
    //    }
    // 监听器
    //    @Bean
    //    public ServletListenerRegistrationBean listenerRegist() {
    //        ServletListenerRegistrationBean srb = new ServletListenerRegistrationBean();
    //        srb.setListener(new MyHttpSessionListener());
    //        System.out.println("listener");
    //        return srb;
    //    }
}
