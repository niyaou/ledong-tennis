package com.desay.usersystem.config;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.desay.cd.log.LogActionEnum;
import com.desay.cd.log.LogServiceEnum;
import com.desay.cd.log.LoggerUtil;
import com.desay.cd.log.MicroLog;

/**
 * 
 * @Description： 切面日志
 * 
 * @author Shouyi.Huang@desay-svautomotive.com on
 *         [2019年9月10日下午5:19:55]
 * @Modified By： [修改人] on [修改日期] for [修改说明]
 *
 */
@Aspect
@Component
public class WebLogAspect {

    @Pointcut("execution(* com.desay.usersystem.rest.*.*(..))")
    public void pointLog() {
    }

    @Around("pointLog()")
    public Object timeAround(ProceedingJoinPoint joinPoint) throws Throwable {
        // 接收到请求，记录请求内容
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        // 获取返回结果集
        Object obj = joinPoint.proceed(joinPoint.getArgs());
        //写入日志
        MicroLog microLog = new MicroLog();
        microLog.setMessageId(request.getHeader("messageId"));
        microLog.setCreateTime(System.currentTimeMillis());
        microLog.setIp(LoggerUtil.getCliectIp(request));
        microLog.setUserId(request.getHeader("userId"));
        microLog.setMessage(
                request.getMethod() + " " + request.getRequestURL().toString() + " " + JSON.toJSONString(obj));
        microLog.setOpt(LogActionEnum.GETDATA);
        microLog.setType(LogServiceEnum.USERSYSTEM);
        microLog.setErrorType("info");
        LoggerUtil.writeInfo(microLog);
        return obj;
    }
}