package com.desay.usersystem.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.MD5Util;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.OrgBean;
import com.desay.usersystem.dao.OrgUserViewDao;
import com.desay.usersystem.dao.OrganizationDao;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.OrgUserView;
import com.desay.usersystem.entity.Organization;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.service.OrgService;
import com.desay.usersystem.utils.PageUtil;

/**
 * 组织结构角色权限管理实现
 * 
 * @author uidq1163
 *
 */
@Service
public class OrgServiceImpl implements OrgService {
    Logger log = Logger.getLogger(OrgServiceImpl.class);
    @Autowired
    private OrganizationDao organizationDao;

    @Autowired
    private OrgUserViewDao orgUserViewDao;

    @Autowired
    private PangooUserDao pangooUserDao;

    @Override
    public ResponseDTO<?> creatOrg(OrgBean orgBean, String parentId) {
        Organization organization = new Organization();
        BeanUtils.copyProperties(orgBean, organization);
        organization.setRemake(orgBean.getRemark());
        if (null != organizationDao.findOne(orgBean.getOrgId())) {
            return ResponseDTO.NewErrorResponseDTO("机构域名已经存在！", ResponseCode.AUTH_ORG_ERROR);
        }
        organization.setParentId(parentId);
        if (StringUtil.isNotEmpty(organization.getParentId())) {
            if (null == organizationDao.findOne(organization.getParentId())) {
                return ResponseDTO.NewErrorResponseDTO("机构域名不存在！", ResponseCode.AUTH_ORG_ERROR);
            }
        }
        organization.setAuthParams(JSON.toJSONString(orgBean.getAuthParams()));
        organizationDao.save(organization);
        return ResponseDTO.ResponseDTO("");
    }

    @Override
    public ResponseDTO<?> delOrg(String org) {
        return null;
    }

    @Override
    public ResponseDTO<?> exploreOrg(String org, String pageNo, String pageSize) {
        int[] pageParams = PageUtil.creagePageAbleParams(pageNo, pageSize);
        Pageable pageable = new PageRequest(pageParams[0], pageParams[1]);
        Page<Organization> result = organizationDao.findByParentId(org, pageable);
        return ResponseDTO.ResponseDTO(result);
    }

    @Override
    public ResponseDTO<?> exploreOrgUser(String orgId, String isManager, String pageNo, String pageSize) {
        int[] pageParams = PageUtil.creagePageAbleParams(pageNo, pageSize);
        Pageable pageable = new PageRequest(pageParams[0], pageParams[1]);
        Page<OrgUserView> result = null;
        if (StringUtil.isEmpty(isManager)) {
            result = orgUserViewDao.findByOrgId(orgId, pageable);
        } else {
            result = orgUserViewDao.findByOrgIdAndIsManager(orgId, isManager, pageable);
        }

        return ResponseDTO.ResponseDTO(result);
    }

    @Override
    public ResponseDTO<?> addOrgMember(String orgId, Boolean isManager, String userName) {
        PangooUser newUser = new PangooUser();
        List<Organization> org = organizationDao.findByOrgId(orgId);
        if (org == null || org.size() == 0) {
            return ResponseDTO.NewErrorResponseDTO("当前企业不存在", ResponseCode.ERROR);
        } else {
            PangooUser pangooUser = pangooUserDao.findByUserNameAndOrg(userName, orgId);
            if (null != pangooUser) {
                return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_EXISTED_ERROR);
            }
            // 不是管理员并且是在平台鉴权：不允许直接添加
            if (!isManager && !org.get(0).getAuth()) {
                // 企业自主鉴权：true 是 false 否
                return ResponseDTO.NewErrorResponseDTO("企业成员并且平台鉴权、不允许直接添加", ResponseCode.ERROR);
            }
            newUser.setLogin(userName);
            newUser.setOrgId(orgId);
            newUser.setUserStatus(isManager);
            newUser.setIsManager(isManager);
            newUser.setStatus(Boolean.TRUE);
            if (isManager && !org.get(0).getAuth()) {
                // 企业自主鉴权：true 是 false 否
                // 系统默认密码：12345678
                newUser.setPassword(MD5Util.md5("12345678"));
            }
            newUser.setSourceId("PLATFORM");

            pangooUserDao.save(newUser);
            return ResponseDTO.ResponseDTO("");
        }

    }

}
