package com.desay.usersystem.adapter.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户登录异常实体类
 * 
 * @author uidq1163
 *
 */
public class LogInError implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 8064978822802324575L;
    /** 登录名称 */
    String login;
    /** 登录端 */
    String client;
    /** 登录错误次数 */
    Integer loginErrCounts;
    /** 最近登录异常时间 */
    Long loginErrTime;
    /** 最近正常登录时间 */
    Date lastLoginDatetime;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Integer getLoginErrCounts() {
        return loginErrCounts;
    }

    public void setLoginErrCounts(Integer loginErrCounts) {
        this.loginErrCounts = loginErrCounts;
    }

    public Long getLoginErrTime() {
        return loginErrTime;
    }

    public void setLoginErrTime(Long loginErrTime) {
        this.loginErrTime = loginErrTime;
    }

    public Date getLastLoginDatetime() {
        return lastLoginDatetime;
    }

    public void setLastLoginDatetime(Date lastLoginDatetime) {
        this.lastLoginDatetime = lastLoginDatetime;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }
}
