package com.desay.usersystem.utils;

import org.apache.commons.lang.StringUtils;

public class PageUtil {
    public static final int PAGE = 1;
    public static final int DEFAULT_SIZE = 20;
    
    
    /**
     * 根据传入的数据构造分页查询参数
     * @param pageNo
     * @param pageSize
     * @return
     */
    public static int[] creagePageAbleParams(String pageNo,String pageSize) {
        Integer pageNoInt = null;
        Integer pageSizeInt = null;
        int[] arr=new int[2];
        try {
            pageNoInt = StringUtils.isNotEmpty(pageNo) ? Integer.parseInt(pageNo) : null;
            pageSizeInt = StringUtils.isNotEmpty(pageSize) ? Integer.parseInt(pageSize) : null;
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        if(pageNoInt == null || pageSizeInt == null) {
             pageNoInt = PAGE;
             pageSizeInt = DEFAULT_SIZE; 
        }
        arr[0]=pageNoInt-1;
        arr[1]=pageSizeInt;
        
        return   arr;
        
    }

}
