package com.desay.usersystem.service.impl;

import java.util.UUID;

import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.security.SecurityChecker;
import com.desay.usersystem.security.VerificationCodeManager;
import com.desay.usersystem.utils.Cst;

/**
 * 用户注册
 * 
 * @author uidq1163
 *
 */
public abstract class BaseRegisterServiceImpl {
    @Autowired
    PangooUserDao pangooUserDao;
    @Autowired
    VerificationCodeManager vrificationCodeManager;

    /**
     * 创建用户CID。也可由数据库创建cid策略
     *
     * @return
     */
    String creatCid() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }

    /**
     * 注册校验此账户是否可以正常注册 首先判断账户是否存在。再判断密码格式
     * 
     * @param password
     * @param phone
     * @param email
     * @param username
     * @param org
     * @return
     */
    ResponseDTO<?> checkPreRegister(String password, String phone, String email, String username, String org) {
        if (TextUtils.isEmpty(org)) {
            org = Cst.NORMAL_ORG;
        }
        PangooUser info = null;
        if (StringUtil.isNotEmpty(email)) {
            info = pangooUserDao.exist(phone, username, email, org);
        } else {
            info = pangooUserDao.exist(phone, username, org);
        }
        if (!checkPwdlegal(password)) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_PWD_LEGAL_ERROR);
        } else if (info != null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_EXISTED_ERROR);
        } else {
            return null;
        }
    }

    /**
     * 检测密码格式是否合法
     *
     * @param pwd
     * @return
     */
    boolean checkPwdlegal(String pwd) {
        if (TextUtils.isEmpty(pwd)) {
            return false;
        }
        return pwd.length() > 7;
    }

    /**
     * 判断加密密码是否合法
     * 
     * @param passwd
     * @return
     */
    public SecurityChecker checkerEffectiveness(String passwd) {
        SecurityChecker checker = new SecurityChecker();
        return checker.decodeDES(passwd).checkTime();
    }
}
