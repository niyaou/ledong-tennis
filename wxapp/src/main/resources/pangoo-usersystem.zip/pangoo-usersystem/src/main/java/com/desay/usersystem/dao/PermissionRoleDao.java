package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.PermissionRole;

/**
 * 用户角色权限
 * 
 * @author uidq1163
 *
 */
public interface PermissionRoleDao
        extends JpaRepository<PermissionRole, String>, JpaSpecificationExecutor<PermissionRole> {

    /**
     * 获取角色权限列表
     * 
     * @param role
     * @return
     */
    @Query("select t from PermissionRole t where t.roleId = :role")
    List<PermissionRole> getRolePermission(@Param("role") String role);

    /**
     * 获取角色权限列表
     * 
     * @param role
     * @return
     */
    @Query("select t from PermissionRole t where t.permissionId = :permissionId")
    List<PermissionRole> getRolePermissionByPermissionId(@Param("permissionId") String permissionId);

    /**
     * 获取角色权限
     * 
     * @param role
     * @param permissionId
     * @return
     */
    @Query("select t from PermissionRole t where t.roleId = :role and t.permissionId = :permissionId")
    PermissionRole findOne(@Param("role") String role, @Param("permissionId") String permissionId);

    /**
     * 删除角色权限
     * 
     * @param permissionId
     * @return
     */
    @Modifying
    @Query("delete from PermissionRole t where t.permissionId = :permissionId")
    void delRolePermission(@Param("permissionId") String permissionId);

    /**
     * 删除角色权限
     * 
     * @param roleId
     * @return
     */
    @Modifying
    @Query("delete from PermissionRole t where t.roleId = :role")
    void delRolePermissionByRoleId(@Param("role") String roleId);
}
