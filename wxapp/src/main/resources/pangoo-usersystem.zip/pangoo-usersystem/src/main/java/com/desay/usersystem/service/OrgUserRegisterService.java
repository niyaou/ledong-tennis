package com.desay.usersystem.service;

import com.desay.cd.DTO.ResponseDTO;

/**
 * 用戶注册实现类
 * 
 * @author uidq1163
 *
 */
public interface OrgUserRegisterService {

    /**
     * 用戶注册
     * 
     * @param password
     * @param phone
     * @param email
     * @param username
     * @param org
     * @return
     */
    public ResponseDTO<?> registration(String password, String phone, String email, String username, String org);

    /***
     * 创建管理员
     * 
     * @param password
     * @param phone
     * @param email
     * @param username
     * @param org
     * @return
     */
    public ResponseDTO<?> creatRoot(String password, String phone, String email, String username, String org);
}
