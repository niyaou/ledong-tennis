package com.desay.usersystem.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * 
 * @author uidq1163
 *
 */
@Embeddable
public class AccountTagKey implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 2532322744024689642L;
    private String orgId;
    private String sourceId;
    private String name;
    private String tag;
    private Integer type;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

}