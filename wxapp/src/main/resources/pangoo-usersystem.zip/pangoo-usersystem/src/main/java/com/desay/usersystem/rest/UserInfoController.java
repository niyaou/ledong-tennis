package com.desay.usersystem.rest;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.util.TextUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.usersystem.adapter.bean.Password;
import com.desay.usersystem.adapter.bean.UpdateUserInfo;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.service.TokenAuthorizeService;
import com.desay.usersystem.service.UserInfoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 用户基础信息
 * 
 * @author uidq1163
 *
 */
@RestController
@RequestMapping(value = "/userInfo")
@Api(tags = "用户基础信息")
public class UserInfoController {
    public static Logger log = Logger.getLogger(UserInfoController.class);
    @Autowired
    PangooUserDao pangooUserDao;
    @Autowired
    UserInfoService userInfoImp;
    @Autowired
    TokenAuthorizeService authRequest;

    @ApiOperation(value = "获取用户基础信息接口", notes = "获取用户基础信息接口", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "username", value = "用户名,用户email，用户手机号", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/userInfo", method = RequestMethod.GET)
    public ResponseDTO<?> getUser(HttpServletRequest request,
            @RequestParam(value = "username", required = true) String username) {
        if (TextUtils.isBlank(username)) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.PARAMETER_ERROR);
        }
        TokenDTO token = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        PangooUser info = null;
        if (null != token) {
            info = pangooUserDao.findByUserNameAndOrg(username, token.getOrgId());
        } else {
            info = pangooUserDao.findByUserName(username);
        }
        if (info == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        } else {
            return ResponseDTO.ResponseDTO(info);
        }
    }

    @ApiOperation(value = "通过token获取用户基础信息", notes = "通过token获取用户基础信息", httpMethod = "GET")
    @RequestMapping(value = "/token", method = RequestMethod.GET)
    public ResponseDTO<?> getUser(HttpServletRequest request) {
        TokenDTO token = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        PangooUser info = pangooUserDao.findByUserNameAndOrg(token.getLogin(), token.getOrgId());
        if (info == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        } else {
            info.setToken(token.getToken());
            return ResponseDTO.ResponseDTO(info);
        }
    }

    @ApiOperation(value = "修改用户密码", notes = "修改用户密码", httpMethod = "POST")
    @RequestMapping(value = "/password", method = RequestMethod.POST)
    public Object changePassword(HttpServletRequest request,
            @ApiParam(required = true, name = "password", value = "user用户信息json数据") @RequestBody(required = true) Password password) {
        TokenDTO tokenDTO = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        ResponseDTO<?> responseDTO = userInfoImp.changePassword(tokenDTO.getCid(), password.getNewPassword(),
                password.getOldPassword());
        if (responseDTO == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.ERROR));
        }
        return JsonResponseEntity.instatnce(responseDTO);
    }

    @ApiOperation(value = "修改用户基本信息", notes = "获取用户基础信息接口", httpMethod = "POST")
    @RequestMapping(value = "/userInfo", method = RequestMethod.POST)
    public Object upUserInfo(HttpServletRequest request,
            @ApiParam(required = true, name = "userInfo", value = "user用户信息json数据") @RequestBody(required = true) UpdateUserInfo user) {
        TokenDTO tokenDTO = (TokenDTO) request.getAttribute(ConstantUtils.SESSION_TOKEN);
        PangooUser info = pangooUserDao.findOne(tokenDTO.getCid());
        if (info == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND));
        } else {
            info.setAvatar(user.getAvatar());
            info.setBloodType(user.getBloodType());
            info.setNickName(user.getNickName());
            info.setTelPhone(user.getTelPhone());
            info.setEmail(user.getEmail());
            PangooUser pangooUser = pangooUserDao.exist(user.getTelPhone(), info.getLogin(), user.getEmail(),
                    info.getOrgId());
            if (null != pangooUser) {
                if (!pangooUser.getCid().equals(info.getCid())) {
                    return JsonResponseEntity
                            .instatnce(ResponseDTO.NewErrorResponseDTO("电话号码或者邮箱重复", ResponseCode.USER_NOT_FIND));
                }
            }
            pangooUserDao.saveAndFlush(info);
            return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(ResponseCode.OK));
        }
    }

}
