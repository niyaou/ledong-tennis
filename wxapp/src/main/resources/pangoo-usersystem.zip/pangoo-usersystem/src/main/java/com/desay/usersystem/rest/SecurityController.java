package com.desay.usersystem.rest;

import java.util.Calendar;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.session.ExpiringSession;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.ClusterRsaCheck;
import com.desay.usersystem.adapter.httpentity.JsonResponseEntity;
import com.desay.usersystem.security.RsaKeyManager;
import com.desay.usersystem.service.impl.AuthorizeBase;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 获取公共秘钥
 * 
 * @author uidq1163
 *
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@RestController
@Api(tags = "权限安全管理")
public class SecurityController {
    @Autowired
    private FindByIndexNameSessionRepository findByIndexNameSessionRepository;
    @Autowired
    RsaKeyManager rsaKeyManager;

    @ApiOperation(value = "获取公共秘钥", notes = "获取公共秘钥,用于密码加密", httpMethod = "GET")
    @ApiImplicitParams({})
    @RequestMapping(value = "/getPublicKey", method = RequestMethod.GET)
    public Object getPublicKey(HttpServletResponse response) {
        response.setHeader("date", Calendar.getInstance().getTime().toString());
        String key = Base64.encodeBase64String(RsaKeyManager.getPublicKey());
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(key));
    }

    @ApiOperation(value = "获取用户专属AES秘钥", notes = "获取用户专属AES秘钥,用于密码加密", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "token", value = "客户token", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "key", value = "AES公钥,客户端生成的加密公钥，bye进行64位编码", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/getAESKey", method = RequestMethod.GET)
    public Object getAESKey(@RequestParam(name = "token") String token, @RequestParam(name = "key") String key) {
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        String aesKey = null;
        if (session != null) {
            aesKey = session.getAttribute(AuthorizeBase.AES_KEY);
        }
        byte[] bkey = Base64.decodeBase64(key);
        String codeKey = RSAUtils.RSAEncode(RSAUtils.restorePublicKey(bkey), aesKey);
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(codeKey));
    }

    @ApiOperation(value = "配置用户专属AES秘钥", notes = "配置用户专属AES秘钥,用于密码加密解密，用户首先获取公钥。对本地生成AES秘钥进行加密，并上传到服务器", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "token", value = "客户token", required = true, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "key", value = "AES公钥,客户端生成的加密公钥，bye进行64位编码", required = true, dataType = "String", paramType = "query") })
    @RequestMapping(value = "/uploadAESKey", method = RequestMethod.GET)
    public Object uploadAESKey(@RequestParam(name = "token") String token, @RequestParam(name = "key") String key) {
        if (TextUtils.isEmpty(key)) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AES_EMPTY_ERROR));
        }
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        if (session == null) {
            return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOKEN_ERROR));
        } else {
            key = rsaKeyManager.clusterDecode(key);
            if (!TextUtils.isEmpty(key)) {
                session.setAttribute(AuthorizeBase.AES_KEY, key);
                findByIndexNameSessionRepository.save(session);
                return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(""));
            } else {
                return JsonResponseEntity.instatnce(ResponseDTO.NewErrorResponseDTO(ResponseCode.AES_PWD_ERROR));
            }
        }
    }

    /**
     * 集群秘钥解密
     * 
     * @param content
     * @return
     */
    @ApiIgnore
    @RequestMapping(value = "/clusterRsaDecode", method = RequestMethod.GET)
    public Object clusterRsaDecode(@RequestParam(name = "content") String content) {
        String cotent = RsaKeyManager.decode(content);
        ClusterRsaCheck clusterRsaCheck = new ClusterRsaCheck();
        if (StringUtil.isNotEmpty(cotent)) {
            clusterRsaCheck.setContent(cotent);
            clusterRsaCheck.setFlg(Boolean.TRUE);
        }
        return JsonResponseEntity.instatnce(ResponseDTO.ResponseDTO(clusterRsaCheck));
    }
}
