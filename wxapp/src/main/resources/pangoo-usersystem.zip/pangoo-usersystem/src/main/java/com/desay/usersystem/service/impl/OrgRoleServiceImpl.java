package com.desay.usersystem.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.utils.CollectionUtil;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.RoleBean;
import com.desay.usersystem.adapter.bean.UserRoleBean;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.dao.PermissionDao;
import com.desay.usersystem.dao.PermissionRoleDao;
import com.desay.usersystem.dao.RoleDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.entity.Permission;
import com.desay.usersystem.entity.PermissionRole;
import com.desay.usersystem.entity.Role;
import com.desay.usersystem.entity.UserRole;
import com.desay.usersystem.exception.BizException;
import com.desay.usersystem.service.OrgRoleService;
import com.desay.usersystem.utils.Cst;

/**
 * 组织结构角色权限管理实现
 * 
 * @author uidq1163
 *
 */
@Service
public class OrgRoleServiceImpl implements OrgRoleService {
    Logger log = Logger.getLogger(OrgRoleServiceImpl.class);
    @Autowired
    RoleDao roleDao;
    @Autowired
    PangooUserDao pangooUserDao;
    @Autowired
    UserRoleDao userRoleDao;
    @Autowired
    PermissionRoleDao permissionRoleDao;
    @Autowired
    PermissionDao permissionDao;

    /**
     * 创建角色
     * 
     * @param orgRole
     * @param org
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> creatRole(RoleBean orgRole, TokenDTO tokenDTO) {

        String org = tokenDTO.getOrgId();
        Role exist = roleDao.findOrgRoleByName(org, orgRole.getRoleName());
        if (exist != null) {
            return ResponseDTO.NewErrorResponseDTO("角色已存在", ResponseCode.ERROR);
        }

        Role role = new Role();
        role.setRoleName(orgRole.getRoleName());
        role.setOrgId(org);
        role.setRemark(orgRole.getRemark());
        role.setCreateId(tokenDTO.getLogin());
        roleDao.save(role);

        List<String> permission = orgRole.getPermissionList();
        if (CollectionUtil.isNotEmpty(permission)) {
            PermissionRole permissionRole = null;
            for (String id : permission) {
                Permission permissionold = permissionDao.findOne(id);
                if (null == permissionold) {
                    throw new BizException(ResponseCode.ERROR, "当前权限不存在");
                }
                permissionRole = new PermissionRole();
                permissionRole.setPermissionId(id);
                permissionRole.setRoleId(role.getId());
                permissionRoleDao.save(permissionRole);
            }
        }
        log.info("创建角色:" + role.getRoleName() + " org:" + role.getOrgId());
        return null;
    }

    /**
     * 修改角色
     * 
     * @param orgRole
     * @param tokenDTO
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> updateRole(RoleBean orgRole, TokenDTO tokenDTO) {

        String org = tokenDTO.getOrgId();
        Role role = roleDao.findOne(orgRole.getRoleId());
        // 只能操作自己机构的
        if (!org.equals(role.getOrgId())) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.PERMISSION_ERROR);
        }
        role.setRemark(orgRole.getRemark());
        role.setCreateId(tokenDTO.getLogin());
        roleDao.saveAndFlush(role);
        // 删除角色权限
        permissionRoleDao.delRolePermissionByRoleId(orgRole.getRoleId());
        // 重新添加权限
        List<String> permission = orgRole.getPermissionList();
        if (CollectionUtil.isNotEmpty(permission)) {
            PermissionRole permissionRole = null;
            for (String id : permission) {
                Permission permissionold = permissionDao.findOne(id);
                if (null == permissionold) {
                    throw new BizException(ResponseCode.ERROR, "当前权限不存在");
                }
                permissionRole = new PermissionRole();
                permissionRole.setPermissionId(id);
                permissionRole.setRoleId(role.getId());
                permissionRoleDao.saveAndFlush(permissionRole);
            }
        }
        // 继承这个角色的角色配置权限
        List<Role> listOthers = roleDao.getOrgRoleByParentId(orgRole.getRoleId());
        List<PermissionRole> listPer = permissionRoleDao.getRolePermission(orgRole.getRoleId());
        if (CollectionUtil.isNotEmpty(listOthers)) {
            PermissionRole subPermissionRole = null;
            for (Role role2 : listOthers) {
                // 删除角色权限
                permissionRoleDao.delRolePermissionByRoleId(role2.getId());
                // 复制角色权限
                for (PermissionRole permissionRole : listPer) {
                    // 增加角色权限
                    subPermissionRole = new PermissionRole();
                    subPermissionRole.setPermissionId(permissionRole.getPermissionId());
                    subPermissionRole.setRoleId(role2.getId());
                    permissionRoleDao.save(subPermissionRole);
                }
            }
        }
        log.info("修改角色:" + role.getRoleName() + " org:" + role.getOrgId());
        return null;
    }

    /**
     * 删除角色
     * 
     * @param roleid
     * @param org
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> delRole(String roleid, String org) {
        Role role = roleDao.findOne(roleid);
        if (role == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        }
        // 只能操作自己机构的
        if (!org.equals(role.getOrgId())) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.PERMISSION_ERROR);
        }

        // 开启事物， 删除已分配角色，删除权限，删除角色.
        List<UserRole> list = userRoleDao.findByRoleId(roleid);
        if (CollectionUtil.isNotEmpty(list)) {
            return ResponseDTO.NewErrorResponseDTO("该角色已经被占用不能删除！", ResponseCode.ERROR);
        }
        permissionRoleDao.delRolePermissionByRoleId(role.getId());
        roleDao.delete(role);
        return ResponseDTO.ResponseDTO("");
    }

    /**
     * 设置用户角色，只有本机构的人才可以设置自己机构
     *
     * @param orgRole
     * @param org
     *            操作者认证的机构id
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ResponseDTO<?> setUserRole(UserRoleBean orgRole, Object org) {
        PangooUser user = pangooUserDao.findOne(orgRole.getUserCid());
        if (user == null) {
            return ResponseDTO.NewErrorResponseDTO("用户不存在", ResponseCode.ERROR);
        }
        List<UserRole> list = new ArrayList<>();
        if (CollectionUtil.isEmpty(orgRole.getRoleIds())) {
            return ResponseDTO.NewErrorResponseDTO("角色不能为空", ResponseCode.ERROR);
        }

        List<UserRole> histUserRole = userRoleDao.findByUserCid(user.getCid());
        if (!user.getIsManager()) {
            //普通用户
            for (UserRole userRole : histUserRole) {
                Boolean exist = true;
                for (String roleId : orgRole.getRoleIds()) {
                    //如果这个角色还存在
                    if (roleId.equals(userRole.getRoleId())) {
                        exist = false;
                        break;
                    }
                }
                if (exist) {
                    // 删除用户角色
                    userRoleDao.delete(userRole);
                }
            }
        } else {
            // 如果是其他企业管理员
            if (user.getIsManager() && !user.getOrgId().equals(Cst.NORMAL_ORG)) {
                // 删除企业管理员角色
                // 及继承了当前管理员权限的用户权限
                // 删除已经存在的用户角色信息
                for (UserRole userRole : histUserRole) {
                    Role role = roleDao.findOne(userRole.getRoleId());
                    Boolean exist = true;
                    for (String roleId : orgRole.getRoleIds()) {
                        //如果这个角色还存在
                        if (roleId.equals(role.getParentId())) {
                            exist = false;
                            break;
                        }
                    }
                    if (exist) {
                        // 删除角色对应的权限
                        permissionRoleDao.delRolePermissionByRoleId(role.getId());
                        // 删除用户角色对应的权限
                        userRoleDao.deleteByRoleId(role.getId());
                        //删除角色
                        roleDao.delete(role);
                    }
                }
            }
        }

        UserRole tmp = null;
        for (String roleId : orgRole.getRoleIds()) {
            Role t = roleDao.findOne(roleId);
            if (t == null) {
                return ResponseDTO.NewErrorResponseDTO("角色不存在", ResponseCode.ERROR);
            }
            tmp = new UserRole();
            tmp.setUserCid(orgRole.getUserCid());
            // 如果用户是其他企业管理员
            if (user.getIsManager() && !user.getOrgId().equals(Cst.NORMAL_ORG)) {
                // 企业是否继承了这个角色
                Role parentRole = roleDao.findOrgRole(user.getOrgId(), t.getId());
                if (null == parentRole) {
                    // 复制角色
                    Role subRole = new Role();
                    BeanUtils.copyProperties(t, subRole);
                    subRole.setParentId(t.getId());
                    subRole.setOrgId(user.getOrgId());
                    subRole.setId(null);
                    roleDao.save(subRole);
                    // 复制角色权限
                    List<PermissionRole> listPer = permissionRoleDao.getRolePermission(t.getId());
                    for (PermissionRole permissionRole : listPer) {
                        // 增加角色权限
                        PermissionRole subPermissionRole = permissionRoleDao.findOne(subRole.getId(),
                                permissionRole.getPermissionId());
                        if (null == subPermissionRole) {
                            subPermissionRole = new PermissionRole();
                            subPermissionRole.setPermissionId(permissionRole.getPermissionId());
                            subPermissionRole.setRoleId(subRole.getId());
                            permissionRoleDao.save(subPermissionRole);
                        }
                    }
                    tmp.setRoleId(subRole.getId());
                } else {
                    tmp.setRoleId(parentRole.getId());
                    // 更新角色权限
                    List<PermissionRole> listPer = permissionRoleDao.getRolePermission(t.getId());
                    for (PermissionRole permissionRole : listPer) {
                        PermissionRole subPermissionRole = permissionRoleDao.findOne(parentRole.getId(),
                                permissionRole.getPermissionId());
                        if (null == subPermissionRole) {
                            // 增加角色权限
                            subPermissionRole = new PermissionRole();
                            subPermissionRole.setPermissionId(permissionRole.getPermissionId());
                            subPermissionRole.setRoleId(parentRole.getId());
                            permissionRoleDao.save(subPermissionRole);
                        }
                    }
                }
            } else {
                if (org == null || !Cst.checkOrg(org, t.getOrgId())) {
                    return ResponseDTO.NewErrorResponseDTO("不能操控非本机构", ResponseCode.PERMISSION_ERROR);
                }
                UserRole userRole = userRoleDao.findByUserCidAndRoleId(user.getCid(), roleId);
                if (null != userRole) {
                    continue;
                }
                tmp.setRoleId(roleId);
            }
            list.add(tmp);
        }
        // 保存新的用户角色信息
        userRoleDao.save(list);
        return ResponseDTO.ResponseDTO("");
    }

    /**
     * 增加角色权限
     * 
     * @param permission
     * @param org
     * @return
     */
    @Override
    public ResponseDTO<?> addRolePermission(PermissionRole permission, Object org) {
        Role role = roleDao.findOne(permission.getRoleId());
        if (role == null) {
            return ResponseDTO.NewErrorResponseDTO("没有该角色", ResponseCode.ERROR);
        }
        Permission permission1 = permissionDao.findOne(permission.getPermissionId());

        if (permission1 == null) {
            return ResponseDTO.NewErrorResponseDTO("没有该权限", ResponseCode.ERROR);
        }
        // 权限必须是自己所在机构或者通用权限，角色必须是自己所在机构特有角色
        if (Cst.checkOrg(org, permission1.getOrgId()) && org.equals(role.getOrgId())) {
            PermissionRole exit = permissionRoleDao.findOne(permission.getRoleId(), permission.getPermissionId());
            if (exit != null) {
                return ResponseDTO.NewErrorResponseDTO("权限已存在", ResponseCode.ERROR);
            }
            permissionRoleDao.save(permission);
        } else {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.PERMISSION_ERROR);
        }
        log.info("设置角色权限:" + role.getRoleName() + " org:" + role.getOrgId() + " permission:" + permission1.getName()
                + " id:" + permission1.getPermissionId());
        return ResponseDTO.ResponseDTO("");
    }

    /**
     * 删除角色权限
     * 
     * @param permission
     * @param org
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> delRolePermission(PermissionRole permission, Object org) {
        Role role = roleDao.findOne(permission.getRoleId());
        if (role == null) {
            return ResponseDTO.NewErrorResponseDTO("没有该角色", ResponseCode.ERROR);
        }
        Permission permission1 = permissionDao.findOne(permission.getPermissionId());

        if (permission1 == null) {
            return ResponseDTO.NewErrorResponseDTO("没有该权限", ResponseCode.ERROR);
        }
        // 权限必须是自己所在机构或者通用权限，角色必须是自己所在机构特有角色
        if (Cst.checkOrg(org, permission1.getOrgId()) && org.equals(role.getOrgId())) {
            PermissionRole exit = permissionRoleDao.findOne(permission.getRoleId(), permission.getPermissionId());
            if (exit == null) {
                return ResponseDTO.NewErrorResponseDTO("权限不存在", ResponseCode.ERROR);
            }
            permissionRoleDao.delete(exit);
        } else {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.PERMISSION_ERROR);
        }
        log.info("设置角色权限:" + role.getRoleName() + " org:" + role.getOrgId() + " permission:" + permission1.getName()
                + " id:" + permission1.getPermissionId());
        return ResponseDTO.ResponseDTO("");
    }

    /**
     * 查询用户角色信息
     * 
     * @param cid
     * @param org
     * @return
     */
    @Override
    public ResponseDTO<?> getUserRole(String cid, Object org) {
        PangooUser user = pangooUserDao.findOne(cid);
        List<UserRole> usrRoles = userRoleDao.findByUserCid(user.getCid());
        if (CollectionUtil.isEmpty(usrRoles)) {
            return ResponseDTO.ResponseDTO("");
        }
        List<Role> roles = new ArrayList<>();
        for (UserRole userRole : usrRoles) {
            Role role = roleDao.findOne(userRole.getRoleId());
            // 如果设置用户和登录用户属于同一个企业
            if (user.getOrgId().equals(org)) {
                roles.add(role);
            } else {
                // 管理员为下级管理员分配角色
                if (user.getIsManager() && !user.getOrgId().equals(org)) {
                    // 如果是企业管理员
                    // 角色是通过只能通过继承父级企业的角色来设置的
                    if (StringUtil.isNotEmpty(role.getParentId())) {
                        roles.add(roleDao.findOne(role.getParentId()));
                    }
                } else {
                    roles.add(role);
                }
            }
        }
        return ResponseDTO.ResponseDTO(roles);
    }

}
