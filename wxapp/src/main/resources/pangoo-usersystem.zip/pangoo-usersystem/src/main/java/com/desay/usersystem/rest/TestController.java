package com.desay.usersystem.rest;

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.codec.binary.Base64;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.common.auth.RSAUtils;
import com.desay.cd.utils.DateUtil;
import com.desay.usersystem.security.RsaKeyManager;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 测试
 * 
 * @author uidq1163
 *
 */
@RestController
@Api(value = "内部测试专用", tags = "内部测试专用")
public class TestController {

    /**
     * 获取服务器公钥
     * 
     * @return
     */
    @RequestMapping(value = "/getPassWordRSA", method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "password", value = "用户密码", required = true, dataType = "string", paramType = "query") })
    @ApiOperation(value = "密码进行RSA加密", notes = "")
    public ResponseDTO<?> getServerPublicKey(@ApiIgnore HttpServletRequest request,
            @RequestParam(value = "password", required = true) String password) {
        String key = Base64.encodeBase64String(RsaKeyManager.getPublicKey());
        String encodepwd = null;
        try {
            String decodepwd = DateUtil.getDate(new Date(), "yyyyMMddHHmmss") + password;
            encodepwd = RSAUtils.RSAEncode(string2PublicKey(key), decodepwd);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseDTO.ResponseDTO(encodepwd);
    }

    /**
     * 将Base64编码后的公钥转换成PublicKey对象
     * 
     * @param pubStr
     * @return
     * @throws Exception
     */
    public PublicKey string2PublicKey(String pubStr) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(pubStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }
}
