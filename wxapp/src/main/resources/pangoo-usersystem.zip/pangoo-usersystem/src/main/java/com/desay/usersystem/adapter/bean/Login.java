package com.desay.usersystem.adapter.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 登录数据结构
 * @author uidq1163
 *
 */
@ApiModel(value="登录数据结构",description="登录数据结构")
public class Login {
    @ApiModelProperty(value="用户名",name="userName",example="xingguo",required=true)
    String userName;
    @ApiModelProperty(value="终端ID",name="clientId",example="W0201806130001",required=true)
    String clientId;
    @ApiModelProperty(value="本地系统时间+明文密码后用接口getPublicKey所得公钥，本地时间不能与服务器时间相差2分钟以上",name="password",example="123456",required=true)
    String password;
    @ApiModelProperty(value="验证码,三次密码错误后，需要填写验证码进行登录",name="verifyCode",example="W0201806130001",required=false)
    String verifyCode;
    @ApiModelProperty(value="组织机构ID，普通用户填空",name="org",example="benz",required=false)
    String org;

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }



    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
