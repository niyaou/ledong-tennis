package com.desay.usersystem.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.session.ExpiringSession;
import org.springframework.session.MapSession;
import org.springframework.session.Session;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.PersonDTO;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.dao.OrganizationDao;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.entity.ClientInfo;
import com.desay.usersystem.entity.Organization;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.entity.UserRoleView;
import com.desay.usersystem.security.SecurityChecker;
import com.desay.usersystem.service.LdapAuthorizeService;
import com.desay.usersystem.service.PwdAuthorizeService;
import com.desay.usersystem.utils.Cst;
import com.desay.usersystem.utils.HttpUtil;

/**
 * 密码认证实现类
 * 
 * @author uidq1163
 *
 */
@Service
public class PwdAuthorizeServiceImpl extends AuthorizeBase implements PwdAuthorizeService {

    /** 组织机构认证 */
    @Autowired
    private OrganizationDao organizationDao;
    @Autowired
    private LdapAuthorizeService ldapImp;
    @Autowired
    private PangooUserDao pangooUserDao;
    @Value("${http.proxy}")
    private String proxy;
    @Value("${http.proxy.host}")
    private String host;
    @Value("${http.proxy.port}")
    private Integer port;

    /**
     * 登出删除session
     * 
     * @param token
     * @return
     */
    @Override
    public boolean logout(String token) {
        ExpiringSession session = (ExpiringSession) findByIndexNameSessionRepository.getSession(token);
        if (session == null) {
            return false;
        } else {
            findByIndexNameSessionRepository.delete(token);
            return true;
        }
    }

    /**
     * 删除认证信息
     * 
     * @param token
     * @return
     */
    @Override
    public boolean logoutNetty(String token) {
        ExpiringSession expiringSession = redisTemplate.opsForValue().get(token);
        if (null == expiringSession) {
            return false;
        } else {
            Session s = redisTemplate.opsForValue().get(token);
            redisTemplate.delete(token);
            TokenDTO tokenDTO = s.getAttribute(ConstantUtils.SESSION_TOKEN);
            if (tokenDTO != null) {
                redisTemplateNetty.delete(tokenDTO.cid + tokenDTO.client);
            }
            return true;
        }
    }

    /**
     * 用户登录验证
     * 
     * @param name
     * @param pwd
     * @param clientId
     * @param session
     * @return
     */
    @Override
    public ResponseDTO<?> login(String name, String pwd, String clientId, String org, String verifyCode,
            HttpSession session) {
        // 应用ID
        ClientInfo clint = secretDao.findOne(clientId);
        if (null == clint) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_CLINT_ERROR);
        }
        // 验证密码有效性效验
        SecurityChecker checker = checkerEffectiveness(pwd, clientId);
        if (!checker.isSafty()) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TIME_ERROR);
        }
        System.err.println("proxy" + Boolean.valueOf(proxy) + host + port);
        PangooUser info = null;
        boolean authResult = false;
        if (TextUtils.isEmpty(org)) {
            info = pangooUserDao.findByUserName(name);
            authResult = checker.checkPass(info.getPassword());
        } else {
            Organization organization = organizationDao.findOne(org);
            if (null == organization) {
                return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_ORG_ERROR);
            }
            info = pangooUserDao.findByUserNameAndOrg(name, org);
            if (!org.equals(Cst.NORMAL_ORG) && organization.getAuth()) {
                // 三方认证
                info = pangooUserDao.findByUserNameAndOrg(name, org);
                if (info == null) {
                    return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
                }
                authResult = orgAuth(organization, name, checker.getPass());
            } else {
                // 系统平台认证
                if (info == null) {
                    return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_LOGIN_OR_PWD_ERROR);
                }
                // 密码验证
                authResult = checker.checkPass(info.getPassword());
            }
        }

        // 检查登录是否已超过次数
        if (!checkLogCount(info, verifyCode)) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOO_MANY);
        }
        upLogCountStatus(info, authResult);
        if (authResult) {
            invalidMultiLogin(info.getCid(), clientId);
            createSession(session, clint, info);
            return ResponseDTO.ResponseDTO(info);
        } else {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_LOGIN_OR_PWD_ERROR);
        }
    }

    /**
     * 企业自主鉴权
     * 
     * @param organization
     * @param username
     * @param pwd
     * @return
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    private boolean orgAuth(Organization organization, String username, String pwd) {
        // 企业自主鉴权
        Map params = null;
        if (StringUtil.isNotEmpty(organization.getAuthParams())) {
            params = JSON.parseObject(organization.getAuthParams(), Map.class);
        }
        if (null == params) {
            params = new HashMap();
        }
        params.put("username", username);
        params.put("password", pwd);
        String response = "";
        if (organization.getAuthType().toUpperCase().equals("POST")) {
            response = HttpUtil.sendPost(organization.getAuthUrl(), params, Boolean.valueOf(proxy), host, port);
        } else if (organization.getAuthType().toUpperCase().equals("GET")) {
            response = HttpUtil.get(organization.getAuthUrl(), params, Boolean.valueOf(proxy), host, port);
        }
        return StringUtil.isNotEmpty(response);
    }

    /**
     * 用户登录验证:针对集群并发
     * 
     * @param name
     * @param pwd
     * @param clientId
     * @param org
     * @param verifyCode
     * @param session
     * @return
     */
    @Override
    public ResponseDTO<?> login(String name, String pwd, String clientId, String org, String verifyCode) {

        PangooUser info = null;
        if (TextUtils.isEmpty(org)) {
            info = pangooUserDao.findByUserName(name);
        } else {
            Organization organization = organizationDao.findOne(org);
            if (null == organization) {
                return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_ORG_ERROR);
            }
            info = pangooUserDao.findByUserNameAndOrg(name, org);
        }
        if (info == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_LOGIN_OR_PWD_ERROR);
        }

        // 检查登录是否已超过次数
        if (!checkLogCount(info, verifyCode)) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOO_MANY);
        }
        // 验证密码有效性效验
        SecurityChecker checker = checkerEffectiveness(pwd);
        if (!checker.isSafty()) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TIME_ERROR);
        }
        // 应用ID
        ClientInfo clint = secretDao.findOne(clientId);
        if (null == clint) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_CLINT_ERROR);
        }

        boolean authResult = checker.checkPass(info.getPassword());
        upLogCountStatus(info, authResult);
        if (authResult) {
            try {
                invalidMultiLoginNetty(info.getCid(), clientId);
                ExpiringSession session = new MapSession();
                createSession(session, clientId, info);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ResponseDTO.ResponseDTO(info);
        } else {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_LOGIN_OR_PWD_ERROR);
        }
    }

    /**
     * 处理重复登录，无效化操作
     *
     * @param cid
     * @param client
     */
    private void invalidMultiLoginNetty(String cid, String client) {
        String tokenId = redisTemplateNetty.opsForValue().get(cid + client);
        if (StringUtil.isNotEmpty(tokenId)) {
            redisTemplate.delete(tokenId);
            redisTemplateNetty.delete(cid + client);
        }
    }

    @Override
    public ResponseDTO<?> loginToLdap(String name, String pwd, String clientId, String org, String verifyCode,
            HttpSession session) {

        UserRoleView info = new UserRoleView();
        info.setTelPhone("");
        info.setLogin(name);
        // 获取LDAP用户
        PangooUser pangooUser = null;
        if (StringUtil.isNotEmpty(org)) {
            pangooUser = pangooUserDao.findByUserNameAndOrg(name, org);
        } else {
            pangooUser = pangooUserDao.findByUserNameOther(name);
        }
        if (null == pangooUser) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        }
        info.setCid(pangooUser.getCid());
        info.setUserStatus(pangooUser.getUserStatus());
        info.setStatus(pangooUser.getStatus());
        info.setOrgId(pangooUser.getOrgId());

        // 检查登录是否已超过次数
        if (!checkLogCount(pangooUser.getCid())) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TOO_MANY);
        }
        // 验证密码
        boolean authResult = false;
        SecurityChecker checker = checkerEffectiveness(pwd, clientId);
        if (!checker.isSafty()) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TIME_ERROR);
        }
        authResult = ldapImp.authenricate(name, checker.getPass());
        upLogCountStatus(pangooUser.getCid(), authResult);
        if (authResult) {
            invalidMultiLogin(info.getCid(), clientId);
            ClientInfo clint = secretDao.findOne(clientId);
            PersonDTO personDTO = ldapImp.get(name);
            if (null != personDTO) {
                info.setMemberof(personDTO.getMemberOf().toString());
                info.setPersonDTO(personDTO);
                info.setNickName(personDTO.getName().get(0));
                info.setEmail(personDTO.getMail().get(0));
            } else {
                return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
            }
            createLdapSession(session, clint, info);
            return ResponseDTO.ResponseDTO(info.toUserInfoDTO());
        }
        return null;
    }
}
