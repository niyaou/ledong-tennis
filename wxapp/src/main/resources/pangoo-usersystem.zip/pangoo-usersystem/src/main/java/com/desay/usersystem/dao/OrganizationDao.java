package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.desay.usersystem.entity.Organization;

/**
 * 组织机构
 * 
 * @author uidq1163
 *
 */
public interface OrganizationDao extends JpaRepository<Organization, String>, JpaSpecificationExecutor<Organization> {

    List<Organization> findByOrgId(String orgId);

    /**
     * 查询当前管理所属子系统
     * 
     * @param parentId
     * @param pageable
     * @return
     */
    Page<Organization> findByParentId(String parentId, Pageable pageable);
}
