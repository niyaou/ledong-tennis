package com.desay.usersystem.adapter.bean;

import java.util.Set;

import io.swagger.annotations.ApiModel;

/**
 * 用户所在机构角色,一个用户可能会有多个角色
 * 
 * @author uidq1163
 *
 */
@ApiModel(value = "用户角色", description = "用户角色对象")
public class UserRoleBean {
    String userCid;
    Set<String> roleIds;

    public String getUserCid() {
        return userCid;
    }

    public void setUserCid(String userCid) {
        this.userCid = userCid;
    }

    public Set<String> getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(Set<String> roleIds) {
        this.roleIds = roleIds;
    }

}
