package com.desay.usersystem.utils;

/**
 * 
 * @author uidq1163
 *
 */
public class Cst {
    /** WX_SECRET */
    static public final String WX_SECRET = "c531a6f26a9de627c9906e954734511e";
    /** APPID */
    static public final String WX_APPID = "wx158a37ab03f52b64";
    /** SESSION_PERMISSIOM */
    static public final String SESSION_PERMISSIOM = "session_permissiom";
    /** netty大并发token认证 */
    static public final String TOKEN_AUTHORIZE = "/tokenAuthorize?";
    /** netty大并发获取公钥 */
    static public final String GET_PUBLICKEY = "/getPublicKey";
    /** 配置用户专属AES秘钥 */
    static public final String UPLOAD_AESKEY = "/uploadAESKey?";
    /** 用户认证 */
    static public final String PWDAUTHORIZE = "/pwdAuthorize?";
    /** 用户退出 */
    static public final String LOGOUTBYTOKEN = "/logOutBytoken?";

    static public final String ATTRIBUTE_ORG = "org";
    static public final String HEADER_TOKEN = "accept_token";
    static public final String NORMAL_ORG = "normal";
    static public final String ROOT_ID = "root";
    static public final String AGENT_ID = "agent";
    public static final String AES_KEY = "AES_KEY";
    /** 分钟 :60 */
    public static final Integer MINUTE = 60;
    /** 秒60 */
    public static final Integer SECONDS = 60;
    /** 毫秒:1000 */
    public static final Integer MILLISECOND = 1000;
    /** 整数：5 */
    public static final Integer FIVE = 5;
    /** 登录时间戳验证过期时间整数：2 分钟 */
    public static final Integer TWO = 10;
    /** 超过5分钟 */
    public static final Integer OVER_MINUTE = 5;

    /**
     * 比对机构代码。是否相等，或者目标机构为通用normal返回true
     * 
     * @param src
     *            操作者的机构
     * @param dist
     *            被操作的机构
     * @return
     */
    static public boolean checkOrg(Object src, String dist) {
        if (dist.equalsIgnoreCase(NORMAL_ORG)) {
            return true;
        }
        return src.equals(dist);
    }
}
