package com.desay.usersystem.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.utils.MD5Util;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.adapter.bean.User;
import com.desay.usersystem.adapter.bean.WxUser;
import com.desay.usersystem.dao.OrganizationDao;
import com.desay.usersystem.dao.PangooUserDao;
import com.desay.usersystem.dao.UserRoleDao;
import com.desay.usersystem.dao.WeixinCodeDao;
import com.desay.usersystem.entity.PangooUser;
import com.desay.usersystem.entity.UserRole;
import com.desay.usersystem.entity.WeixinCode;
import com.desay.usersystem.security.SecurityChecker;
import com.desay.usersystem.service.RegistrationService;
import com.desay.usersystem.utils.Cst;

/**
 * 注册实现类
 * 
 * @author uidq1163
 *
 */
@Service
public class RegistrationServiceImpl extends BaseRegisterServiceImpl implements RegistrationService {
    public Logger log = Logger.getLogger(RegistrationServiceImpl.class);

    @Autowired
    private PangooUserDao pangooUserDao;
    @Autowired
    private WeixinCodeDao weixinCodeDao;
    @Autowired
    private OrganizationDao organizationDao;
    @Autowired
    private UserRoleDao userRoleDao;

    @Override
    public ResponseDTO<?> registration(User user) {
        String password = user.getPassword();
        String phone = user.getTelPhone();
        String username = user.getLogin();
        SecurityChecker checker = checkerEffectiveness(password);
        if (!checker.isSafty()) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TIME_ERROR);
        }
        // 解密
        password = checker.getPass();
        ResponseDTO<?> responseDTO = checkPreRegister(password, phone, user.getEmail(), username, null);
        if (responseDTO != null) {
            return responseDTO;
        } else {
            PangooUser newUser = new PangooUser();
            // MD5后存入数据库
            newUser.setPassword(MD5Util.md5(password));
            newUser.setLogin(username);
            newUser.setTelPhone(phone);
            if (StringUtil.isNotEmpty(user.getOrg())) {
                if (null != organizationDao.findOne(user.getOrg())) {
                    newUser.setOrgId(user.getOrg());
                } else {
                    return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_ORG_ERROR);
                }
            } else {
                newUser.setOrgId(Cst.NORMAL_ORG);
            }
            newUser.setStatus(Boolean.TRUE);
            newUser.setIsManager(Boolean.FALSE);
            newUser.setEmail(user.getEmail());
            // 审核通过
            newUser.setUserStatus(Boolean.TRUE);

            if (StringUtil.isNotEmpty(user.getSourceId())) {
                newUser.setSourceId(user.getSourceId());
            } else {
                // 平台用户
                newUser.setSourceId("PLATFORM");
            }
            pangooUserDao.save(newUser);
            //添加用户角色:体验用户
            UserRole userRole = new UserRole();
            userRole.setUserCid(newUser.getCid());
            userRole.setRoleId("8a5982626d19e882016d1a025cf70001");
            userRoleDao.save(userRole);

            return ResponseDTO.ResponseDTO("");
        }
    }

    /**
     * 创建微信普通用户
     *
     * @param user
     * @return
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
    public ResponseDTO<?> wxRegistration(WxUser user) {
        WeixinCode wx = weixinCodeDao.findOne(user.getOpenid());
        if (wx != null) {
            return ResponseDTO.NewErrorResponseDTO("微信已经绑定账户", ResponseCode.USER_EXISTED_ERROR);
        }
        SecurityChecker checker = checkerEffectiveness(user.getPassword());
        if (!checker.isSafty()) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TIME_ERROR);
        }
        // 解密
        user.setPassword(checker.getPass());
        ResponseDTO<?> responseDTO = checkPreRegister(user.getPassword(), user.getTelPhone(), user.getEmail(),
                user.getLogin(), null);
        if (responseDTO != null) {
            // 账户已存在
            if (responseDTO.getCode() == ResponseCode.USER_EXISTED_ERROR.getCode()) {
                return dobindWx(user, checker);
            } else {
                return responseDTO;
            }
        } else {
            // 账户不存在，且密码合法,创建新的账户
            PangooUser newUser = new PangooUser();
            // MD5后存入数据库
            newUser.setPassword(MD5Util.md5(user.getPassword()));
            newUser.setLogin(user.getLogin());
            newUser.setTelPhone(user.getTelPhone());
            newUser.setOrgId(Cst.NORMAL_ORG);
            newUser.setStatus(Boolean.TRUE);
            newUser.setIsManager(Boolean.FALSE);
            WeixinCode weixinCode = new WeixinCode();
            weixinCode.setCid(newUser.getCid());
            weixinCode.setUnionid(user.getUnionid());
            weixinCode.setOpenid(user.getOpenid());

            pangooUserDao.save(newUser);
            weixinCodeDao.save(weixinCode);
            log.info("weixin user registration phone:" + user.getTelPhone() + " userName:" + user.getLogin());
            return ResponseDTO.ResponseDTO("");
        }
    }

    /**
     * 解密密码，并开始绑定
     * 
     * @param user
     * @return
     */
    @Override
    public ResponseDTO<?> bindWx(WxUser user) {
        WeixinCode wx = weixinCodeDao.findOne(user.getOpenid());
        if (wx != null) {
            return ResponseDTO.NewErrorResponseDTO("微信已经绑定", ResponseCode.USER_EXISTED_ERROR);
        }
        SecurityChecker checker = checkerEffectiveness(user.getPassword());
        // 解密
        user.setPassword(checker.getPass());
        return dobindWx(user, checker);
    }

    /**
     * 用戶账户存在，绑定微信
     * 
     * @param user
     * @param checker
     * @return
     */
    private ResponseDTO<?> dobindWx(WxUser user, SecurityChecker checker) {
        if (!checker.isSafty()) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TIME_ERROR);
        }
        PangooUser existUser = pangooUserDao.exist(user.getTelPhone(), user.getLogin());
        if (existUser == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        }
        // 检测密码合法性
        if (!checker.checkPass(existUser.getPassword())) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_PWD_ERROR);
        }

        WeixinCode weixinCode = new WeixinCode();
        weixinCode.setCid(existUser.getCid());
        weixinCode.setUnionid(user.getUnionid());
        weixinCode.setOpenid(user.getOpenid());
        weixinCodeDao.save(weixinCode);
        log.info("weixin user bind phone:" + user.getTelPhone() + " userName:" + user.getLogin());
        return ResponseDTO.ResponseDTO("");
    }

    /**
     * 解绑微信
     * 
     * @param user
     * @return
     */
    @Override
    public ResponseDTO<?> unBindWx(WxUser user) {
        SecurityChecker checker = checkerEffectiveness(user.getPassword());
        // 解密
        user.setPassword(checker.getPass());
        if (!checker.isSafty()) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_TIME_ERROR);
        }
        WeixinCode wx = weixinCodeDao.findOne(user.getOpenid());
        if (wx == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        }
        PangooUser existUser = pangooUserDao.exist(user.getTelPhone(), user.getLogin());
        if (existUser == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        }

        // 检测密码合法性
        if (!checker.checkPass(existUser.getPassword())) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_PWD_ERROR);
        } else {
            weixinCodeDao.delete(wx);
            log.info("unbind weixin phone:" + user.getTelPhone() + " userName:" + user.getLogin());
            return ResponseDTO.ResponseDTO("");
        }
    }
}
