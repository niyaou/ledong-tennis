package com.desay.usersystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.desay.usersystem.entity.Permission;

/**
 * 
 * @author uidq1163
 *
 */
public interface PermissionDao extends JpaRepository<Permission, String>, JpaSpecificationExecutor<Permission> {
    /**
     * 获取机构角色权限列表
     * 
     * @param org
     * @return
     */
    @Query("select t from Permission t where t.orgId = :org or t.orgId='normal' order by t.createTime desc")
    List<Permission> getOrgPermissionList(@Param("org") String org);

    /**
     * 根据主键查询
     * 
     * @param id
     * @return
     */
    @Query("select t from Permission t where t.permissionId = :id")
    Permission findOne(@Param("id") int id);

    /**
     * 查询权限是否重复
     * 
     * @param method
     * @param type
     * @return
     */
    List<Permission> findByMethodAndType(String method, String type);

    /**
     * 查询是否有字节点占用
     * 
     * @param method
     * @param type
     * @return
     */
    List<Permission> findByParentId(String parentId);
}
