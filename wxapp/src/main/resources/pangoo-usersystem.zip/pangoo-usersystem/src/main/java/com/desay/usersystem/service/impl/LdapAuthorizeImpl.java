package com.desay.usersystem.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.lang.SerializationException;
import org.apache.log4j.Logger;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.desay.cd.DTO.PersonDTO;
import com.desay.cd.utils.StringUtil;
import com.desay.usersystem.service.LdapAuthorizeService;

/**
 * 
 * @author 倪旭春
 *
 */
@Service
public class LdapAuthorizeImpl implements LdapAuthorizeService {
    public static Logger log = Logger.getLogger(LdapAuthorizeImpl.class);
    public static String SEARCHBASES = "OU=LDA,DC=v01,DC=net";
    public static String[] SEARCHSEQUENSE = null;
    public static String URL = "";
    public static String FACTORY = "";
    public static String ADMIN = "";
    private static String SEARCHDN = "v01\\";
    private LdapContext ctx = null;
    private Hashtable<String, String> env = null;
    private Control[] connCtls = null;
    @Resource
    private RedisTemplate<String, PersonDTO> redisTemplate;
    /**
     * 加载ldap用户组信息
     */
    static {
        InputStream inputStream = LdapAuthorizeImpl.class.getClassLoader().getResourceAsStream("ldapgroup.properties");
        Properties properties = new Properties();
        try {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        URL = properties.getProperty("URL");
        FACTORY = properties.getProperty("FACTORY");
        ADMIN = properties.getProperty("ADMIN");

        // 惠州1
        String hzh1Ou = properties.getProperty("HZH1_OU");
        String[] hzh1Ous = hzh1Ou.split(",");
        StringBuilder sb = null;
        for (int i = 0; i < hzh1Ous.length; i++) {
            sb = new StringBuilder();
            sb.append("OU=Users");
            sb.append(hzh1Ous[i]);
            sb.append(",OU=Users,OU=HZH1,");
            sb.append(SEARCHBASES);
            hzh1Ous[i] = sb.toString();
        }
        String fra1Ou = properties.getProperty("FRA1_OU");
        fra1Ou = fra1Ou + SEARCHBASES;
        String hij1Ou = properties.getProperty("HIJ1_OU");
        hij1Ou = hij1Ou + SEARCHBASES;
        // 惠州2
        String hzh2Ou = properties.getProperty("HZH2_OU");
        String[] hzh2Ous = hzh2Ou.split(",");
        for (int i = 0; i < hzh2Ous.length; i++) {
            sb = new StringBuilder();
            sb.append("OU=Users");
            sb.append(hzh2Ous[i]);
            sb.append(",OU=Users,OU=HZH2,");
            sb.append(SEARCHBASES);
            hzh2Ous[i] = sb.toString();
        }
        // 新加坡
        String sgp1Ou = properties.getProperty("SGP1_OU");
        String[] sgp1Ous = sgp1Ou.split(",");
        for (int i = 0; i < sgp1Ous.length; i++) {
            sb = new StringBuilder();
            sb.append("OU=Users");
            sb.append(sgp1Ous[i]);
            sb.append(",OU=Users,OU=SGP1,");
            sb.append(SEARCHBASES);
            sgp1Ous[i] = sb.toString();
        }
        // 台北
        String tpe1Ou = properties.getProperty("TPE1_OU");
        tpe1Ou = tpe1Ou + SEARCHBASES;
        // KAWA
        String kawaou = properties.getProperty("KAWA_OU");
        kawaou = kawaou + SEARCHBASES;
        //南京
        String nkg1ou = properties.getProperty("NKG1_OU");
        nkg1ou = nkg1ou + SEARCHBASES;
        String nkg5ou = properties.getProperty("NKG5_OU");
        nkg5ou = nkg5ou + SEARCHBASES;

        String[] others = new String[6];
        others[0] = fra1Ou;
        others[1] = hij1Ou;
        others[2] = tpe1Ou;
        others[3] = nkg1ou;
        others[4] = nkg5ou;
        others[5] = kawaou;
        SEARCHSEQUENSE = unitStringArray(hzh1Ous, hzh2Ous, sgp1Ous, others);
    }

    /**
     * 合并数组
     */
    public static String[] unitStringArray(String[]... bytes) {
        String[] byte1 = null;
        for (String[] byte2 : bytes) {
            if (byte1 == null) {
                byte1 = byte2;
            } else {
                String[] unitByte = new String[byte1.length + byte2.length];
                System.arraycopy(byte1, 0, unitByte, 0, byte1.length);
                System.arraycopy(byte2, 0, unitByte, byte1.length, byte2.length);
                byte1 = unitByte;
            }
        }
        return byte1;
    }

    /**
     * 删除缓存
     * 
     * @param key
     */
    public void delete(String key) {
        redisTemplate.delete(key);
    }

    @Override
    public PersonDTO get(String key) {
        try {
            ValueOperations<String, PersonDTO> vo = redisTemplate.opsForValue();
            PersonDTO p = vo.get(key);
            return p;
        } catch (SerializationException e) {
            e.printStackTrace();
            return null;
        }

    }

    public void set(String key, PersonDTO value) {
        ValueOperations<String, PersonDTO> vo = redisTemplate.opsForValue();
        vo.set(key, value);
    }

    /**
     * 16进制直接转换成为字符串(无需Unicode解码)
     * 
     * @param hexStr
     * @return
     */
    private String hexStr2Str(String hexStr) {
        String str = "0123456789ABCDEF";
        char[] hexs = hexStr.toCharArray();
        byte[] bytes = new byte[hexStr.length() / 2];
        int n;
        for (int i = 0; i < bytes.length; i++) {
            n = str.indexOf(hexs[2 * i]) * 16;
            n += str.indexOf(hexs[2 * i + 1]);
            bytes[i] = (byte) (n & 0xff);
        }
        return new String(bytes);
    }

    private boolean ldapConnect(String name, String password) {
        log.info("用户名：" + name + " 密码：" + password);
        env = new Hashtable<String, String>(16);
        env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY);
        // LDAP server
        env.put(Context.PROVIDER_URL, URL);
        env.put(Context.SECURITY_PRINCIPAL, SEARCHDN + name);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_CREDENTIALS, password);
        // 此处若不指定用户名和密码,则自动转换为匿名登录
        try {
            ctx = new InitialLdapContext(env, connCtls);
        } catch (NamingException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 自动装载ldap用户信息
     * 
     * @return
     */
    public int autoCacheDI(String uid, String passwd) {
        // ldapConnect(hexStr2Str(uid), hexStr2Str(passwd));
        return cachePerson(SEARCHSEQUENSE);
    }

    /**
     * 缓存用户信息
     * 
     * @param searchBases
     * @return
     */
    private int cachePerson(String[] searchBases) {
        int count = 0;
        if (searchBases != null) {
            for (String seachbase : searchBases) {
                count += cachePersonImp(seachbase);
            }
        } else {
            count += cachePersonImp(SEARCHBASES);
        }
        try {
            ctx.close();
        } catch (NamingException e) {
            e.printStackTrace();
        }

        return count;
    }

    private int cachePersonImp(String base) {
        String filters = "(&(objectClass=person)(l=*))";
        String[] returnedAtts = { "name", "distinguishedName", "l", "memberOf", "mail", "mailnickname", "mobile", "cn",
                "extensionattribute2" };
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setCountLimit(6000);
        int count = 0;
        if (returnedAtts != null && returnedAtts.length > 0) {
            constraints.setReturningAttributes(returnedAtts);
        }
        try {
            NamingEnumeration<?> answer = ctx.search(base, filters, constraints);
            String company = "";
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                // 得到符合条件的属性集
                Attributes attrs = sr.getAttributes();
                Map<String, ArrayList<String>> user = new HashMap<String, ArrayList<String>>(16);
                if (attrs != null) {
                    count++;
                    try {
                        for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                            // 得到下一个属性
                            Attribute attr = (Attribute) ne.next();
                            String key = attr.getID().toString();
                            ArrayList<String> params = new ArrayList<String>();
                            for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                                company = e.next().toString();
                                params.add(company);
                            }
                            user.put(key, params);
                        }
                    } catch (NamingException e) {
                        System.err.println("Throw Exception : " + e);
                    }

                    PersonDTO p = JSON.parseObject(JSON.toJSONString(user), PersonDTO.class);
                    if (p == null || p.getMailnickname() == null) {
                        continue;
                    }
                    set(p.getMailnickname().get(0), p);
                }
            }
        } catch (NamingException e1) {
            e1.printStackTrace();
            return 0;
        }
        return count;
    }

    /**
     * 
     * @param type
     *            organizationalUnit:组织架构 group：用户组 user|person：用户
     * @param name
     * @return
     */
    public PersonDTO getADInfo(String filter, String name, String searchBase) {
        // 用户名称
        String userName = name;
        if (userName == null) {
            userName = "";
        }
        String company = "";
        try {
            if (searchBase == null || searchBase.isEmpty()) {
                searchBase = "ou=LDA,DC=v01,DC=net";
            }
            String searchFilter = "(&(objectClass=user)(" + filter + "=*" + userName + "*))";
            SearchControls searchCtls = new SearchControls();
            searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String[] returnedAtts = { "name", "distinguishedName", "l", "memberOf", "mail", "mailnickname", "mobile",
                    "cn" };
            searchCtls.setReturningAttributes(returnedAtts);
            NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
            // 遍历结果集
            while (answer.hasMoreElements()) {
                SearchResult sr = answer.next();
                String dn = sr.getName();
                System.out.println(dn);
                Attributes attrs = sr.getAttributes();
                Map<String, ArrayList<String>> user = new HashMap<String, ArrayList<String>>(16);
                if (attrs != null) {
                    try {
                        for (NamingEnumeration<?> ne = attrs.getAll(); ne.hasMore();) {
                            Attribute attr = (Attribute) ne.next();
                            String key = attr.getID().toString();
                            ArrayList<String> params = new ArrayList<String>();
                            for (NamingEnumeration<?> e = attr.getAll(); e.hasMore();) {
                                company = e.next().toString();
                                params.add(company);
                            }
                            user.put(key, params);
                        }
                    } catch (NamingException e) {
                        System.err.println("Throw Exception : " + e);
                    }
                    return JSON.parseObject(JSON.toJSONString(user), PersonDTO.class);
                }
            }
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取当前用户信息
     * 
     * @return
     */
    @Override
    public Map<String, String> getCurrentUser() {

        Map<String, String> map = new HashMap<String, String>(16);
        try {
            if (ctx != null) {
                NamingEnumeration<NameClassPair> list = ctx.list("dc=v01,dc=net");
                while (list.hasMore()) {
                    NameClassPair ncp = list.next();
                    String cn = ncp.getName();
                    if (cn.indexOf("=") != -1) {
                        int index = cn.indexOf("=");
                        cn = cn.substring(index + 1, cn.length());
                        map.put(cn, ncp.getNameInNamespace());
                    }
                }
            }
        } catch (NamingException e) {
            e.printStackTrace();
            return null;
        }

        try {
            if (ctx != null) {
                ctx.close();
            }
        } catch (NamingException e) {
            e.printStackTrace();
        }
        Iterator<Entry<String, String>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Entry<String, String> entry = it.next();
            System.out.println("Key:" + entry.getKey());
            System.out.println("Value:" + entry.getValue());
        }
        return map;
    }

    /**
     * 用户认证
     * 
     * @param id
     * @param password
     * @return
     */
    @Override
    public boolean authenricate(String id, String password) {
        boolean valide = false;
        if (!ldapConnect(id, password)) {
            return false;
        }
        if (get(id) == null) {
            PersonDTO p = getADInfo("cn", id, null);
            if (p != null) {
                set(p.getMailnickname().get(0), p);
            }
        }
        if (StringUtil.isNotEmpty(ADMIN) && ADMIN.equals(id)) {
            // 异步装载所有用户信息
            CompletableFuture.runAsync(() -> {
                autoCacheDI(id, password);
            });
        }
        valide = true;
        return valide;
    }
}