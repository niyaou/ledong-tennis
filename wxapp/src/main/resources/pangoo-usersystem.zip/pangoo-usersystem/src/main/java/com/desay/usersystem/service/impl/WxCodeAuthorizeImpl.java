package com.desay.usersystem.service.impl;

import javax.servlet.http.HttpSession;

import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.desay.cd.ResponseCode;
import com.desay.cd.DTO.ResponseDTO;
/**
 * 微信认证
 * @author uidq1163
 *
 */
import com.desay.usersystem.adapter.bean.WxAuthBean;
import com.desay.usersystem.dao.SecretDao;
import com.desay.usersystem.dao.UserRoleViewDao;
import com.desay.usersystem.dao.WeixinCodeDao;
import com.desay.usersystem.entity.ClientInfo;
import com.desay.usersystem.entity.UserRoleView;
import com.desay.usersystem.entity.WeixinCode;
import com.desay.usersystem.feign.AuthFactory;
import com.desay.usersystem.service.WxCodeAuthorizeService;
import com.desay.usersystem.utils.Cst;

/**
 * 微信认证实现类
 * 
 * @author uidq1163
 *
 */
@Component
public class WxCodeAuthorizeImpl extends AuthorizeBase implements WxCodeAuthorizeService {
    @Autowired
    AuthFactory authFactory;
    @Autowired
    WeixinCodeDao weixinCodeDao;
    @Autowired
    UserRoleViewDao userRoleViewDao;
    @Autowired
    SecretDao secretDao;

    /**
     * 微信认证
     * 
     * @param code
     * @param session
     * @return
     */
    @Override
    public ResponseDTO<?> codeAuthorize(String code, HttpSession session) {
        WxAuthBean wxAuth = authFactory.getGsonInterFace().auth(Cst.WX_APPID, Cst.WX_SECRET, code);
        if (!TextUtils.isEmpty(wxAuth.getErrcode())) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.AUTH_PWD_ERROR);
        }
        WeixinCode wxCode = weixinCodeDao.findOne(code);
        if (wxCode == null) {
            return ResponseDTO.NewErrorResponseDTO(ResponseCode.USER_NOT_FIND);
        }
        wxCode.setSessionKey(wxAuth.getSession_key());
        weixinCodeDao.save(wxCode);
        UserRoleView user = userRoleViewDao.findOne(wxCode.getCid());
        if (user == null) {
            return ResponseDTO.NewErrorResponseDTO("没有匹配的账户", ResponseCode.ERROR);
        }
        ClientInfo clientInfo = secretDao.findOne("Wx0201806130001");
        // createSession(session, clientInfo, user);
        invalidMultiLogin(user.getCid(), clientInfo.getClientId());
        return ResponseDTO.ResponseDTO(user.toUserInfoDTO());
    }

}
